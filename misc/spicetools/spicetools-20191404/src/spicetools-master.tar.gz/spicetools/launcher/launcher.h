#ifndef SPICETOOLS_LAUNCHER_H
#define SPICETOOLS_LAUNCHER_H

#include <string>
#include <windows.h>

namespace rawinput {
    class RawInputManager;
}

extern char MODULE_PATH[256];
extern std::string MODULE_PATH_STR;
extern HANDLE LOG_FILE;
extern rawinput::RawInputManager* RI_MGR;
extern int LAUNCHER_ARGC;
extern char** LAUNCHER_ARGV;

#endif //SPICETOOLS_LAUNCHER_H
