#ifndef SPICETOOLS_LAUNCHER_SIGNAL_H
#define SPICETOOLS_LAUNCHER_SIGNAL_H

namespace launcher::signal {

    // settings
    extern bool DISABLE;

    void init();
}

#endif //SPICETOOLS_LAUNCHER_SIGNAL_H
