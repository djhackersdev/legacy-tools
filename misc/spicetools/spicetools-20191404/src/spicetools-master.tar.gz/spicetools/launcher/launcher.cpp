#include <iostream>
#include <vector>
#include <queue>
#include <winsock2.h>
#include <shlwapi.h>
#include "api/controller.h"
#include "launcher/launcher.h"
#include "launcher/signal.h"
#include "external/cardio/cardio_runner.h"
#include "external/scard/scard.h"
#include "stubs/stubs.h"
#include "rawinput/rawinput.h"
#include "cfg/spicecfg.h"
#include "util/utils.h"
#include "util/logging.h"
#include "util/peb.h"
#include "util/libutils.h"
#include "util/fileutils.h"
#include "util/crypt.h"
#include "acio/acio.h"
#include "acio/icca/icca.h"
#include "misc/device.h"
#include "misc/extdev.h"
#include "misc/sciunit.h"
#include "misc/bt5api.h"
#include "easrv/easrv.h"
#include "reader/reader.h"
#include "build/defs.h"
#include "misc/sde.h"
#include "misc/eamuse.h"
#include "hooks/acphook.h"
#include "hooks/networkhook.h"
#include "hooks/debughook.h"
#include "hooks/devicehook.h"
#include "hooks/dxhook.h"
#include "hooks/dinputhook.h"
#include "touch/touch.h"
#include "games/game.h"
#include "games/popn/popn.h"
#include "games/bbc/bbc.h"
#include "games/ddr/ddr.h"
#include "games/iidx/iidx.h"
#include "games/sdvx/sdvx.h"
#include "games/sdvx/printer.h"
#include "games/jb/jb.h"
#include "games/nost/nost.h"
#include "games/gitadora/gitadora.h"
#include "games/mga/mga.h"
#include "games/sc/sc.h"
#include "games/rb/rb.h"
#include "games/qma/qma.h"
#include "avs/core.h"
#include "avs/ea3.h"
#include "avs/game.h"


// general settings
static std::vector<std::string> game_hooks;
static std::string STUBS[] = {"kbt.dll", "kld.dll"};
char MODULE_PATH[256];
std::string MODULE_PATH_STR;
HANDLE LOG_FILE = nullptr;
api::Controller* API_CONTROLLER = nullptr;
rawinput::RawInputManager* RI_MGR = nullptr;
int LAUNCHER_ARGC = 0;
char** LAUNCHER_ARGV = nullptr;

int main(int argc, char *argv[]) {

    // remember argv, argv
    LAUNCHER_ARGC = argc;
    LAUNCHER_ARGV = argv;

    // register signals
    launcher::signal::init();

    // get module path
    GetModuleFileName(NULL, MODULE_PATH, 256);
    PathRemoveFileSpec(MODULE_PATH);
    MODULE_PATH_STR = std::string(MODULE_PATH) + "\\";

    // initialize crypt
    crypt::init();

    // api settings
    bool api_enable = false;
    bool api_pretty = false;
    bool api_debug = false;
    unsigned short api_port = 1337;
    std::string api_pass = "";

    // attach settings
    bool attach_io = false;
    bool attach_acio = false;
    bool attach_icca = false;
    bool attach_device = false;
    bool attach_extdev = false;
    bool attach_sciunit = false;
    bool attach_iidx = false;
    bool attach_sdvx = false;
    bool attach_sdvx_printer = false;
    bool attach_jb = false;
    bool attach_rb = false;
    bool attach_mga = false;
    bool attach_sc = false;
    bool attach_popn = false;
    bool attach_ddr = false;
    bool attach_gitadora = false;
    bool attach_nostalgia = false;
    bool attach_bbc = false;
    bool attach_qma = false;

    // misc settings
    unsigned short easrv_port = 0;
    bool easrv_maint = true;
    bool load_stubs = false;
    bool netfix_disable = false;
    bool acphook_disable = false;
    bool realtime = false;
    bool cardio_enabled = false;
    bool peb_print = false;
    bool cfg_run = false;
    std::vector<std::string> sextet_devices;

    // parse arguments
    for (int i = 1; i < argc; i++) {
        if (strlen(argv[i]) > 1) {
            if (stricmp(argv[i], "-cfg") == 0 || stricmp(argv[i], "-config") == 0)
                cfg_run = true;
            else if (stricmp(argv[i], "-ea") == 0) {
                avs::ea3::URL_SLASH = 1;
                easrv_port = 8080;
            }
            else if (stricmp(argv[i], "-eamaint") == 0) {
                if (++i >= argc)
                    log_fatal("launcher", "-eamaint [0/1] parameter missing");
                easrv_maint = abs(strtol(argv[i], (char **) nullptr, 10)) > 0;
            }
            else if (stricmp(argv[i], "-w") == 0)
                DXHOOK_WINDOWED = true;
            else if (stricmp(argv[i], "-c") == 0)
                DXHOOK_CAPTURE = true;
            else if (stricmp(argv[i], "-s") == 0)
                DXHOOK_SHOW_CURSOR = true;
            else if (stricmp(argv[i], "-k") == 0) {
                if (i + 1 < argc)
                    game_hooks.emplace_back(std::string(argv[++i]));
                else
                    log_fatal("launcher", "No hook specified.");
            } else if (stricmp(argv[i], "-stubs") == 0)
                load_stubs = true;
            else if (stricmp(argv[i], "-io") == 0)
                attach_io = true;
            else if (stricmp(argv[i], "-acio") == 0)
                attach_acio = true;
            else if (stricmp(argv[i], "-icca") == 0)
                attach_icca = true;
            else if (stricmp(argv[i], "-device") == 0)
                attach_device = true;
            else if (stricmp(argv[i], "-extdev") == 0)
                attach_extdev = true;
            else if (stricmp(argv[i], "-sciunit") == 0)
                attach_sciunit = true;
            else if (stricmp(argv[i], "-sdvx") == 0)
                attach_sdvx = true;
            else if (stricmp(argv[i], "-iidx") == 0)
                attach_iidx = true;
            else if (stricmp(argv[i], "-iidxflipcams") == 0)
                games::iidx::FLIPCAMS = true;
            else if (stricmp(argv[i], "-jb") == 0)
                attach_jb = true;
            else if (stricmp(argv[i], "-rb") == 0)
                attach_rb = true;
            else if (stricmp(argv[i], "-pnm") == 0)
                attach_popn = true;
            else if (stricmp(argv[i], "-mga") == 0)
                attach_mga = true;
            else if (stricmp(argv[i], "-gd") == 0)
                attach_gitadora = true;
            else if (stricmp(argv[i], "-nostalgia") == 0)
                attach_nostalgia = true;
            else if (stricmp(argv[i], "-bbc") == 0)
                attach_bbc = true;
            else if (stricmp(argv[i], "-qma") == 0)
                attach_qma = true;
            else if (stricmp(argv[i], "-2ch") == 0)
                games::gitadora::TWOCHANNEL = true;
            else if (stricmp(argv[i], "-ddr") == 0)
                attach_ddr = true;
            else if (stricmp(argv[i], "-o") == 0 ||
                     stricmp(argv[i], "-ddrsd") == 0)
                games::ddr::SDMODE = true;
            else if (stricmp(argv[i], "-sc") == 0)
                attach_sc = true;
            else if (stricmp(argv[i], "-netfixdisable") == 0)
                netfix_disable = true;
            else if (stricmp(argv[i], "-acphookdisable") == 0)
                acphook_disable = true;
            else if (stricmp(argv[i], "-signaldisable") == 0)
                launcher::signal::DISABLE = true;
            else if (stricmp(argv[i], "-createfiledebug") == 0)
                DEVICE_CREATEFILE_DEBUG = true;
            else if (stricmp(argv[i], "-pebprint") == 0)
                peb_print = true;
            else if (stricmp(argv[i], "-bt5api") == 0)
                BT5API_ENABLED = true;
            else if (stricmp(argv[i], "-cardio") == 0)
                cardio_enabled = true;
            else if (stricmp(argv[i], "-printer") == 0)
                attach_sdvx_printer = true;
            else if (stricmp(argv[i], "-printerpath") == 0) {
                if (++i >= argc)
                    log_fatal("launcher", "-printerpath parameter missing");
                games::sdvx::PRINTER_PATH.emplace_back(argv[i]);
            } else if (stricmp(argv[i], "-printerformat") == 0) {
                if (++i >= argc)
                    log_fatal("launcher", "-printerformat parameter missing");
                games::sdvx::PRINTER_FORMAT.emplace_back(argv[i]);
            }
            else if (stricmp(argv[i], "-printerjpgquality") == 0) {
                if (++i >= argc)
                    log_fatal("launcher", "-printerjpgquality parameter missing");
                games::sdvx::PRINTER_JPG_QUALITY = abs(strtol(argv[i], (char **) nullptr, 10));
            } else if (stricmp(argv[i], "-printerclear") == 0)
                games::sdvx::PRINTER_CLEAR = true;
            else if (stricmp(argv[i], "-urlslash") == 0) {
                if (++i >= argc)
                    log_fatal("launcher", "-urlslash [0/1] parameter missing");
                avs::ea3::URL_SLASH = abs(strtol(argv[i], (char **) nullptr, 10));
                if (avs::ea3::URL_SLASH < 0 || avs::ea3::URL_SLASH > 1)
                    log_fatal("launcher", "-urlslash invalid parameter");
            }
            else if (stricmp(argv[i], "-disablenumpad") == 0)
                acio::ICCA_NUMPAD_ENABLE = false;
            else if (stricmp(argv[i], "-disabletoprow") == 0)
                acio::ICCA_TOPROW_ENABLE = false;
            else if (stricmp(argv[i], "-realtime") == 0)
                realtime = true;
            else if (stricmp(argv[i], "-sleep") == 0)
                Sleep(5000);
            else if (stricmp(argv[i], "-h") == 0) {
                if (++i >= argc)
                    log_fatal("launcher", "-h (HEAP SIZE parameter missing)");
                avs::core::HEAP_SIZE = (size_t) abs(strtol(argv[i], (char **) nullptr, 10));
            } else if (stricmp(argv[i], "-a") == 0) {
                if (++i >= argc)
                    log_fatal("launcher", "-a (APP CONFIG parameter missing)");
                avs::ea3::CFG_PATH = std::string(argv[i]);
            } else if (stricmp(argv[i], "-v") == 0) {
                if (++i >= argc)
                    log_fatal("launcher", "-v (AVS CONFIG parameter missing)");
                avs::core::CFG_PATH = std::string(argv[i]);
            } else if (stricmp(argv[i], "-e") == 0) {
                if (++i >= argc)
                    log_fatal("launcher", "-e (EA3 CONFIG parameter missing)");
                avs::ea3::CFG_PATH = std::string(argv[i]);
            } else if (stricmp(argv[i], "-y") == 0) {
                if (++i >= argc)
                    log_fatal("launcher", "-y (LOG FILE parameter missing)");
                avs::core::LOG_PATH = std::string(argv[i]);
            } else if (stricmp(argv[i], "-p") == 0) {
                if (++i >= argc)
                    log_fatal("launcher", "-p (PCBID parameter missing)");
                avs::ea3::PCBID_CUSTOM = argv[i];
            } else if (stricmp(argv[i], "-r") == 0) {
                if (++i >= argc)
                    log_fatal("launcher", "-r (SOFTID parameter missing)");
                avs::ea3::SOFTID_CUSTOM = argv[i];
            } else if (stricmp(argv[i], "-url") == 0) {
                if (++i >= argc)
                    log_fatal("launcher", "-url (SERVICE URL parameter missing)");
                avs::ea3::URL_CUSTOM = argv[i];
            } else if (stricmp(argv[i], "-modules") == 0) {
                if (++i >= argc)
                    log_fatal("launcher", "-modules (MODULES PATH parameter missing)");
                strcpy(MODULE_PATH, argv[i]);
                SetDllDirectoryA(MODULE_PATH);
                MODULE_PATH_STR = std::string(MODULE_PATH) + "\\";
            } else if (stricmp(argv[i], "-reader") == 0) {
                static int reader_id = 0;
                if (++i >= argc)
                    log_fatal("launcher", "-reader (READER COM parameter missing)");
                if (reader_id < 2)
                    start_reader_thread(std::string(argv[i]), reader_id++);
                else
                    log_fatal("launcher", "too many readers specified (maximum is 2)");
            } else if (stricmp(argv[i], "-sextet") == 0) {
                if (++i >= argc)
                    log_fatal("launcher", "-sextet (COM parameter missing)");
                sextet_devices.emplace_back(argv[i]);
            }
            else if (stricmp(argv[i], "-scard") == 0) {
                WINSCARD_CONFIG.cardinfo_callback = eamuse_scard_callback;
                scard_threadstart();
            }
            else if (stricmp(argv[i], "-scardflip") == 0) {
                WINSCARD_CONFIG.flip_order = true;
            }
            else if (stricmp(argv[i], "-scardtoggle") == 0) {
                WINSCARD_CONFIG.toggle_order = true;
            }
            else if (stricmp(argv[i], "-cardioflip") == 0) {
                CARDIO_RUNNER_FLIP = true;
            }
            else if (stricmp(argv[i], "-togglereader") == 0) {
                if (++i >= argc)
                    log_fatal("launcher", "-togglereader (READER COM parameter missing)");
                start_reader_thread(std::string(argv[i]), -1);
            } else if (stricmp(argv[i], "-sde") == 0) {
                if (++i >= argc)
                    log_fatal("launcher", "-sde (PATH parameter missing)");
                sde_init(std::string(argv[i]));
            } else if (stricmp(argv[i], "-network") == 0) {
                if (++i >= argc)
                    log_fatal("launcher", "-network parameter missing");
                NETWORK_ADDRESS = std::string(argv[i]);
            } else if (stricmp(argv[i], "-subnet") == 0) {
                if (++i >= argc)
                    log_fatal("launcher", "-subnet parameter missing");
                NETWORK_SUBNET = std::string(argv[i]);
            } else if (stricmp(argv[i], "-api") == 0) {
                if (++i >= argc)
                    log_fatal("launcher", "-api [PORT] parameter missing");
                api_enable = true;
                api_port = (unsigned short) abs(strtol(argv[i], (char **) nullptr, 10));
            } else if (stricmp(argv[i], "-apipass") == 0) {
                if (++i >= argc)
                    log_fatal("launcher", "-apipass [PASS] parameter missing");
                api_pass = argv[i];
            } else if (stricmp(argv[i], "-apipretty") == 0) {
                api_pretty = true;
            } else if (stricmp(argv[i], "-apilogging") == 0) {
                api::LOGGING = true;
            } else if (stricmp(argv[i], "-apidebug") == 0) {
                api_debug = true;
            } else if (stricmp(argv[i], "-dbghookdisable") == 0) {
                debughook::DEBUGHOOK_LOGGING = false;
            } else if (argv[i][0] != '-' && avs::game::DLL_NAME.empty()) {
                avs::game::DLL_NAME = argv[i];
            }
        }
    }

    // API debugging
    if (api_debug) {
        API_CONTROLLER = new api::Controller(api_port, api_pass, api_pretty);
        while (API_CONTROLLER->server_running)
            Sleep(100);
        log_fatal("launcher", "API server stopped.");
    }

    // run configuration utility
    if (cfg_run)
        exit(spicecfg_run(sextet_devices));

    // create log file
    avs::core::create_log();

    // log
    log_info("launcher", "SpiceTools Bootstrap");
    log_info("launcher", to_string(VERSION_STRING));

    // set process priority
    if (!SetPriorityClass(GetCurrentProcess(), HIGH_PRIORITY_CLASS))
        log_info("launcher", "Couldn't set process priority to high.");
    if (realtime)
        if (!SetPriorityClass(GetCurrentProcess(), REALTIME_PRIORITY_CLASS))
            log_info("launcher", "Couldn't set process priority to realtime.");

    // set thread priority to max
    if (!SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_HIGHEST))
        log_info("launcher", "Couldn't set thread priority to highest.");

    // auto detect game if not specified
    if (avs::game::DLL_NAME.empty()) {
        bool module_path_tried = false;
        do {
            std::string path;

            // IIDX
            path = MODULE_PATH_STR + "bm2dx.dll";
            if (fileutils::file_exists(path.c_str()) && fileutils::verify_header_pe(path)) {
                avs::game::DLL_NAME = "bm2dx.dll";
                attach_io = true;
                attach_iidx = true;

#ifdef SPICE64
                // beatmania IIDX 25 heap size
                avs::core::HEAP_SIZE = 134217728;
#endif
                break;
            }

            // SDVX
            path = MODULE_PATH_STR + "soundvoltex.dll";
            if (fileutils::file_exists(path.c_str()) && fileutils::verify_header_pe(path)) {
                avs::game::DLL_NAME = "soundvoltex.dll";
                attach_io = true;
                attach_sdvx = true;
                DXHOOK_CAPTURE = true;
#ifdef SPICE64
                avs::core::HEAP_SIZE = 0x10000000;
                debughook::DEBUGHOOK_LOGGING = false;
#endif
                break;
            }

            // JB
            path = MODULE_PATH_STR + "jubeat.dll";
            if (fileutils::file_exists(path.c_str()) && fileutils::verify_header_pe(path)) {
                avs::game::DLL_NAME = "jubeat.dll";
                attach_io = true;
                attach_jb = true;
                break;
            }

            // RB
            path = MODULE_PATH_STR + "reflecbeat.dll";
            if (fileutils::file_exists(path.c_str()) && fileutils::verify_header_pe(path)) {
                avs::game::DLL_NAME = "reflecbeat.dll";
                attach_io = true;
                attach_rb = true;
                break;
            }

            // MGA
            path = MODULE_PATH_STR + "launch.dll";
            if (fileutils::file_exists(path.c_str()) && fileutils::verify_header_pe(path)) {
                avs::game::DLL_NAME = "launch.dll";
                attach_io = true;
                attach_mga = true;
                break;
            }

            // DEA
            path = MODULE_PATH_STR + "arkkdm.dll";
            if (fileutils::file_exists(path.c_str()) && fileutils::verify_header_pe(path)) {
                avs::game::DLL_NAME = "arkkdm.dll";
                attach_io = true;

                // the game is windowed by default unless we set the env
                if (DXHOOK_WINDOWED)
                    DXHOOK_WINDOWED = false;
                else
                    SetEnvironmentVariable("DAMAC_VIEWER_FULLSCREEN", "0");

                break;
            }

            // BS
            path = MODULE_PATH_STR + "beatstream.dll";
            if (fileutils::file_exists(path.c_str()) && fileutils::verify_header_pe(path)) {
                avs::game::DLL_NAME = "beatstream.dll";
                attach_io = true;
                break;
            }

            // RF3D
            path = MODULE_PATH_STR + "jgt.dll";
            if (fileutils::file_exists(path.c_str()) && fileutils::verify_header_pe(path)) {
                avs::game::DLL_NAME = "jgt.dll";
                attach_io = true;
                break;
            }

            // MUSECA
            path = MODULE_PATH_STR + "museca.dll";
            if (fileutils::file_exists(path.c_str()) && fileutils::verify_header_pe(path)) {
                avs::game::DLL_NAME = "museca.dll";
                attach_io = true;
                avs::core::HEAP_SIZE = 201326592;
                break;
            }

            // POPN22
            path = MODULE_PATH_STR + "popn22.dll";
            if (fileutils::file_exists(path.c_str()) && fileutils::verify_header_pe(path)) {
                avs::game::DLL_NAME = "popn22.dll";
                attach_io = true;
                attach_popn = true;
                break;
            }

            // POPN21
            path = MODULE_PATH_STR + "popn21.dll";
            if (fileutils::file_exists(path.c_str()) && fileutils::verify_header_pe(path)) {
                avs::game::DLL_NAME = "popn21.dll";
                attach_io = true;
                attach_popn = true;
                break;
            }

            // DDR ACE
            path = MODULE_PATH_STR + "arkmdxp3.dll";
            if (fileutils::file_exists(path.c_str()) && fileutils::verify_header_pe(path)) {
                avs::game::DLL_NAME = "arkmdxp3.dll";
                attach_io = true;
                attach_ddr = true;
                avs::core::HEAP_SIZE = 33554432;
                break;
            }

            // DDR 945
            path = MODULE_PATH_STR + "mdxja_945.dll";
            if (fileutils::file_exists(path.c_str()) && fileutils::verify_header_pe(path)) {
                avs::game::DLL_NAME = "mdxja_945.dll";
                attach_io = true;
                attach_ddr = true;
                break;
            }

            // DDR hm65
            path = MODULE_PATH_STR + "mdxja_hm65.dll";
            if (fileutils::file_exists(path.c_str()) && fileutils::verify_header_pe(path)) {
                avs::game::DLL_NAME = "mdxja_hm65.dll";
                attach_io = true;
                attach_ddr = true;
                break;
            }

            // DDR KDX
            path = MODULE_PATH_STR + "ddr.dll";
            if (fileutils::file_exists(path.c_str()) && fileutils::verify_header_pe(path)) {
                avs::game::DLL_NAME = "ddr.dll";
                attach_io = true;
                attach_ddr = true;
                break;
            }

            // GitaDora
            path = MODULE_PATH_STR + "gdxg.dll";
            if (fileutils::file_exists(path.c_str()) && fileutils::verify_header_pe(path)) {
                avs::game::DLL_NAME = "gdxg.dll";
                attach_io = true;
                attach_device = true;
                attach_extdev = true;
                attach_gitadora = true;
                break;
            }

            // Nostalgia
            path = MODULE_PATH_STR + "nostalgia.dll";
            if (fileutils::file_exists(path.c_str()) && fileutils::verify_header_pe(path)) {
                avs::game::DLL_NAME = "nostalgia.dll";
                attach_io = true;
                attach_nostalgia = true;
                avs::core::HEAP_SIZE = 134217728;

                // automatically show cursor when no touchscreen is available
                if (!is_win_touch_available())
                    DXHOOK_SHOW_CURSOR = true;

                break;
            }

            // Bishi Bashi Channel
            path = MODULE_PATH_STR + "bsch.dll";
            if (fileutils::file_exists(path.c_str()) && fileutils::verify_header_pe(path)) {
                avs::game::DLL_NAME = "bsch.dll";
                attach_io = true;
                attach_bbc = true;
                avs::core::HEAP_SIZE = 201326592;
                break;
            }

            // Quiz Magic Academy
            path = MODULE_PATH_STR + "client.dll";
            if (fileutils::file_exists(path.c_str()) && fileutils::verify_header_pe(path)) {
                avs::game::DLL_NAME = "client.dll";
                attach_io = true;
                attach_qma = true;
                avs::core::HEAP_SIZE = 70000000;
                break;
            }

            // Steel Chronicles
            path = MODULE_PATH_STR + "arkkgg.dll";
            if (fileutils::file_exists(path.c_str()) && fileutils::verify_header_pe(path)) {
                avs::game::DLL_NAME = "arkkgg.dll";
                attach_io = true;
                attach_sc = true;
                break;
            }

            // try module path
            if (!module_path_tried) {
                module_path_tried = true;

                MODULE_PATH_STR += "modules";
                SetDllDirectoryA(MODULE_PATH_STR.c_str());

                MODULE_PATH_STR += "\\";

                continue;
            }

            // usage error
            log_fatal("launcher", "Module auto detection failed.");
            break;

        } while (true);
    }

    // set error mode to show all errors
    SetErrorMode(0);

    // load the games
    std::vector<games::Game*> games;
    if (attach_popn)
        games.push_back(new games::popn::POPNGame());
    if (attach_bbc)
        games.push_back(new games::bbc::BBCGame());
    if (attach_ddr)
        games.push_back(new games::ddr::DDRGame());
    if (attach_iidx)
        games.push_back(new games::iidx::IIDXGame());
    if (attach_sdvx)
        games.push_back(new games::sdvx::SDVXGame());
    if (attach_jb)
        games.push_back(new games::jb::JBGame());
    if (attach_nostalgia)
        games.push_back(new games::nost::NostGame());
    if (attach_gitadora)
        games.push_back(new games::gitadora::GitaDoraGame());
    if (attach_mga)
        games.push_back(new games::mga::MGAGame());
    if (attach_sc)
        games.push_back(new games::sc::SCGame());
    if (attach_rb)
        games.push_back(new games::rb::RBGame());
    if (attach_qma)
        games.push_back(new games::qma::QMAGame());

    // cardio
    if (cardio_enabled)
        cardio_runner_start(true);

    // call pre-attach
    for (auto game : games)
        game->pre_attach();

    // load stubs
    if (load_stubs) {
        for (const auto &stub : STUBS) {
            if (fileutils::verify_header_pe(MODULE_PATH_STR + stub)) {
                libutils::load_library(MODULE_PATH_STR + stub);
            } else {
                log_warning("launcher", "failed loading stubs!");
                load_stubs = false;
            }
        }
    }

    // load DLLs
    avs::core::load_dll();
    avs::ea3::load_dll();

    /*
     * TODO
     * MUSECA workaround - might be possible to remove this hack, further testing needed
     * experienced crashes on earlier versions with netfix enabled
     */
    if (avs::game::DLL_NAME == "museca.dll")
        netfix_disable = true;

    // net fix
    if (!netfix_disable)
        networkhook_init();

    // boot AVS
    avs::core::boot();

    // load game
    avs::game::load_dll();

    // attach games
    for (auto game : games)
        game->attach();

    // attach stub functions
    if (!load_stubs)
        stubs::attach();

    // ACP hook
    if (!acphook_disable)
        acphook_init();

    // DirectInput hook
    dinputhook_init();

    // D3D9 hook
    dxhook_init();

    // debug hook
    debughook::attach();

    // device debug
    if (DEVICE_CREATEFILE_DEBUG)
        devicehook_init();

    // server
    if (easrv_port != 0u)
        easrv_start(easrv_port, easrv_maint, 4, 8);

    // initialize raw input
    RI_MGR = new rawinput::RawInputManager();
    for (auto device : sextet_devices)
        RI_MGR->sextet_register(device);

    // acio attach
    if (attach_io || attach_acio)
        acio::attach();

    // acio icca attach
    if (attach_icca)
        acio::attach_icca();

    // device attach
    if (attach_io || attach_device)
        spicedevice_attach();

    // ext dev attach
    if (attach_io || attach_extdev)
        extdev_attach();

    // sci unit attach
    if (attach_io || attach_sciunit)
        sciunit_attach();

    // SDVX printer attach
    if (attach_sdvx_printer)
        games::sdvx::printer_attach();

    // net fix
    if (!netfix_disable)
        networkhook_init();

    // load AVS-EA3
    avs::ea3::boot(easrv_port);

    // eamuse init
    eamuse_autodetect_game();

    // BT5API
    if (BT5API_ENABLED)
        bt5api_init();

    // API
    if (api_enable)
        API_CONTROLLER = new api::Controller(api_port, api_pass, api_pretty);

    // load hooks
    log_info("launcher", "loading hooks");
    for (auto &hook : game_hooks)
        libutils::load_library(hook);

    // print PEB
    if (peb_print)
        peb::peb_print();

    // game start
    log_info("launcher", "calling game entry");
    avs::game::entry_main();

    // detach games
    for (auto game : games)
        game->detach();

    // sci unit detach
    if (attach_io || attach_sciunit)
        sciunit_detach();

    // ext dev dettach
    if (attach_io || attach_extdev)
        extdev_detach();

    // device dettach
    if (attach_io || attach_device)
        spicedevice_detach();

    // acio dettach
    if (attach_io || attach_acio)
        acio::detach();

    // delete games
    while (!games.empty()) {
        delete games.back();
        games.pop_back();
    }

    // free api controller
    if (API_CONTROLLER) {
        delete API_CONTROLLER;
        API_CONTROLLER = nullptr;
    }

    // BT5API
    if (BT5API_ENABLED)
        bt5api_dispose();

    // stop raw input
    delete RI_MGR;
    RI_MGR = nullptr;

    // debug hook
    debughook::detach();

    // scard
    scard_fini();

    // stop reader thread in case it was running
    stop_reader_thread();

    // cardio
    if (cardio_enabled)
        cardio_runner_stop();

    // server
    if (easrv_port != 0u)
        easrv_shutdown();

    // AVS EA3 shutdown
    avs::ea3::shutdown();

    // AVS cleanup
    avs::core::shutdown();

    // dispose crypt
    crypt::dispose();

    // return no error
    log_info("launcher", "end");
    return 0;
}
