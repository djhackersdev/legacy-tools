#include "signal.h"
#include <string>
#include <csignal>
#include "util/logging.h"
#include "external/stackwalker/stackwalker.h"

namespace launcher::signal {

    // settings
    bool DISABLE = false;
}

static std::string signal_tostr(int sig) {
    switch (sig) {
        case SIGABRT:
            return "SIGABRT";
        case SIGSEGV:
            return "SIGSEGV";
        case SIGILL:
            return "SIGILL";
        case SIGFPE:
            return "SIGFPE";
        default:
            return "SIG(" + to_string(sig) + ")";
    }
}

static void signal_handler(int sig) {

    // ignore signal if disabled
    if (launcher::signal::DISABLE)
        return;

    // print signal
    log_warning("sig", "caught signal (" + signal_tostr(sig) + ")");

    // print stacktrace
    StackWalker sw;
    log_info("sig", "printing callstack");
    if (!sw.ShowCallstack())
        log_warning("sig", "failed to print callstack");

    // we quit
    exit(sig);
}

void launcher::signal::init() {

    // don't register signals if disabled from start
    if (signal::DISABLE)
        return;

    // register signal handlers
    int signals[] = {
            SIGABRT,
            SIGABRT_COMPAT,
            SIGSEGV,
            SIGILL,
            SIGFPE
    };
    for (auto sig : signals)
        ::signal(sig, signal_handler);
}
