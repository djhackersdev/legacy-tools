#ifndef SPICETOOLS_ACIO_J32D_H
#define SPICETOOLS_ACIO_J32D_H

#include "../module.h"

namespace acio {

    class J32DModule : public ACIOModule {
    public:
        J32DModule(HMODULE module, HookMode hookMode);

        virtual void attach() override;
    };
}

#endif // SPICETOOLS_ACIO_J32D_H
