#include "j32d.h"
#include "launcher/launcher.h"
#include "rawinput/rawinput.h"

#include "util/logging.h"

//using namespace GameAPI;

// static stuff
static uint32_t J32D_CONTROL_STATUS_BUFFER[20];
static uint32_t counter = 0xFFFFFFFF;

/*
 * Implementations
 */

static bool __cdecl ac_io_j32d_get_control_status_buffer(size_t a1, void* buffer, int a3) {

  /*
    log_info("j32d", "get_control_status_buffer a1: " + to_string(a1) +
        ", a2: " + to_string(buffer) +
        ", a3: " + to_string(a3));
        */

    // only trigger on a3 = 0 or 1
    J32D_CONTROL_STATUS_BUFFER[14] = counter - a3;

    // copy buffer
    memcpy(buffer, J32D_CONTROL_STATUS_BUFFER, sizeof(J32D_CONTROL_STATUS_BUFFER));

    // return buffer
    return buffer;
}


static bool __cdecl ac_io_j32d_update_control_status_buffer(size_t a1) {

    // clear buffer
    memset(J32D_CONTROL_STATUS_BUFFER, 0, sizeof(J32D_CONTROL_STATUS_BUFFER));

    //log_info("j32d", "ac_io_j32d_update_control_status_buffer(" + to_string(a1) + ")");

    static int bit_pos = 0;
    if (GetAsyncKeyState(VK_F5) & 1) {
      bit_pos = bit_pos > 0 ? bit_pos - 1 : 0;
      log_info("j32d", to_string(bit_pos));
    }
    if (GetAsyncKeyState(VK_F6) & 1) {
      bit_pos = bit_pos < 19 ? bit_pos + 1 : 19;
      log_info("j32d", to_string(bit_pos));
    }
    if (GetAsyncKeyState(VK_F7)) {
      J32D_CONTROL_STATUS_BUFFER[bit_pos] = ~0u;
    }

    // return success
    return true;
}

/*
 * Module stuff
 */

acio::J32DModule::J32DModule(HMODULE module, acio::HookMode hookMode) : ACIOModule("J32D", module, hookMode) {
}

void acio::J32DModule::attach() {
    ACIOModule::attach();

    // hooks
    ACIO_MODULE_HOOK(ac_io_j32d_get_control_status_buffer);
    ACIO_MODULE_HOOK(ac_io_j32d_update_control_status_buffer);
}
