#ifndef SPICETOOLS_ACIO_CORE_H
#define SPICETOOLS_ACIO_CORE_H

#include "../module.h"

namespace acio {

    class CoreModule : public ACIOModule {
    public:
        CoreModule(HMODULE module, HookMode hookMode);

        virtual void attach() override;
    };
}

#endif //SPICETOOLS_ACIO_CORE_H
