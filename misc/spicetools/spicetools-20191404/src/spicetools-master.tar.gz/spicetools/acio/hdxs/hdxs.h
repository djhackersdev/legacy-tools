#ifndef SPICETOOLS_ACIO_HDXS_H
#define SPICETOOLS_ACIO_HDXS_H

#include "../module.h"

namespace acio {

    class HDXSModule : public ACIOModule {
    public:
        HDXSModule(HMODULE module, HookMode hookMode);

        virtual void attach() override;
    };
}

#endif //SPICETOOLS_ACIO_HDXS_H
