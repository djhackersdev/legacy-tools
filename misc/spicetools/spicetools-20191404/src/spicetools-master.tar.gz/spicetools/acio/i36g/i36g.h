#ifndef SPICETOOLS_ACIO_I36G_H
#define SPICETOOLS_ACIO_I36G_H

#include "../module.h"

namespace acio {

    class I36GModule : public ACIOModule {
    public:
        I36GModule(HMODULE module, HookMode hookMode);

        virtual void attach() override;
    };
}

#endif //SPICETOOLS_ACIO_I36G_H
