#ifndef SPICETOOLS_ACIO_HGTH_H
#define SPICETOOLS_ACIO_HGTH_H

#include "../module.h"

namespace acio {

    class HGTHModule : public ACIOModule {
    public:
        HGTHModule(HMODULE module, HookMode hookMode);

        virtual void attach() override;
    };
}

#endif //SPICETOOLS_ACIO_HGTH_H
