#include "hgth.h"
#include "launcher/launcher.h"
#include "rawinput/rawinput.h"
#include "cfg/api.h"
#include "games/rf3d/io.h"
#include "../icca/icca.h"

using namespace GameAPI;

/*
 * Implementations
 */

static int __cdecl ac_io_hgth_set_senddata(int a1) {
    return 1;
}

static char __cdecl ac_io_hgth_update_recvdata() {
    return 1;
}

static void __cdecl ac_io_hgth_get_recvdata(void *a1) {

    // RF3D keypad mirror fix
    acio::ICCA_FLIP_ROWS = true;

    // reset
    memset(a1, 0, 32);

    // variables
    uint16_t wheel = 0x7FFF;
    uint16_t accelerator = 0x00;
    uint16_t brake = 0x00;

    // get buttons
    auto buttons = games::rf3d::get_buttons();

    // check buttons
    bool wheel_button = false;
    bool accelerate_button = false;
    bool brake_button = false;
    if (Buttons::getState(RI_MGR, buttons->at(games::rf3d::Buttons::WheelLeft))) {
        wheel -= 0x7FFF;
        wheel_button = true;
    }
    if (Buttons::getState(RI_MGR, buttons->at(games::rf3d::Buttons::WheelRight))) {
        wheel += 0x8000;
        wheel_button = true;
    }
    if (Buttons::getState(RI_MGR, buttons->at(games::rf3d::Buttons::Accelerate))) {
        accelerator = 0xFFFF;
        accelerate_button = true;
    }
    if (Buttons::getState(RI_MGR, buttons->at(games::rf3d::Buttons::Brake))) {
        brake = 0xFFFF;
        brake_button = true;
    }

    // analogs
    auto analogs = games::rf3d::get_analogs();
    if (!wheel_button && analogs->at(games::rf3d::Analogs::Wheel)->isSet())
        wheel = (uint16_t) (Analogs::getState(RI_MGR, analogs->at(games::rf3d::Analogs::Wheel)) * 0xFFFF);
    if (!accelerate_button && analogs->at(games::rf3d::Analogs::Accelerate)->isSet())
        accelerator = (uint16_t) (Analogs::getState(RI_MGR, analogs->at(games::rf3d::Analogs::Accelerate)) * 0xFFFF);
    if (!brake_button && analogs->at(games::rf3d::Analogs::Brake)->isSet())
        brake = (uint16_t) (Analogs::getState(RI_MGR, analogs->at(games::rf3d::Analogs::Brake)) * 0xFFFF);

    // write values
    *((uint16_t *) a1 + 1) = wheel;
    *((uint16_t *) a1 + 2) = accelerator;
    *((uint16_t *) a1 + 3) = brake;
}

static char __cdecl ac_io_hgth_directreq_set_handle_limit(char a1, int *a2) {
    *a2 = 1;
    return 1;
}

static bool __cdecl ac_io_hgth_directreq_set_handle_limit_isfinished(int *a1) {
    *a1 = 2;
    return true;
}

/*
 * Module stuff
 */

acio::HGTHModule::HGTHModule(HMODULE module, acio::HookMode hookMode) : ACIOModule("HGTH", module, hookMode) {
}

void acio::HGTHModule::attach() {
    ACIOModule::attach();

    // hooks
    ACIO_MODULE_HOOK(ac_io_hgth_set_senddata);
    ACIO_MODULE_HOOK(ac_io_hgth_update_recvdata);
    ACIO_MODULE_HOOK(ac_io_hgth_get_recvdata);
    ACIO_MODULE_HOOK(ac_io_hgth_directreq_set_handle_limit);
    ACIO_MODULE_HOOK(ac_io_hgth_directreq_set_handle_limit_isfinished);
}
