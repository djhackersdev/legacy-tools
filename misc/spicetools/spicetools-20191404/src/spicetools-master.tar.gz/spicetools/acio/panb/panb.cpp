#include "panb.h"
#include "launcher/launcher.h"
#include "rawinput/rawinput.h"
#include "games/nost/io.h"
#include "games/nost/nost.h"

using namespace GameAPI;

// static stuff
static uint8_t PANB_CONTROL_STATUS_BUFFER[277];

/*
 * Implementations
 */

static long __cdecl ac_io_panb_control_led_bright(int a1, int a2) {
    return 0;
}

static long __cdecl ac_io_panb_control_reset() {
    return 0;
}

static uint8_t* __cdecl ac_io_panb_get_control_status_buffer(uint8_t* buffer) {

    // copy buffer
    memcpy(buffer, PANB_CONTROL_STATUS_BUFFER, 277);

    // return buffer
    return buffer;
}

static bool __cdecl ac_io_panb_start_auto_input() {
    return true;
}

static bool __cdecl ac_io_panb_update_control_status_buffer() {

    // update touch
    games::nost::touch_update();

    // clear buffer
    memset(PANB_CONTROL_STATUS_BUFFER, 0, 277);

    /*
     * first byte is number of input data
     * when it's set to 0 the game will not update it's key states
     * setting it too high will make the game read over the buffer
     *
     * unsure why you would send more than one set of data, so
     * we just set it to 1 and provide our current status
     */
    PANB_CONTROL_STATUS_BUFFER[0] = 1;

    // get buttons/analogs
    auto buttons = games::nost::get_buttons();
    auto analogs = games::nost::get_analogs();

    // mappings
    static const size_t button_mapping[] = {
            games::nost::Buttons::Key1, games::nost::Buttons::Key2,
            games::nost::Buttons::Key3, games::nost::Buttons::Key4,
            games::nost::Buttons::Key5, games::nost::Buttons::Key6,
            games::nost::Buttons::Key7, games::nost::Buttons::Key8,
            games::nost::Buttons::Key9, games::nost::Buttons::Key10,
            games::nost::Buttons::Key11, games::nost::Buttons::Key12,
            games::nost::Buttons::Key13, games::nost::Buttons::Key14,
            games::nost::Buttons::Key15, games::nost::Buttons::Key16,
            games::nost::Buttons::Key17, games::nost::Buttons::Key18,
            games::nost::Buttons::Key19, games::nost::Buttons::Key20,
            games::nost::Buttons::Key21, games::nost::Buttons::Key22,
            games::nost::Buttons::Key23, games::nost::Buttons::Key24,
            games::nost::Buttons::Key25, games::nost::Buttons::Key26,
            games::nost::Buttons::Key27, games::nost::Buttons::Key28,
    };
    static const size_t analog_mapping[] = {
            games::nost::Analogs::Key1, games::nost::Analogs::Key2,
            games::nost::Analogs::Key3, games::nost::Analogs::Key4,
            games::nost::Analogs::Key5, games::nost::Analogs::Key6,
            games::nost::Analogs::Key7, games::nost::Analogs::Key8,
            games::nost::Analogs::Key9, games::nost::Analogs::Key10,
            games::nost::Analogs::Key11, games::nost::Analogs::Key12,
            games::nost::Analogs::Key13, games::nost::Analogs::Key14,
            games::nost::Analogs::Key15, games::nost::Analogs::Key16,
            games::nost::Analogs::Key17, games::nost::Analogs::Key18,
            games::nost::Analogs::Key19, games::nost::Analogs::Key20,
            games::nost::Analogs::Key21, games::nost::Analogs::Key22,
            games::nost::Analogs::Key23, games::nost::Analogs::Key24,
            games::nost::Analogs::Key25, games::nost::Analogs::Key26,
            games::nost::Analogs::Key27, games::nost::Analogs::Key28,
    };

    // iterate pairs of keys
    for (size_t key_pair = 0; key_pair < 28 / 2; key_pair++) {

        // default states
        uint8_t state0 = 0;
        uint8_t state1 = 0;

        // check analogs
        auto analog0 = analogs->at(analog_mapping[key_pair * 2 + 0]);
        auto analog1 = analogs->at(analog_mapping[key_pair * 2 + 1]);
        if (analog0->isSet())
            state0 = (uint8_t) (Analogs::getState(RI_MGR, analog0) * 15.999f);
        if (analog1->isSet())
            state1 = (uint8_t) (Analogs::getState(RI_MGR, analog1) * 15.999f);

        // check buttons
        auto velocity0 = Buttons::getVelocity(RI_MGR, buttons->at(button_mapping[key_pair * 2 + 0]));
        auto velocity1 = Buttons::getVelocity(RI_MGR, buttons->at(button_mapping[key_pair * 2 + 1]));
        if (velocity0 > 0.f)
            state0 = (uint8_t) (velocity0 * 15.999f);
        if (velocity1 > 0.f)
            state1 = (uint8_t) (velocity1 * 15.999f);

        // build value
        uint8_t value = 0;
        value |= state0 << 4;
        value |= state1 & 0xF;

        // set value
        PANB_CONTROL_STATUS_BUFFER[key_pair + 3] = value;
    }

    // return success
    return true;
}

/*
 * Module stuff
 */

acio::PANBModule::PANBModule(HMODULE module, acio::HookMode hookMode) : ACIOModule("PANB", module, hookMode) {
}

void acio::PANBModule::attach() {
    ACIOModule::attach();

    // hooks
    ACIO_MODULE_HOOK(ac_io_panb_control_led_bright);
    ACIO_MODULE_HOOK(ac_io_panb_control_reset);
    ACIO_MODULE_HOOK(ac_io_panb_get_control_status_buffer);
    ACIO_MODULE_HOOK(ac_io_panb_start_auto_input);
    ACIO_MODULE_HOOK(ac_io_panb_update_control_status_buffer);
}
