#ifndef SPICETOOLS_ACIO_PANB_H
#define SPICETOOLS_ACIO_PANB_H

#include "../module.h"

namespace acio {

    class PANBModule : public ACIOModule {
    public:
        PANBModule(HMODULE module, HookMode hookMode);

        virtual void attach() override;
    };
}

#endif //SPICETOOLS_ACIO_PANB_H
