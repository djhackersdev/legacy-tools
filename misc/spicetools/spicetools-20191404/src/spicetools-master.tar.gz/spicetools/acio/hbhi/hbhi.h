#ifndef SPICETOOLS_ACIO_HBHI_H
#define SPICETOOLS_ACIO_HBHI_H

#include "../module.h"

namespace acio {

    class HBHIModule : public ACIOModule {
    public:
        HBHIModule(HMODULE module, HookMode hookMode);

        virtual void attach() override;
    };
}

#endif //SPICETOOLS_ACIO_HBHI_H
