#ifndef SPICETOOLS_ACIO_BI2A_H
#define SPICETOOLS_ACIO_BI2A_H

#include "../module.h"

namespace acio {

    class BI2AModule : public ACIOModule {
    public:
        BI2AModule(HMODULE module, HookMode hookMode);

        virtual void attach() override;
    };
}

#endif //SPICETOOLS_ACIO_BI2A_H
