#ifndef SPICETOOLS_ACIO_H
#define SPICETOOLS_ACIO_H

namespace acio {
    void attach();
    void attach_icca();
    void detach();
}

#endif //SPICETOOLS_ACIO_H
