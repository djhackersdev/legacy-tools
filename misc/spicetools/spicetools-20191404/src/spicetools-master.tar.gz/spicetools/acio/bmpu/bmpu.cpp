#include "bmpu.h"
#include "acio/icca/icca.h"
#include "launcher/launcher.h"
#include "rawinput/rawinput.h"
#include "cfg/api.h"
#include "games/dea/io.h"
#include "games/museca/io.h"
#include "games/bbc/io.h"
#include "misc/eamuse.h"
#include "avs/game.h"

#include "util/logging.h"

using namespace GameAPI;

// static stuff
static unsigned char BMPU_CONTROL_STATUS_BUFFER[64];

/*
 * Implementations
 */

static char __cdecl ac_io_bmpu_consume_coinstock(int a1, int a2) {
    eamuse_coin_consume_stock();
    return 1;
}

static int __cdecl ac_io_bmpu_control_1p_start_led_off() {
    return 1;
}

static int __cdecl ac_io_bmpu_control_1p_start_led_on() {
    return 1;
}

static int __cdecl ac_io_bmpu_control_2p_start_led_off() {
    return 1;
}

static int __cdecl ac_io_bmpu_control_2p_start_led_on() {
    return 1;
}

static int __cdecl ac_io_bmpu_control_coin_blocker_close() {
    eamuse_coin_set_block(true);
    return 1;
}

static int __cdecl ac_io_bmpu_control_coin_blocker_open() {
    eamuse_coin_set_block(false);
    return 1;
}

static int __cdecl ac_io_bmpu_control_led_bright(uint32_t led_field, uint8_t brightness) {

    // MUSECA
    if (avs::game::is_model("PIX")) {

        // get lights
        auto lights = games::museca::get_lights();

        // control mapping
        static int mapping[] = {
                games::museca::Lights::UnderLED3G,
                games::museca::Lights::UnderLED3R,
                games::museca::Lights::UnderLED2B,
                games::museca::Lights::UnderLED2G,
                games::museca::Lights::UnderLED2R,
                games::museca::Lights::UnderLED1B,
                games::museca::Lights::UnderLED1G,
                games::museca::Lights::UnderLED1R,
                -1, -1, -1, -1,
                games::museca::Lights::SideB,
                games::museca::Lights::SideG,
                games::museca::Lights::SideR,
                games::museca::Lights::UnderLED3B,
        };

        // write light
        float value = brightness > 127.f ? 1.f : brightness / 127.f;
        for (size_t i = 0; i < std::size(mapping); i++)
            if (mapping[i] >= 0 && led_field & (1 << i))
                Lights::writeLight(RI_MGR, lights->at((size_t) mapping[i]), value);
    }

    // BISHI BASHI CHANNEL
    if (avs::game::is_model("R66")) {

        // get lights
        auto lights = games::bbc::get_lights();

        // control mapping
        static int mapping[] = {
                games::bbc::Lights::UNDER_LED3_G,
                games::bbc::Lights::UNDER_LED3_R,
                games::bbc::Lights::UNDER_LED2_B,
                games::bbc::Lights::UNDER_LED2_G,
                games::bbc::Lights::UNDER_LED2_R,
                games::bbc::Lights::UNDER_LED1_B,
                games::bbc::Lights::UNDER_LED1_G,
                games::bbc::Lights::UNDER_LED1_R,
                -1, -1, -1, -1,
                games::bbc::Lights::IC_CARD_B,
                games::bbc::Lights::IC_CARD_G,
                games::bbc::Lights::IC_CARD_R,
                games::bbc::Lights::UNDER_LED3_B,
        };

        // write light
        float value = brightness / 255.f;
        for (size_t i = 0; i < std::size(mapping); i++)
            if (mapping[i] >= 0 && led_field & (1 << i))
                Lights::writeLight(RI_MGR, lights->at((size_t) mapping[i]), value);
    }

    // return success
    return 1;
}

static char __cdecl ac_io_bmpu_current_coinstock(int a1, int *a2) {
    *a2 = eamuse_coin_get_stock();
    return 1;
}

static char __cdecl ac_io_bmpu_get_control_status_buffer(void *a1) {
    unsigned int control_data = 0;

    // DEA
    if (avs::game::is_model("KDM")) {

        // dance evolution workaround for rawinput
        static bool dea_rawinput_thread = false;
        if (!dea_rawinput_thread) {
            dea_rawinput_thread = true;
        }

        // get buttons
        auto buttons = games::dea::get_buttons();

        // get control data
        if (Buttons::getState(RI_MGR, buttons->at(games::dea::Buttons::Service)))
            control_data |= 0xF0000000;
        if (Buttons::getState(RI_MGR, buttons->at(games::dea::Buttons::Test)))
            control_data |= 0x0F000000;
        if (Buttons::getState(RI_MGR, buttons->at(games::dea::Buttons::P1Start)))
            control_data |= 0x00000001;
        if (Buttons::getState(RI_MGR, buttons->at(games::dea::Buttons::P1Left)))
            control_data |= 0x00000008;
        if (Buttons::getState(RI_MGR, buttons->at(games::dea::Buttons::P1Right)))
            control_data |= 0x00000010;
        if (Buttons::getState(RI_MGR, buttons->at(games::dea::Buttons::P2Start)))
            control_data |= 0x00000100;
        if (Buttons::getState(RI_MGR, buttons->at(games::dea::Buttons::P2Left)))
            control_data |= 0x00000800;
        if (Buttons::getState(RI_MGR, buttons->at(games::dea::Buttons::P2Right)))
            control_data |= 0x00001000;

        // set control data
        for (int i = 0; i < 64; i += 4)
            *((int *) &BMPU_CONTROL_STATUS_BUFFER[i]) = control_data;
        memcpy(a1, &BMPU_CONTROL_STATUS_BUFFER, 64);
    }

    // FutureTomTom
    if (avs::game::is_model("MMD")) {

        // get buttons
        auto buttons = games::dea::get_buttons();

        // get control data
        if (Buttons::getState(RI_MGR, buttons->at(games::dea::Buttons::Service)))
            control_data |= 0x0F000000;
        if (Buttons::getState(RI_MGR, buttons->at(games::dea::Buttons::Test)))
            control_data |= 0xF0000000;

        /*
        static int bit_pos = 0;
        if (GetAsyncKeyState(VK_F5) & 1) {
          bit_pos = bit_pos > 0 ? bit_pos - 1 : 0;
          log_info("bmpu", to_string(bit_pos));
        }
        if (GetAsyncKeyState(VK_F6) & 1) {
          bit_pos = bit_pos < 31 ? bit_pos + 1 : 31;
          log_info("bmpu", to_string(bit_pos));
        }
        if (GetAsyncKeyState(VK_F7)) {
          control_data |= 1 << bit_pos;
        }
        */

        // set control data
        for (int i = 0; i < 64; i += 4)
            *((int *) &BMPU_CONTROL_STATUS_BUFFER[i]) = control_data;
        memcpy(a1, &BMPU_CONTROL_STATUS_BUFFER, 64);
    }

    // MUSECA
    if (avs::game::is_model("PIX")) {

        // get buttons
        auto buttons = games::museca::get_buttons();

        // get control data
        if (Buttons::getState(RI_MGR, buttons->at(games::museca::Buttons::Service)))
            control_data |= 0x0F000000;
        if (Buttons::getState(RI_MGR, buttons->at(games::museca::Buttons::Test)))
            control_data |= 0xF0000000;
        if (Buttons::getState(RI_MGR, buttons->at(games::museca::Buttons::Start)))
            control_data |= 0x00000001;

        // set control data
        for (int i = 0; i < 16; i += 4)
            *((int *) &BMPU_CONTROL_STATUS_BUFFER[i]) = control_data;
        memcpy(a1, &BMPU_CONTROL_STATUS_BUFFER, 16);
    }

    // BISHI BASHI CHANNEL
    if (avs::game::is_model("R66")) {

        // get buttons
        std::vector<Button *> *buttons = games::bbc::get_buttons();

        // get control data
        if (Buttons::getState(RI_MGR, buttons->at(games::bbc::Buttons::Service)) == Buttons::State::BUTTON_PRESSED)
            control_data |= 0x0F000000;
        if (Buttons::getState(RI_MGR, buttons->at(games::bbc::Buttons::Test)) == Buttons::State::BUTTON_PRESSED)
            control_data |= 0xF0000000;

        // set control data
        for (int i = 0; i < 16; i += 4)
            *((int *) &BMPU_CONTROL_STATUS_BUFFER[i]) = control_data;
        memcpy(a1, &BMPU_CONTROL_STATUS_BUFFER, 56);
    }

    return 1;
}

static char *__cdecl ac_io_bmpu_get_softwareid(char *a1) {
    *a1 = 0;
    return a1;
}

static char *__cdecl ac_io_bmpu_get_systemid(char *a1) {
    *a1 = 0;
    return a1;
}

static char __cdecl ac_io_bmpu_init_outport() {

    // dance evolution keypad mirror fix
    acio::ICCA_FLIP_ROWS = true;

    return 1;
}

static char __cdecl ac_io_bmpu_lock_coincounter(signed int a1) {
    return 1;
}

static char __cdecl ac_io_bmpu_req_secplug_check_isfinished(DWORD *a1) {
    return 1;
}

static char __cdecl ac_io_bmpu_req_secplug_check_softwareplug(char *a1) {
    return 1;
}

static char __cdecl ac_io_bmpu_req_secplug_check_systemplug() {
    return 1;
}

static char __cdecl ac_io_bmpu_req_secplug_missing_check() {
    return 1;
}

static int __cdecl ac_io_bmpu_req_secplug_missing_check_isfinished(DWORD *a1) {
    return 1;
}

static int __cdecl ac_io_bmpu_set_outport_led(int a1, int a2) {
    return 1;
}

static int __cdecl ac_io_bmpu_set_output_mode(__int16 a1) {
    return 1;
}

static char __cdecl ac_io_bmpu_unlock_coincounter(int a1) {
    return 1;
}

static char __cdecl ac_io_bmpu_update_control_status_buffer() {
    return 1;
}

static bool __cdecl ac_io_bmpu_set_watchdog_time(char a1) {
    return true;
}

static char __cdecl ac_io_bmpu_get_watchdog_time_min() {
    return 0;
}

static char __cdecl ac_io_bmpu_get_watchdog_time_now() {
    return 0;
}

static void __cdecl ac_io_bmpu_watchdog_off() {
}

/*
 * Module stuff
 */

acio::BMPUModule::BMPUModule(HMODULE module, acio::HookMode hookMode) : ACIOModule("BMPU", module, hookMode) {
}

void acio::BMPUModule::attach() {
    ACIOModule::attach();

    // hooks
    ACIO_MODULE_HOOK(ac_io_bmpu_consume_coinstock);
    ACIO_MODULE_HOOK(ac_io_bmpu_control_1p_start_led_off);
    ACIO_MODULE_HOOK(ac_io_bmpu_control_1p_start_led_on);
    ACIO_MODULE_HOOK(ac_io_bmpu_control_2p_start_led_off);
    ACIO_MODULE_HOOK(ac_io_bmpu_control_2p_start_led_on);
    ACIO_MODULE_HOOK(ac_io_bmpu_control_coin_blocker_close);
    ACIO_MODULE_HOOK(ac_io_bmpu_control_coin_blocker_open);
    ACIO_MODULE_HOOK(ac_io_bmpu_control_led_bright);
    ACIO_MODULE_HOOK(ac_io_bmpu_current_coinstock);
    ACIO_MODULE_HOOK(ac_io_bmpu_get_control_status_buffer);
    ACIO_MODULE_HOOK(ac_io_bmpu_get_softwareid);
    ACIO_MODULE_HOOK(ac_io_bmpu_get_systemid);
    ACIO_MODULE_HOOK(ac_io_bmpu_init_outport);
    ACIO_MODULE_HOOK(ac_io_bmpu_lock_coincounter);
    ACIO_MODULE_HOOK(ac_io_bmpu_req_secplug_check_isfinished);
    ACIO_MODULE_HOOK(ac_io_bmpu_req_secplug_check_softwareplug);
    ACIO_MODULE_HOOK(ac_io_bmpu_req_secplug_check_systemplug);
    ACIO_MODULE_HOOK(ac_io_bmpu_req_secplug_missing_check);
    ACIO_MODULE_HOOK(ac_io_bmpu_req_secplug_missing_check_isfinished);
    ACIO_MODULE_HOOK(ac_io_bmpu_set_outport_led);
    ACIO_MODULE_HOOK(ac_io_bmpu_set_output_mode);
    ACIO_MODULE_HOOK(ac_io_bmpu_unlock_coincounter);
    ACIO_MODULE_HOOK(ac_io_bmpu_update_control_status_buffer);
    ACIO_MODULE_HOOK(ac_io_bmpu_set_watchdog_time);
    ACIO_MODULE_HOOK(ac_io_bmpu_get_watchdog_time_min);
    ACIO_MODULE_HOOK(ac_io_bmpu_get_watchdog_time_now);
    ACIO_MODULE_HOOK(ac_io_bmpu_watchdog_off);
}
