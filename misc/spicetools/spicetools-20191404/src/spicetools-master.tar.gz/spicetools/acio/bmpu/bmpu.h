#ifndef SPICETOOLS_ACIO_BMPU_H
#define SPICETOOLS_ACIO_BMPU_H

#include "../module.h"

namespace acio {

    class BMPUModule : public ACIOModule {
    public:
        BMPUModule(HMODULE module, HookMode hookMode);

        virtual void attach() override;
    };
}

#endif //SPICETOOLS_ACIO_BMPU_H
