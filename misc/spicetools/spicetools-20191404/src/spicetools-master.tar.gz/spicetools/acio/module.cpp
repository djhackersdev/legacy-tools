#include "module.h"
#include "util/logging.h"
#include "util/detour.h"
#include "util/libutils.h"
#include "avs/game.h"

std::string acio::hookmode_tostr(acio::HookMode hookMode) {
    switch (hookMode) {
        case HookMode::INLINE:
            return "Inline";
        case HookMode::IAT:
            return "IAT";
        default:
            return "Unknown";
    }
}

acio::ACIOModule::ACIOModule(std::string name, HMODULE module, HookMode hookMode) {
    this->name = name;
    this->module = module;
    this->hookMode = hookMode;
}

/*
 * Hook functions depending on the specified mode.
 * We don't care about errors here since different versions of libacio contain different feature sets,
 * which means that not all hooks must/can succeed.
 */
void acio::ACIOModule::hook(void* func, std::string func_name) {
    switch (this->hookMode) {
        case HookMode::INLINE:
            detour::inline_hook(func, (DWORD_PTR) libutils::try_proc(this->module, func_name.c_str()));
            break;
        case HookMode::IAT:
            detour::iat_try(func_name.c_str(), func);
            break;
        default:
            log_warning("acio", "can't hook using mode " + hookmode_tostr(this->hookMode));
    }
}

void acio::ACIOModule::attach() {
    log_info("acio", "module attach: " + this->name + " " + hookmode_tostr(this->hookMode));
}
