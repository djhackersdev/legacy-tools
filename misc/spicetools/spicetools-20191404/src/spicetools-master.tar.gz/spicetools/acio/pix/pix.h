#ifndef SPICETOOLS_ACIO_PIX_H
#define SPICETOOLS_ACIO_PIX_H

#include "../module.h"

namespace acio {

    class PIXModule : public ACIOModule {
    public:
        PIXModule(HMODULE module, HookMode hookMode);

        virtual void attach() override;
    };
}

#endif //SPICETOOLS_ACIO_PIX_H
