#include "acio.h"
#include <iostream>
#include <windows.h>
#include <fstream>
#include "rawinput/rawinput.h"
#include "cfg/api.h"
#include "util/logging.h"
#include "util/utils.h"
#include "util/fileutils.h"
#include "util/libutils.h"
#include "hooks/libraryhook.h"
#include "cfg/config.h"
#include "misc/eamuse.h"
#include "avs/game.h"
#include "module.h"
#include "bi2a/bi2a.h"
#include "bmpu/bmpu.h"
#include "core/core.h"
#include "hbhi/hbhi.h"
#include "hdxs/hdxs.h"
#include "hgth/hgth.h"
#include "i36g/i36g.h"
#include "icca/icca.h"
#include "j32d/j32d.h"
#include "kfca/kfca.h"
#include "panb/panb.h"
#include "pix/pix.h"

// ACIO
static HINSTANCE ACIO_INSTANCE;
static std::string ACIO_INSTANCE_NAME = "libacio.dll";
static std::vector<acio::ACIOModule*> ACIO_MODULES;

/*
 * decide on hook mode used
 * libacio compiled using ICC64 sometimes doesn't leave enough space to insert the inline hooks
 * in this case, we want to use IAT instead
 */
static inline acio::HookMode get_hookmode() {
#ifdef SPICE64
    return acio::HookMode::IAT;
#else
    return acio::HookMode::INLINE;
#endif
}

void acio::attach() {
    log_info("acio", "SpiceTools ACIO");

    // load settings and instance
    ACIO_INSTANCE = LoadLibraryA(ACIO_INSTANCE_NAME.c_str());

    /*
     * library hook
     * some games have a second DLL laying around which gets loaded dynamically
     * we just give it the same instance as the normal one so the hooks still work
     */
    libraryhook_enable(avs::game::DLL_INSTANCE);
    libraryhook_hook_library("libacioex.dll", ACIO_INSTANCE);
    libraryhook_hook_library("libacio_ex.dll", ACIO_INSTANCE);
    libraryhook_hook_library("libacio_old.dll", ACIO_INSTANCE);

    // get hook mode
    acio::HookMode hook_mode = get_hookmode();

    // load modules
    ACIO_MODULES.push_back(new acio::BI2AModule(ACIO_INSTANCE, hook_mode));
    ACIO_MODULES.push_back(new acio::BMPUModule(ACIO_INSTANCE, hook_mode));
    ACIO_MODULES.push_back(new acio::CoreModule(ACIO_INSTANCE, hook_mode));
    ACIO_MODULES.push_back(new acio::HBHIModule(ACIO_INSTANCE, hook_mode));
    ACIO_MODULES.push_back(new acio::HDXSModule(ACIO_INSTANCE, hook_mode));
    ACIO_MODULES.push_back(new acio::HGTHModule(ACIO_INSTANCE, hook_mode));
    ACIO_MODULES.push_back(new acio::I36GModule(ACIO_INSTANCE, hook_mode));
    ACIO_MODULES.push_back(new acio::ICCAModule(ACIO_INSTANCE, hook_mode));
    ACIO_MODULES.push_back(new acio::J32DModule(ACIO_INSTANCE, hook_mode));
    ACIO_MODULES.push_back(new acio::KFCAModule(ACIO_INSTANCE, hook_mode));
    ACIO_MODULES.push_back(new acio::PANBModule(ACIO_INSTANCE, hook_mode));

    /*
     * PIX is special and needs another DLL.
     * we load that module only if the file exists.
     */
    if (fileutils::file_exists(MODULE_PATH_STR + "libacio_pix.dll")) {
        HINSTANCE pix_instance = libutils::load_library(MODULE_PATH_STR + "libacio_pix.dll");
        ACIO_MODULES.push_back(new acio::PIXModule(pix_instance, hook_mode));
    }

    // apply modules
    for (auto &module : ACIO_MODULES)
        module->attach();

    // start coin input thread
    eamuse_coin_start_thread();
}

void acio::attach_icca() {
    log_info("acio", "SpiceTools ACIO ICCA");

    // load instance if needed
    if (!ACIO_INSTANCE)
        ACIO_INSTANCE = LoadLibraryA(ACIO_INSTANCE_NAME.c_str());

    // get hook mode
    acio::HookMode hook_mode = get_hookmode();

    // load single module
    auto icca_module = new acio::ICCAModule(ACIO_INSTANCE, hook_mode);
    icca_module->attach();
    ACIO_MODULES.push_back(icca_module);
}

void acio::detach() {

    // stop coin input thread
    eamuse_coin_stop_thread();

    // clear modules
    while (!ACIO_MODULES.empty()) {
        delete ACIO_MODULES.back();
        ACIO_MODULES.pop_back();
    }
}
