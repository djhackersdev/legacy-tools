#ifndef SPICETOOLS_ACIO_ICCA_H
#define SPICETOOLS_ACIO_ICCA_H

#include "../module.h"

namespace acio {

    // settings
    extern bool ICCA_NUMPAD_ENABLE;
    extern bool ICCA_TOPROW_ENABLE;
    extern bool ICCA_FLIP_ROWS;

    class ICCAModule : public ACIOModule {
    public:
        ICCAModule(HMODULE module, HookMode hookMode);

        virtual void attach() override;
    };
}

#endif //SPICETOOLS_ACIO_ICCA_H
