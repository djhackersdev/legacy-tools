#include "kfca.h"
#include "launcher/launcher.h"
#include "rawinput/rawinput.h"
#include "games/sdvx/io.h"
#include "games/bs/io.h"
#include "games/nost/io.h"
#include "misc/eamuse.h"
#include "util/utils.h"
#include "avs/game.h"

using namespace GameAPI;

// static stuff
static POINT MOUSE_POS_OLD;
static unsigned char KFCA_CONTROL_STATUS_BUFFER[64];
static unsigned int KFCA_VOLL = 0;
static unsigned int KFCA_VOLL_SENSIVITY = 6; // recommended 3 for COPAL, 6 for DAO AC KNOBS
static unsigned int KFCA_VOLR = 0;
static unsigned int KFCA_VOLR_SENSIVITY = 6; // recommended 3 for COPAL, 6 for DAO AC KNOBS

/*
 * Helpers
 */

static inline void mouse_update() {
    POINT p{};
    if (GetCursorPos(&p) != 0) {
        LONG diff_x = p.x - MOUSE_POS_OLD.x;
        LONG diff_y = p.y - MOUSE_POS_OLD.y;
        KFCA_VOLL = (KFCA_VOLL + diff_x * KFCA_VOLL_SENSIVITY) & 1023;
        KFCA_VOLR = (KFCA_VOLR + diff_y * KFCA_VOLR_SENSIVITY) & 1023;

        // reset mouse if clipped
        RECT rect{};
        HWND wnd = GetForegroundWindow();
        if (string_begins_with(GetActiveWindowTitle(), "SOUND VOLTEX") && GetWindowRect(wnd, &rect)) {
            int x = (rect.left + rect.right) / 2;
            int y = (rect.top + rect.bottom) / 2;
            SetCursorPos(x, y);
            MOUSE_POS_OLD.x = x;
            MOUSE_POS_OLD.y = y;
        } else
            MOUSE_POS_OLD = p;
    }
}

static inline void kfca_volume_keyboard_update() {

    // get buttons
    auto buttons = games::sdvx::get_buttons();

    // volume left
    if (Buttons::getState(RI_MGR, buttons->at(games::sdvx::Buttons::VOL_L_Left)) == Buttons::State::BUTTON_PRESSED)
        KFCA_VOLL = (KFCA_VOLL - 16) & 1023;
    if (Buttons::getState(RI_MGR, buttons->at(games::sdvx::Buttons::VOL_L_Right)) == Buttons::State::BUTTON_PRESSED)
        KFCA_VOLL = (KFCA_VOLL + 16) & 1023;

    // volume right
    if (Buttons::getState(RI_MGR, buttons->at(games::sdvx::Buttons::VOL_R_Left)) == Buttons::State::BUTTON_PRESSED)
        KFCA_VOLR = (KFCA_VOLR - 16) & 1023;
    if (Buttons::getState(RI_MGR, buttons->at(games::sdvx::Buttons::VOL_R_Right)) == Buttons::State::BUTTON_PRESSED)
        KFCA_VOLR = (KFCA_VOLR + 16) & 1023;
}

static inline void kfca_control_status_buffer_update() {
    int input_offset = 4;
    memset(KFCA_CONTROL_STATUS_BUFFER, 0, 64);

    // SDVX
    if (avs::game::is_model("KFC")) {

        // get buttons
        auto buttons = games::sdvx::get_buttons();

        // test
        if (Buttons::getState(RI_MGR, buttons->at(games::sdvx::Buttons::Test)) == Buttons::State::BUTTON_PRESSED)
            KFCA_CONTROL_STATUS_BUFFER[input_offset + 1] |= 0x20;

        // service
        if (Buttons::getState(RI_MGR, buttons->at(games::sdvx::Buttons::Service)) == Buttons::State::BUTTON_PRESSED)
            KFCA_CONTROL_STATUS_BUFFER[input_offset + 1] |= 0x10;

        // coin
        if (Buttons::getState(RI_MGR, buttons->at(games::sdvx::Buttons::CoinMech)) == Buttons::State::BUTTON_PRESSED)
            KFCA_CONTROL_STATUS_BUFFER[input_offset + 1] |= 0x04;

        // start
        if (Buttons::getState(RI_MGR, buttons->at(games::sdvx::Buttons::Start)) == Buttons::State::BUTTON_PRESSED)
            KFCA_CONTROL_STATUS_BUFFER[input_offset + 9] |= 0x08;

        // A
        if (Buttons::getState(RI_MGR, buttons->at(games::sdvx::Buttons::BT_A)) == Buttons::State::BUTTON_PRESSED)
            KFCA_CONTROL_STATUS_BUFFER[input_offset + 9] |= 0x04;

        // B
        if (Buttons::getState(RI_MGR, buttons->at(games::sdvx::Buttons::BT_B)) == Buttons::State::BUTTON_PRESSED)
            KFCA_CONTROL_STATUS_BUFFER[input_offset + 9] |= 0x02;

        // C
        if (Buttons::getState(RI_MGR, buttons->at(games::sdvx::Buttons::BT_C)) == Buttons::State::BUTTON_PRESSED)
            KFCA_CONTROL_STATUS_BUFFER[input_offset + 9] |= 0x01;

        // D
        if (Buttons::getState(RI_MGR, buttons->at(games::sdvx::Buttons::BT_D)) == Buttons::State::BUTTON_PRESSED)
            KFCA_CONTROL_STATUS_BUFFER[input_offset + 11] |= 0x20;

        // FXL
        if (Buttons::getState(RI_MGR, buttons->at(games::sdvx::Buttons::FX_L)) == Buttons::State::BUTTON_PRESSED)
            KFCA_CONTROL_STATUS_BUFFER[input_offset + 11] |= 0x10;

        // FXR
        if (Buttons::getState(RI_MGR, buttons->at(games::sdvx::Buttons::FX_R)) == Buttons::State::BUTTON_PRESSED)
            KFCA_CONTROL_STATUS_BUFFER[input_offset + 11] |= 0x08;

        // update volumes
        kfca_volume_keyboard_update();
        auto analogs = games::sdvx::get_analogs();
        auto vol_left = KFCA_VOLL;
        auto vol_right = KFCA_VOLR;
        if (analogs->at(0)->isSet() || analogs->at(1)->isSet()) {
            vol_left += (unsigned int) (Analogs::getState(RI_MGR,
                                                          analogs->at(games::sdvx::Analogs::VOL_L)) * 1023.99f);
            vol_right += (unsigned int) (Analogs::getState(RI_MGR,
                                                           analogs->at(games::sdvx::Analogs::VOL_R)) * 1023.99f);
        } else {
            mouse_update();
            vol_left = KFCA_VOLL;
            vol_right = KFCA_VOLR;
        }

        // save volumes in buffer
        KFCA_CONTROL_STATUS_BUFFER[input_offset + 16 + 0] |= (unsigned char) ((vol_left << 6) & 0xFF);
        KFCA_CONTROL_STATUS_BUFFER[input_offset + 16 + 1] |= (unsigned char) ((vol_left >> 2) & 0xFF);
        KFCA_CONTROL_STATUS_BUFFER[input_offset + 16 + 2] |= (unsigned char) ((vol_right << 6) & 0xFF);
        KFCA_CONTROL_STATUS_BUFFER[input_offset + 16 + 3] |= (unsigned char) ((vol_right >> 2) & 0xFF);
    }

    // BS
    if (avs::game::is_model("NBT")) {

        // get buttons
        auto buttons = games::bs::get_buttons();

        // test
        if (Buttons::getState(RI_MGR, buttons->at(games::bs::Buttons::Test)))
            KFCA_CONTROL_STATUS_BUFFER[input_offset + 1] |= 0x20;

        // service
        if (Buttons::getState(RI_MGR, buttons->at(games::bs::Buttons::Service)))
            KFCA_CONTROL_STATUS_BUFFER[input_offset + 1] |= 0x10;

        // coin
        if (Buttons::getState(RI_MGR, buttons->at(games::bs::Buttons::CoinMech)))
            KFCA_CONTROL_STATUS_BUFFER[input_offset + 1] |= 0x04;
    }

    // Nostalgia
    if (avs::game::is_model("PAN")) {

        // get buttons
        auto buttons = games::nost::get_buttons();

        // service
        if (Buttons::getState(RI_MGR, buttons->at(games::nost::Buttons::Service)))
            KFCA_CONTROL_STATUS_BUFFER[input_offset + 1] |= 0x10;

        // test
        if (Buttons::getState(RI_MGR, buttons->at(games::nost::Buttons::Test)))
            KFCA_CONTROL_STATUS_BUFFER[input_offset + 1] |= 0x20;

        // coin mech
        if (Buttons::getState(RI_MGR, buttons->at(games::nost::Buttons::CoinMech)))
            KFCA_CONTROL_STATUS_BUFFER[input_offset + 1] |= 0x04;
    }
}

/*
 * Implementations
 */

static int __cdecl ac_io_kfca_control_button_led(unsigned int button, bool state) {

    // control mapping
    static size_t mapping[] = {
            games::sdvx::Lights::BT_A,
            games::sdvx::Lights::BT_B,
            games::sdvx::Lights::BT_C,
            games::sdvx::Lights::BT_D,
            games::sdvx::Lights::FX_L,
            games::sdvx::Lights::FX_R,
            games::sdvx::Lights::START,
            games::sdvx::Lights::GENERATOR_B,
    };

    // check if button is mapped
    if (button < 8) {

        // get lights
        auto lights = games::sdvx::get_lights();

        // write light
        float value = state ? 1.f : 0.f;
        Lights::writeLight(RI_MGR, lights->at(mapping[button]), value);
    }

    // return success
    return 1;
}

static int __cdecl ac_io_kfca_control_coin_blocker_close(int a1) {
    eamuse_coin_set_block(true);
    return 1;
}

static int __cdecl ac_io_kfca_control_coin_blocker_open(int a1) {
    eamuse_coin_set_block(false);
    return 1;
}

static int __cdecl ac_io_kfca_control_led_bright(int led_field, uint8_t brightness) {

    // get lights
    auto lights = games::sdvx::get_lights();

    // control mapping
    static size_t mapping[] = {
            games::sdvx::Lights::WING_LEFT_UP_R,
            games::sdvx::Lights::WING_LEFT_UP_G,
            games::sdvx::Lights::WING_LEFT_UP_B,
            games::sdvx::Lights::WING_RIGHT_UP_R,
            games::sdvx::Lights::WING_RIGHT_UP_G,
            games::sdvx::Lights::WING_RIGHT_UP_B,
            games::sdvx::Lights::WING_LEFT_LOW_R,
            games::sdvx::Lights::WING_LEFT_LOW_G,
            games::sdvx::Lights::WING_LEFT_LOW_B,
            games::sdvx::Lights::WING_RIGHT_LOW_R,
            games::sdvx::Lights::WING_RIGHT_LOW_G,
            games::sdvx::Lights::WING_RIGHT_LOW_B,
            games::sdvx::Lights::WOOFER_R,
            games::sdvx::Lights::WOOFER_G,
            games::sdvx::Lights::WOOFER_B,
            games::sdvx::Lights::CONTROLLER_R,
            games::sdvx::Lights::CONTROLLER_G,
            games::sdvx::Lights::CONTROLLER_B,
            games::sdvx::Lights::GENERATOR_R,
            games::sdvx::Lights::GENERATOR_G,
    };

    // write light
    float value = brightness / 255.f;
    for (size_t i = 0; i < 20; i++)
        if (led_field & (1 << i))
            Lights::writeLight(RI_MGR, lights->at(mapping[i]), value);

    // return success
    return 1;
}

static char __cdecl ac_io_kfca_current_coinstock(int a1, DWORD *a2) {
    *a2 = (DWORD) eamuse_coin_get_stock();
    return 1;
}

static void *__cdecl ac_io_kfca_get_control_status_buffer(void *a1) {
    kfca_control_status_buffer_update();
    return memcpy(a1, KFCA_CONTROL_STATUS_BUFFER, 64);
}

static int __cdecl ac_io_kfca_lock_coincounter(int a1) {
    eamuse_coin_set_block(true);
    return 1;
}

static bool __cdecl ac_io_kfca_req_volume_control(char a1, char a2, char a3, char a4) {
    return true;
}

static bool __cdecl ac_io_kfca_set_watchdog_time(short a1) {
    return true;
}

static char __cdecl ac_io_kfca_unlock_coincounter(int a1) {
    eamuse_coin_set_block(false);
    return 1;
}

static char __cdecl ac_io_kfca_update_control_status_buffer() {
    return 1;
}

static void __cdecl ac_io_kfca_watchdog_off() {
}

/*
 * Module stuff
 */

acio::KFCAModule::KFCAModule(HMODULE module, acio::HookMode hookMode) : ACIOModule("KFCA", module, hookMode) {
}

void acio::KFCAModule::attach() {
    ACIOModule::attach();

    // hooks
    ACIO_MODULE_HOOK(ac_io_kfca_control_button_led);
    ACIO_MODULE_HOOK(ac_io_kfca_control_coin_blocker_close);
    ACIO_MODULE_HOOK(ac_io_kfca_control_coin_blocker_open);
    ACIO_MODULE_HOOK(ac_io_kfca_control_led_bright);
    ACIO_MODULE_HOOK(ac_io_kfca_current_coinstock);
    ACIO_MODULE_HOOK(ac_io_kfca_get_control_status_buffer);
    ACIO_MODULE_HOOK(ac_io_kfca_lock_coincounter);
    ACIO_MODULE_HOOK(ac_io_kfca_req_volume_control);
    ACIO_MODULE_HOOK(ac_io_kfca_set_watchdog_time);
    ACIO_MODULE_HOOK(ac_io_kfca_unlock_coincounter);
    ACIO_MODULE_HOOK(ac_io_kfca_update_control_status_buffer);
    ACIO_MODULE_HOOK(ac_io_kfca_watchdog_off);
}
