#ifndef SPICETOOLS_ACIO_KFCA_H
#define SPICETOOLS_ACIO_KFCA_H

#include "../module.h"

namespace acio {

    class KFCAModule : public ACIOModule {
    public:
        KFCAModule(HMODULE module, HookMode hookMode);

        virtual void attach() override;
    };
}

#endif //SPICETOOLS_ACIO_KFCA_H
