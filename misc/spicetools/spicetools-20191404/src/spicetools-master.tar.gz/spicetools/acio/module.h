#ifndef SPICETOOLS_ACIO_MODULE_H
#define SPICETOOLS_ACIO_MODULE_H

#include <string>
#include <windows.h>

// macro for lazy typing of hooks
#define ACIO_MODULE_HOOK(f) this->hook((void*) &f, #f)

namespace acio {

    /*
     * Hook Modes
     * Since some versions can't handle inline hooking
     */
    enum class HookMode {
        INLINE,
        IAT
    };

    // this makes logging easier
    std::string hookmode_tostr(HookMode hookMode);

    /*
     * The ACIO module itself
     * Inherit this for extending our libacio implementation
     */
    class ACIOModule {
    private:

        // settings
        std::string name;
        HMODULE module;
        HookMode hookMode;

    protected:

        // the magic
        void hook(void* func, std::string func_name);

    public:

        ACIOModule(std::string name, HMODULE module, HookMode hookMode);
        virtual ~ACIOModule() = default;

        virtual void attach();
    };
}

#endif //SPICETOOLS_ACIO_MODULE_H
