#include <windows.h>
#include <hooks/libraryhook.h>
#include <util/logging.h>
#include "stubs.h"


/*
 * export/import macros
 */

#if defined(STUB)
#define EXPORT __attribute__((visibility("default")))
#define IMPORT
#else
// needs to be __cdecl if we hook stuff at runtime
#define EXPORT __attribute__((visibility("default"))) __cdecl
#define IMPORT
#endif

/*
 * implementations
 */

extern "C" void EXPORT bt_fcheck_finish() {
    return;
}

extern "C" void EXPORT bt_fcheck_init() {
    return;
}

extern "C" int EXPORT bt_fcheck_main() {
    return 0;
}

extern "C" int EXPORT bt_get_ikey_status(stubs::ikey_status* status) {
    memset(status, 0, 32);
    for (int i = 0; i < 2; i++) {
        status[i].v2 = 1;
        status[i].v4 = 1;
        status[i].v7 = ~0u;
    }
    return 0;
}

extern "C" int EXPORT k_bt0001(stubs::ikey_status* status) {
    return bt_get_ikey_status(status);
}

extern "C" void EXPORT k_bt0002(void (__cdecl *func)(void *), void *arg) {
    if (&func != nullptr)
        func(arg);
}

/*
 * DLL entry function
 * for standalone stubs
 */
#ifdef STUB
BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved) {
    return TRUE;
}
#endif

/*
 * Dynamic hooks for use without kbt/kld DLL stubs
 * Should be called after all game DLLs are loaded in memory.
 * This works because most (all?) games use GetModuleHandle for those two.
 */
#ifndef STUB
void stubs::attach() {
    log_info("stubs", "attaching");
    libraryhook_hook_library("kbt.dll", GetModuleHandle(NULL));
    libraryhook_hook_library("kld.dll", GetModuleHandle(NULL));
    libraryhook_hook_proc("bt_fcheck_finish", (FARPROC) &bt_fcheck_finish);
    libraryhook_hook_proc("bt_fcheck_init", (FARPROC) &bt_fcheck_init);
    libraryhook_hook_proc("bt_fcheck_main", (FARPROC) &bt_fcheck_main);
    libraryhook_hook_proc("bt_get_ikey_status", (FARPROC) &bt_get_ikey_status);
    libraryhook_hook_proc("k_bt0001", (FARPROC) &k_bt0001);
    libraryhook_hook_proc("k_bt0002", (FARPROC) &k_bt0002);
    libraryhook_enable();
}
#endif
