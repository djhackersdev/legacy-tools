#include "light.h"
#include "rawinput/rawinput.h"
#include "rawinput/piuio.h"
#include "util/logging.h"
#include "util/utils.h"
#include "rawinput/sextet.h"

Light::Light(std::string lightName) {
    this->lightName = lightName;
    this->deviceIdentifier = "";
    this->index = 0;
}

std::string Light::getDisplayString(rawinput::RawInputManager* manager) {

    // get index string
    auto index = (uint16_t) this->getIndex();
    std::string indexString;
    if (index > 0xFF)
        indexString = bin2hex(&((char*) &index)[1], 1) + bin2hex(&((char*) &index)[0], 1);
    else
        indexString = bin2hex(&((char*) &index)[0], 1);

    // device must be existing
    if (this->deviceIdentifier.empty())
        return "";

    // get device
    auto device = manager->devices_get(this->deviceIdentifier);
    if (!device)
        return "Device missing (0x" + indexString + ")";

    // return string based on device type
    switch (device->type) {
        case rawinput::HID: {
            auto hid = device->hidInfo;

            // check button output caps
            if (index < hid->button_output_caps_names.size()) {
                return hid->button_output_caps_names[index] +
                    " (0x" + indexString + " - " + device->desc + ")";
            } else {
                index -= hid->button_output_caps_names.size();
            }

            // check value output caps
            if (index < hid->value_output_caps_names.size()) {
                return hid->value_output_caps_names[index] +
                    " (0x" + indexString + " - " + device->desc + ")";
            }

            // not found
            return "Invalid Light (0x" + indexString + ")";
        }
        case rawinput::SEXTET_OUTPUT: {

            // get light name of sextet device
            if (index < rawinput::SextetDevice::LIGHT_COUNT)
                return rawinput::SextetDevice::LIGHT_NAMES[index] + " (0x" + indexString + ")";

            // not found
            return "Invalid Sextet Light (0x" + indexString + ")";
        }
        case rawinput::PIUIO_DEVICE: {

            // get light name of PIUIO device
            if (index < rawinput::PIUIO::PIUIO_MAX_NUM_OF_LIGHTS)
                return rawinput::PIUIO::LIGHT_NAMES[index] + " (0x" + indexString + ")";

            return "Invalid PIUIO Light (0x" + indexString + ")";
        }
        default:
            return "Unknown Light (0x" + indexString + ")";
    }
}
