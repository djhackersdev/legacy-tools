#include "spicecfg.h"
#include "window.h"
#include "util/logging.h"
#include "games/bbc/io.h"
#include "games/bs/io.h"
#include "games/ddr/io.h"
#include "games/dea/io.h"
#include "games/gitadora/io.h"
#include "games/iidx/io.h"
#include "games/jb/io.h"
#include "games/mga/io.h"
#include "games/museca/io.h"
#include "games/nost/io.h"
#include "games/popn/io.h"
#include "games/rb/io.h"
#include "games/rf3d/io.h"
#include "games/sc/io.h"
#include "games/sdvx/io.h"
#include "games/qma/io.h"

#define USE_CONSOLE false

// standalone configuration utility
#ifdef SPICETOOLS_SPICECFG_STANDALONE

// config entry method
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    return spicecfg_run(std::vector<std::string>());
}

#endif

int spicecfg_run(std::vector<std::string> sextet_devices) {
    if (USE_CONSOLE) {

        // TODO: interactive CLI mode?
        AllocConsole();
        freopen("conin$", "r", stdin);
        freopen("conout$", "w", stdout);
        freopen("conout$", "w", stderr);
        return EXIT_SUCCESS;

    } else {

        // initialize config
        Config &config = Config::getInstance();
        if (!config.getStatus())
            return EXIT_FAILURE;

        // initialize window
        SpiceToolsWindow* spiceToolsWindow = SpiceToolsWindow::getInstance();
        for (auto device : sextet_devices)
            spiceToolsWindow->getRawInputManager()->sextet_register(device);

        // check if window was created successfully
        if (!spiceToolsWindow->isOpen())
            log_fatal("cfg", "Window couldn't be created");

        // initialize games
        std::vector<Game *> games;

        /*
         * Sound Voltex
         */
        Game *sdvx = new Game("Sound Voltex");
        sdvx->addDLLName("soundvoltex.dll");
        for (auto item : *games::sdvx::get_buttons())
            sdvx->addItems(item);
        for (auto item : *games::sdvx::get_analogs())
            sdvx->addItems(item);
        for (auto item : *games::sdvx::get_lights())
            sdvx->addItems(item);
        games.push_back(sdvx);

        /*
         * Beatmania IIDX
         */
        Game *iidx = new Game("Beatmania IIDX");
        iidx->addDLLName("bm2dx.dll");
        for (auto item : *games::iidx::get_buttons())
            iidx->addItems(item);
        for (auto item : *games::iidx::get_analogs())
            iidx->addItems(item);
        for (auto item : *games::iidx::get_lights())
            iidx->addItems(item);
        games.push_back(iidx);

        /*
         * Jubeat
         */
        Game *jubeat = new Game("Jubeat");
        jubeat->addDLLName("jubeat.dll");
        for (auto item : *games::jb::get_buttons())
            jubeat->addItems(item);
        for (auto item : *games::jb::get_lights())
            jubeat->addItems(item);
        games.push_back(jubeat);

        /*
         * Dance Evolution
         */
        Game *dea = new Game("Dance Evolution");
        dea->addDLLName("arkkdm.dll");
        for (auto item : *games::dea::get_buttons())
            dea->addItems(item);
        games.push_back(dea);

        /*
         * Dance Dance Revolution
         */
        Game *ddr = new Game("Dance Dance Revolution");
        ddr->addDLLName("ddr.dll");
        ddr->addDLLName("mdxja_945.dll");
        ddr->addDLLName("arkmdxp3.dll");
        for (auto item : *games::ddr::get_buttons())
            ddr->addItems(item);
        for (auto item : *games::ddr::get_lights())
            ddr->addItems(item);
        games.push_back(ddr);

        /*
         * Beatstream
         */
        Game *beatstream = new Game("Beatstream");
        beatstream->addDLLName("beatstream.dll");
        for (auto item : *games::bs::get_buttons())
            beatstream->addItems(item);
        games.push_back(beatstream);

        /*
         * Metal Gear
         */
        Game *metalGear = new Game("Metal Gear");
        metalGear->addDLLName("launch.dll");
        for (auto item : *games::mga::get_buttons())
            metalGear->addItems(item);
        for (auto item : *games::mga::get_analogs())
            metalGear->addItems(item);
        games.push_back(metalGear);

        /*
         * Reflec Beat
         */
        Game *reflecBeat = new Game("Reflec Beat");
        reflecBeat->addDLLName("reflecbeat.dll");
        for (auto item : *games::rb::get_buttons())
            reflecBeat->addItems(item);
        games.push_back(reflecBeat);

        /*
         * Pop'n Music
         */
        Game *popn = new Game("Pop'n Music");
        popn->addDLLName("popn21.dll");
        popn->addDLLName("popn22.dll");
        popn->addDLLName("popn23.dll");
        popn->addDLLName("popn24.dll");
        for (auto item : *games::popn::get_buttons())
            popn->addItems(item);
        for (auto item : *games::popn::get_lights())
            popn->addItems(item);
        games.push_back(popn);

        /*
         * Steel Chronicles
         */
        Game *steelChronicles = new Game("Steel Chronicles");
        steelChronicles->addDLLName("gamekgg.dll");
        for (auto item : *games::sc::get_buttons())
            steelChronicles->addItems(item);
        games.push_back(steelChronicles);

        /*
         * Road Fighters 3D
         */
        Game *rf3d = new Game("Road Fighters 3D");
        rf3d->addDLLName("jgt.dll");
        for (auto item : *games::rf3d::get_buttons())
            rf3d->addItems(item);
        for (auto item : *games::rf3d::get_analogs())
            rf3d->addItems(item);
        games.push_back(rf3d);

        /*
         * Museca
         */
        Game *museca = new Game("Museca");
        museca->addDLLName("museca.dll");
        for (auto item : *games::museca::get_buttons())
            museca->addItems(item);
        for (auto item : *games::museca::get_analogs())
            museca->addItems(item);
        for (auto item : *games::museca::get_lights())
            museca->addItems(item);
        games.push_back(museca);

        /*
         * Bishi Bashi Channel
         */
        Game *bbc = new Game("Bishi Bashi Channel");
        bbc->addDLLName("bsch.dll");
        for (auto item : *games::bbc::get_buttons())
            bbc->addItems(item);
        for (auto item : *games::bbc::get_analogs())
            bbc->addItems(item);
        for (auto item : *games::bbc::get_lights())
            bbc->addItems(item);
        games.push_back(bbc);

        /*
         * GitaDora
         */
        Game *gitaDora = new Game("GitaDora");
        gitaDora->addDLLName("gdxg.dll");
        for (auto item : *games::gitadora::get_buttons())
            gitaDora->addItems(item);
        for (auto item : *games::gitadora::get_analogs())
            gitaDora->addItems(item);
        games.push_back(gitaDora);

        /*
         * Nostalgia
         */
        Game *nostalgia = new Game("Nostalgia");
        nostalgia->addDLLName("nostalgia.dll");
        for (auto item : *games::nost::get_buttons())
            nostalgia->addItems(item);
        for (auto item : *games::nost::get_analogs())
            nostalgia->addItems(item);
        games.push_back(nostalgia);

        /*
         * Quiz Magic Academy
         */
        Game *qma = new Game("Quiz Magic Academy");
        qma->addDLLName("client.dll");
        for (auto item : *games::qma::get_buttons())
            qma->addItems(item);
        for (auto item : *games::qma::get_lights())
            qma->addItems(item);
        games.push_back(qma);

        // add games to the config and window
        for (auto &game : games) {
            config.addGame(game);
            if (!config.getStatus()) {
                return EXIT_FAILURE;
            }
            spiceToolsWindow->addGames(game);
        }

        // main window loop
        while (spiceToolsWindow->isOpen()) {
            spiceToolsWindow->poll();
        }

        // clean up
        for (auto &game : games) {
            for (auto &bt : *game->getButtons()) {
                delete bt;
            }
            delete game;
        }

        return static_cast<int>(spiceToolsWindow->getFinalMsg());
    }
}
