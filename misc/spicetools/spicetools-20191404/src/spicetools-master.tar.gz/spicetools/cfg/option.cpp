#include "option.h"

Option::Option(std::string optionName) {
    this->optionName = optionName;
    this->optionValue = "";
}

Option::Option(std::string optionName, std::string optionValue) {
    this->optionName = optionName;
    this->optionValue = optionValue;
}

std::string Option::getName() {
    return this->optionName;
}

std::string Option::getValue() {
    return this->optionValue;
}

void Option::setValue(std::string optionValue) {
    this->optionValue = optionValue;
}
