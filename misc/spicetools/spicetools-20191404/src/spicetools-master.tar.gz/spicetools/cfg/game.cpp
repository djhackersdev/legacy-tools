#include "game.h"

///////////////////
/// Constructor ///
///////////////////

Game::Game(std::string gameName) {
    this->gameName = std::move(gameName);
}


/////////////////////
/// Deconstructor ///
/////////////////////

Game::~Game() = default;


////////////////////////
/// Public Functions ///
////////////////////////

std::string Game::getGameName() {
    return this->gameName;
}

std::vector<std::string> *Game::getDLLNames() {
    return &this->dllNames;
};

std::vector<Button *> *Game::getButtons() {
    return &this->buttons;
}

std::vector<Analog *> *Game::getAnalogs() {
    return &this->analogs;
}

std::vector<Light *> *Game::getLights() {
    return &this->lights;
}

std::vector<Option *> *Game::getOptions() {
    return &this->options;
}


///////////////////////////
/// Protected Functions ///
///////////////////////////


/////////////////////////
/// Private Functions ///
/////////////////////////

// add button items
void Game::addItem(Button *button) {
    this->buttons.push_back(button);
}

// add analog items
void Game::addItem(Analog *analog) {
    this->analogs.push_back(analog);
}

// add light items
void Game::addItem(Light *light) {
    this->lights.push_back(light);
}

// add option items
void Game::addItem(Option *option) {
    this->options.push_back(option);
}
