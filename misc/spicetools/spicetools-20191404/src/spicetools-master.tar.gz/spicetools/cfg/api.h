#ifndef SPICETOOLS_CFG_API_H
#define SPICETOOLS_CFG_API_H

#include <windows.h>
#include <string>
#include <vector>
#include "analog.h"

namespace rawinput {
    class RawInputManager;
    class Device;
}
class Game;
class Button;
class Analog;
class Light;
class Option;

namespace GameAPI {
    namespace Buttons {
        enum State {
            BUTTON_PRESSED = true,
            BUTTON_NOT_PRESSED = false
        };

        /**
         * Parses the config and returns the buttons set by the user.
         *
         * @param a std::string containing the game name OR a pointer to a Game
         * @return a vector pointer containing pointers of Button's set by the user
         */
        std::vector<Button *> *getButtons(std::string);

        std::vector<Button *> *getButtons(Game *);

        /**
         * Sorts Buttons by their name
         *
         * @param a pointer to a vector pointer of Button pointers that will be sorted by the order of a vector pointer of strings
         *        OR a parameter pack of std::string... can be used.
         * @return void
         */
        void sortButtons(std::vector<Button *> **, std::vector<std::string> *);

        template<typename T>
        void sortButtons(std::vector<Button *> **buttons, T t) {
            std::vector<std::string> *buttonNames = new std::vector<std::string>{t};
            GameAPI::Buttons::sortButtons(buttons, buttonNames);
            delete buttonNames;
        }

        template<typename T, typename... Rest>
        void sortButtons(std::vector<Button *> **buttons, T t, Rest... rest) {
            std::vector<std::string> *buttonNamesVector = new std::vector<std::string>{t, rest...};
            GameAPI::Buttons::sortButtons(buttons, buttonNamesVector);
            delete buttonNamesVector;
        }

        /**
         * Returns the state of whether a button is pressed or not.
         * Highly recommended to use either of these two functions than the other two below them.
         *
         * @return either a GameAPI::Buttons::State::BUTTON_PRESSED or a Game::API::Buttons::State::BUTTON_NOT_PRESSED
         */
        GameAPI::Buttons::State getState(rawinput::RawInputManager* manager, Button* button, bool check_alts = true);

        /**
         * Returns the current velocity of a button.
         * When not pressed, the returned velocity is 0.
         * When pressed, the velocity can be anywhere in the range [0, 1]
         * @return velocity in the range [0, 1]
         */
        float getVelocity(rawinput::RawInputManager* manager, Button* button);
    }

    namespace Analogs {

        std::vector<Analog *> *getAnalogs(std::string gameName);

        void sortAnalogs(std::vector<Analog *> **, std::vector<std::string> *);

        template<typename T>
        void sortAnalogs(std::vector<Analog *> **analogs, T t) {
            std::vector<std::string> *analogNames = new std::vector<std::string>{t};
            GameAPI::Analogs::sortAnalogs(analogs, analogNames);
            delete analogNames;
        }

        template<typename T, typename... Rest>
        void sortAnalogs(std::vector<Analog *> **analogs, T t, Rest... rest) {
            std::vector<std::string> *analogNamesVector = new std::vector<std::string>{t, rest...};
            GameAPI::Analogs::sortAnalogs(analogs, analogNamesVector);
            delete analogNamesVector;
        }

        float getState(rawinput::Device* device, int index, float sensivity, bool inverted);

        float getState(rawinput::RawInputManager* manager, Analog* analog);
    }

    namespace Lights {

        std::vector<Light *> *getLights(std::string gameName);

        void sortLights(std::vector<Light *> **, std::vector<std::string> *);

        template<typename T>
        void sortLights(std::vector<Light *> **lights, T t) {
            std::vector<std::string> *lightNames = new std::vector<std::string>{t};
            GameAPI::Lights::sortLights(lights, lightNames);
            delete lightNames;
        }

        template<typename T, typename... Rest>
        void sortLights(std::vector<Light *> **lights, T t, Rest... rest) {
            std::vector<std::string> *lightNamesVector = new std::vector<std::string>{t, rest...};
            GameAPI::Lights::sortLights(lights, lightNamesVector);
            delete lightNamesVector;
        }

        void writeLight(rawinput::Device* device, int index, float value);
        void writeLight(rawinput::RawInputManager* manager, Light* light, float value);

        float readLight(rawinput::Device* device, int index);
        float readLight(rawinput::RawInputManager* manager, Light* light);
    }
}


#endif //SPICETOOLS_CFG_API_H
