#include "light_binding_dialog.h"
#include "util/logging.h"
#include "util/utils.h"
#include "rawinput/piuio.h"


static const HICON WINDOW_ICON = LoadIcon(GetModuleHandle(nullptr), MAKEINTRESOURCE(MAINICON));
static const HICON WINDOW_SM_ICON = LoadIcon(GetModuleHandle(nullptr), MAKEINTRESOURCE(MAINICON));
static const std::string WINDOW_CLASS_NAME = "LightBindingDialog";
static const std::string WINDOW_TITLE_TEXT = "Light Binding";
static const int WINDOW_SIZE_X = 360;
static const int WINDOW_SIZE_Y = 240;

// commands
static const int DEVICE_SELECT_SWITCH = 300;
static const int LIGHT_SELECT_SWITCH = 400;
static const int BUTTON_APPLY = 500;
static const int BUTTON_CANCEL = 501;
static const int BUTTON_TURNON = 502;
static const int BUTTON_TURNOFF = 503;
static const int VALUE_TRACKBAR = 504;

LightBindingDialog::LightBindingDialog(SpiceToolsWindow *config_window, HWND parent) {
    this->config_window = config_window;
    this->parent = parent;

    // build window title
    this->light = config_window->getSelectedLight();
    if (this->light)
        this->title = WINDOW_TITLE_TEXT + " (" + light->getName() + ")";
    else
        return;

    // get devices
    auto devices_all = config_window->getRawInputManager()->devices_get();
    for (auto &device : *devices_all) {
        switch (device.type) {
            case rawinput::HID:
                if (!device.hidInfo->button_output_caps_list.empty()
                        || !device.hidInfo->value_output_caps_list.empty())
                    this->devices.emplace_back(&device);
                break;
            case rawinput::SEXTET_OUTPUT:
            case rawinput::PIUIO_DEVICE:
                this->devices.emplace_back(&device);
                break;
            default:
                continue;
        }

        // check if this is the current device
        if (device.name == this->light->getDeviceIdentifier()) {
            this->device_selected = (int) this->devices.size() - 1;
            this->light_selected = this->light->getIndex();
        }
    }

    // build window class
    memset(&this->wc, 0, sizeof(WNDCLASSEX));
    this->wc.cbSize = sizeof(WNDCLASSEX);
    this->wc.style = 0;
    this->wc.lpfnWndProc = &LightBindingDialog::wnd_proc;
    this->wc.cbClsExtra = 0;
    this->wc.cbWndExtra = 0;
    this->wc.hInstance = GetModuleHandle(nullptr);
    this->wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    this->wc.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1);
    this->wc.lpszMenuName = nullptr;
    this->wc.lpszClassName = WINDOW_CLASS_NAME.c_str();
    this->wc.hIconSm = WINDOW_SM_ICON;
    this->wc.hIcon = WINDOW_ICON;

    // register window class
    if (!RegisterClassEx(&wc))
        log_fatal("cfg", "Unable to register window class.");

    // create window
    this->hwnd = CreateWindowEx(
            WS_EX_CLIENTEDGE,
            WINDOW_CLASS_NAME.c_str(),
            this->title.c_str(),
            WS_POPUPWINDOW | WS_SYSMENU | WS_OVERLAPPED | WS_CAPTION,
            CW_USEDEFAULT,
            CW_USEDEFAULT,
            WINDOW_SIZE_X,
            WINDOW_SIZE_Y,
            this->parent,
            nullptr,
            GetModuleHandle(nullptr),
            this
    );

    // check window
    if (this->hwnd == nullptr)
        log_fatal("cfg", "Couldn't open light binding dialog: " + to_string(GetLastError()));

    // show window
    this->open = true;
    ShowWindow(this->hwnd, SW_SHOWNORMAL);
    UpdateWindow(this->hwnd);

    // disable parent window
    EnableWindow(this->parent, FALSE);

    // set current device
    for (size_t device_index = 0; device_index < this->devices.size(); device_index++) {

        // check if this is the current device
        if (this->devices[device_index]->name == this->light->getDeviceIdentifier()) {
            this->device_set((int) device_index);
            this->light_set(this->light->getIndex());
            break;
        }
    }
}

LightBindingDialog::~LightBindingDialog() {
    DestroyWindow(this->hwnd);
    while (this->isOpen()) {
        this->poll();
    }
    UnregisterClass(WINDOW_CLASS_NAME.c_str(), GetModuleHandle(nullptr));
}

void LightBindingDialog::poll() {
    if (GetMessage(&this->msg, nullptr, 0, 0) > 0) {
        TranslateMessage(&this->msg);
        DispatchMessage(&this->msg);
    } else {
        this->open = false;
    }
}

LRESULT CALLBACK LightBindingDialog::wnd_proc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {
    auto instance = (LightBindingDialog*)(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
    switch (msg) {
        case WM_CTLCOLORSTATIC: {
            SetTextColor((HDC) wparam, RGB(0,0,0));
            return (LRESULT) CreateSolidBrush(RGB(255, 255, 255));
        }
        case WM_CREATE: {

            // set user data of window to class pointer
            auto pcs = (LPCREATESTRUCT) lparam;
            instance = (LightBindingDialog *) pcs->lpCreateParams;
            SetWindowLongPtrW(hwnd, GWLP_USERDATA, PtrToUlong(instance));

            // device label
            HWND device_label = CreateWindowEx(
                    WS_EX_TRANSPARENT,
                    WC_STATIC,
                    "",
                    WS_CHILD | WS_VISIBLE | SS_LEFT | WS_SYSMENU,
                    10, 10,
                    WINDOW_SIZE_X - 10, 15,
                    hwnd,
                    nullptr,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            instance->config_window->setDefaultFont(device_label);
            SetWindowText(device_label, "Device");

            // device select
            instance->device_select_hwnd = CreateWindow(
                    WC_COMBOBOX,
                    TEXT(""),
                    CBS_DROPDOWNLIST | CBS_HASSTRINGS | WS_CHILD | WS_OVERLAPPED | WS_VISIBLE,
                    10, 30,
                    WINDOW_SIZE_X - 20, 30,
                    hwnd,
                    reinterpret_cast<HMENU>(DEVICE_SELECT_SWITCH),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            instance->config_window->setDefaultFont(instance->device_select_hwnd);
            ComboBox_SetMinVisible(instance->device_select_hwnd, 256);

            // add devices
            for (auto device : instance->devices) {
                SendMessage(
                        instance->device_select_hwnd,
                        (UINT) CB_ADDSTRING,
                        (WPARAM) 0,
                        (LPARAM) device->desc.c_str()
                );
            }

            // light label
            HWND light_label = CreateWindowEx(
                    WS_EX_TRANSPARENT,
                    WC_STATIC,
                    "",
                    WS_CHILD | WS_VISIBLE | SS_LEFT | WS_SYSMENU,
                    10, 60,
                    WINDOW_SIZE_X - 10, 15,
                    hwnd,
                    nullptr,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            instance->config_window->setDefaultFont(light_label);
            SetWindowText(light_label, "Light Control");

            // light select
            instance->light_select_hwnd = CreateWindow(
                    WC_COMBOBOX,
                    TEXT(""),
                    CBS_DROPDOWNLIST | CBS_HASSTRINGS | WS_CHILD | WS_OVERLAPPED | WS_VISIBLE,
                    10, 80,
                    WINDOW_SIZE_X - 20, 30,
                    hwnd,
                    reinterpret_cast<HMENU>(LIGHT_SELECT_SWITCH),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            instance->config_window->setDefaultFont(instance->light_select_hwnd);
            ComboBox_SetMinVisible(instance->light_select_hwnd, 256);

            // test label
            HWND test_label = CreateWindowEx(
                    WS_EX_TRANSPARENT,
                    WC_STATIC,
                    "",
                    WS_CHILD | WS_VISIBLE | SS_LEFT | WS_SYSMENU,
                    10, 110,
                    WINDOW_SIZE_X - 10, 15,
                    hwnd,
                    nullptr,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            instance->config_window->setDefaultFont(test_label);
            SetWindowText(test_label, "Test");

            // turn on button
            HWND button_turnon = CreateWindow(
                    WC_BUTTON,
                    "Turn on",
                    WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,
                    10,
                    130,
                    64,
                    24,
                    hwnd,
                    reinterpret_cast<HMENU>(BUTTON_TURNON),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            instance->config_window->setDefaultFont(button_turnon);

            // turn off button
            HWND button_turnoff = CreateWindow(
                    WC_BUTTON,
                    "Turn off",
                    WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,
                    80,
                    130,
                    64,
                    24,
                    hwnd,
                    reinterpret_cast<HMENU>(BUTTON_TURNOFF),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            instance->config_window->setDefaultFont(button_turnoff);

            // value trackbar
            instance->value_trackbar_hwnd = CreateWindowEx(
                    0,
                    TRACKBAR_CLASS,
                    "Sensivity",
                    WS_CHILD | WS_VISIBLE,
                    150, 124,
                    WINDOW_SIZE_X - 165, 30,
                    hwnd,
                    (HMENU) VALUE_TRACKBAR,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            SendMessage(instance->value_trackbar_hwnd, TBM_SETRANGE, (WPARAM) TRUE, (LPARAM) MAKELONG(0, 100));
            SendMessage(instance->value_trackbar_hwnd, TBM_SETPOS, (WPARAM) TRUE, (LPARAM) 50);
            for (int i = 0; i <= 100; i += 10)
                SendMessage(instance->value_trackbar_hwnd, TBM_SETTIC, (WPARAM) TRUE, (LPARAM) i);

            // apply button
            HWND button_apply = CreateWindow(
                    WC_BUTTON,
                    "Apply",
                    WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,
                    WINDOW_SIZE_X - WINDOW_SIZE_X / 2,
                    WINDOW_SIZE_Y - 60,
                    WINDOW_SIZE_X / 2 - 15,
                    24,
                    hwnd,
                    reinterpret_cast<HMENU>(BUTTON_APPLY),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            instance->config_window->setDefaultFont(button_apply);

            // cancel button
            HWND button_cancel = CreateWindow(
                    WC_BUTTON,
                    "Cancel",
                    WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,
                    5,
                    WINDOW_SIZE_Y - 60,
                    WINDOW_SIZE_X / 2 - 15,
                    24,
                    hwnd,
                    reinterpret_cast<HMENU>(BUTTON_CANCEL),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            instance->config_window->setDefaultFont(button_cancel);

            // set to first device
            if (!instance->devices.empty())
                instance->device_set(0);

            break;
        }
        case WM_COMMAND: {

            // check command
            switch (LOWORD(wparam)) {
                case BUTTON_APPLY:
                    switch (HIWORD(wparam)) {
                        case BN_CLICKED: {

                            // save binding
                            if (instance->light_selected < 0)
                                break;
                            if ((size_t) instance->device_selected >= instance->devices.size())
                                break;
                            auto device = instance->devices[instance->device_selected];
                            instance->light->setDeviceIdentifier(device->name);
                            instance->light->setIndex((unsigned short) instance->light_selected);
                            instance->config_window->updateBindings(instance->light);

                            // close window
                            PostMessage(hwnd, WM_CLOSE, 0, 0);
                            break;
                        }
                        default:
                            break;
                    }
                    break;
                case BUTTON_CANCEL:
                    switch (HIWORD(wparam)) {
                        case BN_CLICKED: {

                            // close without saving binding
                            PostMessage(hwnd, WM_CLOSE, 0, 0);
                            break;
                        }
                        default:
                            break;
                    }
                    break;
                case BUTTON_TURNON:
                    switch (HIWORD(wparam)) {
                        case BN_CLICKED: {

                            // check if device is existing
                            if ((size_t) instance->device_selected >= instance->devices.size())
                                break;

                            // write light
                            GameAPI::Lights::writeLight(
                                    instance->devices[instance->device_selected],
                                    instance->light_selected, 1.f);
                            instance->config_window->getRawInputManager()->devices_flush_output();

                            // set trackbar
                            SendMessage(instance->value_trackbar_hwnd, TBM_SETPOS, TRUE, 100);

                            break;
                        }
                        default:
                            break;
                    }
                    break;
                case BUTTON_TURNOFF:
                    switch (HIWORD(wparam)) {
                        case BN_CLICKED: {

                            // check if device is existing
                            if ((size_t) instance->device_selected >= instance->devices.size())
                                break;

                            // write light
                            GameAPI::Lights::writeLight(
                                    instance->devices[instance->device_selected],
                                    instance->light_selected, 0.f);
                            instance->config_window->getRawInputManager()->devices_flush_output();

                            // set trackbar
                            SendMessage(instance->value_trackbar_hwnd, TBM_SETPOS, TRUE, 0);

                            break;
                        }
                        default:
                            break;
                    }
                    break;
                case DEVICE_SELECT_SWITCH:

                    // check combo box command
                    switch (HIWORD(wparam)) {
                        case CBN_SELCHANGE: {

                            // select device
                            instance->device_set(
                                    SendMessage(
                                            instance->device_select_hwnd,
                                            CB_GETCURSEL,
                                            (WPARAM) 0,
                                            (LPARAM) 0
                                    )
                            );
                            break;
                        }
                        default:
                            break;
                    }
                    break;
                case LIGHT_SELECT_SWITCH:

                    // check light box command
                    switch (HIWORD(wparam)) {
                        case CBN_SELCHANGE: {

                            // select light
                            instance->light_set(
                                    SendMessage(
                                            instance->light_select_hwnd,
                                            CB_GETCURSEL,
                                            (WPARAM) 0,
                                            (LPARAM) 0
                                    )
                            );
                            break;
                        }
                        default:
                            break;
                    }
                    break;
                default:
                    break;
            }
            break;
        }
        case WM_HSCROLL: {

            // get sensivity
            auto pos = SendMessage(instance->value_trackbar_hwnd, TBM_GETPOS, 0, 0);

            // set light value
            auto value = pos / 100.f;
            GameAPI::Lights::writeLight(
                    instance->devices[instance->device_selected],
                    instance->light_selected, value);
            instance->config_window->getRawInputManager()->devices_flush_output();

            break;
        }
        case WM_CLOSE:

            // enable parent window
            EnableWindow(instance->parent, TRUE);

            // call destroy
            DestroyWindow(hwnd);
            return 0;

        case WM_DESTROY:

            // mark as closed
            instance->open = false;
            return 0;

        default:
            break;
    }
    return DefWindowProc(hwnd, msg, wparam, lparam);
}

void LightBindingDialog::device_set(int device_no) {

    // clean up light combo box
    SendMessage(
            this->light_select_hwnd,
            CB_RESETCONTENT,
            (WPARAM) 0,
            (LPARAM) 0
    );

    // get device
    if (device_no < 0 || (size_t) device_no >= this->devices.size())
        return;
    auto device = this->devices[device_no];

    // set selection
    this->device_selected = device_no;
    SendMessage(
            this->device_select_hwnd,
            CB_SETCURSEL,
            (WPARAM) device_no,
            (LPARAM) 0
    );

    // add light names based on device type
    switch (device->type) {
        case rawinput::HID: {
            size_t index = 0;

            // add button names
            for (auto &button_name : device->hidInfo->button_output_caps_names) {

                // build name
                std::string name = button_name;
                if (index > 0xFF)
                    name += " (0x" + bin2hex(&((char*) &index)[1], 1) + bin2hex(&((char*) &index)[0], 1) + ")";
                else
                    name += " (0x" + bin2hex(&((char*) &index)[0], 1) + ")";

                // add name
                SendMessage(
                        this->light_select_hwnd,
                        (UINT) CB_ADDSTRING,
                        (WPARAM) 0,
                        (LPARAM) name.c_str()
                );
                index++;
            }

            // add value names
            for (auto &value_name : device->hidInfo->value_output_caps_names) {

                // build name
                std::string name = value_name;
                if (index > 0xFF)
                    name += " (0x" + bin2hex(&((char*) &index)[1], 1)
                            + bin2hex(&((char*) &index)[0], 1)
                            + ", value cap)";
                else
                    name += " (0x" + bin2hex(&((char*) &index)[0], 1) + ", value cap)";

                // add name
                SendMessage(
                        this->light_select_hwnd,
                        (UINT) CB_ADDSTRING,
                        (WPARAM) 0,
                        (LPARAM) name.c_str()
                );
                index++;
            }

            break;
        }
        case rawinput::SEXTET_OUTPUT: {

            // add all names of sextet device
            for (int i = 0; i < rawinput::SextetDevice::LIGHT_COUNT; i++) {
                std::string name(rawinput::SextetDevice::LIGHT_NAMES[i]);

                // add name
                SendMessage(
                    this->light_select_hwnd,
                    (UINT) CB_ADDSTRING,
                    (WPARAM) 0,
                    (LPARAM) name.c_str()
                );
            }
            break;
        }
        case rawinput::PIUIO_DEVICE: {

            // add all names of PIUIO device
            for (int i = 0; i < rawinput::PIUIO::PIUIO_MAX_NUM_OF_LIGHTS; i++) {
                std::string name(rawinput::PIUIO::LIGHT_NAMES[i]);

                // add name
                SendMessage(
                    this->light_select_hwnd,
                    (UINT) CB_ADDSTRING,
                    (WPARAM) 0,
                    (LPARAM) name.c_str()
                );
            }
            break;
        }
        default:
            break;
    }

    // automatically select first light
    light_set(0);
}

void LightBindingDialog::light_set(int light_no) {
    this->light_selected = light_no;

    // set selection
    SendMessage(
            this->light_select_hwnd,
            CB_SETCURSEL,
            (WPARAM) light_no,
            (LPARAM) 0
    );

    // get value
    auto value = GameAPI::Lights::readLight(this->devices[this->device_selected], this->light_selected);

    // set trackbar
    SendMessage(this->value_trackbar_hwnd, TBM_SETPOS, TRUE, (LPARAM) (value * 100));
}
