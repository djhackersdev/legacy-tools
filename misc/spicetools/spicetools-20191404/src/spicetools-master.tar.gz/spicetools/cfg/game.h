#ifndef SPICETOOLS_CFG_GAME_H
#define SPICETOOLS_CFG_GAME_H

#include <vector>
#include <typeinfo>
#include <iostream>

#include "button.h"
#include "analog.h"
#include "light.h"
#include "option.h"
#include "external/tinyxml2/tinyxml2.h"

class Game {
public:
    explicit Game(std::string);

    template<typename T, typename... Rest>
    Game(std::string gameName) {
        this->gameName = gameName;
    };

    ~Game();

    std::string getGameName();
    std::vector<std::string> *getDLLNames();

    void addDLLName(std::string dllName) {
        this->dllNames.push_back(dllName);
    }

    template<typename T>
    void addItems(T t) {
        this->addItem(t);
    }

    template<typename T, typename... Rest>
    void addItems(T t, Rest... rest) {
        this->addItem(t);
        this->addItems(rest...);
    }

    std::vector<Button *> *getButtons();

    std::vector<Analog *> *getAnalogs();

    std::vector<Light *> *getLights();

    std::vector<Option *> *getOptions();

private:
    std::string gameName;
    std::vector<std::string> dllNames;
    std::vector<Button *> buttons;
    std::vector<Analog *> analogs;
    std::vector<Light *> lights;
    std::vector<Option *> options;


    void addItem(Button *);
    void addItem(Analog *);
    void addItem(Light *);
    void addItem(Option *);

};

#endif //SPICETOOLS_CFG_GAME_H
