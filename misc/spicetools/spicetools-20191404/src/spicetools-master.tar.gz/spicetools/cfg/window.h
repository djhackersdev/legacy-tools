#ifndef SPICETOOLS_CFG_WINDOW_H
#define SPICETOOLS_CFG_WINDOW_H

#include <vector>
#include <windows.h>
#include <commctrl.h>
#include <algorithm>
#include <thread>
#include <mutex>
#include <sstream>
#include "resource.h"
#include "config.h"
#include "icon.h"
#include "rawinput/rawinput.h"


//////////////////////////////////////
/// SpiceToolsWindow               ///
/// Singleton Class                ///
/// Used to manage the main window ///
//////////////////////////////////////
class SpiceToolsWindow {
public:
    // Public Singleton Functions
    static SpiceToolsWindow* getInstance();

    // Public Functions
    bool isOpen();

    void poll();

    WPARAM getFinalMsg();

    template<typename T>
    void addGames(T t) {
        this->addGame(t);
    }

    template<typename T, typename... Rest>
    void addGames(T t, Rest... rest) {
        this->addGame(t);
        this->addGames(rest...);
    }

    void setSelectedGame(Game *);

    void setSelectedGame(std::string);

    void setSelectedGame(unsigned long long int);

    Analog* getSelectedAnalog();
    Light* getSelectedLight();
    void updateBindings(Analog* analog);
    void updateBindings(ConfigKeypadBindings keypadBindings);
    void updateBindings(Light* light);
    ConfigKeypadBindings getKeypadBindings();
    rawinput::Device* getKeypadDevice(int index);

    inline rawinput::RawInputManager* getRawInputManager() {
        return &this->rawInputManager;
    }

    // for setting a control to the default font
    inline void setDefaultFont(HWND control) {
        SendMessage(control, WM_SETFONT, (WPARAM) this->defaultFont, TRUE);
    }

    // for setting a control to the monospace font
    inline void setMonospaceFont(HWND control) {
        SendMessage(control, WM_SETFONT, (WPARAM) this->monospaceFont, TRUE);
    }

private:
    // Private Variables
    const char g_szClassName[22] = "spiceToolsWindowClass";

    HWND hwnd;
    HWND hwndTabControl;
    HWND hwndTabControlSelected;
    HWND hwndButtons;
    HWND hwndButtonsAlternative;
    HWND hwndAnalogs;
    HWND hwndKeypads;
    HWND hwndKeypadsBox[2];
    HWND hwndKeypadsTest[2];
    HWND hwndCards[2];
    HWND hwndLights;
    HWND hwndLightsAlternative;
    HWND hwndOptions;
    HWND hwndAbout;
    HWND hwndLicenses;
    HWND hwndComboBoxGameSwitcher;
    HWND hwndButtonsListViewSelectedGame;
    HWND hwndAnalogsListViewSelectedGame;
    HWND hwndLightsListViewSelectedGame;
    HWND hwndOptionsListViewSelectedGame;

    HFONT defaultFont;
    HFONT monospaceFont;

    MSG Msg;
    WNDCLASSEX wc;
    INITCOMMONCONTROLSEX icex;

    int selectedKeyBinding;
    int selectedKeyAlternative = -1;
    int selectedAnalogBinding;
    int selectedKeypad[2];
    int selectedLightBinding;
    int selectedLightAlternative = -1;
    long long int selectedGame;
    std::thread* keypadThread = nullptr;

    bool stillOpen;
    rawinput::RawInputManager rawInputManager;
    std::vector<Game *> games;

    // Private Singleton Functions
    SpiceToolsWindow();

    virtual ~SpiceToolsWindow();

    SpiceToolsWindow(const SpiceToolsWindow &);

    const SpiceToolsWindow &operator=(const SpiceToolsWindow &);

    // Private Functions
    static BOOL CALLBACK GetButtonBindingProc(HWND, UINT, WPARAM, LPARAM);
    static BOOL CALLBACK GetButtonNaiveBindingProc(HWND, UINT, WPARAM, LPARAM);

    static LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

    static LRESULT CALLBACK ButtonsWndProc(HWND, UINT, WPARAM, LPARAM);
    static LRESULT CALLBACK AnalogsWndProc(HWND, UINT, WPARAM, LPARAM);
    static LRESULT CALLBACK KeypadsWndProc(HWND, UINT, WPARAM, LPARAM);
    static LRESULT CALLBACK LightsWndProc(HWND, UINT, WPARAM, LPARAM);
    static LRESULT CALLBACK OptionsWndProc(HWND, UINT, WPARAM, LPARAM);
    static LRESULT CALLBACK AboutWndProc(HWND, UINT, WPARAM, LPARAM);
    static LRESULT CALLBACK LicensesWndProc(HWND, UINT, WPARAM, LPARAM);

    void addGame(Game *);
};

#endif //SPICETOOLS_CFG_WINDOW_H
