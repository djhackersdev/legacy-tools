#ifndef SPICETOOLS_CFG_BUTTON_H
#define SPICETOOLS_CFG_BUTTON_H

#include <string>
#include <utility>
#include <vector>
#include "api.h"

namespace rawinput {
    class RawInputManager;
}

enum ButtonAnalogType {
    BAT_NONE=0,
    BAT_POSITIVE=1,
    BAT_NEGATIVE=2,
    BAT_HS_UP=3,
    BAT_HS_UPRIGHT=4,
    BAT_HS_RIGHT=5,
    BAT_HS_DOWNRIGHT=6,
    BAT_HS_DOWN=7,
    BAT_HS_DOWNLEFT=8,
    BAT_HS_LEFT=9,
    BAT_HS_UPLEFT=10,
    BAT_HS_NEUTRAL=11,
};

class Button {
private:
    std::vector<Button> alternatives;
    std::string buttonName;
    std::string deviceIdentifier;
    unsigned short vKey;
    std::string getVKeyString();
    GameAPI::Buttons::State lastState;
    float lastVelocity;
    ButtonAnalogType analogType;

public:

    // overrides
    bool override_enabled = false;
    GameAPI::Buttons::State override_state = GameAPI::Buttons::BUTTON_NOT_PRESSED;
    float override_velocity = 0.f;

    explicit Button(std::string buttonName);

    inline std::vector<Button>* getAlternatives() {
        return &this->alternatives;
    }

    inline bool isSet() {
        if (this->override_enabled)
            return true;
        if (this->vKey == 0xFF) {
            for (auto alternative : *getAlternatives()) {
                if (alternative.vKey != 0xFF)
                    return true;
            }
            return false;
        }
        return true;
    }

    std::string getDisplayString(rawinput::RawInputManager* manager);

    inline bool isNaive() {
        return this->deviceIdentifier.empty();
    }

    inline std::string getName() {
        return this->buttonName;
    }

    inline std::string getDeviceIdentifier() {
        return this->deviceIdentifier;
    }

    inline void setDeviceIdentifier(std::string deviceIdentifier) {
        this->deviceIdentifier = std::move(deviceIdentifier);
    }

    inline unsigned short getVKey() {
        return this->vKey;
    }

    inline void setVKey(unsigned short vKey) {
        this->vKey = vKey;
    }

    inline ButtonAnalogType getAnalogType() {
        return this->analogType;
    }

    inline void setAnalogType(ButtonAnalogType analogType) {
        this->analogType = analogType;
    }

    inline GameAPI::Buttons::State getLastState() {
        return this->lastState;
    }

    inline void setLastState(GameAPI::Buttons::State lastState) {
        this->lastState = lastState;
    }

    inline float getLastVelocity() {
        return this->lastVelocity;
    }

    inline void setLastVelocity(float lastVelocity) {
        this->lastVelocity = lastVelocity;
    }

    /*
     * Map hat switch float value from [0-1] to directions.
     * Buffer must be sized 3 or bigger.
     * Order of detection is:
     * 1. Multi Direction Binding (example: BAT_HS_UPRIGHT)
     * 2. Lower number binding (in order up, right, down, left)
     * 3. Higher number binding
     * Empty fields will be 0 (BAT_NONE)
     *
     * Example:
     * Xbox360 Controller reports value 2 => mapped to float [0-1] it's 0.25f
     * Resulting buffer is: {BAT_HS_UPRIGHT, BAT_HS_UP, BAT_HS_RIGHT}
     */
    static void getHatSwitchValues(float analog_state, ButtonAnalogType* buffer);

};

#endif //SPICETOOLS_CFG_BUTTON_H
