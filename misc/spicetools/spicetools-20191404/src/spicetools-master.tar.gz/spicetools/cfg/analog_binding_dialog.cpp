#include "analog_binding_dialog.h"
#include <cmath>
#include "util/logging.h"


static const HICON WINDOW_ICON = LoadIcon(GetModuleHandle(nullptr), MAKEINTRESOURCE(MAINICON));
static const HICON WINDOW_SM_ICON = LoadIcon(GetModuleHandle(nullptr), MAKEINTRESOURCE(MAINICON));
static const std::string WINDOW_CLASS_NAME = "AnalogBindingDialog";
static const std::string WINDOW_TITLE_TEXT = "Analog Binding";
static const int WINDOW_SIZE_X = 360;
static const int WINDOW_SIZE_Y = 300;

// commands
static const int DEVICE_SELECT_SWITCH = 300;
static const int ANALOG_SELECT_SWITCH = 400;
static const int BUTTON_APPLY = 500;
static const int BUTTON_CANCEL = 501;
static const int SENSIVITY_TRACKBAR = 600;
static const int INVERT_CHECKBOX = 700;

AnalogBindingDialog::AnalogBindingDialog(SpiceToolsWindow *config_window, HWND parent) {
    this->config_window = config_window;
    this->parent = parent;

    // build window title
    this->analog = config_window->getSelectedAnalog();
    if (this->analog)
        this->title = WINDOW_TITLE_TEXT + " (" + analog->getName() + ")";
    else
        return;

    // get devices
    auto devices_all = config_window->getRawInputManager()->devices_get();
    for (auto &device : *devices_all) {
        switch (device.type) {
            case rawinput::MOUSE:
                this->devices.emplace_back(&device);
                break;
            case rawinput::HID:
                if (!device.hidInfo->value_caps_names.empty())
                    this->devices.emplace_back(&device);
                break;
            default:
                continue;
        }

        // check if this is the current device
        if (device.name == this->analog->getDeviceIdentifier()) {
            this->device_selected = this->devices.size() - 1;
            this->analog_selected = this->analog->getIndex();
            this->sensivity = this->analog->getSensivity();
            this->invert = this->analog->getInvert();
        }
    }

    // build window class
    memset(&this->wc, 0, sizeof(WNDCLASSEX));
    this->wc.cbSize = sizeof(WNDCLASSEX);
    this->wc.style = 0;
    this->wc.lpfnWndProc = &AnalogBindingDialog::wnd_proc;
    this->wc.cbClsExtra = 0;
    this->wc.cbWndExtra = 0;
    this->wc.hInstance = GetModuleHandle(nullptr);
    this->wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    this->wc.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1);
    this->wc.lpszMenuName = nullptr;
    this->wc.lpszClassName = WINDOW_CLASS_NAME.c_str();
    this->wc.hIconSm = WINDOW_SM_ICON;
    this->wc.hIcon = WINDOW_ICON;

    // register window class
    if (!RegisterClassEx(&wc))
        log_fatal("cfg", "Unable to register window class.");

    // create window
    this->hwnd = CreateWindowEx(
            WS_EX_CLIENTEDGE,
            WINDOW_CLASS_NAME.c_str(),
            this->title.c_str(),
            WS_POPUPWINDOW | WS_SYSMENU | WS_OVERLAPPED | WS_CAPTION,
            CW_USEDEFAULT,
            CW_USEDEFAULT,
            WINDOW_SIZE_X,
            WINDOW_SIZE_Y,
            this->parent,
            nullptr,
            GetModuleHandle(nullptr),
            this
    );

    // check window
    if (this->hwnd == nullptr)
        log_fatal("cfg", "Couldn't open analog binding dialog: " + to_string(GetLastError()));

    // show window
    this->open = true;
    ShowWindow(this->hwnd, SW_SHOWNORMAL);
    UpdateWindow(this->hwnd);

    // disable parent window
    EnableWindow(this->parent, FALSE);

    // set current device
    for (size_t device_index = 0; device_index < this->devices.size(); device_index++) {

        // check if this is the current device
        if (this->devices[device_index]->name == this->analog->getDeviceIdentifier()) {
            this->device_set((int) device_index);
            this->analog_set(this->analog->getIndex());
            this->sensivity = this->analog->getSensivity();
            auto scaled = this->sensivity > 0 ? sqrtf(this->sensivity) : this->sensivity;
            scaled *= 50.f;
            SendMessage(this->sensivity_hwnd, TBM_SETPOS, (WPARAM) TRUE, (LPARAM) (int) scaled);
            this->invert_set(this->analog->getInvert());
        }
    }

    // start input thread
    this->inputThread = new std::thread([this] {
        while (this->isOpen()) {

            // obtain device
            this->inputThreadMutex.lock();
            auto device = this->inputThreadDevice;
            auto index = this->inputThreadIndex;
            auto sensivity = this->inputThreadSensivity;
            auto invert = this->inputThreadInvert;
            this->inputThreadMutex.unlock();

            // get value based on device type
            float value = GameAPI::Analogs::getState(device, index, sensivity, invert);

            // set preview
            SendMessage(this->preview_hwnd, TBM_SETPOS, (WPARAM) TRUE, (LPARAM) (int) (value * 100));

            // chill down
            Sleep(1000 / 30);
        }
    });
}

AnalogBindingDialog::~AnalogBindingDialog() {
    DestroyWindow(this->hwnd);
    while (this->isOpen()) {
        this->poll();
    }
    this->inputThread->join();
    delete this->inputThread;
    UnregisterClass(WINDOW_CLASS_NAME.c_str(), GetModuleHandle(nullptr));
}

void AnalogBindingDialog::poll() {
    if (GetMessage(&this->msg, nullptr, 0, 0) > 0) {
        TranslateMessage(&this->msg);
        DispatchMessage(&this->msg);
    } else {
        this->open = false;
    }
}

LRESULT CALLBACK AnalogBindingDialog::wnd_proc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {
    auto instance = (AnalogBindingDialog*)(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
    switch (msg) {
        case WM_CTLCOLORSTATIC: {
            SetTextColor((HDC) wparam, RGB(0,0,0));
            return (LRESULT) CreateSolidBrush(RGB(255, 255, 255));
        }
        case WM_CREATE: {

            // set user data of window to class pointer
            auto pcs = (LPCREATESTRUCT) lparam;
            instance = (AnalogBindingDialog *) pcs->lpCreateParams;
            SetWindowLongPtrW(hwnd, GWLP_USERDATA, PtrToUlong(instance));

            // device label
            HWND device_label = CreateWindowEx(
                    WS_EX_TRANSPARENT,
                    WC_STATIC,
                    "",
                    WS_CHILD | WS_VISIBLE | SS_LEFT | WS_SYSMENU,
                    10, 10,
                    WINDOW_SIZE_X - 10, 15,
                    hwnd,
                    nullptr,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            instance->config_window->setDefaultFont(device_label);
            SetWindowText(device_label, "Device");

            // device select
            instance->device_select_hwnd = CreateWindow(
                    WC_COMBOBOX,
                    TEXT(""),
                    CBS_DROPDOWNLIST | CBS_HASSTRINGS | WS_CHILD | WS_OVERLAPPED | WS_VISIBLE,
                    10, 30,
                    WINDOW_SIZE_X - 20, 30,
                    hwnd,
                    reinterpret_cast<HMENU>(DEVICE_SELECT_SWITCH),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            instance->config_window->setDefaultFont(instance->device_select_hwnd);
            ComboBox_SetMinVisible(instance->device_select_hwnd, 256);

            // add devices
            for (auto device : instance->devices) {
                SendMessage(
                        instance->device_select_hwnd,
                        (UINT) CB_ADDSTRING,
                        (WPARAM) 0,
                        (LPARAM) device->desc.c_str()
                );
            }

            // analog label
            HWND analog_label = CreateWindowEx(
                    WS_EX_TRANSPARENT,
                    WC_STATIC,
                    "",
                    WS_CHILD | WS_VISIBLE | SS_LEFT | WS_SYSMENU,
                    10, 60,
                    WINDOW_SIZE_X - 10, 15,
                    hwnd,
                    nullptr,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            instance->config_window->setDefaultFont(analog_label);
            SetWindowText(analog_label, "Analog Control");

            // analog select
            instance->analog_select_hwnd = CreateWindow(
                    WC_COMBOBOX,
                    TEXT(""),
                    CBS_DROPDOWNLIST | CBS_HASSTRINGS | WS_CHILD | WS_OVERLAPPED | WS_VISIBLE,
                    10, 80,
                    WINDOW_SIZE_X - 20, 30,
                    hwnd,
                    reinterpret_cast<HMENU>(ANALOG_SELECT_SWITCH),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            instance->config_window->setDefaultFont(instance->analog_select_hwnd);
            ComboBox_SetMinVisible(instance->analog_select_hwnd, 256);

            // sensivity label
            HWND sensivity_label = CreateWindowEx(
                    WS_EX_TRANSPARENT,
                    WC_STATIC,
                    "",
                    WS_CHILD | WS_VISIBLE | SS_LEFT | WS_SYSMENU,
                    10, 108,
                    WINDOW_SIZE_X - 10, 15,
                    hwnd,
                    nullptr,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            instance->config_window->setDefaultFont(sensivity_label);
            SetWindowText(sensivity_label, "Sensivity");

            // sensivity trackbar
            instance->sensivity_hwnd = CreateWindowEx(
                    0,
                    TRACKBAR_CLASS,
                    "Sensivity",
                    WS_CHILD | WS_VISIBLE,
                    10, 120,
                    WINDOW_SIZE_X - 30, 30,
                    hwnd,
                    (HMENU) SENSIVITY_TRACKBAR,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            SendMessage(instance->sensivity_hwnd, TBM_SETRANGE, (WPARAM) TRUE, (LPARAM) MAKELONG(0, 100));
            SendMessage(instance->sensivity_hwnd, TBM_SETPOS, (WPARAM) TRUE, (LPARAM) 50);
            for (int i = 0; i <= 100; i += 10)
                SendMessage(instance->sensivity_hwnd, TBM_SETTIC, (WPARAM) TRUE, (LPARAM) i);

            // invert checkbox
            instance->invert_hwnd = CreateWindowEx(
                    0,
                    WC_BUTTON,
                    "Invert Axis",
                    WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
                    17, 160,
                    100, 20,
                    hwnd,
                    (HMENU) INVERT_CHECKBOX,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            instance->config_window->setDefaultFont(instance->invert_hwnd);

            // preview label
            HWND preview_label = CreateWindowEx(
                    WS_EX_TRANSPARENT,
                    WC_STATIC,
                    "",
                    WS_CHILD | WS_VISIBLE | SS_LEFT | WS_SYSMENU,
                    10, 190,
                    WINDOW_SIZE_X - 10, 15,
                    hwnd,
                    nullptr,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            instance->config_window->setDefaultFont(preview_label);
            SetWindowText(preview_label, "Preview");

            // preview trackbar
            instance->preview_hwnd = CreateWindowEx(
                    0,
                    TRACKBAR_CLASS,
                    "Sensivity",
                    WS_CHILD | WS_VISIBLE | WS_DISABLED,
                    10, 202,
                    WINDOW_SIZE_X - 30, 30,
                    hwnd,
                    (HMENU) SENSIVITY_TRACKBAR,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            SendMessage(instance->preview_hwnd, TBM_SETRANGE, (WPARAM) TRUE, (LPARAM) MAKELONG(0, 100));
            SendMessage(instance->preview_hwnd, TBM_SETPOS, (WPARAM) TRUE, (LPARAM) 50);
            SendMessage(instance->preview_hwnd, TBM_SETTIC, (WPARAM) TRUE, (LPARAM) 50);

            // apply button
            HWND button_apply = CreateWindow(
                    WC_BUTTON,
                    "Apply",
                    WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,
                    5,
                    WINDOW_SIZE_Y - 60,
                    WINDOW_SIZE_X / 2 - 15,
                    24,
                    hwnd,
                    reinterpret_cast<HMENU>(BUTTON_APPLY),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            instance->config_window->setDefaultFont(button_apply);

            // cancel button
            HWND button_cancel = CreateWindow(
                    WC_BUTTON,
                    "Cancel",
                    WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,
                    WINDOW_SIZE_X - WINDOW_SIZE_X / 2,
                    WINDOW_SIZE_Y - 60,
                    WINDOW_SIZE_X / 2 - 15,
                    24,
                    hwnd,
                    reinterpret_cast<HMENU>(BUTTON_CANCEL),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            instance->config_window->setDefaultFont(button_cancel);

            // set to first device
            if (!instance->devices.empty())
                instance->device_set(0);

            break;
        }
        case WM_COMMAND: {

            // check command
            switch (LOWORD(wparam)) {
                case INVERT_CHECKBOX: {
                    switch (HIWORD(wparam)) {
                        case BN_CLICKED: {
                            instance->invert_set(SendMessage(instance->invert_hwnd, BM_GETCHECK, 0, 0) == BST_CHECKED);
                            break;
                        }
                        default:
                            break;
                    }
                    break;
                }
                case BUTTON_APPLY:
                    switch (HIWORD(wparam)) {
                        case BN_CLICKED: {

                            // save binding
                            if (instance->analog_selected < 0)
                                break;
                            if ((size_t) instance->device_selected >= instance->devices.size())
                                break;
                            auto device = instance->devices[instance->device_selected];
                            instance->analog->setDeviceIdentifier(device->name);
                            instance->analog->setIndex((unsigned short) instance->analog_selected);
                            instance->analog->setSensivity(instance->sensivity);
                            instance->analog->setInvert(instance->invert);
                            instance->config_window->updateBindings(instance->analog);

                            // close window
                            PostMessage(hwnd, WM_CLOSE, 0, 0);
                            break;
                        }
                        default:
                            break;
                    }
                    break;
                case BUTTON_CANCEL:
                    switch (HIWORD(wparam)) {
                        case BN_CLICKED: {

                            // close without saving binding
                            PostMessage(hwnd, WM_CLOSE, 0, 0);
                            break;
                        }
                        default:
                            break;
                    }
                    break;
                case DEVICE_SELECT_SWITCH:

                    // check combo box command
                    switch (HIWORD(wparam)) {
                        case CBN_SELCHANGE: {

                            // select device
                            instance->device_set(
                                    SendMessage(
                                            instance->device_select_hwnd,
                                            CB_GETCURSEL,
                                            (WPARAM) 0,
                                            (LPARAM) 0
                                    )
                            );
                            break;
                        }
                        default:
                            break;
                    }
                    break;
                case ANALOG_SELECT_SWITCH:

                    // check analog box command
                    switch (HIWORD(wparam)) {
                        case CBN_SELCHANGE: {

                            // select analog
                            instance->analog_set(
                                    SendMessage(
                                            instance->analog_select_hwnd,
                                            CB_GETCURSEL,
                                            (WPARAM) 0,
                                            (LPARAM) 0
                                    )
                            );
                            break;
                        }
                        default:
                            break;
                    }
                    break;
                default:
                    break;
            }
            break;
        }
        case WM_HSCROLL: {

            // get sensivity
            auto pos = SendMessage(instance->sensivity_hwnd, TBM_GETPOS, 0, 0);

            // convert to float [0;4]
            instance->sensivity = pos / 50.f;
            instance->sensivity *= instance->sensivity;

            // update input thread
            instance->inputThreadMutex.lock();
            instance->inputThreadSensivity = instance->sensivity;
            instance->inputThreadMutex.unlock();

            break;
        }
        case WM_CLOSE:

            // enable parent window
            EnableWindow(instance->parent, TRUE);

            // call destroy
            DestroyWindow(hwnd);
            return 0;

        case WM_DESTROY:

            // mark as closed
            instance->open = false;
            return 0;

        default:
            break;
    }
    return DefWindowProc(hwnd, msg, wparam, lparam);
}

void AnalogBindingDialog::device_set(int device_no) {

    // clean up analog combo box
    SendMessage(
            this->analog_select_hwnd,
            CB_RESETCONTENT,
            (WPARAM) 0,
            (LPARAM) 0
    );

    // get device
    if (device_no < 0 || (size_t) device_no >= this->devices.size())
        return;
    auto device = this->devices[device_no];

    // set selection
    this->device_selected = device_no;
    SendMessage(
            this->device_select_hwnd,
            CB_SETCURSEL,
            (WPARAM) device_no,
            (LPARAM) 0
    );

    // add analog names based on device type
    switch (device->type) {
        case rawinput::MOUSE: {

            // add X and Y axis
            SendMessage(
                    this->analog_select_hwnd,
                    (UINT) CB_ADDSTRING,
                    (WPARAM) 0,
                    (LPARAM) "X"
            );
            SendMessage(
                    this->analog_select_hwnd,
                    (UINT) CB_ADDSTRING,
                    (WPARAM) 0,
                    (LPARAM) "Y"
            );

            break;
        }
        case rawinput::HID: {

            // add value names
            for (auto &analog_name : device->hidInfo->value_caps_names) {
                SendMessage(
                        this->analog_select_hwnd,
                        (UINT) CB_ADDSTRING,
                        (WPARAM) 0,
                        (LPARAM) analog_name.c_str()
                );
            }

            break;
        }
        default:
            break;
    }

    // automatically select first analog
    analog_set(0);
}

void AnalogBindingDialog::analog_set(int analog_no) {
    analog_selected = analog_no;
    SendMessage(
            this->analog_select_hwnd,
            CB_SETCURSEL,
            (WPARAM) analog_no,
            (LPARAM) 0
    );

    // set for input thread
    this->inputThreadMutex.lock();
    this->inputThreadDevice = this->devices[this->device_selected];
    this->inputThreadIndex = this->analog_selected;
    this->inputThreadSensivity = this->sensivity;
    this->inputThreadInvert = this->invert;
    this->inputThreadMutex.unlock();
}

void AnalogBindingDialog::invert_set(bool invert) {
    this->invert = invert;
    SendMessage(
            this->invert_hwnd,
            BM_SETCHECK,
            this->invert ? BST_CHECKED : BST_UNCHECKED,
            0
    );

    // set for input thread
    this->inputThreadMutex.lock();
    this->inputThreadInvert = this->invert;
    this->inputThreadMutex.unlock();
}
