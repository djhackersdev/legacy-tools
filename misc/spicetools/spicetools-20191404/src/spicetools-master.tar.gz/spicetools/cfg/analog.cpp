#include "analog.h"
#include "rawinput/rawinput.h"
#include "util/logging.h"
#include "util/utils.h"

Analog::Analog(std::string analogName) {
    this->analogName = std::move(analogName);
    this->deviceIdentifier = "";
    this->index = 0xFF;
    this->sensivity = 1.f;
    this->invert = false;
    this->lastState = 0.5f;
}

std::string Analog::getDisplayString(rawinput::RawInputManager *manager) {

    // get index string
    auto index = (uint16_t) this->getIndex();
    std::string indexString;
    if (index > 0xFF)
        indexString = bin2hex(&((char*) &index)[1], 1) + bin2hex(&((char*) &index)[0], 1);
    else
        indexString = bin2hex(&((char*) &index)[0], 1);

    // get device
    auto device = manager->devices_get(this->deviceIdentifier);
    if (!device)
        return "Device missing (0x" + indexString + ")";

    // return string based on device type
    switch (device->type) {
        case rawinput::MOUSE:
            return std::string(index > 0 ? "Y" : "X") + " (" + device->desc + ")";
        case rawinput::HID: {
            auto hid = device->hidInfo;
            if (index < hid->value_caps_names.size())
                return hid->value_caps_names[index] + " (" + device->desc + ")";
            return "Invalid Axis (0x" + indexString + ")";
        }
        default:
            return "Unknown Axis (0x" + indexString + ")";
    }
}
