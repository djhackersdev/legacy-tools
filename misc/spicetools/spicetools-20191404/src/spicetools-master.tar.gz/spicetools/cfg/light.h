#ifndef SPICETOOLS_CFG_LIGHT_H
#define SPICETOOLS_CFG_LIGHT_H

#include <string>
#include <vector>

namespace rawinput {
    class RawInputManager;
}

class Light {
private:
    std::vector<Light> alternatives;
    std::string lightName;
    std::string deviceIdentifier;
    unsigned int index;

public:
    float last_state = 0.f;

    // overrides
    bool override_enabled = false;
    float override_state = 0.f;

    explicit Light(std::string lightName);

    std::string getDisplayString(rawinput::RawInputManager* manager);

    inline std::vector<Light>* getAlternatives() {
        return &this->alternatives;
    }

    inline bool isSet() {
        if (this->override_enabled)
            return true;
        if (this->deviceIdentifier.empty()) {
            for (auto alternative : *getAlternatives()) {
                if (!alternative.deviceIdentifier.empty())
                    return true;
            }
            return false;
        }
        return true;
    }

    inline std::string getName() {
        return this->lightName;
    }

    inline std::string getDeviceIdentifier() {
        return this->deviceIdentifier;
    }

    inline void setDeviceIdentifier(std::string deviceIdentifier) {
        this->deviceIdentifier = std::move(deviceIdentifier);
    }

    inline unsigned int getIndex() {
        return this->index;
    }

    inline void setIndex(unsigned int index) {
        this->index = index;
    }
};

#endif //SPICETOOLS_CFG_LIGHT_H
