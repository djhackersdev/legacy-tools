#ifndef SPICETOOLS_CFG_ANALOG_H
#define SPICETOOLS_CFG_ANALOG_H

#include <string>

namespace rawinput {
    class RawInputManager;
}

class Analog {
private:
    std::string analogName;
    std::string deviceIdentifier;
    unsigned short index;
    float sensivity;
    bool invert;
    float lastState;

public:

    // overrides
    bool override_enabled = false;
    float override_state = 0.5f;

    explicit Analog(std::string analogName);

    std::string getDisplayString(rawinput::RawInputManager* manager);

    inline bool isSet() {
        if (this->override_enabled)
            return true;
        return this->getIndex() != 0xFF;
    }

    inline std::string getName() {
        return this->analogName;
    }

    inline std::string getDeviceIdentifier() {
        return this->deviceIdentifier;
    }

    inline void setDeviceIdentifier(std::string deviceIdentifier) {
        this->deviceIdentifier = std::move(deviceIdentifier);
    }

    inline unsigned short getIndex() {
        return this->index;
    }

    inline void setIndex(unsigned short index) {
        this->index = index;
    }

    inline float getSensivity() {
        return this->sensivity;
    }

    inline void setSensivity(float sensivity) {
        this->sensivity = sensivity;
    }

    inline bool getInvert() {
        return this->invert;
    }

    inline void setInvert(bool invert) {
        this->invert = invert;
    }

    inline float getLastState() {
        return this->lastState;
    }

    inline void setLastState(float lastState) {
        this->lastState = lastState;
    }
};

#endif //SPICETOOLS_CFG_ANALOG_H
