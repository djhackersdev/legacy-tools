#include "api.h"

#include <cmath>
#include "rawinput/rawinput.h"
#include "rawinput/piuio.h"
#include "config.h"
#include "util/logging.h"

using namespace GameAPI;


std::vector<Button *> *GameAPI::Buttons::getButtons(std::string gameName) {
    return Config::getInstance().getButtons(std::move(gameName));
}

std::vector<Button *> *GameAPI::Buttons::getButtons(Game *game) {
    return Config::getInstance().getButtons(game);
}


void GameAPI::Buttons::sortButtons(std::vector<Button *> **buttons, std::vector<std::string> *buttonNames) {
    auto tmpButtons = new std::vector<Button *>;
    bool buttonFound;
    for (auto &buttonName : *buttonNames) {
        buttonFound = false;
        for (auto &bt : *(*buttons)) {
            if (buttonName == bt->getName()) {
                buttonFound = true;
                tmpButtons->push_back(bt);
                break;
            }
        }
        if (!buttonFound)
            tmpButtons->push_back(new Button(buttonName));
    }
    delete *buttons;
    *buttons = tmpButtons;
}

GameAPI::Buttons::State GameAPI::Buttons::getState(rawinput::RawInputManager *manager, Button *button, bool check_alts) {

    // check override
    if (button->override_enabled)
        return button->override_state;

    // for iterating button alternatives
    std::vector<Button> *alternatives = check_alts ? button->getAlternatives() : nullptr;
    unsigned int button_count = 0;
    while (true) {

        // naive behavior
        if (button->isNaive()) {
            auto vkey = button->getVKey();
            GameAPI::Buttons::State state;
            if (vkey == 0xFF)
                state = GameAPI::Buttons::State::BUTTON_NOT_PRESSED;
            else
                state = (GetAsyncKeyState(button->getVKey()) & 0x8000) ?
                       GameAPI::Buttons::State::BUTTON_PRESSED :
                       GameAPI::Buttons::State::BUTTON_NOT_PRESSED;

            // return state
            if (state != GameAPI::Buttons::State::BUTTON_NOT_PRESSED)
                return state;

            // get next button
            button_count++;
            if (!alternatives || alternatives->empty() || button_count - 1 >= alternatives->size())
                return GameAPI::Buttons::State::BUTTON_NOT_PRESSED;
            else {
                button = &alternatives->at(button_count - 1);
                continue;
            }
        }

        // get device
        std::string devid = button->getDeviceIdentifier();
        auto device = manager->devices_get(devid, false); // TODO: fix to update only

        // get state if device was marked as updated
        GameAPI::Buttons::State state = button->getLastState();
        if (device) {

            // lock device
            device->mutex->lock();

            // get vkey
            auto vKey = button->getVKey();

            // update state based on device type
            switch (device->type) {
                case rawinput::MOUSE:
                    break;
                case rawinput::KEYBOARD: {
                    if (vKey < 1024) {
                        auto kb = device->keyboardInfo;
                        state = kb->key_states[vKey] ?
                                GameAPI::Buttons::State::BUTTON_PRESSED :
                                GameAPI::Buttons::State::BUTTON_NOT_PRESSED;
                    }
                    break;
                }
                case rawinput::HID: {
                    auto hid = device->hidInfo;
                    auto bat = button->getAnalogType();
                    switch (bat) {
                        case BAT_NONE: {
                            auto button_states_list = &hid->button_states;
                            for (auto &button_states : *button_states_list) {
                                if (vKey < button_states.size()) {
                                    state = button_states[vKey] ? BUTTON_PRESSED : BUTTON_NOT_PRESSED;
                                    break;
                                } else
                                    vKey -= button_states.size();
                            }
                            break;
                        }
                        case BAT_NEGATIVE:
                        case BAT_POSITIVE: {
                            auto value_states = &hid->value_states;
                            if (vKey < value_states->size()) {
                                auto value = value_states->at(vKey);
                                if (button->getAnalogType() == BAT_POSITIVE)
                                    state = value > 0.6f ? BUTTON_PRESSED : BUTTON_NOT_PRESSED;
                                else
                                    state = value < 0.4f ? BUTTON_PRESSED : BUTTON_NOT_PRESSED;
                            } else
                                state = BUTTON_NOT_PRESSED;
                            break;
                        }
                        case BAT_HS_UP:
                        case BAT_HS_UPRIGHT:
                        case BAT_HS_RIGHT:
                        case BAT_HS_DOWNRIGHT:
                        case BAT_HS_DOWN:
                        case BAT_HS_DOWNLEFT:
                        case BAT_HS_LEFT:
                        case BAT_HS_UPLEFT:
                        case BAT_HS_NEUTRAL: {
                            auto value_states = &hid->value_states;
                            if (vKey < value_states->size()) {
                                auto value = value_states->at(vKey);

                                // get hat switch values
                                ButtonAnalogType buffer[3];
                                Button::getHatSwitchValues(value, buffer);

                                // check if one of the values match our analog type
                                state = BUTTON_NOT_PRESSED;
                                for (ButtonAnalogType buffer_bat : buffer) {
                                    if (buffer_bat == bat) {
                                        state = BUTTON_PRESSED;
                                        break;
                                    }
                                }

                            } else
                                state = BUTTON_NOT_PRESSED;
                            break;
                        }
                        default:
                            state = BUTTON_NOT_PRESSED;
                            break;
                    }
                    break;
                }
                case rawinput::MIDI: {
                    if (vKey < 16 * 128) {
                        auto midi = device->midiInfo;
                        auto midi_event = midi->states_events[vKey];

                        // check for event
                        if (midi_event) {

                            // choose state based on event
                            state = (midi_event % 2) ?
                                    GameAPI::Buttons::State::BUTTON_PRESSED :
                                    GameAPI::Buttons::State::BUTTON_NOT_PRESSED;

                            // update event
                            if (!midi->states[vKey] || midi_event > 1)
                                midi->states_events[vKey]--;

                        } else
                            state = GameAPI::Buttons::State::BUTTON_NOT_PRESSED;
                    }
                    break;
                }
                case rawinput::PIUIO_DEVICE: {
                    state = device->piuioDev->IsPressed(vKey) ? BUTTON_PRESSED : BUTTON_NOT_PRESSED;
                }
                default:
                    break;
            }

            // set last state
            button->setLastState(state);

            // unlock device
            device->mutex->unlock();
        }

        // return state
        if (state != GameAPI::Buttons::State::BUTTON_NOT_PRESSED)
            return state;

        // get next button
        button_count++;
        if (!alternatives || alternatives->empty() || button_count - 1 >= alternatives->size())
            return GameAPI::Buttons::State::BUTTON_NOT_PRESSED;
        else
            button = &alternatives->at(button_count - 1);
    }
}

static float getVelocityHelper(rawinput::RawInputManager *manager, Button *button) {

    // check override
    if (button->override_enabled)
        return button->override_velocity;

    // naive behavior
    if (button->isNaive())
        return (GetAsyncKeyState(button->getVKey()) & 0x8000) ? 1.f : 0.f;

    // get button state
    Buttons::State button_state = Buttons::getState(manager, button, false);

    // check if button isn't being pressed
    if (button_state != Buttons::BUTTON_PRESSED)
        return 0.f;

    // prepare
    float velocity;
    auto vKey = button->getVKey();

    // get device
    std::string devid = button->getDeviceIdentifier();
    auto device = manager->devices_get(devid, false);

    // return last velocity if device wasn't found
    if (!device)
        return button->getLastVelocity();

    // lock device
    device->mutex->lock();

    // determine velocity based on device type
    switch (device->type) {
        case rawinput::MIDI: {
            if (vKey < 16 * 128)
                velocity = (float) device->midiInfo->velocity[vKey] / 127.f;
            else
                velocity = 0.f;
            break;
        }
        default:
            velocity = 1.f;
    }

    // unlock device
    device->mutex->unlock();

    // set last velocity
    button->setLastVelocity(velocity);

    // return determined velocity
    return velocity;
}

float GameAPI::Buttons::getVelocity(rawinput::RawInputManager *manager, Button *button) {

    // get button velocity
    auto velocity = getVelocityHelper(manager, button);

    // check alternatives
    for (auto &alternative : *button->getAlternatives()) {
        auto alt_velocity = getVelocityHelper(manager, &alternative);
        if (alt_velocity > velocity)
            velocity = alt_velocity;
    }

    // return highest velocity detected
    return velocity;
}

float GameAPI::Analogs::getState(rawinput::Device *device, int index, float sensivity, bool inverted) {
    float value = 0.5f;
    if (device) {
        device->mutex->lock();
        switch (device->type) {
            case rawinput::MOUSE: {

                // get mouse position
                auto mouse = device->mouseInfo;
                long pos = index ? mouse->pos_y : mouse->pos_x;

                // apply sensivity
                auto val = (int) roundf(pos * sensivity);

                // modulo
                if (val < 0)
                    inverted = !inverted;
                val = std::abs(val) % 257;

                // normalize
                value = val / 256.f;

                // invert
                if (inverted)
                    value = 1.f - value;

                break;
            }
            case rawinput::HID: {

                // get value
                if (inverted)
                    value = 1.f - device->hidInfo->value_states[index];
                else
                    value = device->hidInfo->value_states[index];

                break;
            }
            default:
                break;
        }
        device->mutex->unlock();
    }
    return value;
}

std::vector<Analog *> *GameAPI::Analogs::getAnalogs(std::string gameName) {
    return Config::getInstance().getAnalogs(std::move(gameName));
}

void GameAPI::Analogs::sortAnalogs(std::vector<Analog *> **analogs, std::vector<std::string> *analogNames) {
    auto tmpAnalogs = new std::vector<Analog *>;
    bool analogFound;
    for (auto &analogName : *analogNames) {
        analogFound = false;
        for (auto &bt : *(*analogs)) {
            if (analogName == bt->getName()) {
                analogFound = true;
                tmpAnalogs->push_back(bt);
                break;
            }
        }
        if (!analogFound)
            tmpAnalogs->push_back(new Analog(analogName));
    }
    delete *analogs;
    *analogs = tmpAnalogs;
}

float GameAPI::Analogs::getState(rawinput::RawInputManager *manager, Analog *analog) {

    // check override
    if (analog->override_enabled)
        return analog->override_state;

    // get device
    std::string devid = analog->getDeviceIdentifier();
    auto device = manager->devices_get(devid, false); // TODO: fix to update only

    // return last state if device wasn't updated
    if (!device)
        return analog->getLastState();
    float state = getState(device, analog->getIndex(), analog->getSensivity(), analog->getInvert());
    analog->setLastState(state);
    return state;
}

std::vector<Light *> *GameAPI::Lights::getLights(std::string gameName) {
    return Config::getInstance().getLights(std::move(gameName));
}

void GameAPI::Lights::sortLights(std::vector<Light *> **lights, std::vector<std::string> *lightNames) {
    auto tmpLights = new std::vector<Light *>;
    bool lightFound;
    for (auto &lightName : *lightNames) {
        lightFound = false;
        for (auto &light : *(*lights)) {
            if (lightName == light->getName()) {
                lightFound = true;
                tmpLights->push_back(light);
                break;
            }
        }
        if (!lightFound)
            tmpLights->push_back(new Light(lightName));
    }
    delete *lights;
    *lights = tmpLights;
}

void GameAPI::Lights::writeLight(rawinput::Device *device, int index, float value) {

    // lock device
    device->mutex->lock();

    // enable output
    device->output_enabled = true;

    // check type
    switch (device->type) {
        case rawinput::HID: {
            auto hid = device->hidInfo;

            // find in buttons
            bool button_found = false;
            for (auto &button_states : hid->button_output_states) {
                if ((size_t) index < button_states.size()) {
                    auto new_state = value > 0.5f;
                    if (button_states[index] != new_state) {
                        button_states[index] = new_state;
                        device->output_pending = true;
                    }
                    button_found = true;
                    break;
                } else
                    index -= button_states.size();
            }

            // find in values
            if (!button_found) {
                auto value_states = &hid->value_output_states;
                if ((size_t) index < value_states->size()) {
                    auto cur_state = &(*value_states)[index];
                    if (*cur_state != value) {
                        *cur_state = value;
                        device->output_pending = true;
                    }
                }
            }

            break;
        }
        case rawinput::SEXTET_OUTPUT: {
            if (index < rawinput::SextetDevice::LIGHT_COUNT) {
                device->sextetInfo->light_state[index] = value > 0;
                device->sextetInfo->push_light_state();
            } else {
                log_warning("api", "invalid sextet light index: " + to_string(index));
            }
            break;
        }
        case rawinput::PIUIO_DEVICE: {
            if (index < rawinput::PIUIO::PIUIO_MAX_NUM_OF_LIGHTS) {
                device->piuioDev->SetLight(index, value > 0);
            } else {
                log_warning("api", "invalid piuio light index: " + to_string(index));
            }
            break;
        }
        default:
            break;
    }

    // unlock device
    device->mutex->unlock();
}

void GameAPI::Lights::writeLight(rawinput::RawInputManager *manager, Light *light, float value) {

    // write to last state
    light->last_state = value;

    // get device
    std::string devid = light->getDeviceIdentifier();
    auto device = manager->devices_get(devid, false);

    // check device
    if (device) {

        // write state
        if (light->override_enabled)
            writeLight(device, light->getIndex(), light->override_state);
        else
            writeLight(device, light->getIndex(), value);
    }

    // alternatives
    for (auto &alternative : *light->getAlternatives()) {
        if (light->override_enabled) {
            alternative.override_enabled = true;
            alternative.override_state = light->override_state;
            writeLight(manager, &alternative, value);
        } else {
            alternative.override_enabled = false;
            writeLight(manager, &alternative, light->override_state);
        }
    }
}

float GameAPI::Lights::readLight(rawinput::Device *device, int index) {
    float ret = 0.f;

    // lock device
    device->mutex->lock();

    // check type
    switch (device->type) {
        case rawinput::HID: {
            auto hid = device->hidInfo;

            // find in buttons
            bool button_found = false;
            for (auto &button_states : hid->button_output_states) {
                if ((size_t) index < button_states.size()) {
                    ret = button_states[index] ? 1.f : 0.f;
                    button_found = true;
                    break;
                } else
                    index -= button_states.size();
            }

            // find in values
            if (!button_found) {
                auto value_states = &hid->value_output_states;
                if ((size_t) index < value_states->size()) {
                    ret = (*value_states)[index];
                }
            }

            break;
        }
        default:
            break;
    }

    // unlock device
    device->mutex->unlock();

    // return result
    return ret;
}

float GameAPI::Lights::readLight(rawinput::RawInputManager *manager, Light *light) {

    // check override
    if (light->override_enabled)
        return light->override_state;

    // just return last state since that reflects the last value being written
    return light->last_state;
}
