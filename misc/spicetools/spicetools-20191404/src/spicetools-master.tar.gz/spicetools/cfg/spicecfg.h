#ifndef SPICETOOLS_CFG_SPICECFG_H
#define SPICETOOLS_CFG_SPICECFG_H

#include <vector>
#include <string>

int spicecfg_run(std::vector<std::string> sextet_devices);

#endif //SPICETOOLS_CFG_SPICECFG_H
