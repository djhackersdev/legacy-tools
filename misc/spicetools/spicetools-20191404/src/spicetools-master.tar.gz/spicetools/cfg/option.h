#ifndef SPICETOOLS_CFG_OPTION_H
#define SPICETOOLS_CFG_OPTION_H

#include <string>

class Option {
public:
    Option(std::string);

    Option(std::string, std::string);

    std::string getName();

    std::string getValue();

    void setValue(std::string);

private:
    std::string optionName;
    std::string optionValue;
};

#endif //SPICETOOLS_CFG_OPTION_H
