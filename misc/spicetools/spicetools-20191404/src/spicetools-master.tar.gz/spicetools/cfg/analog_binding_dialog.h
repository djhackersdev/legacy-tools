#ifndef SPICETOOLS_CFG_ANALOG_BINDING_DIALOG_H
#define SPICETOOLS_CFG_ANALOG_BINDING_DIALOG_H

#include "window.h"
#include "rawinput/device.h"

#include <thread>
#include <mutex>

class AnalogBindingDialog {
private:

    // constructor parameters
    SpiceToolsWindow* config_window;
    HWND parent;
    Analog* analog;

    // window stuff
    std::string title;
    HWND hwnd;
    WNDCLASSEX wc;
    MSG msg;
    bool open;
    std::thread* inputThread;
    rawinput::Device* inputThreadDevice = nullptr;
    int inputThreadIndex = -1;
    float inputThreadSensivity = 1.f;
    bool inputThreadInvert = false;
    std::mutex inputThreadMutex;

    // device stuff
    std::vector<rawinput::Device*> devices;
    int device_selected = -1;
    int analog_selected = -1;
    float sensivity = 1.f;
    bool invert = false;

    // content
    HWND device_select_hwnd;
    HWND analog_select_hwnd;
    HWND sensivity_hwnd;
    HWND invert_hwnd;
    HWND preview_hwnd;

    void device_set(int device_no);
    void analog_set(int analog_no);
    void invert_set(bool invert);

    static LRESULT CALLBACK wnd_proc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);

public:

    AnalogBindingDialog(SpiceToolsWindow* config_window, HWND parent);
    ~AnalogBindingDialog();

    void poll();
    inline bool isOpen() {
        return this->open;
    }
};

#endif //SPICETOOLS_CFG_ANALOG_BINDING_DIALOG_H
