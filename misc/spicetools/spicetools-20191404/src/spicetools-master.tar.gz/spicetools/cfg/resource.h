#ifndef SPICETOOLS_CFG_RESOURCE_H
#define SPICETOOLS_CFG_RESOURCE_H

#define IDC_STATIC                      -1
#define IDD_DIALOG1                     129
#define IDR_CHANGELOG                   130
#define IDR_LICENSES                    131

#endif //SPICETOOLS_CFG_RESOURCE_H
