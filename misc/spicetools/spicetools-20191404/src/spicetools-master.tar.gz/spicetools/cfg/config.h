#ifndef SPICETOOLS_CFG_CONFIG_H
#define SPICETOOLS_CFG_CONFIG_H

#include <iostream>
#include <fstream>

#include "external/tinyxml2/tinyxml2.h"
#include "game.h"

struct ConfigKeypadBindings {
    std::string keypads[2];
    std::string card_paths[2];
};

class Config {
public:
    static Config &getInstance();

    bool getStatus();

    bool addGame(Game *);

    bool updateBinding(Game* game, Button* button, int alternative);
    bool updateBinding(Game* game, Analog* analog);
    bool updateBinding(Game* game, ConfigKeypadBindings keypads);
    bool updateBinding(Game* game, Light* light, int alternative);

    Button *getButton(std::string, std::string);

    Button *getButton(Game *, std::string);

    Light *getLight(std::string, std::string);

    Light *getLight(Game *, std::string);

    Option *getOption(std::string, std::string);

    Option *getOption(Game *, std::string);

    std::vector<Button *> *getButtons(std::string);

    std::vector<Button *> *getButtons(Game *);

    std::vector<Analog *> *getAnalogs(std::string);

    std::vector<Analog *> *getAnalogs(Game *);

    ConfigKeypadBindings getKeypadBindings(Game *);

    ConfigKeypadBindings getKeypadBindings(std::string);

    std::vector<Light *> *getLights(std::string);

    std::vector<Light *> *getLights(Game *);

    std::vector<Option *> *getOptions(std::string);

    std::vector<Option *> *getOptions(Game *);

private:
    Config();

    virtual ~Config();

    Config(const Config &);

    const Config &operator=(const Config &);

    tinyxml2::XMLDocument configFile;
    bool status;
    std::string configLocation;

    bool createConfigFile();

    bool firstFillConfigFile();
};

#endif //SPICETOOLS_CFG_CONFIG_H
