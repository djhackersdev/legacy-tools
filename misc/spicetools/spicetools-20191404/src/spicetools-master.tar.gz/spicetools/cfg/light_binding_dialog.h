#ifndef SPICETOOLS_CFG_LIGHT_BINDING_DIALOG_H
#define SPICETOOLS_CFG_LIGHT_BINDING_DIALOG_H

#include "window.h"
#include "light.h"

class LightBindingDialog {
private:

    // constructor parameters
    SpiceToolsWindow* config_window;
    HWND parent;
    Light* light;

    // window stuff
    std::string title;
    HWND hwnd;
    WNDCLASSEX wc;
    MSG msg;
    bool open;

    // device stuff
    std::vector<rawinput::Device*> devices;
    int device_selected = -1;
    int light_selected = -1;

    // content
    HWND device_select_hwnd;
    HWND light_select_hwnd;
    HWND value_trackbar_hwnd;

    void device_set(int device_no);
    void light_set(int light_no);

    static LRESULT CALLBACK wnd_proc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);

public:

    LightBindingDialog(SpiceToolsWindow* config_window, HWND parent);
    ~LightBindingDialog();

    void poll();
    inline bool isOpen() {
        return this->open;
    }
};

#endif //SPICETOOLS_CFG_LIGHT_BINDING_DIALOG_H
