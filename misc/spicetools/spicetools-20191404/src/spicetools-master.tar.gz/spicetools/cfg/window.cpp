#include <shlwapi.h>

#include <cmath>
#include <utility>
#include "window.h"
#include "analog_binding_dialog.h"
#include "light_binding_dialog.h"
#include "util/logging.h"
#include "build/defs.h"
#include "util/fileutils.h"
#include "util/resutils.h"
#include "rawinput/piuio.h"

//////////////////
/// Unique IDs ///
//////////////////

static const int COMBO_BOX_GAME_SWITCHER = 100;
static const int TAB_CTRL = 150;
static const int LIST_VIEW_BINDINGS = 200;

static const int BUTTON_SET_BINDING = 300;
static const int BUTTON_SET_NAIVE_BINDING = 301;
static const int BUTTON_CLEAR_BINDING = 302;
static const int BUTTON_PREVIOUS_ALTERNATIVE = 303;
static const int BUTTON_NEXT_ALTERNATIVE = 304;
static const int BUTTON_RESET_ALTERNATIVE = 305;

static const int KEYPADS_P1 = 320;
static const int KEYPADS_P2 = 321;
static const int CARD1_BTN = 322;
static const int CARD2_BTN = 323;
static const int CARD1_CLR_BTN = 324;
static const int CARD2_CLR_BTN = 325;

static const int ANALOG_SET_BINDING = 350;
static const int ANALOG_CLEAR_BINDING = 351;

static const int OPTION_SET_BINDING = 400;
static const int OPTION_CLEAR_BINDING = 401;

////////////////////////
/// Window Variables ///
////////////////////////

static const char *WINDOW_TITLE_TEXT = "SpiceTools Config";
static HICON WINDOW_ICON = LoadIcon(GetModuleHandle(nullptr), MAKEINTRESOURCE(MAINICON));
static HICON WINDOW_SM_ICON = LoadIcon(GetModuleHandle(nullptr), MAKEINTRESOURCE(MAINICON));
static const int WINDOW_SIZE_X = 360;
static const int WINDOW_SIZE_Y = 490;
static const std::string MONOSPACE_FONT_NAME = "Courier New";

static const int COMBOBOX_POSITION_X = 10;
static const int COMBOBOX_POSITION_Y = 5;
static const int COMBOBOX_SIZE_X = WINDOW_SIZE_X - 30;
static const int COMBOBOX_SIZE_Y = WINDOW_SIZE_Y;

static const int TAB_CTRL_POSITION_X = 10;
static const int TAB_CTRL_POSITION_Y = 30;
static const int TAB_CTRL_SIZE_X = WINDOW_SIZE_X - 30;
static const int TAB_CTRL_SIZE_Y = WINDOW_SIZE_Y - 75;

static const int LIST_VIEW_POSITION_X = 10;
static const int LIST_VIEW_POSITION_Y = 10;
static const int LIST_VIEW_SIZE_X = 310;
static const int LIST_VIEW_SIZE_Y = TAB_CTRL_SIZE_Y - 75;
static const char *LIST_VIEW_BUTTONS_COLUMN_ONE_TEXT = "Buttons";
static const char *LIST_VIEW_BUTTONS_COLUMN_TWO_TEXT = "Keys";
static const char *LIST_VIEW_ANALOGS_COLUMN_ONE_TEXT = "Analogs";
static const char *LIST_VIEW_ANALOGS_COLUMN_TWO_TEXT = "Bindings";
static const char *LIST_VIEW_ROW_NOT_SET_TEXT = "Not Set";

static const char *OPTIONS_LIST_VIEW_COLUMN_ONE_TEXT = "Options";
static const char *OPTIONS_LIST_VIEW_COLUMN_TWO_TEXT = "Values";

static const char *BUTTON_SET_TEXT = "Set";
static const int BUTTON_SET_POSITION_X = 9;
static const int BUTTON_SET_POSITION_Y = TAB_CTRL_SIZE_Y - 55;
static const int BUTTON_SET_SIZE_X = 100;
static const int BUTTON_SET_SIZE_Y = 24;

static const char *BUTTON_SET_NAIVE_TEXT = "Set Naive";
static const int BUTTON_SET_NAIVE_POSITION_X = 115;
static const int BUTTON_SET_NAIVE_POSITION_Y = TAB_CTRL_SIZE_Y - 55;
static const int BUTTON_SET_NAIVE_SIZE_X = 101;
static const int BUTTON_SET_NAIVE_SIZE_Y = 24;

static const char *BUTTON_CLEAR_TEXT = "Clear";
static const int BUTTON_CLEAR_POSITION_X = 221;
static const int BUTTON_CLEAR_POSITION_Y = TAB_CTRL_SIZE_Y - 55;
static const int BUTTON_CLEAR_SIZE_X = 100;
static const int BUTTON_CLEAR_SIZE_Y = 24;

///////////////////
/// Constructor ///
///////////////////

SpiceToolsWindow::SpiceToolsWindow() {
    this->wc.cbSize = sizeof(WNDCLASSEX);
    this->wc.style = 0;
    this->wc.lpfnWndProc = &SpiceToolsWindow::WndProc;
    this->wc.cbClsExtra = 0;
    this->wc.cbWndExtra = 0;
    this->wc.hInstance = GetModuleHandle(nullptr);
    this->wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    this->wc.hbrBackground = reinterpret_cast<HBRUSH>(COLOR_WINDOW + 1);
    this->wc.lpszMenuName = nullptr;
    this->wc.lpszClassName = g_szClassName;
    this->wc.hIconSm = WINDOW_SM_ICON;
    this->wc.hIcon = WINDOW_ICON;
    this->defaultFont = (HFONT) GetStockObject(DEFAULT_GUI_FONT);
    this->monospaceFont = CreateFont(14, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, ANSI_CHARSET,
                                     OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY,
                                     DEFAULT_PITCH, MONOSPACE_FONT_NAME.c_str());

    // Register Window
    if (!RegisterClassEx(&wc)) {
        this->stillOpen = false;
        return;
    }

    // Main Window
    this->hwnd = CreateWindowEx(
            WS_EX_CLIENTEDGE,
            this->g_szClassName,
            WINDOW_TITLE_TEXT,
            WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
            CW_USEDEFAULT,
            CW_USEDEFAULT,
            WINDOW_SIZE_X,
            WINDOW_SIZE_Y,
            HWND_DESKTOP,
            nullptr,
            GetModuleHandle(nullptr),
            this
    );

    // check HWND
    if (this->hwnd == nullptr) {
        this->stillOpen = false;
        return;
    }

    // set open
    this->stillOpen = true;

    // show window
    ShowWindow(this->hwnd, SW_SHOWNORMAL);
    UpdateWindow(this->hwnd);

    // print raw input devices
    this->rawInputManager.devices_print();
}

/////////////////////
/// Deconstructor ///
/////////////////////

SpiceToolsWindow::~SpiceToolsWindow() {
    delete this->keypadThread;
    DestroyWindow(this->hwnd);
    while (this->isOpen()) {
        this->poll();
    }
    this->hwnd = nullptr;
}




////////////////////////
/// Public Functions ///
////////////////////////

SpiceToolsWindow* SpiceToolsWindow::getInstance() {
    static auto instance = new SpiceToolsWindow();
    return instance;
}

bool SpiceToolsWindow::isOpen() {
    return this->stillOpen;
}

void SpiceToolsWindow::poll() {
    if (GetMessage(&(this->Msg), nullptr, 0, 0) > 0) {
        if (!IsDialogMessage(this->hwnd, &(this->Msg))) {
            TranslateMessage(&(this->Msg));
            DispatchMessage(&(this->Msg));
        }
    } else {
        this->stillOpen = false;
    }
}

WPARAM SpiceToolsWindow::getFinalMsg() {
    return this->Msg.wParam;
}




///////////////////////////
/// Protected Functions ///
///////////////////////////




/////////////////////////
/// Private Functions ///
/////////////////////////

LRESULT CALLBACK SpiceToolsWindow::WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {

    switch (msg) {
        case WM_CREATE: {

            // set user data of window to class pointer
            auto pcs = (LPCREATESTRUCT) lParam;
            auto spiceToolsWindow = (SpiceToolsWindow *) pcs->lpCreateParams;
            SetWindowLongPtrW(hwnd, GWLP_USERDATA, PtrToUlong(spiceToolsWindow));

            // common controls init
            spiceToolsWindow->icex.dwICC = ICC_LISTVIEW_CLASSES | ICC_TAB_CLASSES;
            spiceToolsWindow->icex.dwSize = sizeof(spiceToolsWindow->icex);
            if (InitCommonControlsEx(&spiceToolsWindow->icex) == FALSE)
                MessageBox(nullptr, "Initiation of common controls failed", "Fail", MB_OK);

            // combo box
            spiceToolsWindow->hwndComboBoxGameSwitcher = CreateWindow(
                    WC_COMBOBOX,
                    TEXT(""),
                    CBS_DROPDOWNLIST | CBS_HASSTRINGS | WS_CHILD | WS_OVERLAPPED | WS_VISIBLE,
                    COMBOBOX_POSITION_X,
                    COMBOBOX_POSITION_Y,
                    COMBOBOX_SIZE_X,
                    COMBOBOX_SIZE_Y,
                    hwnd,
                    reinterpret_cast<HMENU>(COMBO_BOX_GAME_SWITCHER),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(spiceToolsWindow->hwndComboBoxGameSwitcher);
            ComboBox_SetMinVisible(spiceToolsWindow->hwndComboBoxGameSwitcher, 256);

            // create tab control
            spiceToolsWindow->hwndTabControl = CreateWindow(
                    WC_TABCONTROL,
                    "",
                    WS_CHILD | WS_VISIBLE,
                    TAB_CTRL_POSITION_X,
                    TAB_CTRL_POSITION_Y,
                    TAB_CTRL_SIZE_X,
                    TAB_CTRL_SIZE_Y,
                    hwnd,
                    reinterpret_cast<HMENU>(TAB_CTRL),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(spiceToolsWindow->hwndTabControl);

            // insert tabs
            TCITEM tie{};
            tie.mask = TCIF_TEXT | TCIF_IMAGE;
            tie.iImage = -1;
            tie.pszText = (LPSTR) "Buttons";
            TabCtrl_InsertItem(spiceToolsWindow->hwndTabControl, 0, &tie);
            tie.pszText = (LPSTR) "Analogs";
            TabCtrl_InsertItem(spiceToolsWindow->hwndTabControl, 1, &tie);
            tie.pszText = (LPSTR) "Keypads";
            TabCtrl_InsertItem(spiceToolsWindow->hwndTabControl, 2, &tie);
            tie.pszText = (LPSTR) "Lights";
            TabCtrl_InsertItem(spiceToolsWindow->hwndTabControl, 3, &tie);
            tie.pszText = (LPSTR) "Options";
            TabCtrl_InsertItem(spiceToolsWindow->hwndTabControl, 4, &tie);
            tie.pszText = (LPSTR) "About";
            TabCtrl_InsertItem(spiceToolsWindow->hwndTabControl, 5, &tie);
            tie.pszText = (LPSTR) "Licenses";
            TabCtrl_InsertItem(spiceToolsWindow->hwndTabControl, 6, &tie);

            // buttons tab window
            spiceToolsWindow->hwndButtons = CreateWindow(
                    WC_STATIC,
                    "",
                    WS_CHILD | WS_CLIPSIBLINGS | WS_VISIBLE | WS_BORDER,
                    0,
                    21,
                    TAB_CTRL_SIZE_X,
                    TAB_CTRL_SIZE_Y - 21,
                    spiceToolsWindow->hwndTabControl,
                    nullptr,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            SetWindowLongPtrW(spiceToolsWindow->hwndButtons, GWLP_USERDATA, PtrToUlong(spiceToolsWindow));
            SetWindowLongPtr(spiceToolsWindow->hwndButtons, GWLP_WNDPROC, (LONG_PTR) ButtonsWndProc);
            SendMessage(spiceToolsWindow->hwndButtons, WM_CREATE, 0, (LONG_PTR) NULL);

            // analogs tab window
            spiceToolsWindow->hwndAnalogs = CreateWindow(
                    WC_STATIC,
                    "",
                    WS_CHILD | WS_CLIPSIBLINGS | WS_VISIBLE | WS_BORDER,
                    0,
                    21,
                    TAB_CTRL_SIZE_X,
                    TAB_CTRL_SIZE_Y - 21,
                    spiceToolsWindow->hwndTabControl,
                    nullptr,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            SetWindowLongPtrW(spiceToolsWindow->hwndAnalogs, GWLP_USERDATA, PtrToUlong(spiceToolsWindow));
            SetWindowLongPtr(spiceToolsWindow->hwndAnalogs, GWLP_WNDPROC, (LONG_PTR) AnalogsWndProc);
            SendMessage(spiceToolsWindow->hwndAnalogs, WM_CREATE, 0, (LONG_PTR) NULL);

            // keypads tab window
            spiceToolsWindow->hwndKeypads = CreateWindow(
                    WC_STATIC,
                    "",
                    WS_CHILD | WS_CLIPSIBLINGS | WS_VISIBLE | WS_BORDER,
                    0,
                    21,
                    TAB_CTRL_SIZE_X,
                    TAB_CTRL_SIZE_Y - 21,
                    spiceToolsWindow->hwndTabControl,
                    nullptr,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            SetWindowLongPtrW(spiceToolsWindow->hwndKeypads, GWLP_USERDATA, PtrToUlong(spiceToolsWindow));
            SetWindowLongPtr(spiceToolsWindow->hwndKeypads, GWLP_WNDPROC, (LONG_PTR) KeypadsWndProc);
            SendMessage(spiceToolsWindow->hwndKeypads, WM_CREATE, 0, (LONG_PTR) NULL);

            // lights tab window
            spiceToolsWindow->hwndLights = CreateWindow(
                    WC_STATIC,
                    "",
                    WS_CHILD | WS_CLIPSIBLINGS | WS_VISIBLE | WS_BORDER,
                    0,
                    21,
                    TAB_CTRL_SIZE_X,
                    TAB_CTRL_SIZE_Y - 21,
                    spiceToolsWindow->hwndTabControl,
                    nullptr,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            SetWindowLongPtrW(spiceToolsWindow->hwndLights, GWLP_USERDATA, PtrToUlong(spiceToolsWindow));
            SetWindowLongPtr(spiceToolsWindow->hwndLights, GWLP_WNDPROC, (LONG_PTR) LightsWndProc);
            SendMessage(spiceToolsWindow->hwndLights, WM_CREATE, 0, (LONG_PTR) NULL);

            // options tab window
            spiceToolsWindow->hwndOptions = CreateWindow(
                    WC_STATIC,
                    "",
                    WS_CHILD | WS_CLIPSIBLINGS | WS_VISIBLE | WS_BORDER,
                    0,
                    21,
                    TAB_CTRL_SIZE_X,
                    TAB_CTRL_SIZE_Y - 21,
                    spiceToolsWindow->hwndTabControl,
                    nullptr,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            SetWindowLongPtrW(spiceToolsWindow->hwndOptions, GWLP_USERDATA, PtrToUlong(spiceToolsWindow));
            SetWindowLongPtr(spiceToolsWindow->hwndOptions, GWLP_WNDPROC, (LONG_PTR) OptionsWndProc);
            SendMessage(spiceToolsWindow->hwndOptions, WM_CREATE, 0, (LONG_PTR) NULL);

            // about tab window
            spiceToolsWindow->hwndAbout = CreateWindow(
                    WC_STATIC,
                    "",
                    WS_CHILD | WS_CLIPSIBLINGS | WS_VISIBLE | WS_BORDER,
                    0,
                    21,
                    TAB_CTRL_SIZE_X,
                    TAB_CTRL_SIZE_Y - 21,
                    spiceToolsWindow->hwndTabControl,
                    nullptr,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            SetWindowLongPtrW(spiceToolsWindow->hwndAbout, GWLP_USERDATA, PtrToUlong(spiceToolsWindow));
            SetWindowLongPtr(spiceToolsWindow->hwndAbout, GWLP_WNDPROC, (LONG_PTR) AboutWndProc);
            SendMessage(spiceToolsWindow->hwndAbout, WM_CREATE, 0, (LONG_PTR) NULL);

            // licenses tab window
            spiceToolsWindow->hwndLicenses = CreateWindow(
                    WC_STATIC,
                    "",
                    WS_CHILD | WS_CLIPSIBLINGS | WS_VISIBLE | WS_BORDER,
                    0,
                    21,
                    TAB_CTRL_SIZE_X,
                    TAB_CTRL_SIZE_Y - 21,
                    spiceToolsWindow->hwndTabControl,
                    nullptr,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            SetWindowLongPtrW(spiceToolsWindow->hwndLicenses, GWLP_USERDATA, PtrToUlong(spiceToolsWindow));
            SetWindowLongPtr(spiceToolsWindow->hwndLicenses, GWLP_WNDPROC, (LONG_PTR) LicensesWndProc);
            SendMessage(spiceToolsWindow->hwndLicenses, WM_CREATE, 0, (LONG_PTR) NULL);

            break;
        }
        case WM_COMMAND: {
            auto spiceToolsWindow = reinterpret_cast<SpiceToolsWindow *>(static_cast<LONG_PTR>(
                    GetWindowLongPtrW(hwnd, GWLP_USERDATA)));

            switch (LOWORD(wParam)) {
                case COMBO_BOX_GAME_SWITCHER:
                    switch (HIWORD(wParam)) {
                        case CBN_SELCHANGE:

                            // add new items
                            spiceToolsWindow->setSelectedGame(
                                    static_cast<unsigned long long int>(
                                            SendMessage(
                                                    spiceToolsWindow->hwndComboBoxGameSwitcher,
                                                    CB_GETCURSEL,
                                                    static_cast<WPARAM>(0),
                                                    static_cast<LPARAM>(0)
                                            )
                                    )
                            );
                            break;
                        default:
                            break;
                    }
                    break;
                default:
                    break;
            }
            break;
        }
        case WM_NOTIFY: {
            auto spiceToolsWindow = reinterpret_cast<SpiceToolsWindow *>(static_cast<LONG_PTR>(
                    GetWindowLongPtrW(hwnd, GWLP_USERDATA)));

            switch (LOWORD(wParam)) {
                case TAB_CTRL:
                    switch (reinterpret_cast<LPNMHDR>(lParam)->code) {
                        case TCN_SELCHANGE: {

                            // hide all tabs
                            ShowWindow(spiceToolsWindow->hwndButtons, SW_HIDE);
                            ShowWindow(spiceToolsWindow->hwndAnalogs, SW_HIDE);
                            ShowWindow(spiceToolsWindow->hwndKeypads, SW_HIDE);
                            ShowWindow(spiceToolsWindow->hwndLights, SW_HIDE);
                            ShowWindow(spiceToolsWindow->hwndOptions, SW_HIDE);
                            ShowWindow(spiceToolsWindow->hwndAbout, SW_HIDE);
                            ShowWindow(spiceToolsWindow->hwndLicenses, SW_HIDE);

                            // show correct tab
                            switch (TabCtrl_GetCurSel(spiceToolsWindow->hwndTabControl)) {
                                case 0: // buttons
                                    ShowWindow(spiceToolsWindow->hwndButtons, SW_SHOW);
                                    spiceToolsWindow->hwndTabControlSelected = spiceToolsWindow->hwndButtons;
                                    break;
                                case 1: // analogs
                                    ShowWindow(spiceToolsWindow->hwndAnalogs, SW_SHOW);
                                    spiceToolsWindow->hwndTabControlSelected = spiceToolsWindow->hwndAnalogs;
                                    break;
                                case 2: // keypads
                                    ShowWindow(spiceToolsWindow->hwndKeypads, SW_SHOW);
                                    spiceToolsWindow->hwndTabControlSelected = spiceToolsWindow->hwndKeypads;
                                    break;
                                case 3: // lights
                                    ShowWindow(spiceToolsWindow->hwndLights, SW_SHOW);
                                    spiceToolsWindow->hwndTabControlSelected = spiceToolsWindow->hwndLights;
                                    break;
                                case 4: // options
                                    ShowWindow(spiceToolsWindow->hwndOptions, SW_SHOW);
                                    spiceToolsWindow->hwndTabControlSelected = spiceToolsWindow->hwndOptions;
                                    break;
                                case 5: // about
                                    ShowWindow(spiceToolsWindow->hwndAbout, SW_SHOW);
                                    spiceToolsWindow->hwndTabControlSelected = spiceToolsWindow->hwndAbout;
                                    break;
                                case 6: // licenses
                                    ShowWindow(spiceToolsWindow->hwndLicenses, SW_SHOW);
                                    spiceToolsWindow->hwndTabControlSelected = spiceToolsWindow->hwndLicenses;
                                    break;
                                default:

                                    // show buttons window on unknown tab
                                    ShowWindow(spiceToolsWindow->hwndButtons, SW_SHOW);
                                    break;
                            }

                            // redraw
                            RedrawWindow(spiceToolsWindow->hwnd, nullptr, nullptr, RDW_INVALIDATE);
                        }
                        default:
                            break;
                    }
                default:
                    break;
            }
            break;
        }
        case WM_INITDIALOG: {

            break;
        }
        case WM_CLOSE:
            DestroyWindow(hwnd);
            break;
        case WM_DESTROY:
            PostQuitMessage(0);
            break;
        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

LRESULT CALLBACK SpiceToolsWindow::ButtonsWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
        case WM_CTLCOLORSTATIC: {
            SetTextColor((HDC) wParam, RGB(0,0,0));
            SetBkMode((HDC) wParam, TRANSPARENT);
            return (LRESULT) GetStockObject(NULL_BRUSH);
        }
        case WM_SHOWWINDOW: {
            auto *spiceToolsWindow = reinterpret_cast<SpiceToolsWindow *>(static_cast<LONG_PTR>(
                    GetWindowLongPtrW(hwnd, GWLP_USERDATA)));

            // reset selected key alternative page
            spiceToolsWindow->selectedKeyAlternative = -1;

            break;
        }
        case WM_CREATE: {
            auto *spiceToolsWindow = reinterpret_cast<SpiceToolsWindow *>(static_cast<LONG_PTR>(
                    GetWindowLongPtrW(hwnd, GWLP_USERDATA)));

            // list view
            spiceToolsWindow->hwndButtonsListViewSelectedGame = CreateWindowExA(
                    WS_EX_CLIENTEDGE,
                    WC_LISTVIEW,
                    nullptr,
                    WS_VISIBLE | WS_CHILD | LVS_REPORT | LVS_SINGLESEL | LVS_SHOWSELALWAYS,
                    LIST_VIEW_POSITION_X,
                    LIST_VIEW_POSITION_Y,
                    LIST_VIEW_SIZE_X,
                    LIST_VIEW_SIZE_Y - 16,
                    hwnd,
                    reinterpret_cast<HMENU>(LIST_VIEW_BINDINGS),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            ListView_SetExtendedListViewStyle(
                    spiceToolsWindow->hwndButtonsListViewSelectedGame,
                    LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES | LVS_EX_TWOCLICKACTIVATE
            );
            spiceToolsWindow->setDefaultFont(spiceToolsWindow->hwndButtonsListViewSelectedGame);

            // add columns to list view
            LVCOLUMNA LvCol{};
            LvCol.mask = LVCF_TEXT | LVCF_WIDTH;
            LvCol.cx = 115;
            LvCol.pszText = (LPSTR) LIST_VIEW_BUTTONS_COLUMN_ONE_TEXT;
            ListView_InsertColumn(spiceToolsWindow->hwndButtonsListViewSelectedGame, 0, &LvCol);
            LvCol.cx = 170;
            LvCol.pszText = (LPSTR) LIST_VIEW_BUTTONS_COLUMN_TWO_TEXT;
            ListView_InsertColumn(spiceToolsWindow->hwndButtonsListViewSelectedGame, 1, &LvCol);

            // previous alternative button
            HWND buttonPreviousAlternative = CreateWindow(
                    WC_BUTTON,
                    "<",
                    WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,
                    LIST_VIEW_POSITION_X,
                    LIST_VIEW_POSITION_Y + LIST_VIEW_SIZE_Y - 14,
                    16,
                    20,
                    hwnd,
                    reinterpret_cast<HMENU>(BUTTON_PREVIOUS_ALTERNATIVE),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(buttonPreviousAlternative);

            // next alternative button
            HWND buttonNextAlternative = CreateWindow(
                    WC_BUTTON,
                    ">",
                    WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,
                    LIST_VIEW_POSITION_X + 50,
                    LIST_VIEW_POSITION_Y + LIST_VIEW_SIZE_Y - 14,
                    16,
                    20,
                    hwnd,
                    reinterpret_cast<HMENU>(BUTTON_NEXT_ALTERNATIVE),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(buttonNextAlternative);

            // alternative label
            spiceToolsWindow->hwndButtonsAlternative = CreateWindow(
                    WC_BUTTON,
                    "",
                    WS_CHILD | WS_VISIBLE | BS_FLAT | BS_ICON,
                    LIST_VIEW_POSITION_X + 20,
                    LIST_VIEW_POSITION_Y + LIST_VIEW_SIZE_Y - 14,
                    25,
                    20,
                    hwnd,
                    reinterpret_cast<HMENU>(BUTTON_RESET_ALTERNATIVE),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(spiceToolsWindow->hwndButtonsAlternative);
            SetWindowText(spiceToolsWindow->hwndButtonsAlternative, "0");

            // set binding button
            HWND buttonSetBinding = CreateWindow(
                    WC_BUTTON,
                    BUTTON_SET_TEXT,
                    WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,
                    BUTTON_SET_POSITION_X,
                    BUTTON_SET_POSITION_Y,
                    BUTTON_SET_SIZE_X,
                    BUTTON_SET_SIZE_Y,
                    hwnd,
                    reinterpret_cast<HMENU>(BUTTON_SET_BINDING),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(buttonSetBinding);

            // set naive binding button
            HWND buttonSetNaiveBinding = CreateWindow(
                    WC_BUTTON,
                    BUTTON_SET_NAIVE_TEXT,
                    WS_TABSTOP | WS_VISIBLE | WS_CHILD,
                    BUTTON_SET_NAIVE_POSITION_X,
                    BUTTON_SET_NAIVE_POSITION_Y,
                    BUTTON_SET_NAIVE_SIZE_X,
                    BUTTON_SET_NAIVE_SIZE_Y,
                    hwnd,
                    reinterpret_cast<HMENU>(BUTTON_SET_NAIVE_BINDING),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(buttonSetNaiveBinding);

            // clear binding button
            HWND buttonClearBinding = CreateWindow(
                    WC_BUTTON,
                    BUTTON_CLEAR_TEXT,
                    WS_TABSTOP | WS_VISIBLE | WS_CHILD,
                    BUTTON_CLEAR_POSITION_X,
                    BUTTON_CLEAR_POSITION_Y,
                    BUTTON_CLEAR_SIZE_X,
                    BUTTON_CLEAR_SIZE_Y,
                    hwnd,
                    reinterpret_cast<HMENU>(BUTTON_CLEAR_BINDING),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(buttonClearBinding);

            break;
        }
        case WM_COMMAND: {
            auto spiceToolsWindow = reinterpret_cast<SpiceToolsWindow *>(static_cast<LONG_PTR>(
                    GetWindowLongPtrW(hwnd, GWLP_USERDATA)));
            switch (LOWORD(wParam)) {
                case BUTTON_PREVIOUS_ALTERNATIVE:
                    switch (HIWORD(wParam)) {
                        case BN_CLICKED: {
                            if (spiceToolsWindow->selectedKeyAlternative >= 0)
                                spiceToolsWindow->selectedKeyAlternative--;
                            else
                                spiceToolsWindow->selectedKeyAlternative = 98;
                            SetWindowText(spiceToolsWindow->hwndButtonsAlternative,
                                          to_string(spiceToolsWindow->selectedKeyAlternative + 1).c_str());
                            spiceToolsWindow->setSelectedGame((unsigned long long) spiceToolsWindow->selectedGame);
                            break;
                        }
                        default:
                            break;
                    }
                    break;
                case BUTTON_NEXT_ALTERNATIVE:
                    switch (HIWORD(wParam)) {
                    case BN_CLICKED: {
                            if (spiceToolsWindow->selectedKeyAlternative < 98)
                                spiceToolsWindow->selectedKeyAlternative++;
                            else
                                spiceToolsWindow->selectedKeyAlternative = -1;
                            SetWindowText(spiceToolsWindow->hwndButtonsAlternative,
                                          to_string(spiceToolsWindow->selectedKeyAlternative + 1).c_str());
                            spiceToolsWindow->setSelectedGame((unsigned long long) spiceToolsWindow->selectedGame);
                            break;
                        }
                        default:
                            break;
                    }
                    break;
                case BUTTON_RESET_ALTERNATIVE:
                    switch (HIWORD(wParam)) {
                        case BN_CLICKED: {
                            spiceToolsWindow->selectedKeyAlternative = -1;
                            SetWindowText(spiceToolsWindow->hwndButtonsAlternative,
                                          to_string(spiceToolsWindow->selectedKeyAlternative + 1).c_str());
                            spiceToolsWindow->setSelectedGame((unsigned long long) spiceToolsWindow->selectedGame);
                            break;
                        }
                        default:
                            break;
                    }
                    break;
                case BUTTON_SET_BINDING:
                    switch (HIWORD(wParam)) {
                        case BN_CLICKED: {
                            auto listViewItem = ListView_GetNextItem(
                                    spiceToolsWindow->hwndButtonsListViewSelectedGame,
                                    (WPARAM) -1,
                                    LVNI_SELECTED
                            );

                            if (listViewItem != -1) {
                                spiceToolsWindow->selectedKeyBinding = listViewItem;
                                DialogBoxParam(
                                        GetModuleHandle(nullptr),
                                        MAKEINTRESOURCE(IDD_DIALOG1),
                                        hwnd,
                                        (DLGPROC) SpiceToolsWindow::GetButtonBindingProc,
                                        (LPARAM) (spiceToolsWindow)
                                );
                            }
                            break;
                        }
                        default:
                            break;
                    }
                    break;
                case BUTTON_SET_NAIVE_BINDING:
                    switch (HIWORD(wParam)) {
                        case BN_CLICKED: {
                            auto listViewItem = ListView_GetNextItem(
                                    spiceToolsWindow->hwndButtonsListViewSelectedGame,
                                    (WPARAM) -1,
                                    LVNI_SELECTED
                            );

                            if (listViewItem != -1) {
                                spiceToolsWindow->selectedKeyBinding = listViewItem;
                                DialogBoxParam(
                                        GetModuleHandle(nullptr),
                                        MAKEINTRESOURCE(IDD_DIALOG1),
                                        hwnd,
                                        (DLGPROC) SpiceToolsWindow::GetButtonNaiveBindingProc,
                                        (LPARAM) (spiceToolsWindow)
                                );
                            }
                            break;
                        }
                        default:
                            break;
                    }
                    break;
                case BUTTON_CLEAR_BINDING:
                    switch (HIWORD(wParam)) {
                        case BN_CLICKED: {
                            auto listViewItem = ListView_GetNextItem(
                                    spiceToolsWindow->hwndButtonsListViewSelectedGame,
                                    (WPARAM) -1,
                                    LVNI_SELECTED
                            );
                            if (listViewItem != -1) {
                                spiceToolsWindow->selectedKeyBinding = listViewItem;
                                char buffer[256] = "";

                                wsprintfA(buffer, LIST_VIEW_ROW_NOT_SET_TEXT);

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wreturn-stack-address"
                                ListView_SetItemText( // NOLINT
                                        spiceToolsWindow->hwndButtonsListViewSelectedGame,
                                        (WPARAM) listViewItem,
                                        1,
                                        buffer
                                );
#pragma clang diagnostic pop

                                // update button
                                int alternative = spiceToolsWindow->selectedKeyAlternative;
                                Game* game = spiceToolsWindow->games.at(
                                        (unsigned int) (spiceToolsWindow->selectedGame));
                                Button* button = game->getButtons()->at(
                                        (unsigned int) (spiceToolsWindow->selectedKeyBinding));
                                if (alternative >= 0) {
                                    while (button->getAlternatives()->size() <= (size_t) alternative)
                                        button->getAlternatives()->push_back(Button(button->getName()));
                                    button = &button->getAlternatives()->at((size_t) alternative);
                                }
                                button->setVKey(0xFF);
                                button->setDeviceIdentifier("");
                                button->setAnalogType(BAT_NONE);

                                // update config for binding
                                Config::getInstance().updateBinding(game, button, alternative);
                            }
                            break;
                        }
                        default:
                            break;
                    }
                    break;
                default:
                    break;
            }
            break;
        }
        case WM_NOTIFY: {
            auto *spiceToolsWindow = reinterpret_cast<SpiceToolsWindow *>(static_cast<LONG_PTR>(
                    GetWindowLongPtrW(hwnd, GWLP_USERDATA)));
            switch (LOWORD(wParam)) {
                case LIST_VIEW_BINDINGS: {
                    switch (reinterpret_cast<LPNMHDR>(lParam)->code) {
                        case LVN_ITEMACTIVATE: {
                            auto selectedItem = reinterpret_cast<LPNMITEMACTIVATE>(lParam);
                            if (selectedItem->iItem != -1) {
                                spiceToolsWindow->selectedKeyBinding = selectedItem->iItem;
                                DialogBoxParam(
                                        GetModuleHandle(nullptr),
                                        MAKEINTRESOURCE(IDD_DIALOG1),
                                        hwnd,
                                        (DLGPROC) SpiceToolsWindow::GetButtonBindingProc,
                                        (LPARAM) (spiceToolsWindow)
                                );
                            }
                            break;
                        }
                        default:
                            break;
                    }
                }
                default:
                    break;
            }

            // disable column resize
            switch (reinterpret_cast<NMHDR *>(lParam)->code) {
                case HDN_BEGINTRACKW:
                case HDN_BEGINTRACKA:
                    return TRUE;
                default:
                    break;
            }

            break;
        }
        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

LRESULT CALLBACK SpiceToolsWindow::AnalogsWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {

    switch (msg) {
        case WM_CTLCOLORSTATIC: {
            SetTextColor((HDC) wParam, RGB(0,0,0));
            SetBkMode((HDC) wParam, TRANSPARENT);
            return (LRESULT) GetStockObject(NULL_BRUSH);
        }
        case WM_CREATE: {
            auto spiceToolsWindow = reinterpret_cast<SpiceToolsWindow *>(static_cast<LONG_PTR>(
                    GetWindowLongPtrW(hwnd, GWLP_USERDATA)));

            // list view
            spiceToolsWindow->hwndAnalogsListViewSelectedGame = CreateWindowExA(
                    WS_EX_CLIENTEDGE,
                    WC_LISTVIEW,
                    nullptr,
                    WS_VISIBLE | WS_CHILD | LVS_REPORT | LVS_SINGLESEL | LVS_SHOWSELALWAYS,
                    LIST_VIEW_POSITION_X,
                    LIST_VIEW_POSITION_Y,
                    LIST_VIEW_SIZE_X,
                    LIST_VIEW_SIZE_Y,
                    hwnd,
                    reinterpret_cast<HMENU>(LIST_VIEW_BINDINGS),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            ListView_SetExtendedListViewStyle(
                    spiceToolsWindow->hwndAnalogsListViewSelectedGame,
                    LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES | LVS_EX_TWOCLICKACTIVATE
            );
            spiceToolsWindow->setDefaultFont(spiceToolsWindow->hwndAnalogsListViewSelectedGame);

            // add columns to list view
            LVCOLUMNA LvCol{};
            LvCol.mask = LVCF_TEXT | LVCF_WIDTH;
            LvCol.cx = 115;
            LvCol.pszText = (LPSTR) LIST_VIEW_ANALOGS_COLUMN_ONE_TEXT;
            ListView_InsertColumn(spiceToolsWindow->hwndAnalogsListViewSelectedGame, 0, &LvCol);
            LvCol.cx = 170;
            LvCol.pszText = (LPSTR) LIST_VIEW_ANALOGS_COLUMN_TWO_TEXT;
            ListView_InsertColumn(spiceToolsWindow->hwndAnalogsListViewSelectedGame, 1, &LvCol);

            // set binding button
            HWND buttonSetBinding = CreateWindow(
                    WC_BUTTON,
                    BUTTON_SET_TEXT,
                    WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,
                    BUTTON_SET_POSITION_X,
                    BUTTON_SET_POSITION_Y,
                    BUTTON_SET_SIZE_X,
                    BUTTON_SET_SIZE_Y,
                    hwnd,
                    reinterpret_cast<HMENU>(ANALOG_SET_BINDING),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(buttonSetBinding);

            // clear binding button
            HWND buttonClearBinding = CreateWindow(
                    WC_BUTTON,
                    BUTTON_CLEAR_TEXT,
                    WS_TABSTOP | WS_VISIBLE | WS_CHILD,
                    BUTTON_CLEAR_POSITION_X,
                    BUTTON_CLEAR_POSITION_Y,
                    BUTTON_CLEAR_SIZE_X,
                    BUTTON_CLEAR_SIZE_Y,
                    hwnd,
                    reinterpret_cast<HMENU>(ANALOG_CLEAR_BINDING),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(buttonClearBinding);

            break;
        }

        case WM_COMMAND: {
            auto spiceToolsWindow = reinterpret_cast<SpiceToolsWindow *>(static_cast<LONG_PTR>(
                    GetWindowLongPtrW(hwnd, GWLP_USERDATA)));
            switch (LOWORD(wParam)) {
                case ANALOG_SET_BINDING:
                    switch (HIWORD(wParam)) {
                        case BN_CLICKED: {
                            auto listViewItem = ListView_GetNextItem(
                                    spiceToolsWindow->hwndAnalogsListViewSelectedGame,
                                    (WPARAM) -1,
                                    LVNI_SELECTED
                            );
                            if (listViewItem != -1) {
                                spiceToolsWindow->selectedAnalogBinding = listViewItem;
                                std::thread t([spiceToolsWindow] {
                                    AnalogBindingDialog dialog(spiceToolsWindow, spiceToolsWindow->hwnd);
                                    while (dialog.isOpen())
                                        dialog.poll();
                                });
                                t.detach();
                            }
                            break;
                        }
                        default:
                            break;
                    }
                    break;
                case ANALOG_CLEAR_BINDING:
                    switch (HIWORD(wParam)) {
                        case BN_CLICKED: {
                            auto listViewItem = ListView_GetNextItem(
                                    spiceToolsWindow->hwndAnalogsListViewSelectedGame,
                                    (WPARAM) -1,
                                    LVNI_SELECTED
                            );
                            if (listViewItem != -1) {
                                spiceToolsWindow->selectedAnalogBinding = listViewItem;
                                char buffer[256] = "";
                                wsprintfA(buffer, LIST_VIEW_ROW_NOT_SET_TEXT);
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wreturn-stack-address"
                                ListView_SetItemText( // NOLINT
                                        spiceToolsWindow->hwndAnalogsListViewSelectedGame,
                                        (WPARAM) listViewItem,
                                        1,
                                        buffer
                                );
#pragma clang diagnostic pop

                                // update analog
                                Game* game = spiceToolsWindow->games.at(
                                        (unsigned int) (spiceToolsWindow->selectedGame));
                                Analog* analog = game->getAnalogs()->at(
                                        (unsigned int) (spiceToolsWindow->selectedAnalogBinding));
                                analog->setIndex(0xFF);
                                analog->setDeviceIdentifier("");
                                analog->setSensivity(1.f);

                                // update config for binding
                                Config::getInstance().updateBinding(game, analog);
                            }
                            break;
                        }
                        default:
                            break;
                    }
                    break;
                default:
                    break;
            }
            break;
        }
        case WM_NOTIFY: {
            auto *spiceToolsWindow = reinterpret_cast<SpiceToolsWindow *>(static_cast<LONG_PTR>(
                    GetWindowLongPtrW(hwnd, GWLP_USERDATA)));
            switch (LOWORD(wParam)) {
                case LIST_VIEW_BINDINGS: {
                    switch (reinterpret_cast<LPNMHDR>(lParam)->code) {
                        case LVN_ITEMACTIVATE: {
                            auto selectedItem = reinterpret_cast<LPNMITEMACTIVATE>(lParam);
                            if (selectedItem->iItem != -1) {
                                spiceToolsWindow->selectedAnalogBinding = selectedItem->iItem;
                                std::thread t([spiceToolsWindow] {
                                    AnalogBindingDialog dialog(spiceToolsWindow, spiceToolsWindow->hwnd);
                                    while (dialog.isOpen())
                                        dialog.poll();
                                });
                                t.detach();
                            }
                            break;
                        }
                        default:
                            break;
                    }
                }
                default:
                    break;
            }

            // disable column resize
            switch (reinterpret_cast<NMHDR *>(lParam)->code) {
                case HDN_BEGINTRACKW:
                case HDN_BEGINTRACKA:
                    return TRUE;
                default:
                    break;
            }

            break;
        }
        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

LRESULT CALLBACK SpiceToolsWindow::KeypadsWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
        case WM_CTLCOLOREDIT:
        case WM_CTLCOLORSTATIC: {
            SetTextColor((HDC) wParam, RGB(0,0,0));
            SetBkMode((HDC) wParam, TRANSPARENT);
            return (LRESULT) CreateSolidBrush(RGB(240, 240, 240));
        }
        case WM_CREATE: {
            auto spiceToolsWindow = reinterpret_cast<SpiceToolsWindow *>(static_cast<LONG_PTR>(
                    GetWindowLongPtrW(hwnd, GWLP_USERDATA)));

            // P1 label
            HWND p1_label = CreateWindowEx(
                    WS_EX_TRANSPARENT,
                    WC_STATIC,
                    "",
                    WS_CHILD | WS_VISIBLE | SS_LEFT | WS_SYSMENU,
                    10, 10,
                    WINDOW_SIZE_X - 80, 15,
                    hwnd,
                    nullptr,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(p1_label);
            SetWindowText(p1_label, "P1 Reader");

            // P1 reader
            spiceToolsWindow->hwndKeypadsBox[0] = CreateWindow(
                    WC_COMBOBOX,
                    TEXT(""),
                    CBS_DROPDOWNLIST | CBS_HASSTRINGS | WS_CHILD | WS_OVERLAPPED | WS_VISIBLE,
                    10, 30,
                    WINDOW_SIZE_X - 50, WINDOW_SIZE_Y,
                    hwnd,
                    (HMENU) KEYPADS_P1,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(spiceToolsWindow->hwndKeypadsBox[0]);

            // P1 reader test
            spiceToolsWindow->hwndKeypadsTest[0] = CreateWindowEx(
                    WS_EX_TRANSPARENT,
                    WC_STATIC,
                    "",
                    WS_CHILD | WS_VISIBLE | SS_LEFT | WS_SYSMENU,
                    14, 55,
                    WINDOW_SIZE_X - 80, 15,
                    hwnd,
                    nullptr,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(spiceToolsWindow->hwndKeypadsTest[0]);
            SetWindowText(spiceToolsWindow->hwndKeypadsTest[0], "Test: ");

            // P2 label
            HWND p2_label = CreateWindowEx(
                    WS_EX_TRANSPARENT,
                    WC_STATIC,
                    "",
                    WS_CHILD | WS_VISIBLE | SS_LEFT | WS_SYSMENU,
                    10, 80,
                    WINDOW_SIZE_X - 80, 15,
                    hwnd,
                    nullptr,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(p2_label);
            SetWindowText(p2_label, "P2 Reader");

            // P2 reader
            spiceToolsWindow->hwndKeypadsBox[1] = CreateWindow(
                    WC_COMBOBOX,
                    TEXT(""),
                    CBS_DROPDOWNLIST | CBS_HASSTRINGS | WS_CHILD | WS_OVERLAPPED | WS_VISIBLE,
                    10, 100,
                    WINDOW_SIZE_X - 50, WINDOW_SIZE_Y,
                    hwnd,
                    (HMENU) KEYPADS_P2,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(spiceToolsWindow->hwndKeypadsBox[1]);

            // P2 reader test
            spiceToolsWindow->hwndKeypadsTest[1] = CreateWindowEx(
                    WS_EX_TRANSPARENT,
                    WC_STATIC,
                    "",
                    WS_CHILD | WS_VISIBLE | SS_LEFT | WS_SYSMENU,
                    14, 125,
                    WINDOW_SIZE_X - 80, 15,
                    hwnd,
                    nullptr,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(spiceToolsWindow->hwndKeypadsTest[1]);
            SetWindowText(spiceToolsWindow->hwndKeypadsTest[1], "Test: ");

            // desc label
            HWND desc_label = CreateWindowEx(
                    WS_EX_TRANSPARENT,
                    WC_STATIC,
                    "",
                    WS_CHILD | WS_VISIBLE | SS_LEFT | WS_SYSMENU,
                    10, 155,
                    WINDOW_SIZE_X - 80, 15,
                    hwnd,
                    nullptr,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(desc_label);
            SetWindowText(desc_label, "Set both keypads to \"None\" to accept any keypad.");

            // card1 label
            HWND card1_label = CreateWindowEx(
                    WS_EX_TRANSPARENT,
                    WC_STATIC,
                    "",
                    WS_CHILD | WS_VISIBLE | SS_LEFT | WS_SYSMENU,
                    10, 200,
                    WINDOW_SIZE_X - 80, 15,
                    hwnd,
                    nullptr,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(card1_label);
            SetWindowText(card1_label, "P1 Card Path");

            // card1 box
            spiceToolsWindow->hwndCards[0] = CreateWindowEx(
                    WS_EX_CLIENTEDGE,
                    WC_EDIT,
                    nullptr,
                    WS_CHILD | WS_VISIBLE | ES_LEFT | ES_AUTOHSCROLL,
                    10, 220,
                    WINDOW_SIZE_X - 115, 20,
                    hwnd,
                    nullptr,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(spiceToolsWindow->hwndCards[0]);
            SendMessage(spiceToolsWindow->hwndCards[0], EM_SETCUEBANNER, 0, (LPARAM) L"card0.txt");
            SHAutoComplete(spiceToolsWindow->hwndCards[0], SHACF_DEFAULT);

            // card1 select button
            HWND card1_btn = CreateWindow(
                    WC_BUTTON,
                    "...",
                    WS_TABSTOP | WS_VISIBLE | WS_CHILD,
                    WINDOW_SIZE_X - 100, 219,
                    25, 20,
                    hwnd,
                    (HMENU) CARD1_BTN,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(card1_btn);

            // card1 clear button
            HWND card1_clr_btn = CreateWindow(
                    WC_BUTTON,
                    "Clear",
                    WS_TABSTOP | WS_VISIBLE | WS_CHILD,
                    WINDOW_SIZE_X - 70, 219,
                    30, 20,
                    hwnd,
                    (HMENU) CARD1_CLR_BTN,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(card1_clr_btn);

            // card2 label
            HWND card2_label = CreateWindowEx(
                    WS_EX_TRANSPARENT,
                    WC_STATIC,
                    "",
                    WS_CHILD | WS_VISIBLE | SS_LEFT | WS_SYSMENU,
                    10, 250,
                    WINDOW_SIZE_X - 80, 15,
                    hwnd,
                    nullptr,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(card2_label);
            SetWindowText(card2_label, "P2 Card Path");

            // card2 box
            spiceToolsWindow->hwndCards[1] = CreateWindowEx(
                    WS_EX_CLIENTEDGE,
                    WC_EDIT,
                    nullptr,
                    WS_CHILD | WS_VISIBLE | ES_LEFT | ES_AUTOHSCROLL,
                    10, 270,
                    WINDOW_SIZE_X - 115, 20,
                    hwnd,
                    nullptr,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(spiceToolsWindow->hwndCards[1]);
            SendMessage(spiceToolsWindow->hwndCards[1], EM_SETCUEBANNER, 0, (LPARAM) L"card1.txt");
            SHAutoComplete(spiceToolsWindow->hwndCards[1], SHACF_DEFAULT);

            // card1 clear button
            HWND card2_clr_btn = CreateWindow(
                    WC_BUTTON,
                    "Clear",
                    WS_TABSTOP | WS_VISIBLE | WS_CHILD,
                    WINDOW_SIZE_X - 70, 269,
                    30, 20,
                    hwnd,
                    (HMENU) CARD2_CLR_BTN,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(card2_clr_btn);

            // card2 select button
            HWND card2_btn = CreateWindow(
                    WC_BUTTON,
                    "...",
                    WS_TABSTOP | WS_VISIBLE | WS_CHILD,
                    WINDOW_SIZE_X - 100, 269,
                    25, 20,
                    hwnd,
                    (HMENU) CARD2_BTN,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(card2_btn);

            // start keypad test thread
            spiceToolsWindow->keypadThread = new std::thread([spiceToolsWindow] {
                while (spiceToolsWindow) {
                    int index = 1;
                    for (auto &device : *spiceToolsWindow->rawInputManager.devices_get()) {
                        if (device.type != rawinput::KEYBOARD)
                            continue;
                        device.mutex->lock();
                        for (int p = 0; p < 2; p++) {
                            if (index == spiceToolsWindow->selectedKeypad[p]) {
                                auto &kb = *device.keyboardInfo;
                                std::string s = "Test: ";
                                static int ALT_KEYS[] {
                                        VK_INSERT,
                                        VK_END,
                                        VK_DOWN,
                                        VK_NEXT,
                                        VK_LEFT,
                                        VK_CLEAR,
                                        VK_RIGHT,
                                        VK_HOME,
                                        VK_UP,
                                        VK_PRIOR
                                };
                                bool detected[10]{};
                                for (int vki = 0; vki < 1024; vki += 256) {
                                    for (int vkey = VK_NUMPAD0; vkey <= VK_NUMPAD9; vkey++)
                                        if (kb.key_states[vki + vkey] && !detected[vkey - VK_NUMPAD0]) {
                                            detected[vkey - VK_NUMPAD0] = true;
                                            s += to_string(vkey - VK_NUMPAD0);
                                        }
                                    for (int i = 0; i < 10; i++)
                                        if (kb.key_states[vki + ALT_KEYS[i]] && !detected[i]) {
                                            detected[i] = true;
                                            s += to_string(i);
                                        }
                                }
                                char buffer[256];
                                GetWindowText(spiceToolsWindow->hwndKeypadsTest[p], (LPSTR) &buffer, sizeof(buffer));
                                if (strcmp(s.c_str(), (const char *) &buffer) != 0 &&
                                        spiceToolsWindow->hwndTabControlSelected == spiceToolsWindow->hwndKeypads) {
                                    SetWindowText(spiceToolsWindow->hwndKeypadsTest[p], s.c_str());
                                    ShowWindow(spiceToolsWindow->hwndKeypads, SW_HIDE);
                                    ShowWindow(spiceToolsWindow->hwndKeypads, SW_SHOW);
                                }
                            }
                        }
                        device.mutex->unlock();
                        index++;
                    }
                    do
                        Sleep(16);
                    while (spiceToolsWindow->hwndTabControlSelected != spiceToolsWindow->hwndKeypads);
                }
            });

            break;
        }
        case WM_COMMAND: {
            auto spiceToolsWindow = reinterpret_cast<SpiceToolsWindow *>(static_cast<LONG_PTR>(
                    GetWindowLongPtrW(hwnd, GWLP_USERDATA)));
            switch (LOWORD(wParam)) {
                case KEYPADS_P1: {
                    auto selection = (int) SendMessage(spiceToolsWindow->hwndKeypadsBox[0], CB_GETCURSEL, 0, 0);
                    spiceToolsWindow->selectedKeypad[0] = selection;
                    ConfigKeypadBindings keypadBindings = spiceToolsWindow->getKeypadBindings();
                    auto device = spiceToolsWindow->getKeypadDevice(selection);
                    if (device)
                        keypadBindings.keypads[0] = device->name;
                    else
                        keypadBindings.keypads[0] = "";
                    spiceToolsWindow->updateBindings(keypadBindings);
                    break;
                }
                case KEYPADS_P2: {
                    auto selection = (int) SendMessage(spiceToolsWindow->hwndKeypadsBox[1], CB_GETCURSEL, 0, 0);
                    spiceToolsWindow->selectedKeypad[1] = selection;
                    ConfigKeypadBindings keypadBindings = spiceToolsWindow->getKeypadBindings();
                    auto device = spiceToolsWindow->getKeypadDevice(selection);
                    if (device)
                        keypadBindings.keypads[1] = device->name;
                    else
                        keypadBindings.keypads[1] = "";
                    spiceToolsWindow->updateBindings(keypadBindings);
                    break;
                }
                case CARD1_BTN:
                case CARD2_BTN: {

                    // check if button was clicked
                    if (HIWORD(wParam) == BN_CLICKED) {

                        // open dialog to get path
                        auto ofn_path = new char[512]{};
                        OPENFILENAME ofn{};
                        memset(&ofn, 0, sizeof(ofn));
                        ofn.lStructSize = sizeof(ofn);
                        ofn.hwndOwner = nullptr;
                        ofn.lpstrFilter = "";
                        ofn.lpstrFile = ofn_path;
                        ofn.nMaxFile = 512;
                        ofn.Flags = OFN_EXPLORER;
                        ofn.lpstrDefExt = "txt";
                        auto success = (bool) GetSaveFileName(&ofn);

                        // check for success
                        if (success) {

                            // get path
                            std::string path(ofn_path);

                            // get index
                            int card_index = wParam == CARD2_BTN ? 1 : 0;

                            // update bindings
                            auto keypadBindings = spiceToolsWindow->getKeypadBindings();
                            keypadBindings.card_paths[card_index] = path;
                            spiceToolsWindow->updateBindings(keypadBindings);

                            // set text
                            SetWindowText(spiceToolsWindow->hwndCards[card_index], path.c_str());

                        } else {
                            auto error = CommDlgExtendedError();
                            if (error)
                                log_warning("cfg", "Couldn't get save file name: " + to_string(error));
                        }

                        // clean up
                        delete[] ofn_path;
                    }
                    break;
                }
                case CARD1_CLR_BTN:
                case CARD2_CLR_BTN: {

                    // check if button was pressed
                    if (HIWORD(wParam) == BN_CLICKED) {

                        // get index
                        int card_index = wParam == CARD2_CLR_BTN ? 1 : 0;

                        // update bindings
                        auto keypadBindings = spiceToolsWindow->getKeypadBindings();
                        keypadBindings.card_paths[card_index] = "";
                        spiceToolsWindow->updateBindings(keypadBindings);

                        // set text
                        SetWindowText(spiceToolsWindow->hwndCards[card_index], "");
                    }
                    break;
                }
                default:
                    break;
            }
            break;
        }
        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

LRESULT CALLBACK SpiceToolsWindow::LightsWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
        case WM_CTLCOLORSTATIC: {
            SetTextColor((HDC) wParam, RGB(0,0,0));
            SetBkMode((HDC) wParam, TRANSPARENT);
            return (LRESULT) GetStockObject(NULL_BRUSH);
        }
        case WM_SHOWWINDOW: {
            auto *spiceToolsWindow = reinterpret_cast<SpiceToolsWindow *>(static_cast<LONG_PTR>(
                    GetWindowLongPtrW(hwnd, GWLP_USERDATA)));

            // reset selected lights alternative page
            spiceToolsWindow->selectedLightAlternative = -1;

            break;
        }
        case WM_CREATE: {
            auto *spiceToolsWindow = reinterpret_cast<SpiceToolsWindow *>(static_cast<LONG_PTR>(
                    GetWindowLongPtrW(hwnd, GWLP_USERDATA)));

            // list view
            spiceToolsWindow->hwndLightsListViewSelectedGame = CreateWindowExA(
                    WS_EX_CLIENTEDGE,
                    WC_LISTVIEW,
                    nullptr,
                    WS_VISIBLE | WS_CHILD | LVS_REPORT | LVS_SINGLESEL | LVS_SHOWSELALWAYS,
                    LIST_VIEW_POSITION_X,
                    LIST_VIEW_POSITION_Y,
                    LIST_VIEW_SIZE_X,
                    LIST_VIEW_SIZE_Y - 16,
                    hwnd,
                    reinterpret_cast<HMENU>(LIST_VIEW_BINDINGS),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            ListView_SetExtendedListViewStyle(
                    spiceToolsWindow->hwndLightsListViewSelectedGame,
                    LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES | LVS_EX_TWOCLICKACTIVATE
            );
            spiceToolsWindow->setDefaultFont(spiceToolsWindow->hwndLightsListViewSelectedGame);

            // add columns to list view
            LVCOLUMNA LvCol{};
            LvCol.mask = LVCF_TEXT | LVCF_WIDTH;
            LvCol.cx = 115;
            LvCol.pszText = (LPSTR) "Light";
            ListView_InsertColumn(spiceToolsWindow->hwndLightsListViewSelectedGame, 0, &LvCol);
            LvCol.cx = 170;
            LvCol.pszText = (LPSTR) "Bindings";
            ListView_InsertColumn(spiceToolsWindow->hwndLightsListViewSelectedGame, 1, &LvCol);

            // previous alternative light
            HWND buttonPreviousAlternative = CreateWindow(
                    WC_BUTTON,
                    "<",
                    WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,
                    LIST_VIEW_POSITION_X,
                    LIST_VIEW_POSITION_Y + LIST_VIEW_SIZE_Y - 14,
                    16,
                    20,
                    hwnd,
                    reinterpret_cast<HMENU>(BUTTON_PREVIOUS_ALTERNATIVE),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(buttonPreviousAlternative);

            // next alternative button
            HWND buttonNextAlternative = CreateWindow(
                    WC_BUTTON,
                    ">",
                    WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,
                    LIST_VIEW_POSITION_X + 50,
                    LIST_VIEW_POSITION_Y + LIST_VIEW_SIZE_Y - 14,
                    16,
                    20,
                    hwnd,
                    reinterpret_cast<HMENU>(BUTTON_NEXT_ALTERNATIVE),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(buttonNextAlternative);

            // alternative label
            spiceToolsWindow->hwndLightsAlternative = CreateWindow(
                    WC_BUTTON,
                    "",
                    WS_CHILD | WS_VISIBLE | BS_FLAT | BS_ICON,
                    LIST_VIEW_POSITION_X + 20,
                    LIST_VIEW_POSITION_Y + LIST_VIEW_SIZE_Y - 14,
                    25,
                    20,
                    hwnd,
                    reinterpret_cast<HMENU>(BUTTON_RESET_ALTERNATIVE),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(spiceToolsWindow->hwndLightsAlternative);
            SetWindowText(spiceToolsWindow->hwndLightsAlternative, "0");

            // set binding button
            HWND buttonSetBinding = CreateWindow(
                    WC_BUTTON,
                    BUTTON_SET_TEXT,
                    WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,
                    BUTTON_SET_POSITION_X,
                    BUTTON_SET_POSITION_Y,
                    BUTTON_SET_SIZE_X,
                    BUTTON_SET_SIZE_Y,
                    hwnd,
                    reinterpret_cast<HMENU>(BUTTON_SET_BINDING),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(buttonSetBinding);

            // clear binding button
            HWND buttonClearBinding = CreateWindow(
                    WC_BUTTON,
                    BUTTON_CLEAR_TEXT,
                    WS_TABSTOP | WS_VISIBLE | WS_CHILD,
                    BUTTON_CLEAR_POSITION_X,
                    BUTTON_CLEAR_POSITION_Y,
                    BUTTON_CLEAR_SIZE_X,
                    BUTTON_CLEAR_SIZE_Y,
                    hwnd,
                    reinterpret_cast<HMENU>(BUTTON_CLEAR_BINDING),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(buttonClearBinding);

            break;
        }
        case WM_COMMAND: {
            auto spiceToolsWindow = reinterpret_cast<SpiceToolsWindow *>(static_cast<LONG_PTR>(
                    GetWindowLongPtrW(hwnd, GWLP_USERDATA)));
            switch (LOWORD(wParam)) {
                case BUTTON_PREVIOUS_ALTERNATIVE:
                    switch (HIWORD(wParam)) {
                        case BN_CLICKED: {
                            if (spiceToolsWindow->selectedLightAlternative >= 0)
                                spiceToolsWindow->selectedLightAlternative--;
                            else
                                spiceToolsWindow->selectedLightAlternative = 98;
                            SetWindowText(spiceToolsWindow->hwndLightsAlternative,
                                          to_string(spiceToolsWindow->selectedLightAlternative + 1).c_str());
                            spiceToolsWindow->setSelectedGame((unsigned long long) spiceToolsWindow->selectedGame);
                            break;
                        }
                        default:
                            break;
                    }
                    break;
                case BUTTON_NEXT_ALTERNATIVE:
                    switch (HIWORD(wParam)) {
                        case BN_CLICKED: {
                            if (spiceToolsWindow->selectedLightAlternative < 98)
                                spiceToolsWindow->selectedLightAlternative++;
                            else
                                spiceToolsWindow->selectedLightAlternative = -1;
                            SetWindowText(spiceToolsWindow->hwndLightsAlternative,
                                          to_string(spiceToolsWindow->selectedLightAlternative + 1).c_str());
                            spiceToolsWindow->setSelectedGame((unsigned long long) spiceToolsWindow->selectedGame);
                            break;
                        }
                        default:
                            break;
                    }
                    break;
                case BUTTON_RESET_ALTERNATIVE:
                    switch (HIWORD(wParam)) {
                        case BN_CLICKED: {
                            spiceToolsWindow->selectedLightAlternative = -1;
                            SetWindowText(spiceToolsWindow->hwndLightsAlternative,
                                          to_string(spiceToolsWindow->selectedLightAlternative + 1).c_str());
                            spiceToolsWindow->setSelectedGame((unsigned long long) spiceToolsWindow->selectedGame);
                            break;
                        }
                        default:
                            break;
                    }
                    break;
                case BUTTON_SET_BINDING:
                    switch (HIWORD(wParam)) {
                        case BN_CLICKED: {
                            auto listViewItem = ListView_GetNextItem(
                                    spiceToolsWindow->hwndLightsListViewSelectedGame,
                                    (WPARAM) -1,
                                    LVNI_SELECTED
                            );
                            if (listViewItem != -1) {
                                spiceToolsWindow->selectedLightBinding = listViewItem;
                                std::thread t([spiceToolsWindow] {
                                    LightBindingDialog dialog(spiceToolsWindow, spiceToolsWindow->hwnd);
                                    while (dialog.isOpen())
                                        dialog.poll();
                                });
                                t.detach();
                            }
                            break;
                        }
                        default:
                            break;
                    }
                    break;
                case BUTTON_CLEAR_BINDING:
                    switch (HIWORD(wParam)) {
                        case BN_CLICKED: {
                            auto listViewItem = ListView_GetNextItem(
                                    spiceToolsWindow->hwndLightsListViewSelectedGame,
                                    (WPARAM) -1,
                                    LVNI_SELECTED
                            );
                            if (listViewItem != -1) {
                                spiceToolsWindow->selectedLightBinding = listViewItem;
                                char buffer[256] = "";
                                wsprintfA(buffer, LIST_VIEW_ROW_NOT_SET_TEXT);
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wreturn-stack-address"
                                ListView_SetItemText( // NOLINT
                                        spiceToolsWindow->hwndLightsListViewSelectedGame,
                                        (WPARAM) listViewItem,
                                        1,
                                        buffer
                                );
#pragma clang diagnostic pop

                                // update light
                                Game* game = spiceToolsWindow->games.at(
                                        (unsigned int) (spiceToolsWindow->selectedGame));
                                Light* light = game->getLights()->at(
                                        (unsigned int) (spiceToolsWindow->selectedLightBinding));
                                light->setIndex(0xFF);
                                light->setDeviceIdentifier("");

                                // update config for binding
                                Config::getInstance().updateBinding(
                                        game, light, spiceToolsWindow->selectedLightAlternative);
                            }
                            break;
                        }
                        default:
                            break;
                    }
                    break;
                default:
                    break;
            }
            break;
        }
        case WM_NOTIFY: {
            auto *spiceToolsWindow = reinterpret_cast<SpiceToolsWindow *>(static_cast<LONG_PTR>(
                    GetWindowLongPtrW(hwnd, GWLP_USERDATA)));
            switch (LOWORD(wParam)) {
                case LIST_VIEW_BINDINGS: {
                    switch (reinterpret_cast<LPNMHDR>(lParam)->code) {
                        case LVN_ITEMACTIVATE: {
                            auto selectedItem = reinterpret_cast<LPNMITEMACTIVATE>(lParam);
                            if (selectedItem->iItem != -1) {
                                spiceToolsWindow->selectedLightBinding = selectedItem->iItem;
                                std::thread t([spiceToolsWindow] {
                                    LightBindingDialog dialog(spiceToolsWindow, spiceToolsWindow->hwnd);
                                    while (dialog.isOpen())
                                        dialog.poll();
                                });
                                t.detach();
                            }
                            break;
                        }
                        default:
                            break;
                    }
                }
                default:
                    break;
            }

            // disable column resize
            switch (reinterpret_cast<NMHDR *>(lParam)->code) {
                case HDN_BEGINTRACKW:
                case HDN_BEGINTRACKA:
                    return TRUE;
                default:
                    break;
            }

            break;
        }
        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

LRESULT CALLBACK SpiceToolsWindow::OptionsWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {

    switch (msg) {
        case WM_CTLCOLORSTATIC: {
            SetTextColor((HDC) wParam, RGB(0,0,0));
            SetBkMode((HDC) wParam, TRANSPARENT);
            return (LRESULT) GetStockObject(NULL_BRUSH);
        }
        case WM_CREATE: {
            auto spiceToolsWindow = reinterpret_cast<SpiceToolsWindow *>(static_cast<LONG_PTR>(
                    GetWindowLongPtrW(hwnd, GWLP_USERDATA)));

            // list view
            spiceToolsWindow->hwndOptionsListViewSelectedGame = CreateWindowExA(
                    WS_EX_CLIENTEDGE,
                    WC_LISTVIEW,
                    nullptr,
                    WS_VISIBLE | WS_CHILD | LVS_REPORT | LVS_SINGLESEL | LVS_SHOWSELALWAYS,
                    LIST_VIEW_POSITION_X,
                    LIST_VIEW_POSITION_Y,
                    LIST_VIEW_SIZE_X,
                    LIST_VIEW_SIZE_Y,
                    hwnd,
                    reinterpret_cast<HMENU>(1111),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            ListView_SetExtendedListViewStyle(
                    spiceToolsWindow->hwndOptionsListViewSelectedGame,
                    LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES | LVS_EX_TWOCLICKACTIVATE
            );
            spiceToolsWindow->setDefaultFont(spiceToolsWindow->hwndOptionsListViewSelectedGame);

            // add columns to list view
            LVCOLUMNA LvCol{};
            LvCol.mask = LVCF_TEXT | LVCF_WIDTH;
            LvCol.cx = 115;
            LvCol.pszText = (LPSTR) OPTIONS_LIST_VIEW_COLUMN_ONE_TEXT;
            ListView_InsertColumn(spiceToolsWindow->hwndOptionsListViewSelectedGame, 0, &LvCol);
            LvCol.cx = 170;
            LvCol.pszText = (LPSTR) OPTIONS_LIST_VIEW_COLUMN_TWO_TEXT;
            ListView_InsertColumn(spiceToolsWindow->hwndOptionsListViewSelectedGame, 1, &LvCol);

            // set binding button
            HWND optionSetBinding = CreateWindow(
                    WC_BUTTON,
                    BUTTON_SET_TEXT,
                    WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,
                    BUTTON_SET_POSITION_X,
                    BUTTON_SET_POSITION_Y,
                    BUTTON_SET_SIZE_X,
                    BUTTON_SET_SIZE_Y,
                    hwnd,
                    reinterpret_cast<HMENU>(OPTION_SET_BINDING),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(optionSetBinding);

            // clear binding button
            HWND optionClearBinding = CreateWindow(
                    WC_BUTTON,
                    BUTTON_CLEAR_TEXT,
                    WS_TABSTOP | WS_VISIBLE | WS_CHILD,
                    BUTTON_CLEAR_POSITION_X,
                    BUTTON_CLEAR_POSITION_Y,
                    BUTTON_CLEAR_SIZE_X,
                    BUTTON_CLEAR_SIZE_Y,
                    hwnd,
                    reinterpret_cast<HMENU>(OPTION_CLEAR_BINDING),
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setDefaultFont(optionClearBinding);

            break;
        }

        case WM_COMMAND: {
            auto spiceToolsWindow = reinterpret_cast<SpiceToolsWindow *>(static_cast<LONG_PTR>(
                    GetWindowLongPtrW(hwnd, GWLP_USERDATA)));
            switch (LOWORD(wParam)) {
                case OPTION_SET_BINDING:
                    switch (HIWORD(wParam)) {
                        case BN_CLICKED: {
                            auto listViewItem = ListView_GetNextItem(
                                    spiceToolsWindow->hwndOptionsListViewSelectedGame,
                                    (WPARAM) -1,
                                    LVNI_SELECTED
                            );

                            if (listViewItem != -1) {
                                // TODO open option edit window here
                            }

                            break;
                        }
                        default:
                            break;
                    }
                    break;
                default:
                    break;
            }
        }

        case WM_NOTIFY: {
            break;
        }

        case WM_DESTROY: {
            break;
        }

        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);

    }
    return 0;
}

LRESULT CALLBACK SpiceToolsWindow::AboutWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
        case WM_CTLCOLOREDIT:
        case WM_CTLCOLORSTATIC: {
            SetTextColor((HDC) wParam, RGB(0,0,0));
            SetBkMode((HDC) wParam, TRANSPARENT);
            return (LRESULT) GetStockObject(DC_BRUSH);
        }
        case WM_CREATE: {
            auto spiceToolsWindow = reinterpret_cast<SpiceToolsWindow *>(static_cast<LONG_PTR>(
                    GetWindowLongPtrW(hwnd, GWLP_USERDATA)));

            // text box with scrollbars
            HWND label = CreateWindowEx(
                    WS_EX_TRANSPARENT,
                    WC_EDIT,
                    "",
                    WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | ES_READONLY | ES_LEFT | ES_MULTILINE,
                    8, 0, WINDOW_SIZE_X - 39, WINDOW_SIZE_Y - 80,
                    hwnd,
                    nullptr,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setMonospaceFont(label);

            // load changelog
            SendMessage(label, WM_SETTEXT, (WPARAM) nullptr, (LPARAM) (std::string("\r\n"
                                                                                   "SpiceTools Beta\r\n"
                                                                                   "================\r\n"
            ) + to_string(VERSION_STRING) + "\r\n\r\n" + to_string(
                    resutil::load_file_string_crlf(IDR_CHANGELOG, RT_RCDATA))).c_str());

            break;
        }

        case WM_COMMAND: {
            break;
        }

        case WM_NOTIFY: {
            break;
        }

        case WM_DESTROY: {
            break;
        }

        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);

    }
    return 0;
}

LRESULT CALLBACK SpiceToolsWindow::LicensesWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
        case WM_CTLCOLOREDIT:
        case WM_CTLCOLORSTATIC: {
            SetTextColor((HDC) wParam, RGB(0,0,0));
            SetBkMode((HDC) wParam, TRANSPARENT);
            return (LRESULT) GetStockObject(DC_BRUSH);
        }
        case WM_CREATE: {
            auto spiceToolsWindow = reinterpret_cast<SpiceToolsWindow *>(static_cast<LONG_PTR>(
                    GetWindowLongPtrW(hwnd, GWLP_USERDATA)));

            // text box with scrollbars
            HWND label = CreateWindowEx(
                    WS_EX_TRANSPARENT,
                    WC_EDIT,
                    "",
                    WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | ES_READONLY | ES_LEFT | ES_MULTILINE,
                    8, 0, WINDOW_SIZE_X - 39, WINDOW_SIZE_Y - 80,
                    hwnd,
                    nullptr,
                    GetModuleHandle(nullptr),
                    nullptr
            );
            spiceToolsWindow->setMonospaceFont(label);

            // load licenses
            SendMessage(label, WM_SETTEXT, (WPARAM) nullptr, (LPARAM) (
                    resutil::load_file_string_crlf(IDR_LICENSES, RT_RCDATA)).c_str());

            break;
        }

        case WM_COMMAND: {
            break;
        }

        case WM_NOTIFY: {
            break;
        }

        case WM_DESTROY: {
            break;
        }

        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);

    }
    return 0;
}

static std::thread *keyboardThread;
static std::mutex keyboardThreadClosingMutex;
static bool keyboardThreadShouldClose = false;

struct ButtonBindData {
    rawinput::Device* device;
    unsigned short vkey;
    ButtonAnalogType analog_type;
};

BOOL CALLBACK SpiceToolsWindow::GetButtonBindingProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
        case WM_INITDIALOG: {
            auto spiceToolsWindow = (SpiceToolsWindow *) lParam;

            SetWindowLongPtrW(
                    hwnd,
                    GWLP_USERDATA,
                    PtrToUlong(spiceToolsWindow)
            );

            keyboardThreadClosingMutex.lock();
            keyboardThreadShouldClose = false;
            keyboardThreadClosingMutex.unlock();

            keyboardThread = new std::thread(
                    [hwnd, spiceToolsWindow]() {

                        // midi freeze
                        spiceToolsWindow->rawInputManager.devices_midi_freeze(true);

                        // clear device states
                        for (auto device : *spiceToolsWindow->rawInputManager.devices_get()) {
                            switch (device.type) {
                                case rawinput::HID: {
                                    for (size_t i = 0; i < device.hidInfo->value_states.size(); i++)
                                        device.hidInfo->bind_value_states[i] = device.hidInfo->value_states[i];
                                    break;
                                }
                                case rawinput::MIDI: {
                                    for (size_t i = 0; i < device.midiInfo->states.size(); i++)
                                        device.midiInfo->bind_states[i] = device.midiInfo->states[i];
                                    break;
                                }
                                default:
                                    break;
                            }
                        }

                        do {
                            // check if should close
                            keyboardThreadClosingMutex.lock();
                            if (keyboardThreadShouldClose) {
                                keyboardThreadClosingMutex.unlock();
                                return;
                            }
                            keyboardThreadClosingMutex.unlock();

                            // iterate updated devices
                            auto updated_devices = spiceToolsWindow->rawInputManager.devices_get_updated();
                            for (auto device : updated_devices) {
                                std::lock_guard<std::mutex> lock(*device->mutex);
                                switch (device->type) {
                                    case rawinput::KEYBOARD: {
                                        auto kb = device->keyboardInfo;
                                        for (unsigned short vkey = 0; vkey < 1024; vkey++) {

                                            // check if key is down
                                            if (vkey != VK_NUMLOCK && kb->key_states[vkey]) {

                                                // cancel on escape key
                                                if (vkey == 0x1B) {
                                                    PostMessage(hwnd, WM_COMMAND,
                                                                MAKEWPARAM(IDCANCEL, 0),
                                                                0);
                                                    return;
                                                }

                                                // bind key
                                                auto data = new ButtonBindData();
                                                data->device = device;
                                                data->vkey = vkey;
                                                data->analog_type = BAT_NONE;
                                                PostMessage(hwnd, WM_COMMAND,
                                                            MAKEWPARAM(IDOK, 0),
                                                            (LPARAM) data);
                                                return;
                                            }
                                        }
                                        break;
                                    }
                                    case rawinput::HID: {
                                        auto hid = device->hidInfo;

                                        // button caps
                                        auto button_states_list = &hid->button_states;
                                        unsigned short button_index = 0;
                                        for (auto &button_states : *button_states_list) {
                                            for (unsigned short i = 0; i < button_states.size(); i++) {

                                                // check if button is down
                                                if (button_states[i]) {

                                                    // bind key
                                                    auto data = new ButtonBindData();
                                                    data->device = device;
                                                    data->vkey = button_index + i;
                                                    data->analog_type = BAT_NONE;
                                                    PostMessage(hwnd, WM_COMMAND,
                                                                MAKEWPARAM(IDOK, 0),
                                                                (LPARAM) data);
                                                    return;
                                                }
                                            }
                                            button_index += button_states.size();
                                        }

                                        // value caps
                                        auto value_states = &hid->value_states;
                                        auto bind_value_states = &hid->bind_value_states;
                                        auto value_names = &hid->value_caps_names;
                                        for (unsigned short i = 0; i < value_states->size(); i++) {
                                            auto &state = value_states->at(i);
                                            auto &bind_state = bind_value_states->at(i);
                                            auto &name = value_names->at(i);

                                            // check for valid axis names
                                            if (name == "X" ||
                                                    name == "Y" ||
                                                    name == "Rx" ||
                                                    name == "Ry" ||
                                                    name == "Z") {

                                                // check if axis is in activation area
                                                float normalized = (state - 0.5f) * 2.f;
                                                float diff = std::fabs(state - bind_state);
                                                if (std::fabs(normalized) > 0.9f && diff > 0.1f) {

                                                    // bind value
                                                    auto data = new ButtonBindData();
                                                    data->device = device;
                                                    data->vkey = i;
                                                    data->analog_type = normalized > 0 ? BAT_POSITIVE : BAT_NEGATIVE;
                                                    PostMessage(hwnd, WM_COMMAND,
                                                                MAKEWPARAM(IDOK, 0),
                                                                (LPARAM) data);
                                                    return;
                                                } else if (diff > 0.3f) {
                                                    bind_state = state;
                                                }
                                            }

                                            // hat switch
                                            if (name == "Hat switch") {

                                                // get hat switch values
                                                ButtonAnalogType buffer[3], buffer_bind[3];
                                                Button::getHatSwitchValues(state, buffer);
                                                Button::getHatSwitchValues(bind_state, buffer_bind);

                                                // check the first entry only
                                                if (buffer[0] != BAT_NONE && buffer[0] != buffer_bind[0]) {

                                                    // bind value
                                                    auto data = new ButtonBindData();
                                                    data->device = device;
                                                    data->vkey = i;
                                                    data->analog_type = buffer[0];
                                                    PostMessage(hwnd, WM_COMMAND,
                                                                MAKEWPARAM(IDOK, 0),
                                                                (LPARAM) data);
                                                    return;
                                                }
                                            }
                                        }
                                        break;
                                    }
                                    case rawinput::MIDI: {
                                        auto midi = device->midiInfo;

                                        // iterate all 128 notes on 16 channels
                                        for (unsigned short index = 0; index < 16 * 128; index++) {

                                            // check if note is down
                                            if (midi->states[index]) {

                                                // check if it wasn't down before
                                                if (!midi->bind_states[index]) {

                                                    // bind key
                                                    auto data = new ButtonBindData();
                                                    data->device = device;
                                                    data->vkey = index;
                                                    data->analog_type = BAT_NONE;
                                                    PostMessage(
                                                        hwnd,
                                                        WM_COMMAND,
                                                        MAKEWPARAM(IDOK, 0),
                                                        (LPARAM) data
                                                    );

                                                    return;

                                                }

                                            } else if (midi->bind_states[index]) {

                                                // note was on when dialog opened, is now off
                                                midi->bind_states[index] = false;
                                            }
                                        }

                                        break;
                                    }
                                    case rawinput::PIUIO_DEVICE: {
                                        auto piuio_dev = device->piuioDev;

                                        for (int i = 0; i < rawinput::PIUIO::PIUIO_MAX_NUM_OF_INPUTS; i++) {
                                            if (piuio_dev->IsPressed(i) && !piuio_dev->WasPressed(i)) {

                                                // bind key
                                                auto data = new ButtonBindData();
                                                data->device = device;
                                                data->vkey = i;
                                                data->analog_type = BAT_NONE;
                                                PostMessage(
                                                    hwnd,
                                                    WM_COMMAND,
                                                    MAKEWPARAM(IDOK, 0),
                                                    (LPARAM) data
                                                );

                                                return;
                                            }
                                        }

                                        break;
                                    }
                                    default:
                                        break;
                                }
                            }

                            // chill down
                            Sleep(1000 / 10);

                        } while (true);
                    }
            );
            return TRUE;
        }

        case WM_COMMAND: {
            auto spiceToolsWindow = reinterpret_cast<SpiceToolsWindow *>(
                    static_cast<LONG_PTR>(
                            GetWindowLongPtrW(
                                    hwnd,
                                    GWLP_USERDATA
                            )
                    )
            );
            switch (LOWORD(wParam)) {
                case IDOK: {

                    // midi un-freeze
                    spiceToolsWindow->rawInputManager.devices_midi_freeze(false);

                    // get device
                    auto data = (ButtonBindData*) lParam;

                    // get button
                    Game *game = spiceToolsWindow->games.at((unsigned int) (spiceToolsWindow->selectedGame));
                    Button *button = game->getButtons()->at((unsigned int) (spiceToolsWindow->selectedKeyBinding));

                    // get alternative
                    int alternative = spiceToolsWindow->selectedKeyAlternative;
                    if (alternative >= 0) {
                        while (button->getAlternatives()->size() <= (unsigned int) alternative)
                            button->getAlternatives()->push_back(Button(button->getName()));
                        button = &button->getAlternatives()->at((unsigned int) alternative);
                    }

                    // update button
                    button->setVKey(data->vkey);
                    button->setDeviceIdentifier(data->device->name);
                    button->setAnalogType(data->analog_type);

                    // delete bind data
                    delete data;

                    // update config for binding
                    Config::getInstance().updateBinding(game, button, spiceToolsWindow->selectedKeyAlternative);

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wreturn-stack-address"
                    std::string displayString = button->getDisplayString(&spiceToolsWindow->rawInputManager);
                    ListView_SetItemText( // NOLINT
                            spiceToolsWindow->hwndButtonsListViewSelectedGame,
                            (WPARAM) spiceToolsWindow->selectedKeyBinding,
                            1,
                            (char*) displayString.c_str()
                    );
#pragma clang diagnostic pop

                    // for cleaning up
                    [[fallthrough]];
                }
                case IDCANCEL: {

                    // stop thread
                    if (keyboardThread != nullptr) {
                        keyboardThreadClosingMutex.lock();
                        keyboardThreadShouldClose = true;
                        keyboardThreadClosingMutex.unlock();
                        keyboardThread->join();
                        delete keyboardThread;
                        keyboardThread = nullptr;
                    }

                    // midi un-freeze
                    spiceToolsWindow->rawInputManager.devices_midi_freeze(false);

                    // close dialog
                    EndDialog(hwnd, LOWORD(wParam));
                    return (INT_PTR) TRUE;
                }
                default:
                    break;
            }
            break;
        }
        default:
            break;
    }

    return FALSE;
}

BOOL CALLBACK SpiceToolsWindow::GetButtonNaiveBindingProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
        case WM_INITDIALOG: {
            auto spiceToolsWindow = (SpiceToolsWindow *) lParam;

            SetWindowLongPtrW(
                    hwnd,
                    GWLP_USERDATA,
                    PtrToUlong(spiceToolsWindow)
            );

            keyboardThreadClosingMutex.lock();
            keyboardThreadShouldClose = false;
            keyboardThreadClosingMutex.unlock();

            keyboardThread = new std::thread(
                    [](HWND hwndDialog) {

                        // clear states
                        for (unsigned short int i = 0x01; i < 0xFF; i++)
                            GetAsyncKeyState(i);

                        do {
                            // check if should close
                            keyboardThreadClosingMutex.lock();
                            if (keyboardThreadShouldClose) {
                                keyboardThreadClosingMutex.unlock();
                                return;
                            }
                            keyboardThreadClosingMutex.unlock();

                            // detect key presses
                            for (unsigned short int i = 0x01; i < 0xFF; i++) {

                                // ignore num lock escape sequence
                                if (i != 0x90) {

                                    // check for key press
                                    if (GetAsyncKeyState(i) & 1) {

                                        // cancel on escape
                                        if (i == 0x1B) {
                                            PostMessage(hwndDialog, WM_COMMAND, MAKEWPARAM(IDCANCEL, i), 0);
                                            return;
                                        }

                                        // bind key
                                        PostMessage(hwndDialog, WM_COMMAND, MAKEWPARAM(IDOK, i), 0);
                                        return;
                                    }
                                }
                            }

                            // chill down
                            Sleep(1);

                        } while (true);
                    },
                    hwnd
            );
            return TRUE;
        }

        case WM_COMMAND: {
            auto spiceToolsWindow = reinterpret_cast<SpiceToolsWindow *>(
                    static_cast<LONG_PTR>(
                            GetWindowLongPtrW(
                                    hwnd,
                                    GWLP_USERDATA
                            )
                    )
            );
            switch (LOWORD(wParam)) {
                case IDOK: {

                    // get button
                    Game* game = spiceToolsWindow->games.at((unsigned int) (spiceToolsWindow->selectedGame));
                    Button* button = game->getButtons()->at((unsigned int) (spiceToolsWindow->selectedKeyBinding));

                    // get alternative
                    int alternative = spiceToolsWindow->selectedKeyAlternative;
                    if (alternative >= 0) {
                        while (button->getAlternatives()->size() <= (unsigned int) alternative)
                            button->getAlternatives()->push_back(Button(button->getName()));
                        button = &button->getAlternatives()->at((unsigned int) alternative);
                    }

                    // update button
                    button->setVKey(HIWORD(wParam));
                    button->setDeviceIdentifier("");

                    // update config for binding
                    Config::getInstance().updateBinding(game, button, spiceToolsWindow->selectedKeyAlternative);

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wreturn-stack-address"
                    std::string displayString = button->getDisplayString(&spiceToolsWindow->rawInputManager);
                    ListView_SetItemText( // NOLINT
                            spiceToolsWindow->hwndButtonsListViewSelectedGame,
                            (WPARAM) spiceToolsWindow->selectedKeyBinding,
                            1,
                            (char*) displayString.c_str()
                    );
#pragma clang diagnostic pop

                    // for cleaning up
                    [[fallthrough]];
                }
                case IDCANCEL: {
                    if (keyboardThread != nullptr) {
                        keyboardThreadClosingMutex.lock();
                        keyboardThreadShouldClose = true;
                        keyboardThreadClosingMutex.unlock();
                        keyboardThread->join();
                        delete keyboardThread;
                        keyboardThread = nullptr;
                    }
                    EndDialog(hwnd, LOWORD(wParam));
                    return (INT_PTR) TRUE;
                }
                default:
                    break;
            }
            break;
        }
        default:
            break;
    }

    return FALSE;
}

void SpiceToolsWindow::addGame(Game *game) {
    this->games.push_back(game);

    // add game to the combobox
    SendMessage(
            this->hwndComboBoxGameSwitcher,
            static_cast<UINT>(CB_ADDSTRING),
            static_cast<WPARAM>(0),
            reinterpret_cast<LPARAM>(game->getGameName().c_str())
    );

    // set game to the default in combobox if its the first game to be added
    if (this->games.size() == 1)
        this->setSelectedGame(game);

    // game DLL autodetection
    bool gameFound = false;
    for (std::string dllName : *game->getDLLNames()) {
        if (fileutils::file_exists(dllName.c_str())) {
            gameFound = true;
            break;
        }
        if (fileutils::file_exists(("contents\\" + dllName).c_str())) {
            gameFound = true;
            break;
        }
    }
    if (gameFound)
        this->setSelectedGame(game);
}

void SpiceToolsWindow::setSelectedGame(Game *game) {

    // delete all items
    SendMessage(
            this->hwndButtonsListViewSelectedGame,
            LVM_DELETEALLITEMS,
            static_cast<WPARAM>(0),
            static_cast<LPARAM>(0)
    );
    SendMessage(
            this->hwndAnalogsListViewSelectedGame,
            LVM_DELETEALLITEMS,
            static_cast<WPARAM>(0),
            static_cast<LPARAM>(0)
    );
    SendMessage(
            this->hwndLightsListViewSelectedGame,
            LVM_DELETEALLITEMS,
            static_cast<WPARAM>(0),
            static_cast<LPARAM>(0)
    );
    SendMessage(
            this->hwndOptionsListViewSelectedGame,
            LVM_DELETEALLITEMS,
            static_cast<WPARAM>(0),
            static_cast<LPARAM>(0)
    );
    for (auto &box : this->hwndKeypadsBox)
        SendMessage(
                box,
                CB_RESETCONTENT,
                static_cast<WPARAM>(0),
                static_cast<LPARAM>(0)
        );

    // get game number
    long long int gameNum = std::find(this->games.begin(), this->games.end(), game) - this->games.begin();

    // select game in combo box
    SendMessage(
            this->hwndComboBoxGameSwitcher,
            CB_SETCURSEL,
            static_cast<WPARAM>(gameNum),
            static_cast<LPARAM>(0)
    );

    // set selected game
    this->selectedGame = static_cast<int>(gameNum);

    // create item buffer
    char buffer[256] = "";
    LVITEMA lvItem{};
    lvItem.mask = LVIF_TEXT;
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wreturn-stack-address"
    lvItem.pszText = buffer;
#pragma clang diagnostic pop

    // buttons
    unsigned short int i = 0;
    for (auto &it : *game->getButtons()) {
        Button* button = it;

        // alternative
        int alternative = this->selectedKeyAlternative;
        if (alternative >= 0) {
            while (button->getAlternatives()->size() <= (unsigned int) alternative)
                button->getAlternatives()->push_back(Button(button->getName()));
            button = &button->getAlternatives()->at((unsigned int) alternative);
        }

        wsprintfA(buffer, button->getName().c_str());
        lvItem.iItem = i;
        lvItem.iSubItem = 0;
        ListView_InsertItem(this->hwndButtonsListViewSelectedGame, &lvItem);

        if (button->getVKey() == 0xFF && button->getDeviceIdentifier().empty())
            wsprintfA(buffer, LIST_VIEW_ROW_NOT_SET_TEXT);
        else
            wsprintfA(buffer, button->getDisplayString(&this->rawInputManager).c_str());

        lvItem.iSubItem = 1;
        ListView_SetItem(this->hwndButtonsListViewSelectedGame, &lvItem);
        i++;
    }

    // analogs
    i = 0;
    for (auto &it : *game->getAnalogs()) {
        wsprintfA(buffer, it->getName().c_str());
        lvItem.iItem = i;
        lvItem.iSubItem = 0;
        ListView_InsertItem(this->hwndAnalogsListViewSelectedGame, &lvItem);

        if (it->getIndex() == 0xFF)
            wsprintfA(buffer, LIST_VIEW_ROW_NOT_SET_TEXT);
        else
            wsprintfA(buffer, it->getDisplayString(&this->rawInputManager).c_str());

        lvItem.iSubItem = 1;
        ListView_SetItem(this->hwndAnalogsListViewSelectedGame, &lvItem);
        i++;
    }

    // lights
    i = 0;
    for (auto &it : *game->getLights()) {
        Light* light = it;

        // alternative
        int alternative = this->selectedLightAlternative;
        if (alternative >= 0) {
            while (light->getAlternatives()->size() <= (unsigned int) alternative)
                light->getAlternatives()->push_back(Light(light->getName()));
            light = &light->getAlternatives()->at((unsigned int) alternative);
        }

        wsprintfA(buffer, light->getName().c_str());
        lvItem.iItem = i;
        lvItem.iSubItem = 0;
        ListView_InsertItem(this->hwndLightsListViewSelectedGame, &lvItem);

        if (light->getDeviceIdentifier().empty())
            wsprintfA(buffer, LIST_VIEW_ROW_NOT_SET_TEXT);
        else
            wsprintfA(buffer, light->getDisplayString(&this->rawInputManager).c_str());

        lvItem.iSubItem = 1;
        ListView_SetItem(this->hwndLightsListViewSelectedGame, &lvItem);
        i++;
    }

    // options
    i = 0;
    for (auto &it : *game->getOptions()) {
        Option *option = it;


        wsprintfA(buffer, it->getName().c_str());
        lvItem.iItem = i;
        lvItem.iSubItem = 0;
        ListView_InsertItem(this->hwndOptionsListViewSelectedGame, &lvItem);

        if (option->getValue().empty()) {
            wsprintfA(buffer, LIST_VIEW_ROW_NOT_SET_TEXT);
        } else {
            wsprintfA(buffer, option->getValue().c_str());
        }

        lvItem.iSubItem = 1;
        ListView_SetItem(this->hwndOptionsListViewSelectedGame, &lvItem);
        i++;
    }

    // default keypad content
    for (auto box : this->hwndKeypadsBox) {
        SendMessage(
                box,
                static_cast<UINT>(CB_ADDSTRING),
                static_cast<WPARAM>(0),
                reinterpret_cast<LPARAM>("None")
        );
        SendMessage(
                box,
                CB_SETCURSEL,
                static_cast<WPARAM>(0),
                static_cast<LPARAM>(0)
        );
    }

    // keypad devices
    auto keypadBindings = this->getKeypadBindings();
    i = 1;
    for (auto &device : *this->rawInputManager.devices_get()) {
        if (device.type != rawinput::KEYBOARD)
            continue;
        for (int p = 0; p < 2; p++) {
            auto box = this->hwndKeypadsBox[p];
            SendMessage(
                    box,
                    static_cast<UINT>(CB_ADDSTRING),
                    static_cast<WPARAM>(0),
                    reinterpret_cast<LPARAM>(device.desc.c_str())
            );

            // check if device is bound
            if (keypadBindings.keypads[p] == device.name) {
                selectedKeypad[p] = i;
                SendMessage(
                        box,
                        CB_SETCURSEL,
                        static_cast<WPARAM>(i),
                        static_cast<LPARAM>(0)
                );
            }
        }
        i++;
    }

    // cards
    for (int card_index = 0; card_index < 2; card_index++)
        if (!keypadBindings.card_paths[card_index].empty())
            SetWindowText(hwndCards[card_index], keypadBindings.card_paths[card_index].c_str());
        else
            SetWindowText(hwndCards[card_index], "");
}

void SpiceToolsWindow::setSelectedGame(std::string gameName) {
    auto it = std::find_if(
            this->games.begin(),
            this->games.end(),
            [&gameName](Game *game) {
                return game->getGameName() == gameName;
            }
    );
    if (it != this->games.end()) {
        this->setSelectedGame(*it);
    }
}

void SpiceToolsWindow::setSelectedGame(unsigned long long int gameNumber) {
    this->setSelectedGame(this->games.at(static_cast<unsigned int>(gameNumber)));
}

Analog* SpiceToolsWindow::getSelectedAnalog() {
    if (this->selectedGame < 0 || this->selectedGame >= (int) this->games.size())
        return nullptr;
    auto analogs = this->games[this->selectedGame]->getAnalogs();
    if (this->selectedAnalogBinding < 0 || this->selectedAnalogBinding >= (int) analogs->size())
        return nullptr;
    return (*analogs)[this->selectedAnalogBinding];
}

Light* SpiceToolsWindow::getSelectedLight() {
    if (this->selectedGame < 0 || this->selectedGame >= (int) this->games.size())
        return nullptr;
    auto lights = this->games[this->selectedGame]->getLights();
    if (this->selectedLightBinding < 0 || this->selectedLightBinding >= (int) lights->size())
        return nullptr;
    return (*lights)[this->selectedLightBinding];
}

void SpiceToolsWindow::updateBindings(Analog *analog) {

    // update config for binding
    Game* game = this->games.at((unsigned int) (this->selectedGame));
    Config::getInstance().updateBinding(game, analog);

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wreturn-stack-address"
    std::string displayString = analog->getDisplayString(&this->rawInputManager);
    ListView_SetItemText( // NOLINT
            this->hwndAnalogsListViewSelectedGame,
            (WPARAM) this->selectedAnalogBinding,
            1,
            (char*) displayString.c_str()
    );
#pragma clang diagnostic pop

}

void SpiceToolsWindow::updateBindings(ConfigKeypadBindings keypadBindings) {
    Game* game = this->games.at((unsigned int) (this->selectedGame));
    Config::getInstance().updateBinding(game, std::move(keypadBindings));
}

void SpiceToolsWindow::updateBindings(Light *light) {

    // update config for binding
    Game* game = this->games.at((unsigned int) (this->selectedGame));
    Config::getInstance().updateBinding(game, light, this->selectedLightAlternative);

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wreturn-stack-address"
    std::string displayString = light->getDisplayString(&this->rawInputManager);
    ListView_SetItemText( // NOLINT
            this->hwndLightsListViewSelectedGame,
            (WPARAM) this->selectedLightBinding,
            1,
            (char*) displayString.c_str()
    );
#pragma clang diagnostic pop

}

ConfigKeypadBindings SpiceToolsWindow::getKeypadBindings() {
    Game* game = this->games.at((unsigned int) (this->selectedGame));
    return Config::getInstance().getKeypadBindings(game);
}

rawinput::Device *SpiceToolsWindow::getKeypadDevice(int index) {
    int i = 1;
    for (auto &device : *this->rawInputManager.devices_get()) {
        if (device.type != rawinput::KEYBOARD)
            continue;
        if (i == index)
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wreturn-stack-address"
            return &device;
#pragma clang diagnostic pop
        i++;
    }
    return nullptr;
}
