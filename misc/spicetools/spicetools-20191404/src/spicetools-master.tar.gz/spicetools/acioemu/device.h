#ifndef SPICETOOLS_ACIOEMU_DEVICE_H
#define SPICETOOLS_ACIOEMU_DEVICE_H

#include "util/circular_buffer.h"

namespace acioemu {

    // message structs
#pragma pack(push, 1)
    struct VersionData {
        uint32_t type;
        uint8_t flag;
        uint8_t ver_major;
        uint8_t ver_minor;
        uint8_t ver_rev;
        char code[4];
        char date[16];
        char time[16];
    };
    struct MessageData {
        union {
            uint8_t raw[0];
            struct {
                uint8_t node;
                uint8_t ukn;
                uint8_t cmd;
                uint8_t pid;
                uint8_t data_size;
                union {
                    uint8_t data_raw[0];
                    uint8_t status;
                    VersionData data_version;
                };
            };
        };
    };
#pragma pack(pop)

    // message sizes
    const size_t MSG_HEADER_SIZE = 5;
    const size_t MSG_VERSION_SIZE = sizeof(VersionData);

    class ACIODeviceEmu {
    public:

        // attributes
        uint8_t node_count = 0;

        /*
         * Helper functions for getting/setting the message contents
         */
        static void set_header(MessageData* data, uint8_t node, uint8_t ukn, uint8_t cmd, uint8_t pid, uint8_t data_size);
        static void set_version(MessageData* data, uint32_t type, uint8_t flag,
                         uint8_t ver_major, uint8_t ver_minor, uint8_t ver_rev,
                         std::string code);

        /*
         * This function creates a basic message with optional parameter data.
         * If data is set to null, the parameter data will be initialized with 0x00
         */
        static MessageData* create_msg(uint8_t node, uint8_t ukn, uint8_t cmd, uint8_t pid,
                size_t data_size, uint8_t* data = nullptr);
        static MessageData* create_msg(MessageData* msg_in, size_t data_size, uint8_t* data = nullptr);

        /*
         * Helper functions for generating messages
         */
        static MessageData* create_msg_status(uint8_t node, uint8_t ukn, uint8_t cmd, uint8_t pid, uint8_t status);
        static MessageData* create_msg_status(MessageData* msg_in, uint8_t status);

        virtual ~ACIODeviceEmu() = default;

        virtual bool is_applicable(uint8_t node_offset, uint8_t node);
        virtual bool parse_msg(
                unsigned int node_offset,
                MessageData *msg_in,
                circular_buffer<uint8_t> *response_buffer) = 0;
        static void write_msg(const uint8_t *data, size_t size, circular_buffer<uint8_t> *response_buffer);
        static void write_msg(MessageData *msg, circular_buffer<uint8_t> *response_buffer);
    };
}

#endif //SPICETOOLS_ACIOEMU_DEVICE_H
