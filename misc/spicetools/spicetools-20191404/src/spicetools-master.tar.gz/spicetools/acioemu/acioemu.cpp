#include "acioemu.h"
#include "util/logging.h"
#include "util/utils.h"

using namespace acioemu;

ACIOEmu::ACIOEmu() {
    this->devices = new std::vector<ACIODeviceEmu *>();
    this->response_buffer = new circular_buffer<uint8_t>(4096);
    this->read_buffer = new circular_buffer<uint8_t>(1024);
}

ACIOEmu::~ACIOEmu() {

    // delete devices
    for (auto device : *this->devices)
        delete device;
    delete this->devices;

    // delete buffers
    delete this->response_buffer;
    delete this->read_buffer;
}

void ACIOEmu::add_device(ACIODeviceEmu *device) {
    this->devices->push_back(device);
}

void ACIOEmu::write(uint8_t byte) {

    // insert into buffer
    if (!invert) {
        if (byte == 0xFF)
            invert = true;
        else
            this->read_buffer->put(byte);
    } else {
        byte = ~byte;
        invert = false;
        this->read_buffer->put(byte);
    }

    // clean garbage
    while (!this->read_buffer->empty() && this->read_buffer->peek() != 0xAA)
        this->read_buffer->get();
    while (this->read_buffer->size() > 1 && this->read_buffer->peek(1) == 0xAA)
        this->read_buffer->get();

    // handshake counter
    static unsigned int handshake_counter = 0;
    if (byte == 0xAA)
        handshake_counter++;
    else
        handshake_counter = 0;

    // check for handshake
    if (handshake_counter > 1) {

        /*
         * small hack - BIO2 seems to expect more bytes here - sending two bytes each time fixes it
         * TODO replace this handshake code with something better
         */
        this->response_buffer->put(0xAA);
        this->response_buffer->put(0xAA);
        handshake_counter--;
        return;
    }

    // parse
    if (!this->read_buffer->empty() && this->read_buffer->size() >= 6) {

        // check msg data size
        auto data_size = this->read_buffer->peek(5);

        // check if msg is complete
        if (this->read_buffer->size() >= 7u + data_size) {
            this->msg_parse();
            this->read_buffer->reset();
        }
    }
}

int ACIOEmu::read() {
    if (this->response_buffer->empty())
        return -1;
    return this->response_buffer->get();
}

void ACIOEmu::msg_parse() {

#ifdef ACIOEMU_LOG
    log_info("acioemu", "ACIOEmu MSG RECV: " + bin2hex(*this->read_buffer));
#endif

    // calculate checksum
    uint8_t chk = 0;
    size_t max = this->read_buffer->size() - 1;
    for (size_t i = 1; i < max; i++)
        chk += this->read_buffer->peek(i);

    // check checksum
    uint8_t chk_receive = this->read_buffer->peek(this->read_buffer->size() - 1);
    if (chk != chk_receive) {
#ifdef ACIOEMU_LOG
        log_info("acioemu", "ACIOEmu detected wrong checksum: " +
                         to_string((int) chk) + "/" + to_string((int) chk_receive));
#endif
        return;
    }

    // get message data
    auto msg_data = this->read_buffer->peek_all();
    auto msg_in = (MessageData*) &msg_data[1];

    // pass to applicable device
    uint8_t node_offset = 0;
    for (auto device : *this->devices) {
        if (device->is_applicable(node_offset, msg_in->node)) {
            auto cur_offset = msg_in->node - node_offset - 1;
            if (cur_offset < 0)
                break;
            if (device->parse_msg((unsigned int) cur_offset, msg_in, this->response_buffer))
                return;
            else
                break;
        }
        node_offset += device->node_count;
    }

    /*
     * Default Behavior
     * If you want to do anything different, just handle the
     * commands in your own device implementation.
     */

    // check for node count report
    if (msg_in->node == 0x00 && msg_in->cmd == 0x01 && node_offset > 0) {
        auto msg = ACIODeviceEmu::create_msg(msg_in, 1, &node_offset);
        ACIODeviceEmu::write_msg(msg, this->response_buffer);
        delete msg;
        return;
    }

    // status 0 defaults
    switch (msg_in->cmd) {
        case 0x00: // CLEAR
        case 0x03: // STARTUP
        case 0x80: // KEEPALIVE
        case 0xFF: // BROADCAST
        {
            // send status 0
            auto msg = ACIODeviceEmu::create_msg_status(msg_in, 0);
            ACIODeviceEmu::write_msg(msg, response_buffer);
            delete msg;
            return;
        }
        default:
            break;
    }

#ifdef ACIOEMU_LOG
    log_info("acioemu", "ACIOEmu UNHANDLED MSG: " + bin2hex(*this->read_buffer));
#endif
}
