#ifndef SPICETOOLS_ACIOEMU_ICCA_H
#define SPICETOOLS_ACIOEMU_ICCA_H

#include <ctime>
#include <thread>
#include <mutex>
#include <cstring>
#include "device.h"
#include "hooks/sleephook.h"

namespace acioemu {
    class ICCADevice : public ACIODeviceEmu {
    private:
        bool type_new;
        bool flip_order;
        std::thread* keypad_thread;
        std::mutex keypad_mutex;
        char **cards;
        time_t *cards_time;
        uint8_t *status;
        bool *accept;
        bool *hold;
        uint8_t *keydown;
        uint16_t *keypad;
        bool** keypad_last;
        uint8_t *keypad_capture;

    public:
        explicit ICCADevice(bool type_new, bool flip_order, bool keypad_thread, uint8_t node_count);
        ~ICCADevice() override;

        bool parse_msg(unsigned int node_offset,
                       MessageData *msg_in,
                       circular_buffer<uint8_t> *response_buffer) override;

        void update_card(int unit);
        void update_keypad(int unit, bool update_edge);
        void update_status(int unit);
    };
}

#endif //SPICETOOLS_ACIOEMU_ICCA_H
