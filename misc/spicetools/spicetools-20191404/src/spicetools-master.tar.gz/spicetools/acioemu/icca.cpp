#include "icca.h"
#include "misc/eamuse.h"
#include "util/logging.h"
#include "util/utils.h"
#include "acio/icca/icca.h"
#include "avs/game.h"

using namespace acioemu;

static inline bool acioemu_icca_is_active(int node_count, int unit) {

    // if the game supports two readers, we check numlock
    if (node_count > 1)
        return (GetAsyncKeyState(VK_NUMLOCK) > 0) == ((unit & 1) > 0);

    // only unit 0 is active
    return unit == 0;
}

ICCADevice::ICCADevice(bool type_new, bool flip_order, bool keypad_thread, uint8_t node_count) {

    // init defaults
    this->type_new = type_new;
    this->flip_order = flip_order;
    this->node_count = node_count;
    this->cards = new char *[node_count] {};
    this->cards_time = new time_t[node_count] {};
    this->status = new uint8_t[node_count * 16] {};
    this->accept = new bool[node_count] {};
    for (int i = 0; i < node_count; i++)
        this->accept[i] = true;
    this->hold = new bool[node_count] {};
    this->keydown = new uint8_t[node_count] {};
    this->keypad = new uint16_t[node_count] {};
    this->keypad_last = new bool*[node_count] {};
    for (int i = 0; i < node_count; i++)
        this->keypad_last[i] = new bool[12]{};
    this->keypad_capture = new uint8_t[node_count] {};
    for (int i = 0; i < node_count; i++)
        this->keypad_capture[i] = 0x08;

    // keypad thread for faster polling
    if (keypad_thread) {
        this->keypad_thread = new std::thread([this]() {
            while (this->cards) {
                for (int unit = 0; unit < this->node_count; unit++)
                    this->update_keypad(unit, false);
                Sleep(7);
            }
        });
    }
}

ICCADevice::~ICCADevice() {

    // stop thread
    delete keypad_thread;

    // delete cards in array
    for (int i = 0; i < node_count; i++)
        delete cards[i];

    // delete the rest
    delete[] cards;
    delete[] cards_time;
    delete[] status;
    delete[] accept;
    delete[] hold;
    delete[] keydown;
    delete[] keypad;
    delete[] keypad_last;
    delete[] keypad_capture;
}

bool ICCADevice::parse_msg(unsigned int node_offset,
                           MessageData *msg_in,
                           circular_buffer<uint8_t> *response_buffer) {

    // get unit
    int unit = node_offset;
    if (this->flip_order)
        unit = this->node_count - unit - 1;
    if (unit != 0 && unit != 1)
        log_fatal("icca", "invalid unit: " + to_string(unit));

#ifdef ACIOEMU_LOG
    log_info("acioemu", "ICCA CMD: " + to_string(unit) + "," + bin2hex(msg_in->cmd));
#endif

    // check command
    switch (msg_in->cmd) {
        case 0x02: { // VERSION

            // send version data
            auto msg = this->create_msg(msg_in, MSG_VERSION_SIZE);
            this->set_version(msg, 0x3, 0, 1, 6, 0, "ICCA");
            write_msg(msg, response_buffer);
            delete msg;
            break;
        }
        case 0x30: { // REINITIALIZE

            // send status 0
            auto msg = this->create_msg_status(msg_in, 0x00);
            write_msg(msg, response_buffer);
            delete msg;
            break;
        }
        case 0x31: { // READ CARD UID

            // build data array
            auto msg = this->create_msg(msg_in, 16);

            // update things
            update_card(unit);
            update_keypad(unit, true);
            update_status(unit);

            // copy status
            memcpy(msg->data_raw, &status[unit * 16], 16);

            // explicitely set no card since this is just read
            msg->data_raw[0] = 0x01;

            // write message
            write_msg(msg, response_buffer);
            delete msg;
            break;
        }
        case 0x35: { // SET ACTION

            // check for data
            if (msg_in->data_size > 0) {

                // subcommand
                switch (msg_in->raw[5]) {
                    case 0x00: // ACCEPT DISABLE
                        this->accept[unit] = false;
                        break;
                    case 0x11: // ACCEPT ENABLE
                        this->accept[unit] = true;
                        break;
                    case 0x12: // EJECT
                        delete this->cards[unit];
                        this->cards[unit] = nullptr;
                    default:
                        break;
                }
            }

            // no break, return status
            [[fallthrough]];
        }
        case 0x34: { // GET STATUS

            // build data array
            auto msg = this->create_msg(msg_in, 16);

            // update things
            update_card(unit);
            update_keypad(unit, true);
            update_status(unit);

            // copy status
            memcpy(msg->data_raw, &status[unit * 16], 16);

            // write message
            write_msg(msg, response_buffer);
            delete msg;
            break;
        }
        case 0x61: { // READ CARD UID NEW

            // if this CMD is called, the reader type must be new
            this->type_new = true;

            // decide on answer
            int answer_type = 0;
            if (avs::game::is_model("LDJ"))
                answer_type = 1;
            if (avs::game::is_model("KFC"))
                answer_type = 1;
            if (avs::game::is_model("L44"))
                answer_type = 2;

            // check answer type
            switch (answer_type) {
                case 1: {

                    // send status 1
                    auto msg = this->create_msg_status(msg_in, 1);
                    write_msg(msg, response_buffer);
                    delete msg;
                    break;
                }
                case 2: {

                    // build data array
                    auto msg = this->create_msg(msg_in, 16);

                    // update card
                    update_card(unit);

                    // check for card
                    if (this->cards[unit] != nullptr) {

                        // copy into data buffer
                        memcpy(msg->data_raw, this->cards[unit], 8);

                        // delete card
                        delete this->cards[unit];
                        this->cards[unit] = nullptr;
                    }

                    // write message
                    write_msg(msg, response_buffer);
                    delete msg;
                    break;
                }
                default: {

                    // send response with no data
                    auto msg = this->create_msg(msg_in, 0);
                    write_msg(msg, response_buffer);
                    delete msg;
                    break;
                }
            }
            break;
        }
        case 0x00: // CMD CLEAR
        case 0x03: // STARTUP
        case 0x16: // ???
        case 0x20: // ???
        case 0x3A: // SLEEP MODE
        case 0xFF: // BROADCAST
        {
            // send status 0
            auto msg = this->create_msg_status(msg_in, 0x00);
            write_msg(msg, response_buffer);
            delete msg;
            break;
        }
        default:
            return false;
    }

    // mark as handled
    return true;
}

void ICCADevice::update_card(int unit) {

    // wavepass timeout after 10s
    if (this->type_new && this->cards[unit] != nullptr) {
        time_t t_now;
        time(&t_now);
        if (difftime(t_now, this->cards_time[unit]) >= 10.f) {
            delete this->cards[unit];
            this->cards[unit] = nullptr;
        }
    }

    // naive keypress
    bool kb_insert_press = false;
    if (eamuse_keypad_state_naive()) {
        kb_insert_press = acioemu_icca_is_active(this->node_count, unit) && (
                (acio::ICCA_TOPROW_ENABLE && GetAsyncKeyState(VK_BACK) != 0)
                || (acio::ICCA_NUMPAD_ENABLE && GetAsyncKeyState(VK_ADD) != 0));
    }

    // eamio keypress
    kb_insert_press |= eamuse_get_keypad_state((size_t) unit) & (1 << EAM_IO_INSERT);

    // check for card
    if (this->cards[unit] == nullptr && (eamuse_card_insert_consume(this->node_count, unit) || kb_insert_press)) {
        this->cards[unit] = new char[8];
        eamuse_get_card(this->node_count, unit, this->cards[unit]);
        time(&this->cards_time[unit]);
    }
}

static int KEYPAD_KEYS[] = {
        VK_NUMPAD0,
        VK_NUMPAD1,
        VK_NUMPAD2,
        VK_NUMPAD3,
        VK_NUMPAD4,
        VK_NUMPAD5,
        VK_NUMPAD6,
        VK_NUMPAD7,
        VK_NUMPAD8,
        VK_NUMPAD9,
        VK_RETURN, // enter
        VK_OEM_COMMA // double zero
};
static int KEYPAD_KEYS_ALT[] = {
        '0',
        '1',
        '2',
        '3',
        '4',
        '5',
        '6',
        '7',
        '8',
        '9',
        VK_BACK, // enter
        VK_OEM_PERIOD // double zero
};
static int KEYPAD_EAMUSE_MAPPING[] = {
        0, 1, 5, 9, 2, 6, 10, 3, 7, 11, 8, 4
};
static int KEYPAD_KEY_CODES[]{
        0x100,
        0x200,
        0x2000,
        2,
        0x400,
        0x4000,
        4,
        0x800,
        0x8000,
        8,
        1,
        0x1000
};
static uint8_t KEYPAD_KEY_CODE_NUMS[]{
        0, 1, 5, 9, 2, 6, 10, 3, 7, 11, 8, 4
};

void ICCADevice::update_keypad(int unit, bool update_edge) {

    // lock keypad so threads can't interfere
    std::lock_guard<std::mutex> lock(this->keypad_mutex);

    // check for active input
    bool active = acioemu_icca_is_active(this->node_count, unit) && eamuse_keypad_state_naive();

    // reset unit
    this->keypad[unit] = 0;

    // get eamu key states
    uint16_t eamu_state = eamuse_get_keypad_state((size_t) unit);

    // iterate keypad
    bool edge = false;
    for (int n = 0; n < 12; n++) {
        int i = n;

        // check if pressed
        if ((active && acio::ICCA_NUMPAD_ENABLE && GetAsyncKeyState(KEYPAD_KEYS[i])) ||
            (active && acio::ICCA_TOPROW_ENABLE && GetAsyncKeyState(KEYPAD_KEYS_ALT[i])) ||
            (eamu_state & (1 << KEYPAD_EAMUSE_MAPPING[i]))) {
            this->keypad[unit] |= KEYPAD_KEY_CODES[i];
            if (!this->keypad_last[unit][i] && update_edge) {
                this->keydown[unit] = (this->keypad_capture[unit] << 4) | KEYPAD_KEY_CODE_NUMS[n];
                this->keypad_last[unit][i] = true;
                edge = true;
            }
        } else
            this->keypad_last[unit][i] = false;
    }

    // update keypad capture
    if (update_edge && edge) {
        this->keypad_capture[unit]++;
        this->keypad_capture[unit] |= 0x08;
    } else
        this->keydown[unit] = 0;
}

void ICCADevice::update_status(int unit) {

    // get buffer
    uint8_t *buffer = &this->status[unit * 16];

    // clear buffer
    memset(buffer + 0, 0x00, 16);

    // check for card
    bool card = false;
    if (this->cards[unit] != nullptr) {

        // copy card into buffer
        memcpy(buffer + 2, this->cards[unit], 8);
        card = true;
    }

    // check for reader type
    if (this->type_new) {

        // check for card
        if (card) {

            // set status to card present
            buffer[0] = 0x02;

            /*
             * set card type
             * 0x00 - ISO15696
             * 0x01 - FELICA
             */
            bool felica = buffer[2] != 0xE0 && buffer[3] != 0x04;
            buffer[1] = (uint8_t) (felica ? 0x01 : 0x00);

            /*
             * remove card only after 1.5 seconds
             * one second doesn't always seem to be enough for DDR A's low polling rate
             */
            time_t t_now;
            time(&t_now);
            if (difftime(t_now, this->cards_time[unit]) >= 1.5f) {
                delete this->cards[unit];
                this->cards[unit] = nullptr;
            }

        } else {

            // set status to no card present (1 or 4)
            buffer[0] = 0x04;
        }

    } else { // old reader

        // check for card
        if (card && accept[unit]) {
            hold[unit] = true;
        }

        // check for hold
        if (hold[unit]) {

            // set status to card present
            buffer[0] = 0x02;

            /*
             * sensors
             * 0x10 - OLD READER FRONT
             * 0x20 - OLD READER BACK
             */

            // activate both sensors
            buffer[1] = 0x30;
        } else {

            // card present but reader isn't accepting it
            if (card) {

                // set card present
                buffer[0] = 0x02;

                // set front sensor
                buffer[1] = 0x10;

            } else {

                // no card present
                buffer[0] = 0x01;
            }
        }
    }

    // other flags
    buffer[10] = 0x00;
    buffer[11] = 0x03;
    buffer[12] = keydown[unit];
    buffer[13] = 0x00;
    buffer[14] = (uint8_t) (keypad[unit] >> 8);
    buffer[15] = (uint8_t) (keypad[unit] & 0xFF);
    *(uint16_t *) &buffer[14] = keypad[unit];
}
