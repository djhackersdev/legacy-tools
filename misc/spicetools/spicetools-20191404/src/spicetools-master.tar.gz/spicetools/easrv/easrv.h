#ifndef SPICETOOLS_EASRV_H
#define SPICETOOLS_EASRV_H

void easrv_start(unsigned short port, bool maintenance, int backlog, int thread_count);

void easrv_shutdown();

#endif //SPICETOOLS_EASRV_H
