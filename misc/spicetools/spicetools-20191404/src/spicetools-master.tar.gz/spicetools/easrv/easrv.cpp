#include "easrv.h"
#include <sstream>
#include <vector>
#include <thread>
#include <winsock2.h>
#include "avs/game.h"
#include "util/logging.h"

extern "C" {
#include "external/http-parser/http_parser.h"
}


#define RECEIVED_BUFFER_LENGTH 4096

static SOCKET SERVER_SOCKET;
static bool SERVER_RUNNING;
static bool SERVER_MAINTENANCE;
static thread_local char URL_BUFFER[RECEIVED_BUFFER_LENGTH];
static thread_local size_t URL_BUFFER_LENGTH = 0;

static std::string HTTP_DEFAULT;
static std::string EA_HEADER;
static std::string EA_SERVICES_GET;
static std::string EA_PCBTRACKER_ALIVE;
static std::string EA_MESSAGE_GET;
static std::string EA_MESSAGE_GET_MAINTENANCE;
static std::string EA_FACILITY_GET;
static std::string EA_PCBEVENT_PUT;

static int on_url(http_parser *, const char *data, size_t length) {
    memcpy(URL_BUFFER, data, length);
    URL_BUFFER_LENGTH = length;
    URL_BUFFER[length] = '\0';
    return 0;
}

static inline bool check_url(const char *module, const char *method) {
    std::string url(URL_BUFFER, URL_BUFFER_LENGTH);
    std::ostringstream check1;
    check1 << "module=" << module << "&method=" << method;
    if (url.find(check1.str()) != std::string::npos)
        return true;
    std::ostringstream check2;
    check2 << '/' << module << '/' << method;
    return url.find(check2.str()) != std::string::npos;
}

static inline void easrv_add_data(std::vector<char> *send, std::string *data) {

    // copy header
    for (size_t i = 0; i < EA_HEADER.size(); i++)
        send->push_back(EA_HEADER[i]);

    // add content length
    std::ostringstream content_length_stream;
    content_length_stream << "Content-Length: " << data->size() << "\r\n\r\n";
    std::string content_length = content_length_stream.str();
    for (size_t i = 0; i < content_length.size(); i++)
        send->push_back(content_length[i]);

    // add data
    // encoded because of null characters
    // if 1 follows after 1 its a 1
    // if 2 follows after 1 its a 0
    bool escape = false;
    for (size_t i = 0; i < data->size(); i++) {
        char c = (*data).begin()[i];
        if (escape) {
            if (c == 2)
                c = 0;
            escape = false;
            send->push_back(c);
        } else if (c == 1)
            escape = true;
        else
            send->push_back(c);
    }
}

static SOCKET easrv_worker_method() {

    // get connection
    sockaddr_in client_address;
    int socket_in_size = sizeof(sockaddr_in);
    SOCKET connected = accept(SERVER_SOCKET, (sockaddr *) &client_address, &socket_in_size);
    if (connected == INVALID_SOCKET)
        return connected;

    // receive data
    char received[RECEIVED_BUFFER_LENGTH];
    ssize_t received_length = recv(connected, received, RECEIVED_BUFFER_LENGTH, 0);
    if (received_length == -1)
        return connected;

    // create parser
    http_parser parser;
    http_parser_init(&parser, HTTP_REQUEST);

    // parser settings
    http_parser_settings parser_settings;
    http_parser_settings_init(&parser_settings);
    parser_settings.on_url = on_url;

    // execute
    size_t parsed_length = http_parser_execute(&parser, &parser_settings, received, (size_t) received_length);
    if (parsed_length != (size_t) received_length)
        return connected;

    // check if protocol is changed
    if (parser.upgrade)
        return connected;

    // check for unsupported method
    if (parser.method != HTTP_GET && parser.method != HTTP_POST)
        return connected;

    // send data
    std::vector<char> send_data;
    switch (parser.method) {
        case HTTP_POST:
        case HTTP_GET: {

            // services
            if (check_url("services", "get"))
                easrv_add_data(&send_data, &EA_SERVICES_GET);
            else if (check_url("pcbtracker", "alive"))
                easrv_add_data(&send_data, &EA_PCBTRACKER_ALIVE);
            else if (check_url("message", "get")) {
                if (SERVER_MAINTENANCE)
                    easrv_add_data(&send_data, &EA_MESSAGE_GET_MAINTENANCE);
                else
                    easrv_add_data(&send_data, &EA_MESSAGE_GET);
            }
            else if (check_url("facility", "get"))
                easrv_add_data(&send_data, &EA_FACILITY_GET);
            else if (check_url("pcbevent", "put"))
                easrv_add_data(&send_data, &EA_PCBEVENT_PUT);

            // default message
            if (!send_data.size()) {
                for (size_t i = 0; i < HTTP_DEFAULT.size(); i++)
                    send_data.push_back(HTTP_DEFAULT[i]);
            }
            break;
        }
        default:
            return connected;
    }

    // send data
    if (send_data.size())
        send(connected, send_data.data(), (int) send_data.size(), 0);

    // exit
    return connected;
}

static void easrv_worker() {
    while (SERVER_RUNNING) {
        SOCKET connected = easrv_worker_method();
        if (connected != INVALID_SOCKET)
            closesocket(connected);
    }
}

static inline void easrv_init_messages();

void easrv_start(unsigned short port, bool maintenance, int backlog, int thread_count) {

    // WSA startup
    WSADATA wsa_data;
    int error;
    if ((error = WSAStartup(MAKEWORD(2, 2), &wsa_data)) != 0)
        log_fatal("easrv", "WSAStartup returned " + to_string(error));

    // create socket
    SERVER_SOCKET = socket(AF_INET, SOCK_STREAM, 0);
    if (SERVER_SOCKET == INVALID_SOCKET)
        log_fatal("easrv", "Couldn't create socket.");

    // configure socket
    if (setsockopt(SERVER_SOCKET, SOL_SOCKET, SO_REUSEADDR, (const char *) &error, sizeof(int)) == -1)
        log_fatal("easrv", "Couldn't set socket options.");

    // create address
    sockaddr_in server_address;
    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(port);
    server_address.sin_addr.s_addr = INADDR_ANY;
    memset(&server_address.sin_zero, 0, sizeof(server_address.sin_zero));

    // bind socket to address
    if (bind(SERVER_SOCKET, (sockaddr *) &server_address, sizeof(sockaddr)) == -1)
        log_fatal("easrv", "Couldn't bind socket.");

    // set socket to listen
    if (listen(SERVER_SOCKET, backlog) == -1)
        log_fatal("easrv", "Couldn't listen to socket.");

    // set server maintenance
    SERVER_MAINTENANCE = maintenance;

    // init messages
    easrv_init_messages();

    // create workers
    SERVER_RUNNING = true;
    for (int i = 0; i < thread_count; i++)
        new std::thread(easrv_worker);

    // information
    log_info("easrv", "EASRV running on port " + to_string(port));
}

void easrv_shutdown() {

    // set running to false
    SERVER_RUNNING = false;

    // give workers time to exit
    Sleep(100);
}

static inline void easrv_init_messages() {
    HTTP_DEFAULT = std::string(
            "HTTP/1.1 200 OK\r\n"
                    "Content-Type: text/html\r\n"
                    "Content-Length: 204\r\n"
                    "\r\n<HTML><HEAD><TITLE>SpiceTools EASRV</TITLE></HEAD>"
                    "<BODY><H1>SpiceTools EASRV</H1>\r\n<IMG src="
                    "\"https://upload.wikimedia.org/wikipedia/commons/thumb/1/19/Felfel-e_t.JPG/800px-Felfel-e_t.JPG\""
                    "></BODY></HTML>"
    );
    EA_HEADER = std::string(
            "HTTP/1.1 200 OK\r\n"
                    "Content-Type: application/octet-stream\r\n"
                    "Server: SpiceTools\r\n"
                    "X-Eamuse-Info: 1-53d121c7-a8b3\r\n"
                    "X-Compress: none\r\n"
                    "Connection: close\r\n"
    );
    EA_SERVICES_GET = std::string(
            "\x17\x7e\xfc\x8e\x1a\x15\x41\x9b\xae\xd5\xa0\xf5\x2c\xa1\xb9\xd2\x53\xca\xe6\x29\x90\x60\xfd\xd5\x86\x2a"
                    "\x8c\x07\x07\xd5\xeb\x59\x63\x6d\x03\xbb\x49\x06\xbf\x7b\x0b\xbf\xe4\x91\x9e\x9f\x85\xab\x5f\x7f"
                    "\x54\xf5\x44\xb6\x51\xa4\x16\x50\xbe\xcc\x4b\x7d\xd7\xf0\xc1\xdc\xb9\xae\x4e\x5b\x4c\x56\xa6\x46"
                    "\xd9\x7a\x61\x8e\x21\xba\x24\x27\xfb\xaf\xc5\xa6\xc8\xf1\x69\x2b\xdc\x2b\xf0\x26\x20\xd2\x46\xf7"
                    "\x87\x3c\x2d\x3d\x64\xd9\xf5\x5f\xd7\xfb\xdc\x53\xf2\x1a\x21\x2b\x2d\xd4\xe2\x56\xae\x0f\xb5\x29"
                    "\x0f\xb3\x9f\x02\x71\x5b\xfb\x7f\xc1\xba\xf9\xa1\xe8\x61\xb0\xf8\xd9\xdd\xab\xf3\x7c\x9b\x76\x9c"
                    "\x37\x31\x8f\x7d\x91\xfd\x1c\xc3\x26\x44\x39\x6d\x70\xed\xac\x94\x33\x55\xaf\x68\xfd\x9b\x3e\xa2"
                    "\xe7\x74\x83\x3c\xdc\x71\xbf\xb3\x6d\xa9\xb8\x1b\xe5\x49\xf1\x37\x06\x96\xad\x63\xaa\x8d\x0f\x17"
                    "\xa1\xe7\xad\x68\xb5\x9a\x1d\x4c\x45\x60\x0f\xb9\x77\x84\x80\xd6\x50\xc3\x46\x21\x8d\x01\x02\x7f"
                    "\x4e\x39\xc5\x15\x6b\x78\xb3\x08\x0f\x21\xc5\x34\xef\x1b\xc2\x50\x93\x5e\xc8\x5b\x78\xa7\xe4\xc6"
                    "\x47\xbc\x30\x6f\x5e\xd3\x6c\xa0\xe4\x06\xf8\x92\xc6\xb3\xb2\x86\x78\xc6\x80\xa8\xe5\xcb\xad\x2b"
                    "\x7e\xa0\xe4\x4c\x5e\xc7\xde\xd6\xc7\xb6\xea\x64\xd4\x34\x83\xe8\x05\x5d\x79\xd8\x55\xb9\x17\x01"
                    "\x02\x01\x01\x7f\x5a\x02\x07\xee\x30\x0b\x77\xb3\xd5\x83\xbe\x79\x21\x19\x01\x01\x18\x05\xd1\x13"
                    "\xe7\xad\xd4\x61\x3b\xa7\xb0\x8b\x8c\x8f\x19\xbe\x3b\x96\x61\x8d\xa3\xc9\x52\xa4\x19\xcd\x86\x5a"
                    "\xb6\x52\x64\x7b\x4a\x90\x40\xaf\xc4\xc5\xcc\xcc\x01\x01\x3c\xa1\xf1\xfa\xc1\x07\x22\x57\x2c\xf9"
                    "\x37\xdd\xcf\x65\x60\x47\x7e\xc2\x14\x89\xfd\xb4\xa3\xea\x3d\xfa\xb3\xca\xed\x38\x7d\x18\x1a\xe6"
                    "\xf7\x5a\xe7\x2e\x80\x81\xa3\x56\xa4\x5e\x8f\xd9\x77\xa0\x65\x88\x8d\x28\xe7\x8d\x43\xb1\x61\xbb"
                    "\xe0\x2f\x60\x51\x82\x5f\x8c\x22\x89\xad\xe5\xa1\x78\xfa\xf7\xe4\x99\x14\x49\xab\x95\x60\x61\x81"
                    "\x15\xce\x24\x85\xa5\x4f\x67\x5e\xcc\xe0\x0b\x43\x16\x96\xa6\x3b\xdf\x36\xf3\xe0\xc2\x76\x01\x01"
                    "\x67\xdf\x0c\x71\x01\x02\x5a\x52\xc4\xf1\xf1\xf5\x4a\x27\x88\xea\x43\x2d\xc4\x93\xcb\xe2\x70\x9b"
                    "\xe0\x16\x41\x91\x19\x03\xdb\xe9\x41\x04\xe2\x46\x35\xf9\x46\xa1\x49\x3f\x84\x67\x5e\x3b\x05\x0d"
                    "\x47\x43\x3b\x9c\xa9\x99\xa1\xd7\x23\x9d\xcd\x61\x57\xd9\x41\xa4\x1f\x69\xbc\xbe\xaf\x57\x75\x3b"
                    "\x88\xb6\xca\xc7\x9f\x04\x72\x77\xdb\x9c\xb7\xf2\xf1\x20\xc8\xa8\x58\x8b\x8b\xb9\x52"
    );
    EA_PCBTRACKER_ALIVE = std::string(
            "\x17\x7e\x7c\x0e\x1a\x15\x41\x23\xae\xd5\xa0\xf5\x2c\xa1\xb9\xd2\x53\xc8\xd2\x0d\x92\x04\x1d\x5d\x2c\x5e"
                    "\x19\x95\x1f\x71\x5c\x0d\x73\xad\x03\xbf\x08\xf6\x91\x4f\xe4\xfb\x71\x0d\x87\x6c\xef\xbb\x93\xfb"
                    "\x7f\x30\x43\x64\xf5\x74\x11\xb7\x9c\xef\x12\xd3\x2d\xc0\x52\x76\x97\xad\xa5\x27\x0c\x80\xa7\x42"
                    "\x62\xe2\xe2\xa0\x25\x74\x48\x8d\xd5\xae\x1e\xda\x88\x0f\x68\x2f\x67\xb3\x72\x08\x24\x1c\x2a\x5d"
                    "\xa9\x3d\xf6\x41\x24\x27\xf4\x5b\x6c\x63\x5e\x7d\xf6\xd4");
    EA_MESSAGE_GET = std::string(
            "\x17\x7e\x7c\x0e\x1a\x15\x41\x03\xae\xd5\xa0\xf5\x2c\xa1\xb9\xd2\x53\xc5\xce\x2a\x53\x40\xbd\xed\xa9\x28"
                    "\xd4\x04\x0c\x10\x6f\x69\xf1\x38\x2d\xb8\xa2\x7a\xff\x8d\x0a\xbb\x5f\x09\x1c\xb1\x81\x65");
    EA_MESSAGE_GET_MAINTENANCE = std::string(
            "\x17\x7E\xFC\x8E\x1A\x15\x41\x4F\xAE\xD5\xA0\xF5\x2C\xA1\xB9\xD2\x53\xC5\xCE\x2A\x53\x40\xBD\xED\xA9\x28"
            "\x9C\x40\xDB\x25\x4F\xB9\x09\x24\xB4\x01\x01\x49\xFA\xFE\x81\xB1\x21\xED\x25\x2F\x1A\xBB\x25\x1D\xD1\xB4"
            "\x9A\x05\xE4\x14\xB9\x8E\xE3\xE1\xA8\xF8\x57\x68\xA4\x1F\x58\x94\x06\x9F\x67\x22\xAC\x69\x2E\xC8\xCE\xD6"
            "\x43\xBC\xC3\xAC\x73\x2B\x52\xD1\xDA\x88\x0F\x68\x2F\x67\xD1\x42\x08\x24\x18\x19\x6D\x99\x3F\xC6\x41\x24"
            "\x25\xC4\x5B\x6C\x61\x6E\x7D\xF6\xD2\x75\xB7\x37\xE7\x39\x2A\xEE\xF1\xB4\x2D\xB4\x22\x5E\x55\x06\xBB\xFA"
            "\xB4\x86\xD7\x66\xB8\xA8\x9F\x4E\x06\x26\xDF\x9B\xF3\x7D\x0B\x76\x9C\x37\x3E\xD1\x2A\xC6\xA4\x40\xAA\x52"
            "\x3D\x39\x6D\x70\xFF\xDF\xED\x40\x5A\xA2\x7D\xEA\x84\x6D\xE3\xE6\x75\x8D\x36\xD3\x69\xB2\xDC\x1E\xDD\x82"
            "\x23\xD5\x73\xF1\x18\x60\xF7"
    );
    EA_FACILITY_GET = std::string(
            "\x17\x7e\x7c\x0e\x1a\x15\x40\x17\xae\xd5\xa0\xf5\x2c\xa1\xb9\xd2\x53\xca\xaa\xee\x45\x1c\x99\x13\x86\x26"
                    "\xf0\xd7\x93\x1d\x02\xa4\x04\xc5\x97\x28\x5c\x71\xf8\x26\x44\x08\xb8\x74\xac\x4f\x8a\x63\xed\x7e"
                    "\x54\x25\x9f\x34\x1a\x5e\xd9\x38\xaf\xa8\xfa\x57\x34\xd3\xc7\x88\x69\xac\xa1\xe1\xe0\x42\xac\x40"
                    "\xd8\x70\x2d\xa3\x20\xd7\x51\x35\x35\x52\xd0\xdb\x8e\xd8\x25\xd6\xc8\x71\x4e\x01\x02\x97\x01\x01"
                    "\x0d\xc6\xb2\x8a\x38\x44\x2e\x94\xe9\x7c\xf7\x7c\x1a\xa2\x66\x2a\x48\x8a\xd4\xac\xb2\xb1\x74\x44"
                    "\x67\x53\xf4\xd7\xd3\x2d\x73\x42\x3e\x24\x55\x39\x11\xd9\x07\x86\xe2\xf8\x2d\xd9\x65\x9f\xd7\xf5"
                    "\x7d\x94\xf1\x56\x87\xfb\x58\xfe\x8e\xa1\x5b\xfa\x75\x81\xcb\x73\x05\x3c\xcd\x8a\xc6\x19\x6b\x32"
                    "\xb3\x25\xc9\x1e\x46\x35\x89\xa6\xe7\xda\x15\x12\xcc\x4b\x63\x1d\x75\xf3\x5e\xb7\x30\x0c\xcc\x2b"
                    "\x35\x06\x38\x41\x97\xa7\x25\x64\x1b\x47\xa6\xc5\x17\x1b\xe8\x99\x2b\x5f\x75\x3d\xb8\x20\x8e\xcb"
                    "\x6b\x7a\x46\xb3\x85\x29\x31\x3c\xe7\x92\x4b\xa0\xc7\xfa\x4e\x10\xc0\x4d\xa2\x0e\x60\x5c\x09\xcd"
                    "\x53\xfe\x31\xbd\xec\xee\xb8\x92\xab\xec\xc5\xbd\x04\x6f\x3a\x7e\x0e\x16\xae\x5e\xc3\xc3\x2d\x0d"
                    "\xd5\x80\x5e\x3b\xda\xd5\xb3\xae\xec\xe8\x99\x66\x0b\xb7\x55\xe9\xd5\x39\x03\x3d\xd3\x6d\x89\x2f"
                    "\x30\x2e\x0f\x3a\x35\x31\x98\x55\x65\x03\x9c\xfc\xad\xbe\x79\x21\x19\x01\x01\x18\x03\x20\x35\x2b"
                    "\x58\xe3\xaf\xd9\x89\x7b\x78\xc9\x2a\x19\xbe\x3b\xb5\x09\xf9\xd6\xb9\x68\x8b\x36\xa3\xc7\x39\xd7"
                    "\x3e\x0d\x14\x39\x9b\x58\x2f\xd6\x45\xfc\xe3\x71\x5d\xed\x85\x88\xa0\x64\x49\x32\x5c\xe6\x1c\xdd"
                    "\xcf\x65\x60\x47\x74\x82\x7f\xee\x91\xdd\xd0\x9e\x3d\xfa\xb3\xca\xcd\x50\x06\x2e\x2a\xdc\xd8\x75"
                    "\x9a\x29\x97\x94\xbf\x04\xe4\x02\x97\x8c\x2c\xf1\x31\xd0\xcd\x2b\xf8\xea\x2f\xd8\x12\xcf\xcf\x04"
                    "\x71\x39\xf6\x2b\xf8\x76\xd2\xf2\x89\xce\x1b\x9b\x8f\xe2\x82\x17\x07\x84\xba\x10\x0e\xee\x79\xe0"
                    "\x5b\x99\xa1\x15\x78\x16\x84\xe0\x67\x2c\x75\xf7\xc0\x38\xd5\x20\xf7\x81\xae\x1f\x77\x02\xdf\x0c"
                    "\x60\x68\x2e\x26\xe5\xbb\xb7\xb4\x41\x72\xc4\xa4\x43\x2a\xc8\x81\xd3\x8a\x1f\xe8\x94\x39\x7e\xf6"
                    "\x69\x56\x9e\xaf\x06\x10\xfd\x47\x69\xb8\x14\xe6\x48\x36\xd6\x25\x18\x0c\x2b\x3d\x69");
    EA_PCBEVENT_PUT = std::string(
            "\x17\x7e\x7c\x0e\x1a\x15\x41\x0b\xae\xd5\xa0\xf5\x2c\xa1\xb9\xd2\x53\xca\xd2\x0d\x81\x34\xdb\x94\x79\xd0"
                    "\xc8\x9d\xb5\xfb\xef\x97");
}
