#ifndef SPICETOOLS_MISC_SCIUNIT_H
#define SPICETOOLS_MISC_SCIUNIT_H

void sciunit_attach();
void sciunit_detach();

#endif //SPICETOOLS_MISC_SCIUNIT_H
