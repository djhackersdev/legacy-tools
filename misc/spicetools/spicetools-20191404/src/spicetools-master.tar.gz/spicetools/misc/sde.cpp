#include "sde.h"
#include <thread>
#include "util/logging.h"
#include "hooks/sleephook.h"


void sde_init(std::string sde_path) {

    // check trailing slash
    if (sde_path.length() > 0 && strncmp(sde_path.end().base(), "\\", 1) == 0)
        sde_path = std::string(sde_path.c_str(), sde_path.length() - 1);

    // get PID
    int pid = getpid();

    // try attach
    log_info("sde", "Attaching SDE (" + sde_path + ") to PID " + to_string(pid));
    std::string cmd = "sde.exe -attach-pid " + to_string(pid);
    std::thread t([sde_path, cmd]() {
        system((sde_path + "\\" + cmd).c_str());
    });
    t.detach();

    // wait to make sure it went through
    Sleep(500);
}
