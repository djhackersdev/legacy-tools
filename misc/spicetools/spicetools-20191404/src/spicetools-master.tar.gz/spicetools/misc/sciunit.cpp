#include "sciunit.h"
#include "util/logging.h"
#include "eamuse.h"
#include "util/detour.h"
#include "util/libutils.h"
#include "rawinput/rawinput.h"
#include "games/jb/jb.h"
#include "games/jb/io.h"
#include "acio/icca/icca.h"
#include "avs/game.h"

// state
static HINSTANCE SCIUNIT_INSTANCE;
static std::string SCIUNIT_INSTANCE_NAME = "sciunit.dll";
static bool SCIUNIT_INITIALIZED = false;
static bool CARD_IN = false;
static bool CARD_PRESSED = false;
static char CARD_UID[8];

static inline void update_card() {
    if (eamuse_card_insert_consume(1, 0)
        || (acio::ICCA_TOPROW_ENABLE && GetAsyncKeyState(VK_BACK))
        || (acio::ICCA_NUMPAD_ENABLE && GetAsyncKeyState(VK_ADD))) {
        if (!CARD_PRESSED) {
            CARD_PRESSED = true;
            CARD_IN = true;
            eamuse_get_card(1, 0, CARD_UID);
        }
    } else
        CARD_PRESSED = false;
}

static int __cdecl mng_card_check_removed(int a1) {
    return 0;
}

static int __cdecl mng_card_eject_init(int a1) {
    CARD_IN = false;
    return 0;
}

static int __cdecl mng_card_get_cardnumber(int a1, uint8_t* cardnumber) {
    memset(cardnumber, 0x20, 15);
    memset(cardnumber + 16, 0, 1);
    return 0;
}

static int __cdecl mng_card_get_cardtype(int a1) {
    return 1;
}

static int __cdecl mng_card_get_stat(int a1) {
    return CARD_IN ? 2 : 1;
}

static int __cdecl mng_card_get_uid(int a1, uint8_t* uid) {
    memcpy(uid, CARD_UID, 8);
    return CARD_IN ? 0 : 1;
}

static int __cdecl mng_card_is_detected(int a1) {
    return 1;
}

static int __cdecl mng_card_is_ejected(int a1) {
    return 1;
}

static int __cdecl mng_card_is_inserted(int a1) {
    update_card();
    return CARD_IN;
}

static bool __cdecl mng_card_is_invalid_unit(int a1) {
    return false;
}

static int __cdecl mng_card_is_read_done(int a1) {
    update_card();
    return CARD_IN;
}

static int __cdecl mng_card_is_ready(int a1) {
    return 1;
}

static int __cdecl mng_card_is_removed(int a1) {
    return 1;
}

static int __cdecl mng_card_is_valid_card(int a1) {
    return CARD_IN;
}

static int __cdecl mng_card_read_init(int a1) {
    return 0;
}

static int __cdecl mng_card_sensor_raw(int a1) {
    update_card();
    return CARD_IN ? 48 : 0;
}

static void __cdecl mng_card_sleep(int a1) {
}

static int __cdecl sciunit_finalize() {
    return 0;
}

static int __cdecl sciunit_get_errorunit() {
    return 0;
}

static int __cdecl sciunit_get_stat() {
    return 0;
}

static int __cdecl sciunit_get_version(int a1, int a2) {
    return 0;
}

static int __cdecl sciunit_initialize() {
    SCIUNIT_INITIALIZED = true;
    return 0;
}

static int __cdecl sciunit_is_initialized() {
    return SCIUNIT_INITIALIZED ? 1 : 0;
}

static int __cdecl sciunit_is_usable() {
    return 1;
}

static int __cdecl sciunit_led_set_color(uint8_t *led_field) {

    // Jubeat
    if (avs::game::is_model("J44") || avs::game::is_model("K44") || avs::game::is_model("L44")) {

        // get lights
        auto lights = games::jb::get_lights();

        // control mapping
        //
        // The list in `Lamp Check` is not in the same order as the LED array passed to this
        // function.
        static size_t mapping[] = {
                games::jb::Lights::PANEL_FRONT_R,
                games::jb::Lights::PANEL_FRONT_G,
                games::jb::Lights::PANEL_FRONT_B,
                games::jb::Lights::PANEL_TOP_R,
                games::jb::Lights::PANEL_TOP_G,
                games::jb::Lights::PANEL_TOP_B,
                games::jb::Lights::PANEL_LEFT_R,
                games::jb::Lights::PANEL_LEFT_G,
                games::jb::Lights::PANEL_LEFT_B,
                games::jb::Lights::PANEL_RIGHT_R,
                games::jb::Lights::PANEL_RIGHT_G,
                games::jb::Lights::PANEL_RIGHT_B,
                games::jb::Lights::PANEL_TITLE_R,
                games::jb::Lights::PANEL_TITLE_G,
                games::jb::Lights::PANEL_TITLE_B,
                games::jb::Lights::PANEL_WOOFER_R,
                games::jb::Lights::PANEL_WOOFER_G,
                games::jb::Lights::PANEL_WOOFER_B,
        };

        // write light
        for (size_t i = 0; i < std::size(mapping); i++) {
            GameAPI::Lights::writeLight(RI_MGR, lights->at(mapping[i]), led_field[i] / 255.f);
        }

        RI_MGR->devices_flush_output();
    }

    return 0;
}

static int __cdecl sciunit_reset() {
    return 0;
}

static int __cdecl sciunit_update() {
    if (SCIUNIT_INITIALIZED)
        update_card();
    return 0;
}

void sciunit_attach() {

    // get instance
    SCIUNIT_INSTANCE = libutils::try_module(SCIUNIT_INSTANCE_NAME);
    if (!SCIUNIT_INSTANCE) {
        log_info("sciunit", "Skipping SCIUNIT");
        return;
    }

    // patch
    detour::inline_hook((void *) &mng_card_check_removed, (DWORD_PTR) libutils::try_proc(
            SCIUNIT_INSTANCE, "mng_card_check_removed"));
    detour::inline_hook((void *) &mng_card_eject_init, (DWORD_PTR) libutils::try_proc(
            SCIUNIT_INSTANCE, "mng_card_eject_init"));
    detour::inline_hook((void *) &mng_card_get_cardnumber, (DWORD_PTR) libutils::try_proc(
            SCIUNIT_INSTANCE, "mng_card_get_cardnumber"));
    detour::inline_hook((void *) &mng_card_get_cardtype, (DWORD_PTR) libutils::try_proc(
            SCIUNIT_INSTANCE, "mng_card_get_cardtype"));
    detour::inline_hook((void *) &mng_card_get_stat, (DWORD_PTR) libutils::try_proc(
            SCIUNIT_INSTANCE, "mng_card_get_stat"));
    detour::inline_hook((void *) &mng_card_get_uid, (DWORD_PTR) libutils::try_proc(
            SCIUNIT_INSTANCE, "mng_card_get_uid"));
    detour::inline_hook((void *) &mng_card_is_detected, (DWORD_PTR) libutils::try_proc(
            SCIUNIT_INSTANCE, "mng_card_is_detected"));
    detour::inline_hook((void *) &mng_card_is_ejected, (DWORD_PTR) libutils::try_proc(
            SCIUNIT_INSTANCE, "mng_card_is_ejected"));
    detour::inline_hook((void *) &mng_card_is_inserted, (DWORD_PTR) libutils::try_proc(
            SCIUNIT_INSTANCE, "mng_card_is_inserted"));
    detour::inline_hook((void *) &mng_card_is_invalid_unit, (DWORD_PTR) libutils::try_proc(
            SCIUNIT_INSTANCE, "mng_card_is_invalid_unit"));
    detour::inline_hook((void *) &mng_card_is_read_done, (DWORD_PTR) libutils::try_proc(
            SCIUNIT_INSTANCE, "mng_card_is_read_done"));
    detour::inline_hook((void *) &mng_card_is_ready, (DWORD_PTR) libutils::try_proc(
            SCIUNIT_INSTANCE, "mng_card_is_ready"));
    detour::inline_hook((void *) &mng_card_is_removed, (DWORD_PTR) libutils::try_proc(
            SCIUNIT_INSTANCE, "mng_card_is_removed"));
    detour::inline_hook((void *) &mng_card_is_valid_card, (DWORD_PTR) libutils::try_proc(
            SCIUNIT_INSTANCE, "mng_card_is_valid_card"));
    detour::inline_hook((void *) &mng_card_read_init, (DWORD_PTR) libutils::try_proc(
            SCIUNIT_INSTANCE, "mng_card_read_init"));
    detour::inline_hook((void *) &mng_card_sensor_raw, (DWORD_PTR) libutils::try_proc(
            SCIUNIT_INSTANCE, "mng_card_sensor_raw"));
    detour::inline_hook((void *) &mng_card_sleep, (DWORD_PTR) libutils::try_proc(
            SCIUNIT_INSTANCE, "mng_card_sleep"));
    detour::inline_hook((void *) &sciunit_finalize, (DWORD_PTR) libutils::try_proc(
            SCIUNIT_INSTANCE, "sciunit_finalize"));
    detour::inline_hook((void *) &sciunit_get_errorunit, (DWORD_PTR) libutils::try_proc(
            SCIUNIT_INSTANCE, "sciunit_get_errorunit"));
    detour::inline_hook((void *) &sciunit_get_stat, (DWORD_PTR) libutils::try_proc(
            SCIUNIT_INSTANCE, "sciunit_get_stat"));
    detour::inline_hook((void *) &sciunit_get_version, (DWORD_PTR) libutils::try_proc(
            SCIUNIT_INSTANCE, "sciunit_get_version"));
    detour::inline_hook((void *) &sciunit_initialize, (DWORD_PTR) libutils::try_proc(
            SCIUNIT_INSTANCE, "sciunit_initialize"));
    detour::inline_hook((void *) &sciunit_is_initialized, (DWORD_PTR) libutils::try_proc(
            SCIUNIT_INSTANCE, "sciunit_is_initialized"));
    detour::inline_hook((void *) &sciunit_is_usable, (DWORD_PTR) libutils::try_proc(
            SCIUNIT_INSTANCE, "sciunit_is_usable"));
    detour::inline_hook((void *) &sciunit_led_set_color, (DWORD_PTR) libutils::try_proc(
            SCIUNIT_INSTANCE, "sciunit_led_set_color"));
    detour::inline_hook((void *) &sciunit_reset, (DWORD_PTR) libutils::try_proc(
            SCIUNIT_INSTANCE, "sciunit_reset"));
    detour::inline_hook((void *) &sciunit_update, (DWORD_PTR) libutils::try_proc(
            SCIUNIT_INSTANCE, "sciunit_update"));
}

void sciunit_detach() {
    // TODO
}
