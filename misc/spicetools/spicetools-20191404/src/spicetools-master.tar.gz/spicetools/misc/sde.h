#ifndef SPICETOOLS_MISC_SDE_H
#define SPICETOOLS_MISC_SDE_H

#include <string>

void sde_init(std::string sde_path);

#endif //SPICETOOLS_MISC_SDE_H
