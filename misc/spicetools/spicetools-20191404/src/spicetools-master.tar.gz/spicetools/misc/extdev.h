#ifndef SPICETOOLS_MISC_EXTDEV_H
#define SPICETOOLS_MISC_EXTDEV_H

void extdev_attach();

void extdev_detach();

#endif //SPICETOOLS_MISC_EXTDEV_H
