#ifndef SPICETOOLS_MISC_SPICEDEVICE_H
#define SPICETOOLS_MISC_SPICEDEVICE_H

void spicedevice_attach();

void spicedevice_detach();

#endif //SPICETOOLS_MISC_SPICEDEVICE_H
