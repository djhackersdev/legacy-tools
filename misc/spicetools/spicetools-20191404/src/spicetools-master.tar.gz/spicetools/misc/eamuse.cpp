#include "eamuse.h"
#include <fstream>
#include <thread>
#include "util/logging.h"
#include "util/utils.h"
#include "cfg/config.h"
#include "rawinput/rawinput.h"
#include "avs/game.h"
#include "bt5api.h"


// state
static bool CARD_INSERT[2] = {false, false};
static char CARD_INSERT_UID[2][8];
static char CARD_INSERT_UID_ENABLE[2] = {false, false};
static int COIN_STOCK = 0;
static bool COIN_BLOCK = false;
static std::thread *COIN_INPUT_THREAD;
static bool COIN_INPUT_THREAD_ACTIVE = false;
static uint16_t KEYPAD_STATE[] = {0, 0};
static uint16_t KEYPAD_STATE_OVERRIDES[] = {0, 0};
static uint16_t KEYPAD_STATE_OVERRIDES_BT5[] = {0, 0};
static std::string EAMUSE_GAME_NAME;
static ConfigKeypadBindings KEYPAD_BINDINGS{};

bool eamuse_get_card(int active_count, int unit_id, char *card) {

    // get unit index
    int index = unit_id > 0 && active_count > 1 ? 1 : 0;

    // reader card input
    if (CARD_INSERT_UID_ENABLE[index]) {
        CARD_INSERT_UID_ENABLE[index] = false;
        memcpy(card, CARD_INSERT_UID[index], 8);
        log_info("eamuse", "Inserted card from reader " + to_string(index) + ": " + bin2hex(card, 8));
        return true;
    }

    // get file path
    std::string path;
    if (!KEYPAD_BINDINGS.card_paths[index].empty())
        path = KEYPAD_BINDINGS.card_paths[index];
    else
        path = index > 0 ? "card1.txt" : "card0.txt";

    // open file
    std::ifstream f(path);
    if (!f) {
        log_warning("eamuse", path + " can not be opened!");
        return false;
    }

    // get size
    f.seekg(0, f.end);
    auto length = (size_t) f.tellg();
    f.seekg(0, f.beg);

    // check size
    if (length < 16) {
        log_warning("eamuse", path + " is too small (must be at least 16 characters)");
        return false;
    }

    // read file
    char buffer[17];
    f.read(buffer, 16);
    buffer[16] = 0;

    // verify card
    for (int n = 0; n < 16; n++) {
        char c = buffer[n];
        bool digit = c >= '0' && c <= '9';
        bool character_big = c >= 'A' && c <= 'F';
        bool character_small = c >= 'a' && c <= 'f';
        if (!digit && !character_big && !character_small) {
            log_warning("eamuse", path + " contains an invalid character sequence at byte " +
                        to_string(n) + " (16 characters, 0-9/A-F only)");
            return false;
        }
    }

    // info
    log_info("eamuse", "Inserted " + path + ": " + to_string(buffer));

    // convert hex to bytes
    hex2bin(buffer, card);

    return true;
}

void eamuse_card_insert(int unit) {
    CARD_INSERT[unit] = true;
}

void eamuse_card_insert(int unit, const char *card) {
    memcpy(CARD_INSERT_UID[unit], card, 8);
    CARD_INSERT[unit] = true;
    CARD_INSERT_UID_ENABLE[unit] = true;
}

bool eamuse_card_insert_consume(int active_count, int unit_id) {

    // get unit index
    int index = unit_id > 0 && active_count > 1 ? 1 : 0;

    // bt5api
    if (BT5API_ENABLED)
        bt5api_poll_reader_card((uint8_t) index);

    // check for card insert
    if (!CARD_INSERT[index])
        return false;
    log_info("eamuse", "Card insert on " + to_string(unit_id + 1) + "/" + to_string(active_count));
    CARD_INSERT[index] = false;
    return true;
}

void eamuse_coin_set_block(bool block) {
    COIN_BLOCK = block;
}

int eamuse_coin_get_stock() {
    return COIN_STOCK;
}

void eamuse_coin_set_stock(int amount) {
    COIN_STOCK = amount;
}

int eamuse_coin_consume_stock() {
    int stock = COIN_STOCK;
    COIN_STOCK = 0;
    return stock;
}

int eamuse_coin_add() {
    return ++COIN_STOCK;
}

void eamuse_coin_start_thread() {

    // set active
    COIN_INPUT_THREAD_ACTIVE = true;

    // create thread
    COIN_INPUT_THREAD = new std::thread([]() {
        static int COIN_INPUT_KEY = VK_F1;
        static bool COIN_INPUT_KEY_STATE = false;
        while (COIN_INPUT_THREAD_ACTIVE) {

            // check input key
            if (GetAsyncKeyState(COIN_INPUT_KEY)) {
                if (!COIN_INPUT_KEY_STATE) {
                    if (COIN_BLOCK)
                        log_info("eamuse", "Coin inserted while blocked.");
                    else {
                        log_info("eamuse", "Coin insert.");
                        COIN_STOCK++;
                    }
                }
                COIN_INPUT_KEY_STATE = true;
            } else
                COIN_INPUT_KEY_STATE = false;

            // once every frame
            Sleep(1000 / 60);
        }
    });
}

void eamuse_coin_stop_thread() {
    COIN_INPUT_THREAD_ACTIVE = false;
    COIN_INPUT_THREAD->join();
    delete COIN_INPUT_THREAD;
    COIN_INPUT_THREAD = nullptr;
}

void eamuse_set_keypad_overrides(size_t unit, uint16_t keypad_state) {

    // check unit
    if (unit >= std::size(KEYPAD_STATE_OVERRIDES))
        return;

    // set state
    KEYPAD_STATE_OVERRIDES[unit] = keypad_state;
}

void eamuse_set_keypad_overrides_bt5(size_t unit, uint16_t keypad_state) {

    // check unit
    if (unit >= std::size(KEYPAD_STATE_OVERRIDES_BT5))
        return;

    // set state
    KEYPAD_STATE_OVERRIDES_BT5[unit] = keypad_state;
}

uint16_t eamuse_get_keypad_state(size_t unit) {

    // check unit
    if (unit >= std::size(KEYPAD_STATE))
        return 0;

    // reset
    KEYPAD_STATE[unit] = KEYPAD_STATE_OVERRIDES[unit];
    KEYPAD_STATE[unit] |= KEYPAD_STATE_OVERRIDES_BT5[unit];

    // bt5api
    if (BT5API_ENABLED)
        bt5api_poll_reader_keypad((uint8_t) unit);

    // keypad bindings
    if (!KEYPAD_BINDINGS.keypads[unit].empty()) {
        for (auto &device : *RI_MGR->devices_get()) {
            if (device.type != rawinput::KEYBOARD)
                continue;
            if (device.name == KEYPAD_BINDINGS.keypads[unit]) {

                // lock device
                device.mutex->lock();

                // iterate vkey pages
                for (int index = 0; index < 1024; index += 256) {

                    // get states of index
                    auto states = &device.keyboardInfo->key_states[index];

                    // parse
                    if (states[VK_NUMPAD0] || states[VK_INSERT])
                        KEYPAD_STATE[unit] |= 1 << EAM_IO_KEYPAD_0;
                    if (states[VK_NUMPAD1] || states[VK_END])
                        KEYPAD_STATE[unit] |= 1 << EAM_IO_KEYPAD_1;
                    if (states[VK_NUMPAD2] || states[VK_DOWN])
                        KEYPAD_STATE[unit] |= 1 << EAM_IO_KEYPAD_2;
                    if (states[VK_NUMPAD3] || states[VK_NEXT])
                        KEYPAD_STATE[unit] |= 1 << EAM_IO_KEYPAD_3;
                    if (states[VK_NUMPAD4] || states[VK_LEFT])
                        KEYPAD_STATE[unit] |= 1 << EAM_IO_KEYPAD_4;
                    if (states[VK_NUMPAD5] || states[VK_CLEAR])
                        KEYPAD_STATE[unit] |= 1 << EAM_IO_KEYPAD_5;
                    if (states[VK_NUMPAD6] || states[VK_RIGHT])
                        KEYPAD_STATE[unit] |= 1 << EAM_IO_KEYPAD_6;
                    if (states[VK_NUMPAD7] || states[VK_HOME])
                        KEYPAD_STATE[unit] |= 1 << EAM_IO_KEYPAD_7;
                    if (states[VK_NUMPAD8] || states[VK_UP])
                        KEYPAD_STATE[unit] |= 1 << EAM_IO_KEYPAD_8;
                    if (states[VK_NUMPAD9] || states[VK_PRIOR])
                        KEYPAD_STATE[unit] |= 1 << EAM_IO_KEYPAD_9;
                    if (states[VK_RETURN])
                        KEYPAD_STATE[unit] |= 1 << EAM_IO_KEYPAD_00;
                    if (states[VK_OEM_COMMA])
                        KEYPAD_STATE[unit] |= 1 << EAM_IO_KEYPAD_DECIMAL;
                    if (states[VK_ADD])
                        KEYPAD_STATE[unit] |= 1 << EAM_IO_INSERT;
                }

                // unlock device
                device.mutex->unlock();
                break;
            }
        }
    }

    // return state
    return KEYPAD_STATE[unit];
}

bool eamuse_keypad_state_naive() {
    return KEYPAD_BINDINGS.keypads[0].empty() && KEYPAD_BINDINGS.keypads[1].empty();
}

void eamuse_set_game(std::string game) {
    if (EAMUSE_GAME_NAME != game) {
        EAMUSE_GAME_NAME = game;
        KEYPAD_BINDINGS = Config::getInstance().getKeypadBindings(game);
    }
}

std::string eamuse_get_game() {
    return EAMUSE_GAME_NAME;
}

void eamuse_autodetect_game() {
    if (avs::game::is_model("KFC"))
        eamuse_set_game("Sound Voltex");
    else if (avs::game::is_model("LDJ"))
        eamuse_set_game("Beatmania IIDX");
    else if (avs::game::is_model("J44") ||
             avs::game::is_model("K44") ||
             avs::game::is_model("L44"))
        eamuse_set_game("Jubeat");
    else if (avs::game::is_model("KDM"))
        eamuse_set_game("Dance Evolution");
    else if (avs::game::is_model("NBT"))
        eamuse_set_game("Beatstream");
    else if (avs::game::is_model("I36"))
        eamuse_set_game("Metal Gear");
    else if (avs::game::is_model("MBR"))
        eamuse_set_game("Reflec Beat");
    else if (avs::game::is_model("M39"))
        eamuse_set_game("Pop'n Music");
    else if (avs::game::is_model("KGG"))
        eamuse_set_game("Steel Chronicles");
    else if (avs::game::is_model("JGT"))
        eamuse_set_game("Road Fighters 3D");
    else if (avs::game::is_model("PIX"))
        eamuse_set_game("Museca");
    else if (avs::game::is_model("R66"))
        eamuse_set_game("Bishi Bashi Channel");
    else if (avs::game::is_model("M32"))
        eamuse_set_game("GitaDora");
    else if (avs::game::is_model("KDX") ||
             avs::game::is_model("MDX"))
        eamuse_set_game("Dance Dance Revolution");
    else if (avs::game::is_model("PAN"))
        eamuse_set_game("Nostalgia");
    else if (avs::game::is_model("LMA"))
        eamuse_set_game("Quiz Magic Academy");
    else if (avs::game::is_model("MMD"))
        eamuse_set_game("FutureTomTom");
    else
        log_warning("eamuse", "Unknown game model: " + to_string(avs::game::MODEL));
}

void eamuse_scard_callback(uint8_t slot_no, cardinfo_t *cardinfo) {
    if (cardinfo->card_type > 0)
        eamuse_card_insert(slot_no, (const char*) cardinfo->uid);
}
