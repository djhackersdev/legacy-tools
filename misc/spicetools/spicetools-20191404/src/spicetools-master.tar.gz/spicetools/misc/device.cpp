#include "device.h"
#include <ctime>
#include "cfg/api.h"
#include "util/logging.h"
#include "util/detour.h"
#include "util/libutils.h"
#include "util/utils.h"
#include "games/jb/jb.h"
#include "games/jb/io.h"
#include "games/gitadora/io.h"
#include "games/rb/io.h"
#include "avs/game.h"
#include "eamuse.h"

using namespace GameAPI;

// settings
static std::string DEVICE_SYSTEM_VERSION = "4.2.0:0";
static std::string DEVICE_SUBBOARD_VERSION = "4.2.0:0";

// state
static HINSTANCE DEVICE_INSTANCE;
static std::string DEVICE_INSTANCE_NAME1 = "device.dll";
static std::string DEVICE_INSTANCE_NAME2 = "libdevice.dll";
static bool DEVICE_INITIALIZED = false;
static int DEVICE_INPUT_STATE;

static int __cdecl device_check_secplug(int a1) {
    if (a1 > 1)
        return 0;

    if (avs::game::is_model("J44") || avs::game::is_model("K44")) {
        return 0x101 - a1;
    } else {
        return 0x100 + a1;
    }
}

static int __cdecl device_force_check_secplug(int a1, int a2) {
    return 0;
}

static short __cdecl device_dispose_coinstock() {
    eamuse_coin_consume_stock();
    return 0;
}

static int __cdecl device_finalize(int a1, int a2) {
    return 0;
}

static void __cdecl device_get_coinstock(unsigned short *coin1, unsigned short *coin2) {
    *coin1 = (unsigned short) eamuse_coin_get_stock();
    *coin2 = 0;

    // without this, jubeat will spawn never ending credit inserts
    eamuse_coin_consume_stock();
}

static void __cdecl device_get_coinstock_all(unsigned short *coin1, unsigned short *coin2) {
    *coin1 = (unsigned short) eamuse_coin_get_stock();
    *coin2 = 0;

    // without this, jubeat will spawn never ending credit inserts
    eamuse_coin_consume_stock();
}

static char __cdecl device_get_dispw() {
    return 0;
}

static long __cdecl device_get_input(int a1) {

    // Gitadora
    if (avs::game::is_model("M32")) {
        long ret = 0;

        // get buttons
        auto buttons = games::gitadora::get_buttons();

        // service
        if (Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::Service)))
            ret |= 0x8;

        // test
        if (Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::Test)))
            ret |= 0x2;

        // coin
        if (Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::Coin)))
            ret |= 0x10;

        // gf player 2 controls
        if (a1 == 1) {

            // start
            if (Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::GuitarP2Start)))
                ret |= 0x4;

            // up
            if (Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::GuitarP2Up)))
                ret |= 0x20;

            // down, wail down, wail up
            if (Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::GuitarP2Down)) ||
                    Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::GuitarP2WailDown)) ||
                    Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::GuitarP2WailUp)))
                ret |= 0x40;

            // left
            if (Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::GuitarP2Left)))
                ret |= 0x80;

            // right
            if (Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::GuitarP2Right)))
                ret |= 0x100;

            // help
            if (Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::GuitarP2Help)))
                ret |= 0x200;

            // effect 1
            if (Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::GuitarP2Effect1)))
                ret |= 0x400;

            // effect 2
            if (Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::GuitarP2Effect2)))
                ret |= 0x800;

            // effect 3
            if (Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::GuitarP2Effect3)))
                ret |= 0x1000;

            // effect pedal
            if (!Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::GuitarP2EffectPedal)))
                ret |= 0x2000;

            // button extra 1
            if (Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::GuitarP2ButtonExtra1)))
                ret |= 0x4000;

            // button extra 2
            if (Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::GuitarP2ButtonExtra2)))
                ret |= 0x8000;

            // return flags
            return ret;
        }

        // gf/dm start
        if (Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::GuitarP1Start)) ||
                Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::DrumStart)))
            ret |= 0x4;

        // gf/dm up
        if (Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::GuitarP1Up)) ||
            Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::DrumUp)))
            ret |= 0x20;

        // gf/dm down
        if (Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::GuitarP1Down)) ||
                Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::GuitarP1WailUp)) ||
                Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::GuitarP1WailDown)) ||
                Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::DrumDown)))
            ret |= 0x40;

        // gf/dm left
        if (Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::GuitarP1Left)) ||
            Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::DrumLeft)))
            ret |= 0x80;

        // gf/dm right
        if (Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::GuitarP1Right)) ||
            Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::DrumRight)))
            ret |= 0x100;

        // gf/dm help
        if (Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::GuitarP1Help)) ||
            Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::DrumHelp)))
            ret |= 0x200;

        // gf effect 1
        if (Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::GuitarP1Effect1)))
            ret |= 0x400;

        // gf effect 2
        if (Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::GuitarP1Effect2)))
            ret |= 0x800;

        // gf effect 3
        if (Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::GuitarP1Effect3)))
            ret |= 0x1000;

        // gf effect pedal
        if (!Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::GuitarP1EffectPedal)))
            ret |= 0x2000;

        // gf/dm button extra 1
        if (Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::GuitarP1ButtonExtra1)) ||
            Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::DrumButtonExtra1)))
            ret |= 0x4000;

        // gf/dm button extra 2
        if (Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::GuitarP1ButtonExtra2)) ||
            Buttons::getState(RI_MGR, buttons->at(games::gitadora::Buttons::DrumButtonExtra2)))
            ret |= 0x8000;

        // return flags
        return ret;
    }

    // all other games get updated in device_update()
    if (a1)
        return 0;
    return DEVICE_INPUT_STATE;
}

static long __cdecl device_get_input_time() {
    time_t t = std::time(nullptr);
    auto now = static_cast<long int> (t);
    return now;
}

static int *__cdecl device_get_jamma() {
    return &DEVICE_INPUT_STATE;
}

static int __cdecl device_get_jamma_history(struct T_JAMMA_HISTORY_INFO *a1, int a2) {
    return 0;
}

static int __cdecl device_get_panel_trg_off(int a1, int a2, int a3) {
    return 0;
}

static int __cdecl device_get_panel_trg_on(int a1, int a2, int a3) {
    return 0;
}

static int __cdecl device_get_panel_trg_short_on(int a1, int a2, int a3) {
    return 0;
}

static int __cdecl device_get_secplug_error(int a1) {
    return 0;
}

static int __cdecl device_get_secplug_hist(int a1, int a2, char *a3) {
    *a3 = 0;
    return 0;
}

static int __cdecl device_get_racecount() {
    return 0;
}

static int __cdecl device_get_secplug(int a1, int a2, int a3) {
    return 1;
}

static int __cdecl device_get_sliptrg(int a1) {
    return 0;
}

static int __cdecl device_get_status() {
    return 0;
}

static int __cdecl device_get_subboard_version(void *data, unsigned int size) {
    if (size < 8)
        memset(data, 0, MIN(1, size));
    else
        memcpy(data, DEVICE_SUBBOARD_VERSION.c_str(), 8);
    return 0;
}

static const char *__cdecl device_get_sys_version() {
    return DEVICE_SYSTEM_VERSION.c_str();
}

static int __cdecl device_initialize(int a1, int a2) {
    DEVICE_INITIALIZED = true;
    return 0;
}

static bool __cdecl device_is_initialized() {
    return DEVICE_INITIALIZED;
}

static void __cdecl device_poweroff() {
}

static int __cdecl device_read_secplug(int a1, int a2, int a3) {
    return 1;
}

static int __cdecl device_set_coinblocker_open(char number, char open) {
    return 0;
}

static void __cdecl device_set_coincounter_merge() {
}

static int __cdecl device_set_coincounter_work() {
    return 0;
}

static int __cdecl device_set_panel_mode(int mode) {
    return 0;
}

static void __cdecl device_set_jamma_asyncmode() {
}

static void __cdecl device_set_jamma_normalmode() {
}

static void __cdecl device_set_jamma_unti_inputskip(int a1) {
}

static int __cdecl device_set_portout(int a1, int a2) {
    return 0;
}

static void __cdecl device_set_portoutbit() {
}

static int __cdecl device_set_watchdog_timer(int a1) {
    return 0;
}

static void __cdecl device_update() {

    // JB knit and copious
    if (avs::game::is_model("J44") || avs::game::is_model("K44")) {

        // update touch
        games::jb::touch_update();

        // get buttons
        auto buttons = games::jb::get_buttons();

        // reset
        DEVICE_INPUT_STATE = 0;

        // service
        if (Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Service)))
            DEVICE_INPUT_STATE |= 1 << 30;

        // test
        if (Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Test)))
            DEVICE_INPUT_STATE |= 1 << 28;

        // coin mech
        if (Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::CoinMech)))
            DEVICE_INPUT_STATE |= 1 << 29;

        // button 1
        if (games::jb::TOUCH_STATE[3] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button1)))
            DEVICE_INPUT_STATE |= 1 << 13;

        // button 2
        if (games::jb::TOUCH_STATE[7] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button2)))
            DEVICE_INPUT_STATE |= 1 << 9;

        // button 3
        if (games::jb::TOUCH_STATE[11] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button3)))
            DEVICE_INPUT_STATE |= 1 << 21;

        // button 4
        if (games::jb::TOUCH_STATE[15] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button4)))
            DEVICE_INPUT_STATE |= 1 << 17;

        // button 5
        if (games::jb::TOUCH_STATE[2] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button5)))
            DEVICE_INPUT_STATE |= 1 << 14;

        // button 6
        if (games::jb::TOUCH_STATE[6] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button6)))
            DEVICE_INPUT_STATE |= 1 << 10;

        // button 7
        if (games::jb::TOUCH_STATE[10] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button7)))
            DEVICE_INPUT_STATE |= 1 << 22;

        // button 8
        if (games::jb::TOUCH_STATE[14] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button8)))
            DEVICE_INPUT_STATE |= 1 << 18;

        // button 9
        if (games::jb::TOUCH_STATE[1] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button9)))
            DEVICE_INPUT_STATE |= 1 << 15;

        // button 10
        if (games::jb::TOUCH_STATE[5] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button10)))
            DEVICE_INPUT_STATE |= 1 << 11;

        // button 11
        if (games::jb::TOUCH_STATE[9] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button11)))
            DEVICE_INPUT_STATE |= 1 << 23;

        // button 12
        if (games::jb::TOUCH_STATE[13] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button12)))
            DEVICE_INPUT_STATE |= 1 << 19;

        // button 13
        if (games::jb::TOUCH_STATE[0] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button13)))
            DEVICE_INPUT_STATE |= 1 << 24;

        // button 14
        if (games::jb::TOUCH_STATE[4] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button14)))
            DEVICE_INPUT_STATE |= 1 << 12;

        // button 15
        if (games::jb::TOUCH_STATE[8] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button15)))
            DEVICE_INPUT_STATE |= 1 << 26;

        // button 16
        if (games::jb::TOUCH_STATE[12] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button16)))
            DEVICE_INPUT_STATE |= 1 << 20;

        DEVICE_INPUT_STATE = ~DEVICE_INPUT_STATE;
    }

    // JB
    if (avs::game::is_model("L44")) {

        // update touch
        games::jb::touch_update();

        // get buttons
        auto buttons = games::jb::get_buttons();

        // reset
        DEVICE_INPUT_STATE = 0;

        // service
        if (Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Service)))
            DEVICE_INPUT_STATE |= 1 << 25;

        // test
        if (Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Test)))
            DEVICE_INPUT_STATE |= 1 << 28;

        // coin mech
        if (Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::CoinMech)))
            DEVICE_INPUT_STATE |= 1 << 24;

        // button 1
        if (games::jb::TOUCH_STATE[0] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button1)))
            DEVICE_INPUT_STATE |= 1 << 5;

        // button 2
        if (games::jb::TOUCH_STATE[1] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button2)))
            DEVICE_INPUT_STATE |= 1 << 1;

        // button 3
        if (games::jb::TOUCH_STATE[2] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button3)))
            DEVICE_INPUT_STATE |= 1 << 13;

        // button 4
        if (games::jb::TOUCH_STATE[3] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button4)))
            DEVICE_INPUT_STATE |= 1 << 9;

        // button 5
        if (games::jb::TOUCH_STATE[4] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button5)))
            DEVICE_INPUT_STATE |= 1 << 6;

        // button 6
        if (games::jb::TOUCH_STATE[5] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button6)))
            DEVICE_INPUT_STATE |= 1 << 2;

        // button 7
        if (games::jb::TOUCH_STATE[6] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button7)))
            DEVICE_INPUT_STATE |= 1 << 14;

        // button 8
        if (games::jb::TOUCH_STATE[7] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button8)))
            DEVICE_INPUT_STATE |= 1 << 10;

        // button 9
        if (games::jb::TOUCH_STATE[8] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button9)))
            DEVICE_INPUT_STATE |= 1 << 7;

        // button 10
        if (games::jb::TOUCH_STATE[9] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button10)))
            DEVICE_INPUT_STATE |= 1 << 3;

        // button 11
        if (games::jb::TOUCH_STATE[10] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button11)))
            DEVICE_INPUT_STATE |= 1 << 15;

        // button 12
        if (games::jb::TOUCH_STATE[11] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button12)))
            DEVICE_INPUT_STATE |= 1 << 11;

        // button 13
        if (games::jb::TOUCH_STATE[12] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button13)))
            DEVICE_INPUT_STATE |= 1 << 16;

        // button 14
        if (games::jb::TOUCH_STATE[13] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button14)))
            DEVICE_INPUT_STATE |= 1 << 4;

        // button 15
        if (games::jb::TOUCH_STATE[14] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button15)))
            DEVICE_INPUT_STATE |= 1 << 20;

        // button 16
        if (games::jb::TOUCH_STATE[15] || Buttons::getState(RI_MGR, buttons->at(games::jb::Buttons::Button16)))
            DEVICE_INPUT_STATE |= 1 << 12;
    }

    // RB
    if (avs::game::is_model("MBR")) {

        // get buttons
        std::vector<Button *> *buttons = games::rb::get_buttons();

        // reset
        DEVICE_INPUT_STATE = 0;

        // service
        if (Buttons::getState(RI_MGR, buttons->at(games::rb::Buttons::Service)))
            DEVICE_INPUT_STATE |= 0x08;

        // test
        if (Buttons::getState(RI_MGR, buttons->at(games::rb::Buttons::Test)))
            DEVICE_INPUT_STATE |= 0x02;
    }
}

static void __cdecl device_update_secplug() {
}

static int __cdecl devsci_break(char a1, char a2) {
    return 0;
}

static int __cdecl devsci_open(int a1, int a2) {
    return 0;
}

static int __cdecl devsci_read(int a1, int a2) {
    return 0;
}

static int __cdecl devsci_write(int a1, int a2, int a3) {
    return a3;
}

void spicedevice_attach() {

    // get instance
    DEVICE_INSTANCE = libutils::try_module(DEVICE_INSTANCE_NAME1);
    if (!DEVICE_INSTANCE)
        DEVICE_INSTANCE = libutils::try_module(DEVICE_INSTANCE_NAME2);
    if (!DEVICE_INSTANCE) {
        log_info("device", "Skipping SpiceTools Device");
        return;
    }

    /*
     * Patches
     * the trick here is to account for normal names and specific ones
     */
    detour::inline_hook((void *) &device_check_secplug, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_check_secplug", "?device_check_secplug@@YAHH@Z"}));
    detour::inline_hook((void *) &device_force_check_secplug, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_force_check_secplug", "?device_force_check_secplug@@YAXXZ"}));
    detour::inline_hook((void *) &device_dispose_coinstock, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_dispose_coinstock"}));
    detour::inline_hook((void *) &device_finalize, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_finalize", "?device_finalize@@YAXXZ"}));
    detour::inline_hook((void *) &device_get_coinstock, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_get_coinstock", "?device_get_coinstock@@YAXPEAG0@Z"}));
    detour::inline_hook((void *) &device_get_coinstock_all, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_get_coinstock_all", "?device_get_coinstock_all@@YAXPEAG0@Z"}));
    detour::inline_hook((void *) &device_get_dispw, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_get_dispw", "?device_get_dipsw@@YAEH@Z"}));
    detour::inline_hook((void *) &device_get_input, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_get_input", "?device_get_input@@YAIH@Z"}));
    detour::inline_hook((void *) &device_get_input_time, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_get_input_time", "?device_get_input_time@@YA_KXZ"}));
    detour::inline_hook((void *) &device_get_jamma, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_get_jamma"}));
    detour::inline_hook((void *) &device_get_jamma_history, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_get_jamma_history",
                              "?device_get_jamma_history@@YAHPEAUT_JAMMA_HISTORY_INFO@@H@Z"}));
    detour::inline_hook((void *) &device_get_panel_trg_off, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_get_panel_trg_off"}));
    detour::inline_hook((void *) &device_get_panel_trg_on, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_get_panel_trg_on"}));
    detour::inline_hook((void *) &device_get_panel_trg_short_on, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_get_panel_trg_short_on"}));
    detour::inline_hook((void *) &device_get_secplug_error, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_get_secplug_error"}));
    detour::inline_hook((void *) &device_get_secplug_hist, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_get_secplug_hist"}));
    detour::inline_hook((void *) &device_get_racecount, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_get_racecount", "?device_get_racecount@@YAHXZ"}));
    detour::inline_hook((void *) &device_get_secplug, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_get_secplug", "?device_get_secplug@@YAHHQEAE0@Z"}));
    detour::inline_hook((void *) &device_get_sliptrg, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_get_sliptrg", "?device_get_sliptrg@@YAIH@Z"}));
    detour::inline_hook((void *) &device_get_status, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_get_status", "?device_get_status@@YAHXZ"}));
    detour::inline_hook((void *) &device_get_subboard_version, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_get_subboard_version", "?device_get_subboard_version@@YAHPEADH@Z"}));
    detour::inline_hook((void *) &device_get_sys_version, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_get_sys_version", "?device_get_sys_version@@YAPEBDXZ"}));
    detour::inline_hook((void *) &device_initialize, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_initialize", "?device_initialize@@YAHH@Z"}));
    detour::inline_hook((void *) &device_is_initialized, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_is_initialized"}));
    detour::inline_hook((void *) &device_poweroff, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_poweroff", "?device_poweroff@@YAXXZ"}));
    detour::inline_hook((void *) &device_read_secplug, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_read_secplug", "?device_read_secplug@@YAHHQEAE0@Z"}));
    detour::inline_hook((void *) &device_set_coinblocker_open, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_set_coinblocker_open", "?device_set_coinblocker_open@@YAXEE@Z"}));
    detour::inline_hook((void *) &device_set_coincounter_merge, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_set_coincounter_merge", "?device_set_coincounter_merge@@YAXE@Z"}));
    detour::inline_hook((void *) &device_set_coincounter_work, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_set_coincounter_work", "?device_set_coincounter_work@@YAXEE@Z"}));
    detour::inline_hook((void *) &device_set_panel_mode, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_set_panel_mode"}));
    detour::inline_hook((void *) &device_set_jamma_asyncmode, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_set_jamma_asyncmode", "?device_set_jamma_asyncmode@@YAXXZ"}));
    detour::inline_hook((void *) &device_set_jamma_normalmode, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_set_jamma_normalmode", "?device_set_jamma_normalmode@@YAXXZ"}));
    detour::inline_hook((void *) &device_set_jamma_unti_inputskip, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_set_jamma_unti_inputskip", "?device_set_jamma_unti_inputskip@@YAXH@Z"}));
    detour::inline_hook((void *) &device_set_portout, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_set_portout", "?device_set_portout@@YAXHH@Z"}));
    detour::inline_hook((void *) &device_set_portoutbit, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_set_portoutbit", "?device_set_portoutbit@@YAXHH@Z"}));
    detour::inline_hook((void *) &device_set_watchdog_timer, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_set_watchdog_timer"}));
    detour::inline_hook((void *) &device_update, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_update", "?device_update@@YAXXZ"}));
    detour::inline_hook((void *) &device_update_secplug, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"device_update_secplug", "?device_update_secplug@@YAXXZ"}));
    detour::inline_hook((void *) &devsci_break, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"devsci_break", "?devsci_break@@YAXHH@Z"}));
    detour::inline_hook((void *) &devsci_open, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"devsci_open", "?devsci_open@@YAXHHH@Z"}));
    detour::inline_hook((void *) &devsci_read, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"devsci_read", "?devsci_read@@YAHHPEAEH@Z"}));
    detour::inline_hook((void *) &devsci_write, (DWORD_PTR) libutils::try_proc_list(
            DEVICE_INSTANCE, {"devsci_write", "?devsci_write@@YAHHPEBEH@Z"}));

    // TODO: missing functions
    // device_hwinfo_etc_update
    // device_hwinfo_get
    // device_hwinfo_update
    // device_set_coincounter_controllable
    // device_set_jamma_interrupt_status
    // sci_mng_get_debug_info
    // test_device
    // p4io_sci_boot
    // p4io_sci_clear_error
    // p4io_sci_close
    // p4io_sci_flush
    // p4io_sci_flush_complete
    // p4io_sci_get_error
    // p4io_sci_gets
    // p4io_sci_print_error
    // p4io_sci_puts
    // p4io_sci_set_linebreak
    // p4io_sci_setparam
}

void spicedevice_detach() {
    // TODO
}
