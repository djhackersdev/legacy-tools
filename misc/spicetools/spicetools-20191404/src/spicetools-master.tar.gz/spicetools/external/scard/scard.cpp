/**
 * MIT-License
 * Copyright (c) 2018 by nolm <nolan@nolm.name>
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 *
 * Modified version.
 */


#include "scard.h"
#include <windows.h>
#include <winscard.h>
#include <thread>
#include "util/utils.h"
#include "util/logging.h"
#include "hooks/sleephook.h"

#define MAX_APDU_SIZE 255
#define SCARD_POLL_INTERVAL_MS 100
BYTE UID_CMD[5] = {0xFFu, 0xCAu, 0x00u, 0x00u, 0x00u};

enum scard_atr_protocol {
    SCARD_ATR_PROTOCOL_ISO14443_PART3 = 0x03,
    SCARD_ATR_PROTOCOL_ISO15693_PART3 = 0x0B,
};

volatile bool shouldExit = false;

winscard_config_t WINSCARD_CONFIG = {};

void scard_update(SCARDCONTEXT hContext, LPCTSTR readerName, uint8_t unitNo) {

    // Connect to the smart card.
    LONG lRet = 0;
    SCARDHANDLE hCard{};
    DWORD dwActiveProtocol{};
    for (int retry = 0; retry < 10; retry++) {
        if ((lRet = SCardConnect(hContext, readerName, SCARD_SHARE_SHARED, SCARD_PROTOCOL_T0 | SCARD_PROTOCOL_T1,
                &hCard, &dwActiveProtocol)) == SCARD_S_SUCCESS) {
            break;
        }
        Sleep(20);
    }

    if (lRet != SCARD_S_SUCCESS) {
        log_warning("scard", "error connecting to the card: " + to_string(lRet));
        return;
    }

    // Read ATR to determine card type.
    TCHAR szReader[200];
    DWORD cchReader = 200;
    BYTE atr[32];
    DWORD cByteAtr = 32;
    lRet = SCardStatus(hCard, szReader, &cchReader, NULL, NULL, atr, &cByteAtr);
    if (lRet != SCARD_S_SUCCESS) {
        log_warning("scard", "error getting card status: 0x%08X" + to_string(lRet));
        return;
    }

    // Only care about 20-byte ATRs returned by arcade-type smart cards
    if (cByteAtr != 20) {
        log_info("scard", "ignoring card with len(atr) = " + to_string(cByteAtr));
        return;
    }

    // Figure out if we should reverse the UID returned by the card based on the ATR protocol
    BYTE cardProtocol = atr[12];
    BOOL shouldReverseUid = false;
    if (cardProtocol == SCARD_ATR_PROTOCOL_ISO15693_PART3) {
        log_info("scard", "card protocol: ISO15693_PART3");
        shouldReverseUid = true;
    } else if (cardProtocol == SCARD_ATR_PROTOCOL_ISO14443_PART3) {
        log_info("scard", "card protocol: ISO14443_PART3");
    }

    // Read UID
    BYTE pbRecv[MAX_APDU_SIZE];
    DWORD cbRecv = MAX_APDU_SIZE;
    auto pci = dwActiveProtocol == SCARD_PROTOCOL_T1 ? SCARD_PCI_T1 : SCARD_PCI_T0;
    if ((lRet = SCardTransmit(hCard, pci, UID_CMD, sizeof(UID_CMD),
                              NULL, pbRecv, &cbRecv)) != SCARD_S_SUCCESS) {
        log_warning("scard", "error querying card UID: " + to_string(lRet));
        return;
    }

    if ((lRet = SCardDisconnect(hCard, SCARD_LEAVE_CARD)) != SCARD_S_SUCCESS) {
        log_info("scard", "failed SCardDisconnect: " + to_string(lRet));
    }

    if (cbRecv < 8) {
        log_info("scard", "ignoring card with len(uid) = " + to_string(cbRecv) + " < 8");
        return;
    } else if (cbRecv > 8) {
        log_info("scard", "taking first 8 bytes of len(uid )= " + to_string(cbRecv));
    }

    // Copy UID to struct, reversing if necessary
    cardinfo_t cardinfo;
    if (shouldReverseUid) {
        for (DWORD i = 0; i < 8; i++) {
            cardinfo.uid[i] = pbRecv[7 - i];
        }
    } else {
        memcpy(cardinfo.uid, pbRecv, 8);
    }
    log_info("scard", "read card: " + bin2hex(cardinfo.uid, 8));

    // set card type to 1
    cardinfo.card_type = 1;

    // update toggle
    bool flip_order = WINSCARD_CONFIG.flip_order;
    if (WINSCARD_CONFIG.toggle_order && (GetKeyState(VK_NUMLOCK) & 1) > 0)
        flip_order = !flip_order;

    // callback
    if (WINSCARD_CONFIG.cardinfo_callback)
        WINSCARD_CONFIG.cardinfo_callback(flip_order ? ~unitNo : unitNo, &cardinfo);
}

void scard_clear(uint8_t unitNo) {

    // reset
    cardinfo_t empty_cardinfo{};

    // callback
    if (WINSCARD_CONFIG.cardinfo_callback)
        WINSCARD_CONFIG.cardinfo_callback(WINSCARD_CONFIG.flip_order ? ~unitNo : unitNo, &empty_cardinfo);
}

void scard_loop(SCARDCONTEXT hContext, LPCTSTR slot0_readerName, LPCTSTR slot1_readerName, uint8_t readerCount) {
    LONG lRet;
    SCARD_READERSTATE readerState[2] = {
            {.szReader = slot0_readerName, .pvUserData = NULL, .dwCurrentState = SCARD_STATE_UNAWARE,
                    .dwEventState = 0, .cbAtr = 0, .rgbAtr = {}},
            {.szReader = slot1_readerName, .pvUserData = NULL, .dwCurrentState = SCARD_STATE_UNAWARE,
                    .dwEventState = 0, .cbAtr = 0, .rgbAtr = {}},
    };

    if (readerCount < 1) {
        return;
    }

    while (!shouldExit) {
        lRet = SCardGetStatusChange(hContext, SCARD_POLL_INTERVAL_MS, readerState, readerCount);
        if (lRet == SCARD_E_TIMEOUT) {
            continue;
        } else if (lRet != SCARD_S_SUCCESS) {
            log_warning("scard", "failed SCardGetStatusChange: " + to_string(lRet));
            continue;
        }

        for (uint8_t unitNo = 0; unitNo < readerCount; unitNo++) {
            if (!(readerState[unitNo].dwEventState & SCARD_STATE_CHANGED)) {
                continue;
            }

            DWORD newState = readerState[unitNo].dwEventState ^ SCARD_STATE_CHANGED;
            bool wasCardPresent = (readerState[unitNo].dwCurrentState & SCARD_STATE_PRESENT) > 0;
            if (newState & SCARD_STATE_UNAVAILABLE) {
                log_info("scard", "new card state: unavailable");
                Sleep(SCARD_POLL_INTERVAL_MS);
            } else if (newState & SCARD_STATE_EMPTY) {
                log_info("scard", "new card state: empty");
                scard_clear(unitNo);
            } else if (newState & SCARD_STATE_PRESENT && !wasCardPresent) {
                log_info("scard", "new card state: present");
                scard_update(hContext, readerState[unitNo].szReader, unitNo);
            }

            readerState[unitNo].dwCurrentState = readerState[unitNo].dwEventState;
        }
    }
}

int scard_threadmain() {
    LONG lRet = 0;
    SCARDCONTEXT hContext = 0;

    if ((lRet = SCardEstablishContext(SCARD_SCOPE_USER, NULL, NULL, &hContext)) != SCARD_S_SUCCESS) {
        log_warning("scard", "failed to establish SCard context: " + bin2hex(&lRet, sizeof(LONG)));
        return lRet;
    }

    LPCTSTR reader = NULL;
    LPTSTR readerNameSlots[2] = {NULL, NULL};
    int readerNameLen = 0;
    while (!(readerNameSlots[0] || readerNameSlots[1])) {

        // get list of readers
        LPTSTR readerList = NULL;
        DWORD pcchReaders = SCARD_AUTOALLOCATE;
        lRet = SCardListReaders(hContext, NULL, (LPTSTR) &readerList, &pcchReaders);

        int slot0_idx = -1;
        int slot1_idx = -1;
        int readerCount = 0;
        switch (lRet) {
            case SCARD_E_NO_READERS_AVAILABLE:
                log_info("scard", "no readers available, waiting 1000ms...");
                Sleep(1000);
                break;

            case SCARD_S_SUCCESS:

                // So WinAPI has this terrible "multi-string" concept wherein you have a list
                // of null-terminated strings, terminated by a double-null.
                for (reader = readerList; *reader; reader = reader + lstrlen(reader) + 1) {
                    log_info("scard", "found reader: " + to_string(reader));
                    if (WINSCARD_CONFIG.slot0_reader_name && !lstrcmp(WINSCARD_CONFIG.slot0_reader_name, reader))
                        slot0_idx = readerCount;
                    if (WINSCARD_CONFIG.slot1_reader_name && !lstrcmp(WINSCARD_CONFIG.slot1_reader_name, reader))
                        slot1_idx = readerCount;
                    readerCount++;
                }

                // If we have at least two readers, assign readers to slots as necessary.
                if (readerCount >= 2) {
                    if (slot1_idx != 0)
                        slot0_idx = 0;
                    if (slot0_idx != 1)
                        slot1_idx = 1;
                }

                // if the reader count is 1 and no reader was set, set first reader
                if (readerCount == 1 && slot0_idx < 0 && slot1_idx < 0)
                    slot0_idx = 0;

                // If we somehow only found slot 1, promote slot 1 to slot 0.
                if (slot0_idx < 0 && slot1_idx >= 0) {
                    slot0_idx = slot1_idx;
                    slot1_idx = -1;
                }

                // Extract the relevant names from the multi-string.
                int i;
                for (i = 0, reader = readerList; *reader; reader = reader + lstrlen(reader) + 1, i++) {
                    if (slot0_idx == i) {
                        readerNameLen = lstrlen(reader);
                        readerNameSlots[0] = (LPTSTR) HeapAlloc(GetProcessHeap(), HEAP_GENERATE_EXCEPTIONS,
                                                                sizeof(TCHAR) * (readerNameLen + 1));
                        memcpy(readerNameSlots[0], &reader[0], (size_t) (readerNameLen + 1));
                    }
                    if (slot1_idx == i) {
                        readerNameLen = lstrlen(reader);
                        readerNameSlots[1] = (LPTSTR) HeapAlloc(GetProcessHeap(), HEAP_GENERATE_EXCEPTIONS,
                                                                sizeof(TCHAR) * (readerNameLen + 1));
                        memcpy(readerNameSlots[1], &reader[0], (size_t) (readerNameLen + 1));
                    }
                }
                break;

            default:
                log_warning("scard", "failed SCardListReaders: " + to_string(lRet));
                Sleep(5000);
                break;
        }

        if (readerList) {
            SCardFreeMemory(hContext, readerList);
        }
    }

    if (readerNameSlots[0])
        log_info("scard", "using reader slot0: " + to_string(readerNameSlots[0]));
    if (readerNameSlots[1])
        log_info("scard", "using reader slot1: " + to_string(readerNameSlots[0]));

    scard_loop(hContext, readerNameSlots[0], readerNameSlots[1], (uint8_t) (readerNameSlots[1] ? 2 : 1));

    if (readerNameSlots[0]) {
        HeapFree(GetProcessHeap(), 0, readerNameSlots[0]);
    }
    if (readerNameSlots[1]) {
        HeapFree(GetProcessHeap(), 0, readerNameSlots[1]);
    }
    return 0;
}

void scard_threadstart() {
    std::thread t([] {
        scard_threadmain();
    });
    t.detach();
}

void scard_fini() {
    shouldExit = true;
}
