
// enable touch functions - set version to windows 7
// mingw otherwise doesn't load touch stuff
#define _WIN32_WINNT 0x0601

#include <thread>
#include <mutex>
#include <windowsx.h>
#include "touch.h"
#include "hooks/dxhook.h"
#include "util/logging.h"
#include "misc/eamuse.h"
#include "util/detour.h"
#include "util/libutils.h"
#include "util/circular_buffer.h"

// mingw issue #2205 workaround
// https://sourceforge.net/p/mingw/bugs/2205/
#undef TOUCHEVENTF_MOVE
#define TOUCHEVENTF_MOVE 0x0001
#undef TOUCHEVENTF_DOWN
#define TOUCHEVENTF_DOWN 0x0002

// mingw doesn't seem to have these
#ifndef WM_TABLET_DEFBASE
#define WM_TABLET_DEFBASE                    0x02C0
#define WM_TABLET_QUERYSYSTEMGESTURESTATUS   (WM_TABLET_DEFBASE + 12)
#define TABLET_DISABLE_PRESSANDHOLD        0x00000001
#define TABLET_DISABLE_PENTAPFEEDBACK      0x00000008
#define TABLET_DISABLE_PENBARRELFEEDBACK   0x00000010
#define TABLET_DISABLE_TOUCHUIFORCEON      0x00000100
#define TABLET_DISABLE_TOUCHUIFORCEOFF     0x00000200
#define TABLET_DISABLE_TOUCHSWITCH         0x00008000
#define TABLET_DISABLE_FLICKS              0x00010000
#define TABLET_DISABLE_SMOOTHSCROLLING     0x00080000
#define TABLET_DISABLE_FLICKFALLBACKKEYS   0x00100000
#define TABLET_ENABLE_MULTITOUCHDATA       0x01000000
#endif

// settings
static const int TOUCH_EVENT_BUFFER_SIZE = 1024 * 4;
static const int TOUCH_EVENT_BUFFER_THRESHOLD1 = 1024 * 2;
static const int TOUCH_EVENT_BUFFER_THRESHOLD2 = 1024 * 3;

// touch states
static std::vector<TouchPoint> TOUCH_POINTS;
static std::mutex TOUCH_POINTS_M;
static circular_buffer<TouchEvent> TOUCH_EVENTS(TOUCH_EVENT_BUFFER_SIZE);
static std::mutex TOUCH_EVENTS_M;

// general states
static bool SPICETOUCH_ATTACHED = false;
static HWND SPICETOUCH_HWND = nullptr;
static WNDPROC SPICETOUCH_OLD_PROC = nullptr;
static bool SPICETOUCH_ENABLE_MOUSE = true;
static bool SPICETOUCH_REGISTERED_TOUCH = false;
static bool SPICETOUCH_CALL_OLD_PROC = false;
static HINSTANCE USER32_INSTANCE = nullptr;
static std::string USER32_NAME = "user32.dll";
static std::string SPICETOUCH_CLASS_NAME = "spiceTouchClass";
static HWND SPICETOUCH_TOUCH_HWND = nullptr;
static std::thread *SPICETOUCH_TOUCH_THREAD = nullptr;
static HFONT SPICETOUCH_FONT;
static std::string SPICETOUCH_FONT_NAME = "Courier New";
static RECT SPICETOUCH_CARD_RECT;
static bool SPICETOUCH_CARD_ENABLED = true;
static std::string WINTOUCH_ENABLED_TEXT = "WinTouch enabled.";
static std::string WINTOUCH_DISABLED_TEXT = "WinTouch disabled.";
static std::string INSERT_CARD_TEXT = "Insert Card";
static std::string FONT_WARNING = "Font couln't be loaded.";
static std::string LOG_MODULE_NAME = "touch";

/* dynamic touch functions
 * to maintain compatibility with windows XP
 */
static std::string SetGestureConfigStr = "SetGestureConfig";
static BOOL (WINAPI *pSetGestureConfig)(HWND, DWORD, UINT, PGESTURECONFIG, UINT);
static std::string RegisterTouchWindowStr = "RegisterTouchWindow";
static BOOL (WINAPI *pRegisterTouchWindow)(HWND, ULONG);
static std::string GetTouchInputInfoStr = "GetTouchInputInfo";
static BOOL (WINAPI *pGetTouchInputInfo)(HANDLE, UINT, PTOUCHINPUT, int);
static std::string CloseTouchInputHandleStr = "CloseTouchInputHandle";
static BOOL (WINAPI *pCloseTouchInputHandle)(HANDLE);
static std::string UnregisterTouchWindowStr = "UnregisterTouchWindow";
static BOOL (WINAPI *pUnregisterTouchWindow)(HWND hWnd);

// other
static std::string ATOM_NAME = "MicrosoftTabletPenServiceProperty";

static void load_touch_functions() {

    // check if already loaded
    static bool functions_loaded = false;
    if (functions_loaded)
        return;

    // load user32
    if (USER32_INSTANCE == nullptr)
        USER32_INSTANCE = libutils::load_library(USER32_NAME);

    // load touch functions
    pSetGestureConfig = (BOOL (WINAPI *)(HWND, DWORD, UINT, PGESTURECONFIG, UINT))
            GetProcAddress(USER32_INSTANCE, SetGestureConfigStr.c_str());
    pRegisterTouchWindow = (BOOL (WINAPI *)(HWND, ULONG))
            GetProcAddress(USER32_INSTANCE, RegisterTouchWindowStr.c_str());
    pGetTouchInputInfo = (BOOL (WINAPI *)(HANDLE, UINT, PTOUCHINPUT, int))
            GetProcAddress(USER32_INSTANCE, GetTouchInputInfoStr.c_str());
    pCloseTouchInputHandle = (BOOL (WINAPI *)(HANDLE))
            GetProcAddress(USER32_INSTANCE, CloseTouchInputHandleStr.c_str());
    pUnregisterTouchWindow = (BOOL (WINAPI *)(HWND))
            GetProcAddress(USER32_INSTANCE, UnregisterTouchWindowStr.c_str());
    functions_loaded = true;
}

static __attribute__((stdcall)) void prepare_win_touch(HWND hWnd) {

    // atom settings
    DWORD dwHwndTabletProperty = TABLET_DISABLE_PRESSANDHOLD |
                                 TABLET_DISABLE_PENTAPFEEDBACK |
                                 TABLET_DISABLE_PENBARRELFEEDBACK |
                                 TABLET_DISABLE_FLICKS;
    LPCTSTR tabletAtom = ATOM_NAME.c_str();

    // get atom ID
    ATOM atomID = GlobalAddAtom(tabletAtom);

    // disable gestures
    if (atomID > 0)
        SetProp(hWnd, tabletAtom, (HANDLE) ((unsigned long long) dwHwndTabletProperty));

    // register touch window
    if ((pRegisterTouchWindow == nullptr) || (pRegisterTouchWindow(hWnd, TWF_WANTPALM) == 0)) {
        // Couldn't register touch window
    }

    // set gesture config
    if (pSetGestureConfig != nullptr) {
        GESTURECONFIG gc{};
        gc.dwID = 0;
        gc.dwWant = 0;
        gc.dwBlock = 1;
        pSetGestureConfig(hWnd, 0, 1, &gc, sizeof(GESTURECONFIG));
    }
}

bool is_win_touch_available() {
    return (bool) (GetSystemMetrics(94) & 0x80);
}

/*
 * Add touch event but take care of buffer size
 * Be careful, this doesn't lock the mutex on it's own
 */
static inline void add_touch_event(TouchEvent* te) {

    // check if first threshold is passed
    if (TOUCH_EVENTS.size() > TOUCH_EVENT_BUFFER_THRESHOLD1) {
        switch (te->type) {
            case TOUCH_DOWN:

                // ignore touch down events after first threshold
                return;

            case TOUCH_MOVE:

                // add move event if we're not over the second threshold
                if (TOUCH_EVENTS.size() <= TOUCH_EVENT_BUFFER_THRESHOLD2)
                    TOUCH_EVENTS.put(*te);
                return;

            case TOUCH_UP:

                // check if buffer is full
                if (TOUCH_EVENTS.full()) {

                    // ignore event
                    return;
                }

                // when the buffer isn't full yet, add the touch up event
                TOUCH_EVENTS.put(*te);
                return;

            default:
                return;
        }
    }

    // add the touch up event
    TOUCH_EVENTS.put(*te);
}

static inline void update_card_button() {

    // check if enabled
    if (!SPICETOUCH_CARD_ENABLED)
        return;

    // check touch points
    for (TouchPoint touchPoint : TOUCH_POINTS) {
        POINT pt{};
        pt.x = touchPoint.x;
        pt.y = touchPoint.y;
        if (PtInRect(&SPICETOUCH_CARD_RECT, pt) != 0)
            eamuse_card_insert(0);
    }
}

static LRESULT CALLBACK SpiceTouchWndProc(
        HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {

    // check if touch was registered
    if (!SPICETOUCH_REGISTERED_TOUCH) {
        SPICETOUCH_REGISTERED_TOUCH = true;
        if (is_win_touch_available()) {
            SPICETOUCH_CARD_ENABLED = true;
            prepare_win_touch(hWnd);
            log_info(LOG_MODULE_NAME, WINTOUCH_ENABLED_TEXT);
        } else {
            SPICETOUCH_CARD_ENABLED = false;
            log_info(LOG_MODULE_NAME, WINTOUCH_DISABLED_TEXT);
        }
    }

    // check messages for dedicated window
    if (SPICETOUCH_TOUCH_THREAD != nullptr) {
        switch (msg) {
            case WM_PAINT: {

                // prepare paint
                PAINTSTRUCT paint{};
                HDC hdc = BeginPaint(hWnd, &paint);
                SetBkMode(hdc, TRANSPARENT);

                // draw card input
                if (SPICETOUCH_CARD_ENABLED && (SPICETOUCH_FONT != nullptr)) {

                    // create brushes
                    HBRUSH brushBorder = CreateSolidBrush(RGB(0, 196, 0));
                    HBRUSH brushFill = CreateSolidBrush(RGB(255, 192, 203));

                    // get window rect
                    RECT windowRect{};
                    GetWindowRect(hWnd, &windowRect);

                    auto height = windowRect.bottom - windowRect.top;
                    auto width = windowRect.right - windowRect.left;
                    bool is_portrait = height > width;

                    // create box rect
                    RECT boxRect{};
                    if (is_portrait) {
                        boxRect.left = 20;
                        boxRect.top = 44;
                        boxRect.right = 141;
                        boxRect.bottom = 75;
                    } else {
                        boxRect.left = windowRect.right - 75;
                        boxRect.top = 20;
                        boxRect.right = windowRect.right - 44;
                        boxRect.bottom = 151;
                    }

                    // save box rect for touch input
                    SPICETOUCH_CARD_RECT = boxRect;

                    // draw borders
                    FillRect(hdc, &boxRect, brushBorder);

                    // modify box rect
                    boxRect.left += 1;
                    boxRect.top += 1;
                    boxRect.right -= 1;
                    boxRect.bottom -= 1;

                    // fill box
                    FillRect(hdc, &boxRect, brushFill);

                    // modify box rect
                    if (is_portrait) {
                        boxRect.left += 5;
                        boxRect.top += 5;
                    } else {
                        boxRect.left += 5 + 20;
                        boxRect.top += 5;
                    }

                    // draw text
                    SelectObject(hdc, SPICETOUCH_FONT);
                    SetTextColor(hdc, RGB(0, 196, 0));
                    DrawText(hdc, INSERT_CARD_TEXT.c_str(), -1, &boxRect, DT_LEFT | DT_BOTTOM | DT_NOCLIP);

                    // delete objects
                    DeleteObject(brushFill);
                    DeleteObject(brushBorder);
                }

                // end paint
                EndPaint(hWnd, &paint);

                // call default window procedure
                return DefWindowProc(hWnd, msg, wParam, lParam);
            }
            case WM_CREATE: {

                // set to layered window
                SetWindowLong(hWnd, GWL_EXSTYLE, GetWindowLong(hWnd, GWL_EXSTYLE) | WS_EX_LAYERED);

                // set alpha value
                SetLayeredWindowAttributes(hWnd, 0, 0xFFu, LWA_ALPHA);
                SetLayeredWindowAttributes(hWnd, RGB(255, 192, 203), 0, LWA_COLORKEY);

                // get window rect
                RECT windowRect{};
                GetWindowRect(hWnd, &windowRect);

                auto height = windowRect.bottom - windowRect.top;
                auto width = windowRect.right - windowRect.left;
                bool is_portrait = height > width;

                auto rotation = is_portrait ? 0 : 2700;

                // load font
                SPICETOUCH_FONT = CreateFont(20, 0, rotation, rotation, FW_NORMAL, FALSE, FALSE, FALSE,
                                             ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                                             NONANTIALIASED_QUALITY, DEFAULT_PITCH,
                                             SPICETOUCH_FONT_NAME.c_str());
                if (SPICETOUCH_FONT == nullptr)
                    log_warning(LOG_MODULE_NAME, FONT_WARNING);

                return 0;
            }
            case WM_DESTROY: {
                PostQuitMessage(0);
                return 0;
            }
            default:
                break;
        }
    }

    // parse touch and mouse messages
    switch (msg) {
        case WM_TOUCH: {

            // touch input fields
            UINT cInputs = LOWORD(wParam);
            auto pInputs = new TOUCHINPUT[cInputs];

            // get touch input
            if ((pGetTouchInputInfo != nullptr) &&
                (pGetTouchInputInfo((HANDLE) lParam, cInputs, pInputs, sizeof(TOUCHINPUT)) != 0)) {

                // lock touch points
                std::lock_guard<std::mutex> lock_points(TOUCH_POINTS_M);
                std::lock_guard<std::mutex> lock_events(TOUCH_EVENTS_M);

                // iterate all inputs
                static long prev_x, prev_y;
                for (UINT i = 0; i < cInputs; i++) {
                    TOUCHINPUT ti = pInputs[i];

                    // touch down
                    if ((ti.dwFlags & TOUCHEVENTF_DOWN) != 0u) {

                        // convert to window position
                        POINT point{};
                        point.x = ti.x / 100;
                        point.y = ti.y / 100;
                        ScreenToClient(hWnd, &point);

                        // create new touch point
                        TouchPoint tp{};
                        tp.id = ti.dwID;
                        tp.x = point.x;
                        tp.y = point.y;
                        TOUCH_POINTS.push_back(tp);

                        // add touch down event
                        TouchEvent te{};
                        te.id = tp.id;
                        te.x = tp.x;
                        te.y = tp.y;
                        te.type = TOUCH_DOWN;
                        add_touch_event(&te);

                        // set prev coordinates
                        prev_x = point.x;
                        prev_y = point.y;

                        // card button
                        update_card_button();
                    }

                    // touch move
                    if ((ti.dwFlags & TOUCHEVENTF_MOVE) != 0u) {

                        // convert to window position
                        POINT point{};
                        point.x = ti.x / 100;
                        point.y = ti.y / 100;
                        ScreenToClient(hWnd, &point);

                        // check prev coordinates
                        if (point.x != prev_x || point.y != prev_y) {

                            // update point
                            for (auto &x : TOUCH_POINTS) {
                                TouchPoint *tp = &x;
                                if (tp->id == ti.dwID) {

                                    // update values
                                    tp->x = point.x;
                                    tp->y = point.y;

                                    // add touch move event
                                    TouchEvent te{};
                                    te.id = tp->id;
                                    te.x = tp->x;
                                    te.y = tp->y;
                                    te.type = TOUCH_MOVE;
                                    add_touch_event(&te);

                                    break;
                                }
                            }
                        }

                        // set prev coordinates
                        prev_x = point.x;
                        prev_y = point.y;
                    }

                    // touch up
                    if ((ti.dwFlags & TOUCHEVENTF_UP) != 0u) {

                        // remove point
                        for (size_t x = 0; x < TOUCH_POINTS.size(); x++) {
                            TouchPoint *tp = &TOUCH_POINTS[x];
                            if (tp->id == ti.dwID) {

                                // add touch up event
                                TouchEvent te{};
                                te.id = tp->id;
                                te.x = tp->x;
                                te.y = tp->y;
                                te.type = TOUCH_UP;
                                add_touch_event(&te);

                                // remove from active touch points
                                TOUCH_POINTS.erase(TOUCH_POINTS.begin() + x);

                                break;
                            }
                        }
                    }
                }
            }

            // clean up
            delete[] pInputs;
            if (pCloseTouchInputHandle != nullptr)
                pCloseTouchInputHandle((HANDLE) lParam);

            break;
        }
        case WM_LBUTTONDOWN: {

            // lock touch points
            std::lock_guard<std::mutex> lock_points(TOUCH_POINTS_M);
            std::lock_guard<std::mutex> lock_events(TOUCH_EVENTS_M);

            // remove all points with ID 0
            for (size_t x = 0; x < TOUCH_POINTS.size(); x++) {
                TouchPoint *tp = &TOUCH_POINTS[x];
                if (tp->id == 0u) {

                    // generate touch up event
                    TouchEvent te{};
                    te.id = tp->id;
                    te.x = tp->x;
                    te.y = tp->y;
                    te.type = TOUCH_UP;
                    add_touch_event(&te);

                    // erase touch point
                    TOUCH_POINTS.erase(TOUCH_POINTS.begin() + x);
                }
            }

            // check if mouse is enabled
            if (SPICETOUCH_ENABLE_MOUSE) {

                // create touch point
                TouchPoint tp{};
                tp.id = 0;
                tp.x = GET_X_LPARAM(lParam);
                tp.y = GET_Y_LPARAM(lParam);
                TOUCH_POINTS.push_back(tp);

                // add touch down event
                TouchEvent te{};
                te.id = tp.id;
                te.x = tp.x;
                te.y = tp.y;
                te.type = TOUCH_DOWN;
                add_touch_event(&te);
            }

            // card button
            update_card_button();

            break;
        }
        case WM_MOUSEMOVE: {

            // check if mouse is enabled
            if (SPICETOUCH_ENABLE_MOUSE) {

                // lock touch points
                std::lock_guard<std::mutex> lock_points(TOUCH_POINTS_M);
                std::lock_guard<std::mutex> lock_events(TOUCH_EVENTS_M);

                // update point
                for (auto &x : TOUCH_POINTS) {
                    TouchPoint *tp = &x;

                    // find ID 0
                    if (tp->id == 0u) {

                        // update touch point position
                        tp->x = GET_X_LPARAM(lParam);
                        tp->y = GET_Y_LPARAM(lParam);

                        // add touch move event
                        TouchEvent te{};
                        te.id = tp->id;
                        te.x = tp->x;
                        te.y = tp->y;
                        te.type = TOUCH_MOVE;
                        add_touch_event(&te);

                        break;
                    }
                }
            }

            break;
        }
        case WM_LBUTTONUP: {

            // lock touch points
            std::lock_guard<std::mutex> lock_points(TOUCH_POINTS_M);
            std::lock_guard<std::mutex> lock_events(TOUCH_EVENTS_M);

            // remove all points with ID 0
            for (size_t x = 0; x < TOUCH_POINTS.size(); x++) {
                TouchPoint *tp = &TOUCH_POINTS[x];
                if (tp->id == 0u) {

                    // generate touch up event
                    TouchEvent te{};
                    te.id = tp->id;
                    te.x = tp->x;
                    te.y = tp->y;
                    te.type = TOUCH_UP;
                    add_touch_event(&te);

                    // remove touch point
                    TOUCH_POINTS.erase(TOUCH_POINTS.begin() + x);
                }
            }

            break;
        }
        case WM_TABLET_QUERYSYSTEMGESTURESTATUS:
            return TABLET_DISABLE_PRESSANDHOLD
                   | TABLET_DISABLE_PENTAPFEEDBACK
                   | TABLET_DISABLE_PENBARRELFEEDBACK
                   | TABLET_DISABLE_TOUCHUIFORCEON
                   | TABLET_DISABLE_TOUCHUIFORCEOFF
                   | TABLET_DISABLE_TOUCHSWITCH
                   | TABLET_DISABLE_FLICKS
                   | TABLET_DISABLE_SMOOTHSCROLLING
                   | TABLET_DISABLE_FLICKFALLBACKKEYS
                   | TABLET_ENABLE_MULTITOUCHDATA;
        default:

            // call original function
            if (SPICETOUCH_CALL_OLD_PROC && (SPICETOUCH_OLD_PROC != nullptr))
                return SPICETOUCH_OLD_PROC(hWnd, msg, wParam, lParam);

            break;
    }

    // clean up
    return DefWindowProc(hWnd, msg, wParam, lParam);
}

void touch_attach_wnd(HWND hWnd) {

    // check if already attached
    if (SPICETOUCH_ATTACHED)
        return;
    SPICETOUCH_ATTACHED = true;

    // load touch functions
    load_touch_functions();

    // hook window process
    SPICETOUCH_HWND = hWnd;
    SPICETOUCH_OLD_PROC = (WNDPROC) SetWindowLongPtr(hWnd, GWLP_WNDPROC, (LONG_PTR) &SpiceTouchWndProc);
}

void touch_attach_dx_hook() {

    // check if already attached
    if (SPICETOUCH_ATTACHED)
        return;
    SPICETOUCH_ATTACHED = true;

    // load touch functions
    load_touch_functions();

    // add dx hook
    dxhook_add_wnd_proc(SpiceTouchWndProc);
}

void touch_create_wnd(HWND hWnd) {

    // check if already attached
    if (SPICETOUCH_ATTACHED)
        return;
    SPICETOUCH_ATTACHED = true;

    // load touch functions
    load_touch_functions();

    // create thread
    SPICETOUCH_TOUCH_THREAD = new std::thread([hWnd]() {

        // create class
        WNDCLASSEX wndClass {};
        wndClass.cbSize = sizeof(WNDCLASSEX);
        wndClass.style = 3;
        wndClass.lpfnWndProc = &SpiceTouchWndProc;
        wndClass.cbClsExtra = 0;
        wndClass.cbWndExtra = 0;
        wndClass.hInstance = GetModuleHandle(nullptr);
        wndClass.hIcon = nullptr;
        wndClass.hCursor = LoadCursor(nullptr, IDC_ARROW);;
        wndClass.hbrBackground = CreateSolidBrush(RGB(255, 192, 203));
        wndClass.lpszMenuName = nullptr;
        wndClass.lpszClassName = SPICETOUCH_CLASS_NAME.c_str();
        wndClass.hIconSm = nullptr;

        // register class
        if (!RegisterClassEx(&wndClass)) {
            return;
        }

        // get window rect
        RECT windowRect{};
        GetWindowRect(hWnd, &windowRect);

        // create window
        SPICETOUCH_TOUCH_HWND = CreateWindowEx(
                0,
                SPICETOUCH_CLASS_NAME.c_str(),
                "",
                (DWORD) CW_USEDEFAULT,
                windowRect.left,
                windowRect.top,
                windowRect.right - windowRect.left,
                windowRect.bottom - windowRect.top,
                hWnd,
                nullptr,
                GetModuleHandle(nullptr),
                nullptr
        );

        // check window
        if (SPICETOUCH_TOUCH_HWND == nullptr) {
            return;
        }

        // window settings
        ShowWindow(SPICETOUCH_TOUCH_HWND, SW_SHOWNOACTIVATE);
        UpdateWindow(SPICETOUCH_TOUCH_HWND);
        if (pRegisterTouchWindow != nullptr)
            pRegisterTouchWindow(SPICETOUCH_TOUCH_HWND, TWF_WANTPALM);

        // window loop
        MSG msg{};
        while (GetMessage(&msg, nullptr, 0, 0) && SPICETOUCH_TOUCH_THREAD != nullptr) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }

        // dispose window
        if (pUnregisterTouchWindow != nullptr)
            pUnregisterTouchWindow(hWnd);
    });
}

void touch_detach() {

    // remove window process hook
    if (SPICETOUCH_HWND != nullptr) {
        SetWindowLongPtr(SPICETOUCH_HWND, GWLP_WNDPROC, (LONG_PTR) SPICETOUCH_OLD_PROC);
        SPICETOUCH_HWND = nullptr;
        SPICETOUCH_OLD_PROC = nullptr;
    }

    // remove dx hook
    dxhook_remove_wnd_proc(SpiceTouchWndProc);
    SPICETOUCH_TOUCH_THREAD = nullptr;
    SPICETOUCH_ATTACHED = false;
}

void touch_write_points(std::vector<TouchPoint> *touch_points) {

    // lock
    std::lock_guard<std::mutex> points(TOUCH_POINTS_M);
    std::lock_guard<std::mutex> events(TOUCH_EVENTS_M);

    // iterate through all the provided touch points
    for (auto &tp : *touch_points) {

        // find touch point to update
        bool found = false;
        for (auto &arr_tp : TOUCH_POINTS) {
            if (arr_tp.id == tp.id) {

                // mark as found
                found = true;

                // update position
                arr_tp.x = tp.x;
                arr_tp.y = tp.y;

                // add touch move event
                TouchEvent te{};
                te.id = tp.id;
                te.x = tp.x;
                te.y = tp.y;
                te.type = TOUCH_MOVE;
                add_touch_event(&te);
            }
        }

        // create new touch point when not found
        if (!found) {

            // add touch point
            TOUCH_POINTS.push_back(tp);

            // add touch down event
            TouchEvent te{};
            te.id = tp.id;
            te.x = tp.x;
            te.y = tp.y;
            te.type = TOUCH_DOWN;
            add_touch_event(&te);
        }
    }
}

void touch_remove_points(std::vector<DWORD> *touch_point_ids) {

    // lock
    std::lock_guard<std::mutex> points(TOUCH_POINTS_M);
    std::lock_guard<std::mutex> events(TOUCH_EVENTS_M);

    // find the touch points to remove
    for (auto id : *touch_point_ids) {
        for (size_t x = 0; x < TOUCH_POINTS.size(); x++) {

            // check if the IDs match
            TouchPoint *tp = &TOUCH_POINTS[x];
            if (tp->id == id) {

                // add touch up event
                TouchEvent te{};
                te.id = id;
                te.x = tp->x;
                te.y = tp->y;
                te.type = TOUCH_UP;
                add_touch_event(&te);

                // delete touch point
                TOUCH_POINTS.erase(TOUCH_POINTS.begin() + x);
                break;
            }
        }
    }
}

void touch_get_points(std::vector<TouchPoint> *touch_points) {
    std::lock_guard<std::mutex> lock(TOUCH_POINTS_M);
    for (TouchPoint &tp : TOUCH_POINTS)
        touch_points->push_back(tp);
}

void touch_get_events(std::vector<TouchEvent> *touch_events) {
    std::lock_guard<std::mutex> lock(TOUCH_EVENTS_M);
    while (!TOUCH_EVENTS.empty())
        touch_events->push_back(TOUCH_EVENTS.get());
}
