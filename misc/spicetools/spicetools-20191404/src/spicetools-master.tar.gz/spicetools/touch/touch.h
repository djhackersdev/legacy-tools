#ifndef SPICETOOLS_TOUCH_H
#define SPICETOOLS_TOUCH_H

#include <vector>
#include <windows.h>

struct TouchPoint {
    DWORD id;
    LONG x, y;
};
enum TouchEventType {
    TOUCH_DOWN,
    TOUCH_MOVE,
    TOUCH_UP
};
struct TouchEvent {
    DWORD id;
    LONG x, y;
    TouchEventType type;
};

bool is_win_touch_available();

void touch_attach_wnd(HWND hWnd);

void touch_attach_dx_hook();

void touch_create_wnd(HWND hWnd);

void touch_detach();

void touch_write_points(std::vector<TouchPoint> *touch_points);
void touch_remove_points(std::vector<DWORD> *touch_point_ids);

void touch_get_points(std::vector<TouchPoint> *touch_points);

void touch_get_events(std::vector<TouchEvent> *touch_events);

#endif // SPICETOOLS_TOUCH_H
