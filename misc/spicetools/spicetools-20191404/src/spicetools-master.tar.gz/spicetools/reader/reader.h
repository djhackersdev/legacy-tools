#ifndef SPICETOOLS_READER_H
#define SPICETOOLS_READER_H

#include <windows.h>
#include <string>
#include "message.h"
#include "crypt.h"

#define READER_CMD_SET_ID 0x01
#define READER_CMD_VERSION 0x02
#define READER_CMD_INIT2 0x03
#define READER_CMD_REINITIALIZE 0x30
#define READER_CMD_READ_CARD_UID 0x31
#define READER_CMD_SET_ACTION 0x35
#define READER_CMD_GET_STATUS 0x34
#define READER_CMD_SLEEP_MODE 0x3A
#define READER_CMD_KEY_EXCHANGE 0x60
#define READER_CMD_RFID_READ_UID 0x61
#define READER_CMD_GET_STATUS_ENC 0x64
#define REDAER_ACTION_BLOCK 0x00
#define READER_ACTION_ACCEPT_CARD 0x11
#define READER_ACTION_EJECT_CARD 0x12

class Reader {

public:
    explicit Reader(std::string serial_port);

    ~Reader();

    bool is_valid();

    bool initialize();

    bool init_crypt();

    char *read_card();

private:
    std::string serial_str;
    HANDLE serial_handle;
    bool valid;
    char card_uid[8];
    uint8_t reinitialized = 0, node = 1;
    uint8_t cur_msg_id = 0;
    Crypt crypt;

    inline uint8_t gen_msg_id() { return ++cur_msg_id; }

    void set_comm_state();

    bool wait_for_handshake();

    bool msg_write(Message msg);

    std::vector<Message> msg_write_read(Message msg);

    std::vector<Message> msg_write_cmd_read(uint8_t cmd);

    std::vector<Message> msg_write_cmd_read(uint8_t cmd, std::vector<uint8_t> data);

    std::vector<Message> msg_read();
};

void start_reader_thread(const std::string &serial_str, int id);
void stop_reader_thread();


#endif //SPICETOOLS_READER_H
