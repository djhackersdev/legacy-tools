#ifndef SPICETOOLS_READER_STRUCTUREDMESSAGE_H
#define SPICETOOLS_READER_STRUCTUREDMESSAGE_H

#include "message.h"

class StructuredMessage : public Message {
public:
    StructuredMessage(uint8_t node, uint8_t param, uint8_t cmd,
                      uint8_t packet_id, std::vector<uint8_t> request_data);
};

#endif //SPICETOOLS_READER_STRUCTUREDMESSAGE_H
