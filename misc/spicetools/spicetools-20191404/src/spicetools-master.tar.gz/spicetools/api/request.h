#ifndef SPICETOOLS_API_REQUEST_H
#define SPICETOOLS_API_REQUEST_H

#include <stdint-gcc.h>
#include "external/rapidjson/document.h"

namespace api {

    class Request {
    public:
        uint64_t id;
        std::string module;
        std::string function;
        rapidjson::Value params;

        Request(rapidjson::Document &document);
    };
}

#endif //SPICETOOLS_API_REQUEST_H
