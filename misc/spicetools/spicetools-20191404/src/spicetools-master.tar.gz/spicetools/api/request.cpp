#include "request.h"
#include "../util/logging.h"
#include "module.h"

using namespace rapidjson;

namespace api {

    Request::Request(rapidjson::Document &document) {
        Value::MemberIterator it;

        // get ID
        it = document.FindMember("id");
        if (it == document.MemberEnd() || !(*it).value.IsUint64()) {
            log_warning("api", "Request ID is invalid");
            return;
        }
        this->id = (*it).value.GetUint64();

        // get module
        it = document.FindMember("module");
        if (it == document.MemberEnd() || !(*it).value.IsString()) {
            log_warning("api", "Request module is invalid");
            return;
        }
        this->module = (*it).value.GetString();

        // get function
        it = document.FindMember("function");
        if (it == document.MemberEnd() || !(*it).value.IsString()) {
            log_warning("api", "Request function is invalid");
            return;
        }
        this->function = (*it).value.GetString();

        // get params
        it = document.FindMember("params");
        if (it == document.MemberEnd() || !(*it).value.IsArray()) {
            log_warning("api", "Request params is invalid");
            return;
        }
        this->params = document["params"];

        // log request
        if (LOGGING) {
            log_info("api", "new request > id: " + to_string(this->id) +
                            ", module: " + to_string(this->module) +
                            ", function: " + to_string(this->function));
        }
    }
}
