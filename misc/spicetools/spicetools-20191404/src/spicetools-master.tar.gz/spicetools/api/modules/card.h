#ifndef SPICETOOLS_API_MODULES_CARD_H
#define SPICETOOLS_API_MODULES_CARD_H

#include "api/module.h"
#include "api/request.h"

namespace api::modules {

    class Card : public Module {
    public:
        Card();

    private:

        // function definitions
        void insert(Request &req, Response &res);
    };
}

#endif // SPICETOOLS_API_MODULES_CARD_H
