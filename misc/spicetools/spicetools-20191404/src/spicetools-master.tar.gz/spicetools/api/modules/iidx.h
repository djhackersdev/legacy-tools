#ifndef SPICETOOLS_API_MODULES_IIDX_H
#define SPICETOOLS_API_MODULES_IIDX_H

#include <vector>
#include "api/module.h"
#include "api/request.h"
#include "games/iidx/iidx.h"

namespace api::modules {

    class IIDX : public Module {
    public:
        IIDX();

    private:

        // function definitions
        void ticker_get(Request &req, Response &res);
        void ticker_set(Request &req, Response &res);
        void ticker_reset(Request &req, Response &res);
    };
}

#endif // SPICETOOLS_API_MODULES_IIDX_H
