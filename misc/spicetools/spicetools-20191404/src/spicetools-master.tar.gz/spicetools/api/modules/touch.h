#ifndef SPICETOOLS_API_MODULES_TOUCH_H
#define SPICETOOLS_API_MODULES_TOUCH_H

#include <vector>
#include "api/module.h"
#include "api/request.h"
#include "touch/touch.h"

namespace api::modules {

    class Touch : public Module {
    public:
        Touch();

    private:

        // function definitions
        void read(Request &req, Response &res);
        void write(Request &req, Response &res);
        void write_reset(Request &req, Response &res);
    };
}

#endif // SPICETOOLS_API_MODULES_TOUCH_H
