#include "control.h"
#include <functional>
#include "external/rapidjson/document.h"
#include "util/logging.h"
#include "util/crypt.h"
#include "util/utils.h"

using namespace std::placeholders;
using namespace rapidjson;


namespace api::modules {

    struct SignalMapping {
        int signum;
        const char* name;
    };
    static SignalMapping SIGNAL_MAPPINGS[] = {
            {SIGABRT, "SIGABRT"},
            {SIGFPE, "SIGFPE"},
            {SIGILL, "SIGILL"},
            {SIGINT, "SIGINT"},
            {SIGSEGV, "SIGSEGV"},
            {SIGTERM, "SIGTERM"},
    };

    Control::Control() : Module("control") {
        functions["raise"] = std::bind(&Control::raise, this, _1, _2);
        functions["exit"] = std::bind(&Control::exit, this, _1, _2);
        functions["session_refresh"] = std::bind(&Control::session_refresh, this, _1, _2);
    }

    /**
     * raise(signal: str)
     */
    void Control::raise(Request &req, Response &res) {

        // check args
        if (req.params.Size() < 1)
            return error_params_insufficient(res);
        if (!req.params[0].IsString())
            return error_type(res, "signal", "string");

        // get signal
        auto signal_str = req.params[0].GetString();
        int signal_val = -1;
        for (auto mapping : SIGNAL_MAPPINGS) {
            if (stricmp(mapping.name, signal_str) == 0)
                signal_val = mapping.signum;
        }

        // check if not found
        if (signal_val < 0)
            return error_unknown(res, "signal", signal_str);

        // raise signal
        if (::raise(signal_val))
            return error(res, "Failed to raise signo " + to_string(signal_val));
    }

    /**
     * exit()
     * exit(code: int)
     */
    void Control::exit(Request &req, Response &res) {

        // exit()
        if (req.params.Size() == 0) {
            ::exit(0);
        }

        // check code
        if (!req.params[0].IsInt())
            return error_type(res, "code", "int");

        // exit
        ::exit(req.params[0].GetInt());
    }

    /**
     * session_refresh()
     */
    void Control::session_refresh(Request &req, Response &res) {

        // generate new password
        uint8_t password_bin[128];
        crypt::random_bytes(password_bin, std::size(password_bin));
        std::string password = bin2hex(&password_bin[0], std::size(password_bin));

        // add to response
        Value password_val(password.c_str(), res.doc()->GetAllocator());
        res.add_data(password_val);

        // change password
        res.password_change(password);
    }
}
