#include <utility>

#include "controller.h"

#include <winsock2.h>
#include <ws2tcpip.h>
#include "external/rapidjson/document.h"
#include "util/logging.h"
#include "util/rc4.h"
#include "util/utils.h"
#include "response.h"
#include "request.h"
#include "module.h"
#include "modules/analogs.h"
#include "modules/buttons.h"
#include "modules/card.h"
#include "modules/coin.h"
#include "modules/control.h"
#include "modules/info.h"
#include "modules/keypads.h"
#include "modules/lights.h"
#include "modules/memory.h"
#include "modules/touch.h"
#include "modules/iidx.h"

using namespace rapidjson;
using namespace api;


Controller::Controller(unsigned short port, std::string password, bool pretty) {
    this->port = port;
    this->password = std::move(password);
    this->pretty = pretty;

    // WSA startup
    WSADATA wsa_data;
    int error;
    if ((error = WSAStartup(MAKEWORD(2, 2), &wsa_data)) != 0)
        log_fatal("api", "WSAStartup() returned " + to_string(error));

    // create socket
    this->server = socket(AF_INET, SOCK_STREAM, 0);
    if (this->server == INVALID_SOCKET)
        log_fatal("api", "Couldn't create socket.");

    // configure socket
    int opt_enable = 1;
    if (setsockopt(this->server, SOL_SOCKET, SO_REUSEADDR, (const char*) &opt_enable, sizeof(int)) == -1)
        log_fatal("api", "Couldn't set socket option SO_REUSEADDR.");
    if (setsockopt(this->server, IPPROTO_TCP, TCP_NODELAY, (const char*) &opt_enable, sizeof(int)) == -1)
        log_fatal("api", "Couldn't set socket option TCP_NODELAY.");

    // create address
    sockaddr_in server_address{};
    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(this->port);
    server_address.sin_addr.s_addr = INADDR_ANY;
    memset(&server_address.sin_zero, 0, sizeof(server_address.sin_zero));

    // bind socket to address
    if (bind(this->server, (sockaddr *) &server_address, sizeof(sockaddr)) == -1)
        log_fatal("api", "Couldn't bind socket.");

    // set socket to listen
    if (listen(this->server, server_backlog) == -1)
        log_fatal("api", "Couldn't listen to socket.");

    // start workers
    this->server_running = true;
    for (int i = 0; i < server_worker_count; i++) {
        this->server_workers.emplace_back(std::thread([this] {
            this->server_worker();
        }));
    }

    // log success
    log_info("api", "API server is listening on port: " + to_string(this->port));
    log_info("api", "Using password: " + std::string(this->password.empty() ? "no" : "yes"));
}

Controller::~Controller() {

    // mark server stop
    this->server_running = false;

    // close socket
    if (this->server != INVALID_SOCKET)
        closesocket(this->server);

    // lock handlers
    std::lock_guard<std::mutex> handlers_guard(this->server_handlers_m);

    // join threads
    for (auto &worker : this->server_workers) {
        worker.join();
    }
    for (auto &handler : this->server_handlers) {
        handler.join();
    }

    // cleanup WSA
    WSACleanup();
}

void Controller::server_worker() {

    // state
    sockaddr_in client_address{};

    // connection loop
    while (this->server_running) {

        // create client state
        ClientState client_state{};
        client_state.password = this->password;

        // accept connection
        int socket_in_size = sizeof(sockaddr_in);
        client_state.socket = accept(this->server, (sockaddr *) &client_address, &socket_in_size);
        if (client_state.socket == INVALID_SOCKET)
            continue;

        // lock handlers
        std::lock_guard<std::mutex> handlers_guard(this->server_handlers_m);

        // check connection limit
        if (this->server_handlers.size() >= server_connection_limit) {
            log_warning("api", "connection limit hit.");
            closesocket(client_state.socket);
            continue;
        }

        // handle connection
        this->server_handlers.emplace_back(std::thread([this, client_state] {
            this->connection_handler(client_state);
        }));
    }
}

void Controller::connection_handler(api::Controller::ClientState client_state) {

    // get address string
    char client_address_str_data[INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &client_state.address.sin_addr, client_address_str_data, INET_ADDRSTRLEN);
    std::string client_address_str(client_address_str_data);

    // log connection
    log_info("api", "client connected: " + client_address_str);

    // cipher
    util::RC4 *cipher = nullptr;
    if (!client_state.password.empty())
        cipher = new util::RC4((uint8_t *) client_state.password.c_str(), client_state.password.size());

    // create module instances
    client_state.modules.push_back(new modules::Analogs());
    client_state.modules.push_back(new modules::Buttons());
    client_state.modules.push_back(new modules::Control());
    client_state.modules.push_back(new modules::Coin());
    client_state.modules.push_back(new modules::Card());
    client_state.modules.push_back(new modules::IIDX());
    client_state.modules.push_back(new modules::Info());
    client_state.modules.push_back(new modules::Keypads());
    client_state.modules.push_back(new modules::Lights());
    client_state.modules.push_back(new modules::Memory());
    client_state.modules.push_back(new modules::Touch());

    // listen loop
    std::vector<char> message_buffer;
    char receive_buffer[server_receive_buffer_size];
    while (this->server_running && !client_state.close) {

        // receive data
        ssize_t received_length = recv(client_state.socket, receive_buffer, server_receive_buffer_size, 0);
        if (received_length < 0) {

            // if the received length is < 0, we've got an error
            log_warning("api", "receive error: " + to_string(WSAGetLastError()));
            break;

        } else if (received_length == 0) {

            // if the received length is 0, the connection is closed
            break;
        }

        // cipher
        if (cipher != nullptr) {
            cipher->crypt(
                    (uint8_t *) receive_buffer,
                    (size_t) received_length
            );
        }

        // put into buffer
        for (int i = 0; i < received_length; i++) {

            // check for escape byte
            if (receive_buffer[i] == 0) {

                // get response
                std::vector<char> send_buffer;
                this->process_request(&client_state, &message_buffer, &send_buffer);

                // clear message buffer
                message_buffer.clear();

                // check send buffer for content
                if (!send_buffer.empty()) {

                    // cipher
                    if (cipher != nullptr) {
                        cipher->crypt(
                                (uint8_t *) send_buffer.data(),
                                (size_t) send_buffer.size()
                        );
                    }

                    // send data
                    send(client_state.socket, send_buffer.data(), (int) send_buffer.size(), 0);

                    // check for password change
                    if (client_state.password_change) {
                        client_state.password_change = false;
                        if (client_state.password.empty()) {
                            delete cipher;
                            cipher = nullptr;
                        } else {
                            delete cipher;
                            cipher = new util::RC4(
                                    (uint8_t *) client_state.password.c_str(),
                                    client_state.password.size());
                        }
                    }
                }

            } else {

                // append to message
                message_buffer.push_back(receive_buffer[i]);

                // check buffer size
                if (message_buffer.size() > server_message_buffer_max_size) {
                    message_buffer.clear();
                    client_state.close = true;
                    break;
                }
            }
        }
    }

    // log disconnect
    delete cipher;
    log_info("api", "client disconnected: " + client_address_str);

    // close connection
    closesocket(client_state.socket);

    // free modules
    for (auto module : client_state.modules)
        delete module;
}

void Controller::process_request(ClientState *state, std::vector<char> *in, std::vector<char> *out) {

    // parse document
    Document document;
    document.Parse(&(*in)[0], in->size());

    // check for parse error
    if (document.HasParseError()) {

        // return empty response and close connection
        out->push_back(0);
        state->close = true;
        return;
    }

    // build request and response
    Request request(document);
    Response response(request.id);

    // find module
    bool module_found = false;
    for (auto module : state->modules) {
        if (module->name == request.module) {
            module_found = true;

            // check password force
            if (module->password_force && this->password.empty()) {
                Value err("Module requires the password to be set.");
                response.add_error(err);
                break;
            }

            // handle request
            module->handle(request, response);
            break;
        }
    }

    // check if module wasn't found
    if (!module_found) {
        Value module_error("Unknown module.");
        response.add_error(module_error);
    }

    // check for password change
    if (response.password_changed) {
        state->password = response.password;
        state->password_change = true;
    }

    // write response
    auto response_out = response.get_string(this->pretty);
    out->insert(out->end(), response_out.begin(), response_out.end());
    out->push_back(0);
}
