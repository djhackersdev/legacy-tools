#ifndef SPICETOOLS_API_CONTROLLER_H
#define SPICETOOLS_API_CONTROLLER_H

#include <string>
#include <vector>
#include <thread>
#include <mutex>
#include <winsock2.h>
#include "module.h"


namespace api {

    class Controller {
    private:

        struct ClientState {
            sockaddr_in address;
            SOCKET socket;
            bool close = false;
            std::vector<Module*> modules;
            std::string password;
            bool password_change = false;
        };

        // configuration
        const static int server_backlog = 16;
        const static int server_receive_buffer_size = 64 * 1024;
        const static int server_message_buffer_max_size = 64 * 1024;
        const static int server_worker_count = 2;
        const static int server_connection_limit = 4096;

        // settings
        unsigned short port;
        std::string password;
        bool pretty;

        // server
        std::vector<std::thread> server_workers;
        std::vector<std::thread> server_handlers;
        std::mutex server_handlers_m;
        SOCKET server;
        void server_worker();
        void connection_handler(ClientState client_state);
        void process_request(ClientState *state, std::vector<char> *in, std::vector<char> *out);

    public:

        // state
        bool server_running;

        // constructor / destructor
        Controller(unsigned short port, std::string password, bool pretty);
        ~Controller();

    };

}

#endif //SPICETOOLS_API_CONTROLLER_H
