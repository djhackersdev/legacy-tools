#include "fileutils.h"
#include <sys/stat.h>
#include <direct.h>

bool fileutils::file_exists(LPCTSTR szPath) {
    DWORD dwAttrib = GetFileAttributes(szPath);
    return (dwAttrib != INVALID_FILE_ATTRIBUTES &&
            !(dwAttrib & FILE_ATTRIBUTE_DIRECTORY));
}

bool fileutils::file_exists(std::string file_name) {
    return file_exists(file_name.c_str());
}

bool fileutils::verify_header_pe(std::string file_name) {
    FILE *f = fopen(file_name.c_str(), "rb");
    char header[2];
    if (!f)
        return false;
    if (!fread(&header, 2, 1, f)) {
        fclose(f);
        return false;
    }
    return header[0] == 'M' && header[1] == 'Z';
}

bool fileutils::version_pe(std::string filename, char *ver) {
    DWORD dwHandle, sz = GetFileVersionInfoSizeA(filename.c_str(), &dwHandle);
    if (!sz)
        return false;
    char *buf = new char[sz];
    if (!GetFileVersionInfoA(filename.c_str(), dwHandle, sz, &buf[0])) {
        delete[] buf;
        return false;
    }
    VS_FIXEDFILEINFO *pvi;
    sz = sizeof(VS_FIXEDFILEINFO);
    if (!VerQueryValueA(&buf[0], "\\", (LPVOID *) &pvi, (unsigned int *) &sz)) {
        delete[] buf;
        return false;
    }
    sprintf(ver, "%d.%d.%d.%d",
            (int) (pvi->dwProductVersionMS >> 16),
            (int) (pvi->dwFileVersionMS & 0xFFFF),
            (int) (pvi->dwFileVersionLS >> 16),
            (int) (pvi->dwFileVersionLS & 0xFFFF));
    delete[] buf;
    return true;
}

bool fileutils::dir_exists(const std::string &path) {
    struct _stat info;
    if (_stat(path.c_str(), &info) != 0)
        return false;
    return (info.st_mode & _S_IFDIR) != 0;
}

bool fileutils::dir_create_recursive(const std::string &path) {

    // single directory
    int ret = _mkdir(path.c_str());
    if (ret == 0)
        return true;

    // check error
    switch (errno) {
        case ENOENT: {

            // recursive creation
            auto pos = path.find_last_of('/');
            if (pos == std::string::npos)
                pos = path.find_last_of('\\');
            if (pos == std::string::npos)
                return false;
            if (!dir_create_recursive(path.substr(0, pos)))
                return false;

            // try creating the directory again
            return _mkdir(path.c_str()) == 0;
        }
        case EEXIST:
            return dir_exists(path);

        default:
            return false;
    }
}
