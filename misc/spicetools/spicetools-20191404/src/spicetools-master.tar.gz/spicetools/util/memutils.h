#ifndef SPICETOOLS_UTIL_MEMUTILS_H
#define SPICETOOLS_UTIL_MEMUTILS_H

#include <windows.h>

namespace memutils {

    DWORDLONG mem_total();
    DWORDLONG mem_total_used();
    DWORDLONG mem_used();

    DWORDLONG vmem_total();
    DWORDLONG vmem_total_used();
    DWORDLONG vmem_used();
}

#endif //SPICETOOLS_UTIL_MEMUTILS_H
