#ifndef SPICETOOLS_UTIL_PEB_H
#define SPICETOOLS_UTIL_PEB_H

#include <windows.h>
#include <winternl.h>
#include <string>

namespace peb {

    const LDR_DATA_TABLE_ENTRY* entry_first();
    const LDR_DATA_TABLE_ENTRY* entry_next(const LDR_DATA_TABLE_ENTRY* entry);
    std::string entry_name(const LDR_DATA_TABLE_ENTRY* entry);
    const PEB* peb_get();
    void peb_print();
}

#endif //SPICETOOLS_UTIL_PEB_H
