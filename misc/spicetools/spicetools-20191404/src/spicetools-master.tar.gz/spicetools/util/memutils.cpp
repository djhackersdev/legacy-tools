#include "memutils.h"
#include <psapi.h>


namespace memutils {

    inline static MEMORYSTATUSEX get_mem_status() {
        MEMORYSTATUSEX mem_status{};
        mem_status.dwLength = sizeof(MEMORYSTATUSEX);
        GlobalMemoryStatusEx(&mem_status);
        return mem_status;
    }

    inline static PROCESS_MEMORY_COUNTERS_EX get_mem_counters() {
        PROCESS_MEMORY_COUNTERS_EX pmc{};
        GetProcessMemoryInfo(GetCurrentProcess(), (PPROCESS_MEMORY_COUNTERS) &pmc, sizeof(pmc));
        return pmc;
    }

    DWORDLONG mem_total() {
        return get_mem_status().ullTotalPhys;
    }

    DWORDLONG mem_total_used() {
        auto status = get_mem_status();
        return status.ullTotalPhys - status.ullAvailPhys;
    }

    DWORDLONG mem_used() {
        return get_mem_counters().WorkingSetSize;
    }

    DWORDLONG vmem_total() {
        return get_mem_status().ullTotalPageFile;
    }

    DWORDLONG vmem_total_used() {
        auto status = get_mem_status();
        return status.ullTotalPageFile - status.ullAvailPageFile;
    }

    DWORDLONG vmem_used() {
        return get_mem_counters().PrivateUsage;
    }
}
