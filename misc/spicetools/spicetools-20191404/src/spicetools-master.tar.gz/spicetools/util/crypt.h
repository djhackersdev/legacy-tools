#ifndef SPICETOOLS_UTIL_CRYPT_H
#define SPICETOOLS_UTIL_CRYPT_H

#include <cstddef>

namespace crypt {

    void init();
    void dispose();
    void random_bytes(void* data, size_t length);

}

#endif //SPICETOOLS_UTIL_CRYPT_H
