#include "crypt.h"
#include <windows.h>
#include <wincrypt.h>
#include "util/logging.h"

namespace crypt {

    static HCRYPTPROV PROVIDER = 0;
    static const char* PROVIDER_XP = "Microsoft Enhanced RSA and AES Cryptographic Provider (Prototype)";
    static const char* PROVIDER_DEFAULT = "Microsoft Enhanced RSA and AES Cryptographic Provider";

    void init() {

        // get version
        OSVERSIONINFOEX version{};
        version.dwOSVersionInfoSize = sizeof(version);
        if (!GetVersionEx((LPOSVERSIONINFOA) &version))
            log_fatal("crypt", "couldn't get version: " + to_string(GetLastError()));

        // determine provider name
        const char* provider;
        if (version.dwMajorVersion < 6)
            provider = PROVIDER_XP;
        else
            provider = PROVIDER_DEFAULT;

        // aquire context
        if (!CryptAcquireContext(&PROVIDER, NULL, provider, PROV_RSA_AES, CRYPT_VERIFYCONTEXT | CRYPT_SILENT))
            log_fatal("crypt", "couldn't aquire context: " + to_string(GetLastError()));
    }

    void dispose() {

        // release context
        if (!CryptReleaseContext(PROVIDER, 0))
            log_warning("crypt", "couldn't release context");
    }

    void random_bytes(void *data, size_t length) {
        CryptGenRandom(PROVIDER, (DWORD) length, (BYTE*) data);
    }

}
