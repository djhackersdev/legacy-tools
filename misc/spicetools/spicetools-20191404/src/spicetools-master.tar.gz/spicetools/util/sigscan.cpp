#include "sigscan.h"
#include <vector>
#include <sstream>
#include "util/utils.h"


intptr_t find_pattern(std::vector<unsigned char> data, intptr_t base, const unsigned char* pattern,
                      const char* mask, intptr_t offset, intptr_t usage) {

    // build pattern
    std::vector<std::pair<unsigned char, bool>> pattern_vector;
    size_t mask_size = strlen(mask);
    for (size_t i = 0; i < mask_size; i++)
        pattern_vector.emplace_back(pattern[i], mask[i] == 'X');

    // the scan loop
    auto data_begin = data.begin();
    auto cur_usage = 0;
    while (true) {

        // search for the pattern
        auto search_result = std::search(data_begin, data.end(), pattern_vector.begin(), pattern_vector.end(),
                               [&](unsigned char c, std::pair<unsigned char, bool> pat) {
                                   return (!pat.second) || c == pat.first;
                               });

        // check for a match
        if (search_result != data.end()) {

            // return the result if we hit the usage count
            if (cur_usage == usage)
                return (std::distance(data.begin(), search_result) + base) + offset;

            // increment the found count
            ++cur_usage;
            data_begin = ++search_result;
        }
        else
            break;
    }

    return 0;
}

intptr_t find_pattern(HMODULE module, const unsigned char* pattern, const char* mask, intptr_t offset,
                      intptr_t resultUsage) {

    // get module information
    MODULEINFO module_info{};
    if (!GetModuleInformation(GetCurrentProcess(), module, &module_info, sizeof(MODULEINFO)))
        return 0;

    // copy data
    std::vector<unsigned char> data(module_info.SizeOfImage);
    memcpy(&data[0], module_info.lpBaseOfDll, module_info.SizeOfImage);

    // find pattern
    return find_pattern(data, (intptr_t) module_info.lpBaseOfDll, pattern, mask, offset, resultUsage);
}

intptr_t replace_pattern(HMODULE module, const unsigned char* pattern, const char* mask, intptr_t offset,
                         intptr_t usage, const unsigned char* replace_data, const char* replace_mask) {

    // find result
    auto result = find_pattern(module, pattern, mask, offset, usage);

    // check result
    if (!result)
        return 0;

    // unprotect memory
    unsigned int old_protect = 0, tmp = 0;
    if (!VirtualProtect((void*) result, 4096, PAGE_EXECUTE_READWRITE, (PDWORD) &old_protect))
        return 0;

    // replace data
    for (size_t i = 0, s = strlen(replace_mask); i < s; i++)
        if (replace_mask[i] == 'X')
            *((unsigned char *) (result + i)) = replace_data[i];

    // protect memory
    VirtualProtect((void*) result, 4096, old_protect, (PDWORD) &tmp);
    return result;
}

intptr_t replace_pattern(HMODULE module, std::string signature, std::string replacement,
        intptr_t offset, intptr_t usage) {

    // build pattern
    std::string pattern_str(signature);
    strreplace(pattern_str, "??", "00");
    char pattern_bin[signature.length() / 2];
    if (!hex2bin(pattern_str.c_str(), pattern_bin))
        return false;

    // build signature mask
    std::ostringstream signature_mask;
    for (size_t i = 0; i < signature.length(); i += 2) {
        if (signature[i] == '?') {
            if (signature[i + 1] == '?')
                signature_mask << '?';
            else
                return false;
        } else {
            signature_mask << 'X';
        }
    }

    // build replace data
    std::string replace_data_str(replacement);
    strreplace(replace_data_str, "??", "00");
    char replace_data_bin[replacement.length() / 2];
    if (!hex2bin(replace_data_str.c_str(), replace_data_bin))
        return false;

    // build replace mask
    std::ostringstream replace_mask;
    for (size_t i = 0; i < replacement.length(); i += 2) {
        if (replacement[i] == '?') {
            if (replacement[i + 1] == '?')
                replace_mask << '?';
            else
                return false;
        } else {
            replace_mask << 'X';
        }
    }

    // do the replacement
    return replace_pattern(
            module,
            (const unsigned char*) pattern_bin,
            signature_mask.str().c_str(),
            offset,
            usage,
            (const unsigned char*) replace_data_bin,
            replace_mask.str().c_str()
    );
}
