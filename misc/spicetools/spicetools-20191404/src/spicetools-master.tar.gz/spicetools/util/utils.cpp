#include <winsock2.h>
#include <ws2tcpip.h>

#include "utils.h"

const char *inet_ntop(short af, const void *src, char *dst, DWORD size) {

    // prepare storage
    struct sockaddr_storage ss;
    ZeroMemory(&ss, sizeof(ss));
    ss.ss_family = af;

    // IPV6 compatibility
    switch(af) {
        case AF_INET:
            ((struct sockaddr_in *)&ss)->sin_addr = *(struct in_addr *)src;
            break;
        case AF_INET6:
            ((struct sockaddr_in6 *)&ss)->sin6_addr = *(struct in6_addr *)src;
            break;
        default:
            return NULL;
    }

    // convert to string
    return (WSAAddressToString((struct sockaddr *)&ss, (DWORD) sizeof(ss), NULL, dst, &size) == 0) ? dst : NULL;
}
