#include "libutils.h"
#include "logging.h"
#include "utils.h"


HMODULE libutils::load_library(std::string module_name) {
    HMODULE module = LoadLibraryA(module_name.c_str());
    if (!module)
        log_fatal("detour", to_string(module_name) + " couldn't be loaded: " + get_last_error_string());
    return module;
}

HMODULE libutils::try_library(std::string module_name) {
    return LoadLibraryA(module_name.c_str());
}

HMODULE libutils::get_module(std::string module_name) {
    HMODULE module = GetModuleHandleA(module_name.c_str());
    if (!module)
        log_fatal("detour", module_name + " couldn't be loaded: " + get_last_error_string());
    return module;
}

HMODULE libutils::try_module(std::string module_name) {
    return GetModuleHandleA(module_name.c_str());
}

FARPROC libutils::get_proc(HINSTANCE hinstance, LPCSTR lpcstr) {
    FARPROC value = GetProcAddress(hinstance, lpcstr);
    if (!value)
        log_fatal("detour", to_string(lpcstr) + " not found.");
    return value;
}

FARPROC libutils::get_proc_list(HINSTANCE hinstance, std::initializer_list<LPCSTR> list) {
    FARPROC value = 0;
    for (auto lpcstr : list) {
        value = GetProcAddress(hinstance, lpcstr);
        if (value)
            return value;
    }

    // error out
    log_fatal("detour", to_string(*list.begin()) + " not found.");
    return nullptr;
}

FARPROC libutils::try_proc(HINSTANCE hinstance, LPCSTR lpcstr) {
    FARPROC value = GetProcAddress(hinstance, lpcstr);
    if (!value)
        return 0;
    return value;
}

FARPROC libutils::try_proc_list(HINSTANCE hinstance, std::initializer_list<LPCSTR> list) {
    FARPROC value = 0;
    for (auto lpcstr : list) {
        value = GetProcAddress(hinstance, lpcstr);
        if (value)
            return value;
    }
    return 0;
}

intptr_t libutils::rva2offset(IMAGE_NT_HEADERS* nt_headers, intptr_t rva) {

    // iterate sections
    auto section_count = nt_headers->FileHeader.NumberOfSections;
    PIMAGE_SECTION_HEADER section_header = IMAGE_FIRST_SECTION(nt_headers);
    for (size_t i = 0; i < section_count; i++) {

        // check if RVA is within section
        if (section_header->VirtualAddress <= (DWORD) rva) {
            if ((section_header->VirtualAddress + section_header->Misc.VirtualSize) > (DWORD) rva) {
                rva -= section_header->VirtualAddress;
                rva += section_header->PointerToRawData;
                return rva;
            }
        }

        // next section
        section_header++;
    }

    // offset out of bounds
    return ~0u;
}


intptr_t libutils::rva2offset(std::string path, intptr_t rva) {

    // open file
    HANDLE dll_file;
    dll_file = CreateFileA(
            path.c_str(),
            GENERIC_READ,
            FILE_SHARE_READ,
            NULL,
            OPEN_EXISTING,
            FILE_ATTRIBUTE_NORMAL,
            0);
    if (!dll_file)
        return ~0;

    // create file mapping
    HANDLE dll_mapping = CreateFileMapping(dll_file, NULL, PAGE_READONLY, 0, 0, NULL);
    if (!dll_mapping) {
        CloseHandle(dll_file);
        log_warning("libutils", "Couldn't create file mapping for " + path);
        return ~0u;
    }

    // map view of file
    LPVOID dll_file_base = MapViewOfFile(dll_mapping, FILE_MAP_READ, 0, 0, 0);
    if (!dll_file_base) {
        CloseHandle(dll_file);
        CloseHandle(dll_mapping);
        log_warning("libutils", "Couldn't map view of file for " + path);
        return ~0u;
    }

    // get offset
    intptr_t offset = ~0u;
    auto dll_dos = (PIMAGE_DOS_HEADER) dll_file_base;
    if (dll_dos->e_magic == IMAGE_DOS_SIGNATURE) {
        auto dll_nt = (PIMAGE_NT_HEADERS) ((uint8_t*) dll_dos + dll_dos->e_lfanew);
        offset = libutils::rva2offset(dll_nt, rva);
    }

    // clean up and return
    UnmapViewOfFile(dll_file_base);
    CloseHandle(dll_file);
    CloseHandle(dll_mapping);
    return offset;
}

intptr_t libutils::offset2rva(IMAGE_NT_HEADERS* nt_headers, intptr_t offset) {

    // iterate sections
    auto section_count = nt_headers->FileHeader.NumberOfSections;
    PIMAGE_SECTION_HEADER section_header = IMAGE_FIRST_SECTION(nt_headers);
    for (int i = 0; i < section_count; i++) {

        // check if offset is within section
        if (section_header->PointerToRawData <= (DWORD) offset) {
            if ((section_header->PointerToRawData + section_header->SizeOfRawData) > (DWORD) offset) {
                offset -= section_header->PointerToRawData;
                offset += section_header->VirtualAddress;
                return offset;
            }
        }

        // next section
        section_header++;
    }

    // offset out of bounds
    return ~0u;
}

intptr_t libutils::offset2rva(std::string path, intptr_t offset) {

    // open file
    HANDLE dll_file;
    dll_file = CreateFileA(
            path.c_str(),
            GENERIC_READ,
            FILE_SHARE_READ,
            NULL,
            OPEN_EXISTING,
            FILE_ATTRIBUTE_NORMAL,
            0);
    if (!dll_file)
        return ~0;

    // create file mapping
    HANDLE dll_mapping = CreateFileMapping(dll_file, NULL, PAGE_READONLY, 0, 0, NULL);
    if (!dll_mapping) {
        log_warning("libutils", "Couldn't create file mapping for " + path + ": " + to_string(GetLastError()));
        CloseHandle(dll_file);
        return ~0u;
    }

    // map view of file
    LPVOID dll_file_base = MapViewOfFile(dll_mapping, FILE_MAP_READ, 0, 0, 0);
    if (!dll_file_base) {
        log_warning("libutils", "Couldn't map view of file for " + path + ": " + to_string(GetLastError()));
        CloseHandle(dll_file);
        CloseHandle(dll_mapping);
        return ~0u;
    }

    // get RVA
    intptr_t rva = ~0u;
    auto dll_dos = (PIMAGE_DOS_HEADER) dll_file_base;
    if (dll_dos->e_magic == IMAGE_DOS_SIGNATURE) {
        auto dll_nt = (PIMAGE_NT_HEADERS) ((uint8_t*) dll_dos + dll_dos->e_lfanew);
        rva = libutils::offset2rva(dll_nt, offset);
    }

    // clean up and return
    UnmapViewOfFile(dll_file_base);
    CloseHandle(dll_file);
    CloseHandle(dll_mapping);
    return rva;
}
