#ifndef SPICETOOLS_UTIL_FILEUTILS_H
#define SPICETOOLS_UTIL_FILEUTILS_H

#include <string>
#include <windows.h>

namespace fileutils {

    // file existance
    bool file_exists(LPCTSTR szPath);
    bool file_exists(std::string file_name);

    // file headers
    bool verify_header_pe(std::string file_name);

    // versions
    bool version_pe(std::string filename, char *ver);

    // directories
    bool dir_exists(const std::string &path);
    bool dir_create_recursive(const std::string &path);
}

#endif //SPICETOOLS_UTIL_FILEUTILS_H
