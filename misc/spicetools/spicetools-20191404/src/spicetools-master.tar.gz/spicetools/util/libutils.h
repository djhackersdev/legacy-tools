#ifndef SPICETOOLS_UTIL_LIBUTILS_H
#define SPICETOOLS_UTIL_LIBUTILS_H

#include <string>
#include <initializer_list>
#include <windows.h>

namespace libutils {

    // load library helpers
    HMODULE load_library(std::string module_name);
    HMODULE try_library(std::string module_name);

    // get module handle helpers
    HMODULE get_module(std::string module_name);
    HMODULE try_module(std::string module_name);

    // get proc address helpers
    FARPROC WINAPI get_proc(HINSTANCE hinstance, LPCSTR lpcstr);
    FARPROC WINAPI get_proc_list(HINSTANCE hinstance, std::initializer_list<LPCSTR> list);
    FARPROC WINAPI try_proc(HINSTANCE hinstance, LPCSTR lpcstr);
    FARPROC WINAPI try_proc_list(HINSTANCE hinstance, std::initializer_list<LPCSTR> list);

    // offset helpers
    intptr_t rva2offset(IMAGE_NT_HEADERS* nt_headers, intptr_t rva);
    intptr_t rva2offset(std::string path, intptr_t rva);
    intptr_t offset2rva(IMAGE_NT_HEADERS* nt_headers, intptr_t offset);
    intptr_t offset2rva(std::string path, intptr_t offset);
}

#endif //SPICETOOLS_UTIL_LIBUTILS_H
