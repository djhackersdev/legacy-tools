#include "detour.h"
#include "logging.h"
#include "utils.h"
#include "peb.h"

bool detour::inline_hook(void *new_adr, DWORD_PTR address) {
#ifdef SPICE64
    if (address) {
        unsigned char patch[] = {0x48, 0xB8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF, 0xE0};
        *(unsigned long long*) &patch[2] = (unsigned long long) new_adr;
        unsigned int OldProtect = 0;
        unsigned int Temp = 0;
        VirtualProtect((void *) address, 4096, PAGE_EXECUTE_READWRITE, (PDWORD) &OldProtect);
        memcpy((void*) address, patch, sizeof(patch));
        VirtualProtect((void *) address, 4096, OldProtect, (PDWORD) &Temp);
        return true;
    }
    return false;
#else
    if (address) {
        unsigned int OldProtect = 0;
        unsigned int Temp = 0;
        int call = (int) ((signed long long) ((uint8_t*) new_adr - (long long) address - 5));
        VirtualProtect((void *) address, 4096, PAGE_EXECUTE_READWRITE, (PDWORD) &OldProtect);
        *((unsigned char *) (address)) = 0xE9;
        *((int *) (address + 1)) = call;
        VirtualProtect((void *) address, 4096, OldProtect, (PDWORD) &Temp);
        return true;
    }
    return false;
#endif
}

bool detour::inline_noprotect(void *new_adr, DWORD_PTR address) {
#ifdef SPICE64
    if (address) {
        unsigned char patch[] = {0x48, 0xB8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF, 0xE0};
        *(unsigned long long*) &patch[2] = (unsigned long long) new_adr;
        memcpy((void*) address, patch, sizeof(patch));
        return true;
    }
    return false;
#else
    if (address) {
        *((unsigned char *) (address)) = 0xE9;
        *((int *) (address + 1)) = (int) ((signed long long) ((uint8_t*) new_adr - (long long) address - 5));
        return true;
    }
    return false;
#endif
}

bool detour::inline_preserve(void *new_adr, DWORD_PTR address, char *data) {
#ifdef SPICE64
    if (address) {
        unsigned char patch[] = {0x48, 0xB8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF, 0xE0};
        *(unsigned long long*) &patch[2] = (unsigned long long) new_adr;
        unsigned int OldProtect = 0;
        VirtualProtect((void *) address, 4096, PAGE_EXECUTE_READWRITE, (PDWORD) &OldProtect);
        memcpy(data, (void *) address, sizeof(patch));
        memcpy((void*) address, patch, sizeof(patch));
        return true;
    }
    return false;
#else
    if (address) {
        unsigned int OldProtect = 0;
        int call = (int) ((signed long long) ((uint8_t*) new_adr - (long long) address - 5));
        VirtualProtect((void *) address, 4096, PAGE_EXECUTE_READWRITE, (PDWORD) &OldProtect);
        memcpy(data, (void *) address, 5);
        *((unsigned char *) (address)) = 0xE9;
        *((int *) (address + 1)) = call;
        return true;
    }
    return false;
#endif
}

bool detour::inline_restore(DWORD_PTR address, char *data) {
#ifdef SPICE64
    if (address) {
        memcpy((void *) address, data, 12);
        return true;
    }
    return false;
#else
    if (address) {
        memcpy((void *) address, data, 5);
        return true;
    }
    return false;
#endif
}

#pragma clang diagnostic push
#pragma ide diagnostic ignored "OCDFAInspection"

void **detour::iat_find(const char *function, HMODULE module, const char *iid_name) {

    // check module
    if (module == 0)
        return 0;

    // check signature
    PIMAGE_DOS_HEADER pImgDosHeaders = (PIMAGE_DOS_HEADER) module;
    if (pImgDosHeaders->e_magic != IMAGE_DOS_SIGNATURE)
        log_fatal("detour", "Signature error.");

    // get import table
    auto nt_headers = (PIMAGE_NT_HEADERS) ((LPBYTE) pImgDosHeaders + pImgDosHeaders->e_lfanew);
    auto data_dir = nt_headers->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
    auto import_table = (PIMAGE_IMPORT_DESCRIPTOR) ((LPBYTE) pImgDosHeaders + data_dir.VirtualAddress);

    // iterate import descriptors
    DWORD iid_count = 0;
    for (IMAGE_IMPORT_DESCRIPTOR *iid = import_table; iid_count < data_dir.Size && iid->Name != 0; iid++) {
        iid_count++;

        // check name
        if (iid_name != nullptr) {

            // get name
            auto name = (PCSTR) RtlOffsetToPointer(module, iid->Name);

            // skip if it's not the correct module
            if (stricmp(name, iid_name) != 0)
                continue;
        }

        // iterate functions
        for (SIZE_T funcIdx = 0; *(funcIdx + (LPVOID *) (iid->FirstThunk + (SIZE_T) module)) != NULL; funcIdx++) {

            // get function name
            auto imports = (uintptr_t*) ((SIZE_T) module + iid->OriginalFirstThunk);
            auto import = (IMAGE_IMPORT_BY_NAME*) ((SIZE_T) module + imports[funcIdx]);

            // check string
            if (import->Name && !IMAGE_SNAP_BY_ORDINAL((SIZE_T) import->Name)) {

                // compare function names
                if (!stricmp(function, import->Name))
                    return funcIdx + (LPVOID *) (iid->FirstThunk + (SIZE_T) module);
            }
        }
    }

    // nothing found
    return 0;
}

void **detour::iat_find_ordinal(const char *iid_name, DWORD ordinal, HMODULE module) {

    // check module
    if (module == 0)
        return 0;

    // check signature
    PIMAGE_DOS_HEADER pImgDosHeaders = (PIMAGE_DOS_HEADER) module;
    if (pImgDosHeaders->e_magic != IMAGE_DOS_SIGNATURE)
        log_fatal("detour", "Signature error.");

    // get import table
    auto nt_headers = (PIMAGE_NT_HEADERS) ((LPBYTE) pImgDosHeaders + pImgDosHeaders->e_lfanew);
    auto data_dir = nt_headers->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
    auto import_table = (PIMAGE_IMPORT_DESCRIPTOR) ((LPBYTE) pImgDosHeaders + data_dir.VirtualAddress);

    // iterate import descriptors
    DWORD iid_count = 0;
    for (IMAGE_IMPORT_DESCRIPTOR *iid = import_table; iid_count < data_dir.Size && iid->Name != 0; iid++) {
        iid_count++;

        // get name and original first thunk (ILT)
        auto name = (PCSTR) RtlOffsetToPointer(module, iid->Name);
        auto OriginalFirstThunk = (PIMAGE_THUNK_DATA) (module + iid->OriginalFirstThunk);

        // skip if it's not the correct module
        if (stricmp(name, iid_name) != 0)
            continue;

        // iterate functions
        for (SIZE_T funcIdx = 0; *(funcIdx + (LPVOID*) (iid->FirstThunk + (SIZE_T)module)) != NULL; funcIdx++) {
            PIMAGE_THUNK_DATA thunk = (PIMAGE_THUNK_DATA) (OriginalFirstThunk + (SIZE_T) funcIdx);
            if (IMAGE_SNAP_BY_ORDINAL(thunk->u1.Ordinal)) {

                // check if the ordinal matches
                if (IMAGE_ORDINAL(thunk->u1.Ordinal) == ordinal) {
                    return funcIdx + (LPVOID *) (iid->FirstThunk + (SIZE_T) module);
                }
            }
        }
    }

    // nothing found
    return 0;
}

#pragma clang diagnostic pop

void *detour::iat_try(const char *function, void *new_func, HMODULE module, const char *iid_name) {

    // apply to all loaded modules by default
    if (module == nullptr) {
        void* ret = nullptr;
        auto cur_entry = peb::entry_first();
        while (cur_entry != nullptr) {
            module = (HMODULE) cur_entry->DllBase;
            if (module) {
                auto old_func = iat_try(function, new_func, module, iid_name);
                ret = ret != nullptr ? ret : old_func;
            }
            cur_entry = peb::entry_next(cur_entry);
        }
        return ret;
    }

    // find entry
    void **func_ptr = iat_find(function, module, iid_name);

    // check entry
    if (!func_ptr || !*func_ptr)
        return nullptr;

    // patch
    void *real_func = *func_ptr;
    DWORD OldProtect, NewProtect = PAGE_READWRITE;
    VirtualProtect(func_ptr, sizeof(LPVOID), NewProtect, &OldProtect);
    *func_ptr = new_func;
    VirtualProtect(func_ptr, sizeof(LPVOID), OldProtect, &NewProtect);
    return real_func;
}

void *detour::iat_try_ordinal(const char *iid_name, DWORD ordinal, void *new_func, HMODULE module) {

    // find entry
    void **func_ptr = iat_find_ordinal(iid_name, ordinal, module);

    // check entry
    if (!func_ptr || !*func_ptr)
        return nullptr;

    // patch
    void *real_func = *func_ptr;
    DWORD OldProtect, NewProtect = PAGE_READWRITE;
    VirtualProtect(func_ptr, sizeof(LPVOID), NewProtect, &OldProtect);
    *func_ptr = new_func;
    VirtualProtect(func_ptr, sizeof(LPVOID), OldProtect, &NewProtect);
    return real_func;
}

void *detour::iat(const char *function, void *new_func, HMODULE module) {
    void *func_ptr = iat_try(function, new_func, module);
    if (!func_ptr)
        log_warning("detour", "Couldn't hook " + to_string(function));
    return func_ptr;
}

void *detour::iat_ordinal(const char *iid_name, DWORD ordinal, void *new_func, HMODULE module) {
    void *func_ptr = iat_try_ordinal(iid_name, ordinal, new_func, module);
    if (!func_ptr)
        log_warning("detour", "Couldn't hook " + to_string(iid_name) + ":" + to_string(ordinal));
    return func_ptr;
}
