#ifndef SPICETOOLS_UTIL_DETOUR_H
#define SPICETOOLS_UTIL_DETOUR_H

#include <string>
#include <initializer_list>
#include <windows.h>

namespace detour {

    /*
     * Inline hooks
     */

    bool inline_hook(void *new_adr, DWORD_PTR address);
    bool inline_noprotect(void *new_adr, DWORD_PTR address);
    bool inline_preserve(void *new_adr, DWORD_PTR address, char *data);
    bool inline_restore(DWORD_PTR address, char *data);

    /*
     * IAT hooks
     */

    // for finding IAT entries - you probably won't need to use those yourself
    void **iat_find(const char *function, HMODULE module, const char *iid_name = nullptr);
    void **iat_find_ordinal(const char *iid_name, DWORD ordinal, HMODULE module);

    // best effort hooks - they will fail silently
    void *iat_try(const char *function, void *new_func, HMODULE module = nullptr, const char *iid_name = nullptr);
    void *iat_try_ordinal(const char *iid_name, DWORD ordinal, void *new_func, HMODULE module);

    // guaranteed hooks - they will stop the program on failure
    void *iat(const char *function, void *new_func, HMODULE module = nullptr);
    void *iat_ordinal(const char *iid_name, DWORD ordinal, void *new_func, HMODULE module);

}

#endif //SPICETOOLS_UTIL_DETOUR_H
