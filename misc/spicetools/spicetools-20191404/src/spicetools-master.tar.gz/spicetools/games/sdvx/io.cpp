#include "io.h"


std::vector<Button*>* games::sdvx::get_buttons() {
    static std::vector<Button*>* buttons = nullptr;
    if (buttons == nullptr) {
        buttons = GameAPI::Buttons::getButtons("Sound Voltex");
        GameAPI::Buttons::sortButtons(
                &buttons,
                "Service",
                "Test",
                "Coin Mech",
                "BT-A",
                "BT-B",
                "BT-C",
                "BT-D",
                "FX-L",
                "FX-R",
                "Start",
                "VOL-L Left",
                "VOL-L Right",
                "VOL-R Left",
                "VOL-R Right"
        );
    }
    return buttons;
}

std::vector<Analog*>* games::sdvx::get_analogs() {
    static std::vector<Analog*>* analogs = nullptr;
    if (analogs == nullptr) {
        analogs = GameAPI::Analogs::getAnalogs("Sound Voltex");
        GameAPI::Analogs::sortAnalogs(
                &analogs,
                "VOL-L",
                "VOL-R"
        );
    }
    return analogs;
}

std::vector<Light*>* games::sdvx::get_lights() {
    static std::vector<Light*>* lights = nullptr;
    if (lights == nullptr) {
        lights = GameAPI::Lights::getLights("Sound Voltex");
        GameAPI::Lights::sortLights(
                &lights,
                "BT-A",
                "BT-B",
                "BT-C",
                "BT-D",
                "FX-L",
                "FX-R",
                "Start",
                "Wing Left Up R",
                "Wing Left Up G",
                "Wing Left Up B",
                "Wing Right Up R",
                "Wing Right Up G",
                "Wing Right Up B",
                "Wing Left Low R",
                "Wing Left Low G",
                "Wing Left Low B",
                "Wing Right Low R",
                "Wing Right Low G",
                "Wing Right Low B",
                "Woofer R",
                "Woofer G",
                "Woofer B",
                "Controller R",
                "Controller G",
                "Controller B",
                "Generator R",
                "Generator G",
                "Generator B",
                "Pop",
                "Title Left",
                "Title Right"
        );
    }
    return lights;
}
