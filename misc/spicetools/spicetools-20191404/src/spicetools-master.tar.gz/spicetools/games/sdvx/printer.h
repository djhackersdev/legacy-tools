#ifndef SPICETOOLS_GAMES_SDVX_PRINTER_H
#define SPICETOOLS_GAMES_SDVX_PRINTER_H

#include <vector>
#include <string>
#include <minwindef.h>

namespace games::sdvx {

    // settings
    extern std::vector<std::string> PRINTER_PATH;
    extern std::vector<std::string> PRINTER_FORMAT;
    extern int PRINTER_JPG_QUALITY;
    extern bool PRINTER_CLEAR;

    void printer_attach();
}

#endif //SPICETOOLS_GAMES_SDVX_PRINTER_H
