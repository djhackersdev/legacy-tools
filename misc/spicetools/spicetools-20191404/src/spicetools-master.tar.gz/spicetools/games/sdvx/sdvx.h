#ifndef SPICETOOLS_GAMES_SDVX_H
#define SPICETOOLS_GAMES_SDVX_H

#include "games/game.h"

namespace games::sdvx {

    class SDVXGame : public games::Game {
    public:
        SDVXGame();
        virtual void attach() override;
        virtual void detach() override;
    };
}

#endif //SPICETOOLS_GAMES_SDVX_H
