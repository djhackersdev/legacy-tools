#ifndef SPICETOOLS_GAMES_SDVX_IO_H
#define SPICETOOLS_GAMES_SDVX_IO_H

#include <vector>
#include "cfg/api.h"

namespace games::sdvx {

    // all buttons in correct order
    namespace Buttons {
        enum {
            Service,
            Test,
            CoinMech,
            BT_A,
            BT_B,
            BT_C,
            BT_D,
            FX_L,
            FX_R,
            Start,
            VOL_L_Left,
            VOL_L_Right,
            VOL_R_Left,
            VOL_R_Right
        };
    }

    // all analogs in correct order
    namespace Analogs {
        enum {
            VOL_L,
            VOL_R
        };
    }

    // all lights in correct order
    namespace Lights {
        enum {
            BT_A,
            BT_B,
            BT_C,
            BT_D,
            FX_L,
            FX_R,
            START,
            WING_LEFT_UP_R,
            WING_LEFT_UP_G,
            WING_LEFT_UP_B,
            WING_RIGHT_UP_R,
            WING_RIGHT_UP_G,
            WING_RIGHT_UP_B,
            WING_LEFT_LOW_R,
            WING_LEFT_LOW_G,
            WING_LEFT_LOW_B,
            WING_RIGHT_LOW_R,
            WING_RIGHT_LOW_G,
            WING_RIGHT_LOW_B,
            WOOFER_R,
            WOOFER_G,
            WOOFER_B,
            CONTROLLER_R,
            CONTROLLER_G,
            CONTROLLER_B,
            GENERATOR_R,
            GENERATOR_G,
            GENERATOR_B,
            POP,
            TITLE_LEFT,
            TITLE_RIGHT
        };
    }

    // getters
    std::vector<Button*>* get_buttons();
    std::vector<Analog*>* get_analogs();
    std::vector<Light*>* get_lights();
}

#endif //SPICETOOLS_GAMES_SDVX_IO_H
