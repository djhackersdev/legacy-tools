#include "sdvx.h"
#include "avs/game.h"
#include "hooks/rs232dummy.h"
#include "hooks/devicehook.h"
#include "hooks/sleephook.h"
#include "games/shared/lcdhandle.h"
#include "util/detour.h"
#include "util/sigscan.h"

games::sdvx::SDVXGame::SDVXGame() : Game("Sound Voltex") {
}

void games::sdvx::SDVXGame::attach() {
    Game::attach();

    // LCD handle
    rs232dummy_init();
    devicehook_init();
    devicehook_add(new games::shared::LCDHandle());

    // sleep hook
    sleephook_init(1000, 1);

#ifdef SPICE64

    // RGB CAMERA error ignore
    if (!replace_pattern(
            avs::game::DLL_INSTANCE,
            "418D480484C074218D51FD",
            "????????????9090??????",
            0, 0))
        log_warning("sdvx", "failed to insert camera error fix");

#endif
}

void games::sdvx::SDVXGame::detach() {
    Game::detach();
    devicehook_dispose();
}
