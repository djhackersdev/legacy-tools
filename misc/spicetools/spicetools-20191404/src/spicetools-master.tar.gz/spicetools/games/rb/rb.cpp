#include "rb.h"
#include "hooks/rs232dummy.h"
#include "hooks/devicehook.h"
#include "touch.h"

games::rb::RBGame::RBGame() : Game("Reflec Beat") {
}

void games::rb::RBGame::attach() {
    Game::attach();

    // init stuff
    rs232dummy_init();
    devicehook_init();

    // add touch device
    devicehook_add(new ReflecBeatTouchDeviceHandle());
}

void games::rb::RBGame::detach() {
    Game::detach();
    devicehook_dispose();
}

