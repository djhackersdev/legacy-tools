#include "io.h"

std::vector<Button*>* games::rb::get_buttons() {
    static std::vector<Button*>* buttons = nullptr;
    if (buttons == nullptr) {
        buttons = GameAPI::Buttons::getButtons("Reflec Beat");
        GameAPI::Buttons::sortButtons(
                &buttons,
                "Service",
                "Test"
        );
    }
    return buttons;
}
