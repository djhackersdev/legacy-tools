#ifndef SPICETOOLS_GAMES_IO_H
#define SPICETOOLS_GAMES_IO_H

#include <vector>
#include "cfg/api.h"


namespace games {

    std::vector<Button*>* get_buttons(std::string game);
    std::vector<Analog*>* get_analogs(std::string game);
    std::vector<Light*>* get_lights(std::string game);
}

#endif //SPICETOOLS_GAMES_IO_H
