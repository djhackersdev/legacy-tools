#include "sate.h"
#include "util/logging.h"

using namespace acioemu;

games::ddr::DDRSATEHandle::SATEDevice::SATEDevice() {
    this->node_count = 7;
}

bool games::ddr::DDRSATEHandle::SATEDevice::parse_msg(unsigned int node_offset, acioemu::MessageData *msg_in,
                                                      circular_buffer<uint8_t> *response_buffer) {

    // check command
    switch (msg_in->cmd) {
        case 0x02: { // VERSION

            // send version data
            auto msg = this->create_msg(msg_in, MSG_VERSION_SIZE);
            this->set_version(msg, 0x105, 0, 1, 1, 0, "DDRS");
            write_msg(msg, response_buffer);
            delete msg;
            break;
        }
        case 0x00: // CMD CLEAR
        case 0x03: // STARTUP
        case 0xFF: // BROADCAST
        {
            // send status 0
            auto msg = this->create_msg_status(msg_in, 0x00);
            write_msg(msg, response_buffer);
            delete msg;
            break;
        }
        default:
            return false;
    }

    // mark as handled
    return true;
}

bool games::ddr::DDRSATEHandle::open(LPCWSTR lpFileName) {
    if (wcscmp(lpFileName, L"COM2") != 0)
        return false;
    log_info("ddr", "Opened COM2 (SATE).");
    acio_emu.add_device(new SATEDevice());
    return true;
}

int games::ddr::DDRSATEHandle::read(LPVOID lpBuffer, DWORD nNumberOfBytesToRead) {

    // read from emu
    DWORD bytes_read = 0;
    while (bytes_read < nNumberOfBytesToRead) {
        int cur_byte = acio_emu.read();
        if (cur_byte >= 0)
            ((uint8_t *) lpBuffer)[bytes_read++] = (uint8_t) cur_byte;
        else
            break;
    }

    // return amount of bytes reasd
    return (int) bytes_read;
}

int games::ddr::DDRSATEHandle::write(LPCVOID lpBuffer, DWORD nNumberOfBytesToWrite) {

    // write to emu
    for (DWORD i = 0; i < nNumberOfBytesToWrite; i++)
        acio_emu.write(((uint8_t *) lpBuffer)[i]);

    // return all data written
    return (int) nNumberOfBytesToWrite;
}

int games::ddr::DDRSATEHandle::device_io(DWORD dwIoControlCode, LPVOID lpInBuffer, DWORD nInBufferSize,
        LPVOID lpOutBuffer, DWORD nOutBufferSize) {
    return -1;
}

bool games::ddr::DDRSATEHandle::close() {
    log_info("ddr", "Closed COM2 (SATE).");
    return true;
}
