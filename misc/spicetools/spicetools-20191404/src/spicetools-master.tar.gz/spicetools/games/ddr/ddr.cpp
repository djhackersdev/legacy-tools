#include "ddr.h"
#include "hooks/devicehook.h"
#include "hooks/rs232dummy.h"
#include "hooks/setupapihook.h"
#include "hooks/dinputhook.h"
#include "util/utils.h"
#include "util/libutils.h"
#include "util/fileutils.h"
#include "util/detour.h"
#include "hooks/sleephook.h"
#include "avs/game.h"
#include "io.h"
#include "sate.h"
#include "usbmem.h"
#include "p3io.h"
#include "foot.h"

using namespace acioemu;

namespace games::ddr {

    // settings
    bool SDMODE = false;

    typedef LRESULT (WINAPI *SendMessage_t)(HWND, UINT, WPARAM, LPARAM);
    static SendMessage_t SendMessage_real;

    static LRESULT WINAPI SendMessageHook(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam) {

        // ignore broadcasts
        if (hWnd == (HWND) 0xFFFF)
            return 1;

        // fallback
        return SendMessage_real(hWnd, Msg, wParam, lParam);
    }

    static SHORT WINAPI GetKeyStateHook(int nVirtKey) {

        // disable debug keys
        return 0;
    }

    DDRGame::DDRGame() : Game("Dance Dance Revolution") {
    }

    void DDRGame::attach() {
        Game::attach();

        // dinput hook on this dll since the game dll doesn't load it
        auto game_mdx = libutils::try_library(MODULE_PATH_STR + "gamemdx.dll");
        dinputhook_init(game_mdx);

        // ignore rs232 stuff for fake COM devices
        rs232dummy_init();

        // add fake devices
        devicehook_init();
        devicehook_add(new DDRFOOTHandle());
        devicehook_add(new DDRSATEHandle());
        devicehook_add(new DDRUSBMEMHandle());
        devicehook_add(new DDRP3IOHandle());

        // settings 1
        SETUPAPI_SETTINGS settings1{};
        settings1.class_guid[0] = 0x1FA4A480;
        settings1.class_guid[1] = 0x40C7AC60;
        settings1.class_guid[2] = 0x7952ACA7;
        settings1.class_guid[3] = 0x5A57340F;

        // has nothing to do with P3IO, but is enough to trick the game into SD/HD mode
        std::string settings1_property;
        if (ddr::SDMODE)
            settings1_property = "Generic Television";
        else
            settings1_property = "Generic Monitor";

        memcpy(settings1.property_devicedesc, settings1_property.c_str(), strlen(settings1_property.c_str()) + 1);
        std::string settings1_detail = "\\\\.\\P3IO";
        memcpy(settings1.interface_detail, settings1_detail.c_str(), strlen(settings1_detail.c_str()) + 1);

        // settings 2
        SETUPAPI_SETTINGS settings2{};
        settings2.class_guid[0] = 0x4D36E96E;
        settings2.class_guid[1] = 0x11CEE325;
        settings2.class_guid[2] = 0x8C1BF;
        settings2.class_guid[3] = 0x1803E12B;

        // has nothing to do with P3IO, but is enough to trick the game into SD/HD mode
        std::string settings2_property;
        if (ddr::SDMODE)
            settings2_property = "Generic Television";
        else
            settings2_property = "Generic Monitor";

        memcpy(settings2.property_devicedesc, settings2_property.c_str(), strlen(settings2_property.c_str()) + 1);
        std::string settings2_detail = "\\\\.\\P3IO";
        memcpy(settings2.interface_detail, settings2_detail.c_str(), strlen(settings2_detail.c_str()) + 1);

        // init SETUP API
        setupapihook_init(avs::game::DLL_INSTANCE);

        // DDR ACE actually uses another DLL for things
        if (fileutils::file_exists("gamemdx.dll"))
            setupapihook_init(GetModuleHandle("gamemdx.dll"));

        // add settings
        setupapihook_add(settings1);
        setupapihook_add(settings2);

        // misc hooks
        SendMessage_real = (SendMessage_t) detour::iat_try("SendMessageW",
                (void *) &SendMessageHook, avs::game::DLL_INSTANCE);
        detour::iat_try("SendMessageA", (void *) &SendMessageHook, avs::game::DLL_INSTANCE);
        detour::iat_try("GetKeyState", (void *) &GetKeyStateHook, avs::game::DLL_INSTANCE);
    }

    void DDRGame::detach() {
        Game::detach();

        // dispose device hook
        devicehook_dispose();
    }
}
