#ifndef SPICETOOLS_GAMES_DDR_H
#define SPICETOOLS_GAMES_DDR_H

#include "games/game.h"

namespace games::ddr {

    // settings
    extern bool SDMODE;

    class DDRGame : public games::Game {
    public:
        DDRGame();
        virtual void attach() override;
        virtual void detach() override;
    };
}

#endif //SPICETOOLS_GAMES_DDR_H
