#ifndef SPICETOOLS_GAMES_GITADORA_H
#define SPICETOOLS_GAMES_GITADORA_H

#include "games/game.h"

namespace games::gitadora {

    // settings
    extern bool TWOCHANNEL;

    class GitaDoraGame : public games::Game {
    public:
        GitaDoraGame();
        virtual void attach();
    };
}

#endif //SPICETOOLS_GAMES_GITADORA_H
