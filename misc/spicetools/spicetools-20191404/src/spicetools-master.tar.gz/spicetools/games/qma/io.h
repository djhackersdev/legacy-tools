#ifndef SPICETOOLS_GAMES_QMA_IO_H
#define SPICETOOLS_GAMES_QMA_IO_H

#include <vector>
#include "cfg/api.h"

namespace games::qma {

    // all buttons in correct order
    namespace Buttons {
        enum {
            Service,
            Test,
            Select,
            CoinMech,
            Select1,
            Select2,
            Left,
            Right,
            OK
        };
    }

    // all lights in correct order
    namespace Lights {
        enum {
            LampRed,
            LampGreen,
            LampBlue,
            ButtonLeft,
            ButtonRight,
            ButtonOK
        };
    }

    // getters
    std::vector<Button*>* get_buttons();
    std::vector<Light*>* get_lights();
}

#endif //SPICETOOLS_GAMES_QMA_IO_H
