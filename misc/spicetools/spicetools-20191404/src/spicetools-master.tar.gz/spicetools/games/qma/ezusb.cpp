#include "ezusb.h"
#include "rawinput/rawinput.h"
#include "cfg/button.h"
#include "cfg/api.h"
#include "util/detour.h"
#include "util/libutils.h"
#include "util/logging.h"
#include "games/qma/io.h"
#include "misc/eamuse.h"

namespace games::qma {

    static int __cdecl usbCheckAlive() {
        return 1;
    }

    static int __cdecl usbCheckSecurityNew() {
        return 0;
    }

    static int __cdecl usbCoinGet() {
        return eamuse_coin_get_stock();
    }

    static int __cdecl usbCoinMode() {
        return 0;
    }

    static int __cdecl usbEnd() {
        return 0;
    }

    static int __cdecl usbFirmResult() {
        return 0;
    }

    static int __cdecl usbGetKEYID() {
        return 0;
    }

    static int __cdecl usbGetSecurity() {
        return 0;
    }

    static int __cdecl usbLamp(uint32_t lamp_bits) {

        // get lights
        auto lights = get_lights();

        // mapping
        static const size_t bits[] = {
                0x20, 0x40, 0x80,
                0x08, 0x10, 0x20
        };
        static const size_t vals[] = {
                Lights::LampRed, Lights::LampGreen, Lights::LampBlue,
                Lights::ButtonLeft, Lights::ButtonRight, Lights::ButtonOK
        };
        for (size_t i = 0; i < 3; i++) {
            float value = (lamp_bits & bits[i]) ? 1.f : 0.f;
            GameAPI::Lights::writeLight(RI_MGR, lights->at(vals[i]), value);
        }

        // return no error
        return 0;
    }

    static int __cdecl usbPadRead(unsigned int *pad_bits) {

        // get buttons
        auto buttons = get_buttons();

        // reset
        *pad_bits = 0;

        // mappings
        static const struct {
            size_t button, shift;
        } mappings[] = {
                { Buttons::Service, 19},
                { Buttons::Test, 18},
                { Buttons::Select, 17},
                { Buttons::CoinMech, 16},
                { Buttons::Select1, 0},
                { Buttons::Select2, 1},
                { Buttons::OK, 2},
                { Buttons::Left, 6},
                { Buttons::Right, 7},
        };

        // set buttons
        for (auto &mapping : mappings)
            if (GameAPI::Buttons::getState(RI_MGR, buttons->at(mapping.button)))
                *pad_bits |= 1 << mapping.shift;

        // return no error
        return 0;
    }

    static int __cdecl usbPadReadLast(uint8_t *a1) {
        memset(a1, 0, 40);
        return 0;
    }

    static int __cdecl usbSecurityInit() {
        return 0;
    }

    static int __cdecl usbSecurityInitDone() {
        return 0;
    }

    static int __cdecl usbSecuritySearch() {
        return 0;
    }

    static int __cdecl usbSecuritySearchDone() {
        return 0;
    }

    static int __cdecl usbSecuritySelect() {
        return 0;
    }

    static int __cdecl usbSecuritySelectDone() {
        return 0;
    }

    static int __cdecl usbSetExtIo() {
        return 0;
    }

    static int __cdecl usbStart() {
        return 0;
    }

    static int __cdecl usbWdtReset() {
        return 0;
    }

    static int __cdecl usbWdtStart() {
        return 0;
    }

    static int __cdecl usbWdtStartDone() {
        return 0;
    }

    static int __cdecl usbCoinBlocker(int a1) {
        return 0;
    }

    static int __cdecl usbMute(int a1) {
        return 0;
    }

    static int __cdecl usbIsHiSpeed() {
        return 1;
    }

    void ezusb_init() {

        // load the library
        HINSTANCE ezusb = libutils::try_library("ezusb.dll");

        // insert hooks
        if (ezusb) {
            detour::inline_hook((void *) &usbCheckAlive,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbCheckAlive@@YAHXZ"));
            detour::inline_hook((void *) &usbCheckSecurityNew,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbCheckSecurityNew@@YAHH@Z"));
            detour::inline_hook((void *) &usbCoinGet,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbCoinGet@@YAHH@Z"));
            detour::inline_hook((void *) &usbCoinMode,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbCoinMode@@YAHH@Z"));
            detour::inline_hook((void *) &usbEnd,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbEnd@@YAHXZ"));
            detour::inline_hook((void *) &usbFirmResult,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbFirmResult@@YAHXZ"));
            detour::inline_hook((void *) &usbGetKEYID,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbGetKEYID@@YAHPAEH@Z"));
            detour::inline_hook((void *) &usbGetSecurity,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbGetSecurity@@YAHHPAE@Z"));
            detour::inline_hook((void *) &usbLamp,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbLamp@@YAHH@Z"));
            detour::inline_hook((void *) &usbPadRead,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbPadRead@@YAHPAK@Z"));
            detour::inline_hook((void *) &usbPadReadLast,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbPadReadLast@@YAHPAE@Z"));
            detour::inline_hook((void *) &usbSecurityInit,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbSecurityInit@@YAHXZ"));
            detour::inline_hook((void *) &usbSecurityInitDone,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbSecurityInitDone@@YAHXZ"));
            detour::inline_hook((void *) &usbSecuritySearch,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbSecuritySearch@@YAHXZ"));
            detour::inline_hook((void *) &usbSecuritySearchDone,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbSecuritySearchDone@@YAHXZ"));
            detour::inline_hook((void *) &usbSecuritySelect,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbSecuritySelect@@YAHH@Z"));
            detour::inline_hook((void *) &usbSecuritySelectDone,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbSecuritySelectDone@@YAHXZ"));
            detour::inline_hook((void *) &usbSetExtIo,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbSetExtIo@@YAHH@Z"));
            detour::inline_hook((void *) &usbStart,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbStart@@YAHH@Z"));
            detour::inline_hook((void *) &usbWdtReset,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbWdtReset@@YAHXZ"));
            detour::inline_hook((void *) &usbWdtStart,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbWdtStart@@YAHH@Z"));
            detour::inline_hook((void *) &usbWdtStartDone,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbWdtStartDone@@YAHXZ"));
            detour::inline_hook((void *) &usbCoinBlocker,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbCoinBlocker@@YAHH@Z"));
            detour::inline_hook((void *) &usbMute,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbMute@@YAHH@Z"));
            detour::inline_hook((void *) &usbIsHiSpeed,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbIsHiSpeed@@YAHXZ"));
        }
    }
}
