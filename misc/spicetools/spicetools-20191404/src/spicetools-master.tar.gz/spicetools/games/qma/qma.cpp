#include "qma.h"
#include <cstdint>
#include <cstring>
#include <d3d9.h>
#include "launcher/launcher.h"
#include "hooks/dxhook.h"
#include "hooks/rs232dummy.h"
#include "hooks/devicehook.h"
#include "games/shared/lcdhandle.h"
#include "games/shared/twtouch.h"
#include "games/qma/ezusb.h"
#include "util/logging.h"
#include "util/utils.h"
#include "util/fileutils.h"
#include "util/detour.h"

namespace games::qma {

    /**
     * Overriden touchscreen for attaching the touch hooks to the window.
     */
    class QMATouchDevice : public games::shared::TwTouchDevice {
    public:
        bool open(LPCWSTR lpFileName) override {

            // check if device was opened
            auto result = TwTouchDevice::open(lpFileName);
            if (result) {

                // attach touch module
                HWND wnd = GetForegroundWindow();
                if (!string_begins_with(GetActiveWindowTitle(), "QMA"))
                    wnd = FindWindowBeginsWith("QMA");
                if (wnd != nullptr) {

                    // check if windowed
                    if (DXHOOK_WINDOWED) {

                        // reset window process
                        SetWindowLongPtr(wnd, GWLP_WNDPROC, (LONG_PTR) DefWindowProc);

                        // remove style borders
                        LONG lStyle = GetWindowLong(wnd, GWL_STYLE);
                        lStyle &= ~(WS_CAPTION | WS_THICKFRAME | WS_MINIMIZE | WS_MAXIMIZE | WS_SYSMENU);
                        SetWindowLongPtr(wnd, GWL_STYLE, lStyle);

                        // remove ex style borders
                        LONG lExStyle = GetWindowLong(wnd, GWL_EXSTYLE);
                        lExStyle &= ~(WS_EX_DLGMODALFRAME | WS_EX_CLIENTEDGE | WS_EX_STATICEDGE);
                        SetWindowLongPtr(wnd, GWL_EXSTYLE, lExStyle);

                        // update window
                        SetWindowPos(wnd, nullptr, 0, 0, 0, 0,
                                     SWP_FRAMECHANGED | SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOOWNERZORDER);

                        // create touch window
                        touch_create_wnd(wnd);

                    } else {

                        // reset window process to make the game not crash
                        SetWindowLongPtr(wnd, GWLP_WNDPROC, (LONG_PTR) DefWindowProc);

                        // create touch window
                        touch_create_wnd(wnd);

                        // show game window because it lost focus
                        ShowWindow(wnd, SW_SHOW);
                    }
                } else {

                    // fallback to dx hook
                    touch_attach_dx_hook();
                }

                // cursor
                if (!is_win_touch_available())
                    ShowCursor(true);
            }

            // return result
            return result;
        }
    };

    /*
     * The game likes to crash if E:\LMA\quiz13 isn't existing.
     * Therefore we create it when the game tries to access E:\LMA the first time.
     */
    namespace dirfix {

        typedef HANDLE (WINAPI *CreateFileW_t)(LPCWSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode,
                                               LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition,
                                               DWORD dwFlagsAndAttributes, HANDLE hTemplateFile);
        static CreateFileW_t CreateFileW_real = nullptr;

        static HANDLE WINAPI CreateFileW_Hook(LPCWSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode,
                                              LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition,
                                              DWORD dwFlagsAndAttributes, HANDLE hTemplateFile) {

            // create quiz directory
            static bool dirs_created = false;
            if (!dirs_created && wcsnicmp(lpFileName, L"E:\\LMA", 6) == 0) {
                fileutils::dir_create_recursive("E:\\LMA\\quiz11");
                fileutils::dir_create_recursive("E:\\LMA\\quiz13");
                fileutils::dir_create_recursive("E:\\LMA\\quiz15");
                dirs_created = true;
            }

            // return result
            return CreateFileW_real(lpFileName, dwDesiredAccess, dwShareMode, lpSecurityAttributes,
                                    dwCreationDisposition, dwFlagsAndAttributes, hTemplateFile);
        }

        void apply() {
            CreateFileW_real = (CreateFileW_t) detour::iat_try("CreateFileW", (void*) CreateFileW_Hook);
        }
    }

    QMAGame::QMAGame() : Game("Quiz Magic Academy") {
    }

    void QMAGame::pre_attach() {
        Game::pre_attach();

        // load without resolving references
        // makes game not trigger DLLMain since that does some EZUSB device stuff
        LoadLibraryEx((MODULE_PATH_STR + "ezusb.dll").c_str(), nullptr, DONT_RESOLVE_DLL_REFERENCES);
    }

    void QMAGame::attach() {
        Game::attach();

        // init stuff
        rs232dummy_init();
        devicehook_init();

        // add touch device
        devicehook_add(new games::shared::LCDHandle());
        devicehook_add(new games::qma::QMATouchDevice());

        // EZUSB for button input
        ezusb_init();

        // fix CreateDevice failing
        DXHOOK_BEHAVIOR_DISABLE = D3DCREATE_ADAPTERGROUP_DEVICE;

        // directory fix
        dirfix::apply();
    }
}
