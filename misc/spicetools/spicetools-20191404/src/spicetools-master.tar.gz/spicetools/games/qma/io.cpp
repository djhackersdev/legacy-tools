#include "io.h"

std::vector<Button*>* games::qma::get_buttons() {
    static std::vector<Button*>* buttons = nullptr;
    if (buttons == nullptr) {
        buttons = GameAPI::Buttons::getButtons("Quiz Magic Academy");
        GameAPI::Buttons::sortButtons(
                &buttons,
                "Service",
                "Test",
                "Select",
                "Coin Mech",
                "Select 1",
                "Select 2",
                "Left",
                "Right",
                "OK"
        );
    }
    return buttons;
}

std::vector<Light*>* games::qma::get_lights() {
    static std::vector<Light*>* lights = nullptr;
    if (lights == nullptr) {
        lights = GameAPI::Lights::getLights("Quiz Magic Academy");
        GameAPI::Lights::sortLights(
                &lights,
                "Lamp Red",
                "Lamp Green",
                "Lamp Blue",
                "Button Left",
                "Button Right",
                "Button OK"
        );
    }
    return lights;
}
