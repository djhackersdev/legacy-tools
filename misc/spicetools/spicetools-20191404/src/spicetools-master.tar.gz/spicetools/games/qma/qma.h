#ifndef SPICETOOLS_GAMES_QMA_H
#define SPICETOOLS_GAMES_QMA_H

#include "games/game.h"

namespace games::qma {

    class QMAGame : public games::Game {
    public:
        QMAGame();
        virtual void pre_attach() override;
        virtual void attach() override;
    };
}

#endif //SPICETOOLS_GAMES_QMA_H
