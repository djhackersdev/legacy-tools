#ifndef SPICETOOLS_GAMES_QMA_EZUSB_H
#define SPICETOOLS_GAMES_QMA_EZUSB_H

namespace games::qma {

    void ezusb_init();
}

#endif //SPICETOOLS_GAMES_QMA_EZUSB_H
