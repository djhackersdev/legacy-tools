#include "io.h"

std::vector<Button*>* games::bs::get_buttons() {
    static std::vector<Button*>* buttons = nullptr;
    if (buttons == nullptr) {
        buttons = GameAPI::Buttons::getButtons("Beatstream");
        GameAPI::Buttons::sortButtons(
                &buttons,
                "Service",
                "Test",
                "Coin Mech"
        );
    }
    return buttons;
}
