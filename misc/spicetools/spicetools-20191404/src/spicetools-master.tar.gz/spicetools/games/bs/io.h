#ifndef SPICETOOLS_GAMES_BS_IO_H
#define SPICETOOLS_GAMES_BS_IO_H

#include <vector>
#include "cfg/api.h"

namespace games::bs {

    // all buttons in correct order
    namespace Buttons {
        enum {
            Service,
            Test,
            CoinMech
        };
    }

    // getters
    std::vector<Button*>* get_buttons();
}

#endif //SPICETOOLS_GAMES_BS_IO_H
