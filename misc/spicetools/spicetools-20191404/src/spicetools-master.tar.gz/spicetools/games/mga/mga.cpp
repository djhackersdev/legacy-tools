#include "mga.h"
#include "hooks/devicehook.h"
#include "util/logging.h"
#include "util/libutils.h"
#include "hooks/rs232dummy.h"
#include "gunio.h"

games::mga::MGAGame::MGAGame() : Game("Metal Gear Arcade") {
}

void games::mga::MGAGame::attach() {
    Game::attach();

    // init the dummies
    rs232dummy_init();

    // init device hook on system.dll
    devicehook_init(libutils::load_library("system.dll"));

    // add the gun
    devicehook_add(new SpiceGearGunHandle());
}

void games::mga::MGAGame::detach() {
    Game::detach();
    devicehook_dispose();
}
