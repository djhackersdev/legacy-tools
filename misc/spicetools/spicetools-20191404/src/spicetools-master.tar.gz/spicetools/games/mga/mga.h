#ifndef SPICETOOLS_GAMES_MGA_H
#define SPICETOOLS_GAMES_MGA_H

#include "games/game.h"

namespace games::mga {

    class MGAGame : public games::Game {
    public:
        MGAGame();
        virtual void attach() override;
        virtual void detach() override;
    };
}

#endif //SPICETOOLS_GAMES_MGA_H
