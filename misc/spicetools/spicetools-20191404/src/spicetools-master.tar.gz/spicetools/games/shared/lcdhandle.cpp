#include <util/utils.h>
#include "lcdhandle.h"

void games::shared::LCDHandle::answer(std::string s) {
    for (auto c : s)
        this->read_buffer.push_back((uint8_t) c);
    this->read_buffer.push_back('\r');
    this->read_buffer.push_back('\n');
}

bool games::shared::LCDHandle::open(LPCWSTR lpFileName) {
    if (wcscmp(lpFileName, L"COM1"))
        return false;
    log_info("lcdhandle", "Opened COM1.");
    return true;
}

int games::shared::LCDHandle::read(LPVOID lpBuffer, DWORD nNumberOfBytesToRead) {

    // return buffer
    if (read_buffer.size()) {
        size_t write_count = MIN(nNumberOfBytesToRead, read_buffer.size());
        memcpy(lpBuffer, &read_buffer[0], write_count);
        read_buffer.erase(read_buffer.begin(), read_buffer.begin() + write_count);
        return write_count;
    }

    // no data
    return 0;
}

int games::shared::LCDHandle::write(LPCVOID lpBuffer, DWORD nNumberOfBytesToWrite) {

    // check maximum size
    if (nNumberOfBytesToWrite >= 256)
        nNumberOfBytesToWrite = 255;

    // get string
    char data[256]{};
    memcpy(data, lpBuffer, nNumberOfBytesToWrite);
    std::string cmd(data);

    // check cmd
    if (string_begins_with(cmd, "0MODEL?")) {
        answer("9MODEL? ");
        answer("9OK");
    } else if (string_begins_with(cmd, "0BRI")) {
        answer("9BRI ");
        answer("9OK");
    } else if (string_begins_with(cmd, "0CON")) {
        answer("9CON ");
        answer("9OK");
    } else if (string_begins_with(cmd, "0BL")) {
        answer("9BL ");
        answer("9OK");
    } else if (string_begins_with(cmd, "0DFLIP")) {
        answer("9DFLIP ");
        answer("9OK");
    } else if (string_begins_with(cmd, "0OFLIP")) {
        answer("9OFLIP ");
        answer("9OK");
    }

    // log unhandled commands
    if (this->read_buffer.empty())
        log_warning("lcdhandle", "unhandled cmd: " + cmd);

    // return all bytes written
    return (int) nNumberOfBytesToWrite;
}

int games::shared::LCDHandle::device_io(DWORD dwIoControlCode, LPVOID lpInBuffer, DWORD nInBufferSize,
        LPVOID lpOutBuffer, DWORD nOutBufferSize) {
    return -1;
}

bool games::shared::LCDHandle::close() {
    log_info("lcdhandle", "Closed COM1.");
    return true;
}
