#ifndef SPICETOOLS_GAMES_MGA_TOUCH_H
#define SPICETOOLS_GAMES_MGA_TOUCH_H

#include <cstdint>
#include <vector>
#include "hooks/devicehook.h"
#include "touch/touch.h"

namespace games::shared {

    class TwTouchDevice : public CustomHandle {
    private:

        // report buffer
        std::vector<TouchEvent> report_buffer;
        unsigned int continuous_reads = 0;

    public:
        bool open(LPCWSTR lpFileName) override;

        int read(LPVOID lpBuffer, DWORD nNumberOfBytesToRead) override;

        int write(LPCVOID lpBuffer, DWORD nNumberOfBytesToWrite) override;

        int device_io(DWORD dwIoControlCode, LPVOID lpInBuffer, DWORD nInBufferSize, LPVOID lpOutBuffer,
                      DWORD nOutBufferSize) override;

        bool close() override;
    };
}

#endif //SPICETOOLS_GAMES_MGA_TOUCH_H
