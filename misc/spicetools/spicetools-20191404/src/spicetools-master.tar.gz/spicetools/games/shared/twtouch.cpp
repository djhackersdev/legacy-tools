#include "twtouch.h"
#include "util/logging.h"

namespace games::shared {

#pragma pack(push, 1)
    struct TwTouchEventReport {
        uint32_t type;
        uint8_t padding1[8];
        uint32_t status;
        uint16_t x;
        uint16_t y;
        uint8_t padding2[4];
    };
#pragma pack(pop)

    bool TwTouchDevice::open(LPCWSTR lpFileName) {
        return wcscmp(lpFileName, L"\\\\.\\TwTouchDriver") == 0;
    }

    int TwTouchDevice::read(LPVOID lpBuffer, DWORD nNumberOfBytesToRead) {

        // ignore if buffer is too small
        if (nNumberOfBytesToRead < sizeof(TwTouchEventReport))
            return 0;

        // get touch events once our buffer is empty
        if (this->report_buffer.empty())
            touch_get_events(&this->report_buffer);

        // check if an event is available
        if (this->report_buffer.empty()) {

            /*
             * We limit the number of continuous reads the device can do
             * since games may try to read all at once into a buffer.
             * QMA has a limit of 100 events going in at once.
             * To avoid this we have to return nothing at least once every 100 read calls.
             */
            if (this->continuous_reads >= 99) {

                // reset counter
                this->continuous_reads = 0;

            } else {

                // get touch points
                std::vector<TouchPoint> touchPoints;
                touch_get_points(&touchPoints);

                // insert fake events
                for (auto touchPoint : touchPoints) {
                    TouchEvent touchEvent{};
                    touchEvent.id = touchPoint.id;
                    touchEvent.type = TOUCH_MOVE;
                    touchEvent.x = touchPoint.x;
                    touchEvent.y = touchPoint.y;
                    this->report_buffer.push_back(touchEvent);
                }
            }

        } else {

            // increase counter
            this->continuous_reads++;

            // pick the first event
            TouchEvent* touchEvent = &this->report_buffer[0];

            // build report
            TwTouchEventReport report = {};

            /*
             * Known report types
             *
             * ID    Size  Desc
             * 0x01  20
             * 0x02  16
             * 0x03  20    QMA checks uint32_t at offset 12 and uint16_t at offset 16
             * 0x04  16
             * 0x05  24    Touch Event
             * 0x06  24
             * 0x08  24
             * 0x09  24
             * 0x0B  32
             * 0x0C  16
             * 0x0D  36
             * 0x0E  16
             */
            report.type = 0x05;

            // set report data
            switch (touchEvent->type) {
                case TOUCH_DOWN:
                case TOUCH_MOVE:

                    // if the status is 1 it means it's pressed
                    report.status = 1;
                    report.x = (uint16_t) touchEvent->x;
                    report.y = (uint16_t) touchEvent->y;

                    break;
                case TOUCH_UP:

                    // status 3 (and 12?) is a touch up event
                    report.status = 3;
                    report.x = 0;
                    report.y = 0;

                    break;
            }

            // erase touch event
            this->report_buffer.erase(this->report_buffer.begin());

            // copy report to buffer
            memcpy(lpBuffer, &report, sizeof(report));
            return sizeof(report);
        }

        // no touch event available for read
        return 0;
    }

    int TwTouchDevice::write(LPCVOID lpBuffer, DWORD nNumberOfBytesToWrite) {
        return 0;
    }

    int TwTouchDevice::device_io(DWORD dwIoControlCode, LPVOID lpInBuffer, DWORD nInBufferSize, LPVOID lpOutBuffer,
            DWORD nOutBufferSize) {
        return 0;
    }

    bool TwTouchDevice::close() {
        return true;
    }
}
