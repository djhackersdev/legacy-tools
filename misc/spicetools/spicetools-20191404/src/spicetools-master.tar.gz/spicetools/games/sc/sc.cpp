#include "sc.h"
#include "hooks/devicehook.h"
#include "hooks/rs232dummy.h"
#include "games/shared/lcdhandle.h"
#include "games/shared/twtouch.h"
#include "util/logging.h"
#include "util/detour.h"
#include "util/libutils.h"

static int __cdecl setvolume_stub(const char* set_volume_file) {
    return 0;
}

games::sc::SCGame::SCGame() : Game("Steel Chronicle") {
}

void games::sc::SCGame::attach() {
    Game::attach();

    // RS232 fix
    rs232dummy_init();

    // add devices
    devicehook_init();
    devicehook_add(new games::shared::TwTouchDevice());
    devicehook_add(new games::shared::LCDHandle());

    // set volume hook - default function causes access violation on some setups
    HMODULE setvolume_module = libutils::load_library("setvolume.dll");
    detour::inline_hook((void *) &setvolume_stub, (DWORD_PTR) libutils::get_proc(
            setvolume_module, "?setvolume@@YAHPAD@Z"));
}

void games::sc::SCGame::detach() {
    Game::detach();
    devicehook_dispose();
}
