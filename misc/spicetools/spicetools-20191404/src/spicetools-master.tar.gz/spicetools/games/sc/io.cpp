#include "io.h"

std::vector<Button*>* games::sc::get_buttons() {
    static std::vector<Button*>* buttons = nullptr;
    if (buttons == nullptr) {
        buttons = GameAPI::Buttons::getButtons("Steel Chronicles Victroopers");
        GameAPI::Buttons::sortButtons(
                &buttons,
                "Service",
                "Test"
        );
    }
    return buttons;
}
