#include "popn.h"
#include <cstdint>
#include <cstring>
#include "rawinput/rawinput.h"
#include "util/detour.h"
#include "util/libutils.h"
#include "cfg/button.h"
#include "cfg/api.h"
#include "hooks/sleephook.h"
#include "launcher/launcher.h"
#include "misc/eamuse.h"
#include "io.h"

namespace games::popn {

    static int __cdecl usbCheckAlive() {
        return 1;
    }

    static int __cdecl usbCheckSecurityNew() {
        return 0;
    }

    static int __cdecl usbCoinGet() {
        return eamuse_coin_get_stock();
    }

    static int __cdecl usbCoinMode() {
        return 0;
    }

    static int __cdecl usbEnd() {
        return 0;
    }

    static int __cdecl usbFirmResult() {
        return 0;
    }

    static int __cdecl usbGetKEYID() {
        return 0;
    }

    static int __cdecl usbGetSecurity() {
        return 0;
    }

    static int __cdecl usbLamp(uint32_t lamp_bits) {

        // get lights
        auto lights = get_lights();

        // bit scan
        static const size_t mapping[] = {
                Lights::Button1,
                Lights::Button2,
                Lights::Button3,
                Lights::Button4,
                Lights::Button5,
                Lights::Button6,
                Lights::Button7,
                Lights::Button8,
                Lights::Button9,
        };
        for (size_t i = 0; i < 9; i++) {
            float value = (lamp_bits & (1 << (i + 23))) ? 1.f : 0.f;
            GameAPI::Lights::writeLight(RI_MGR, lights->at(mapping[i]), value);
        }

        // flush output
        RI_MGR->devices_flush_output();

        // return no error
        return 0;
    }

    static int __cdecl usbPadRead(unsigned int *pad_bits) {

        // get buttons
        auto buttons = get_buttons();

        // reset
        *pad_bits = 0;

        // service
        if (GameAPI::Buttons::getState(RI_MGR, buttons->at(Buttons::Service)))
            *pad_bits |= 1 << 6;

        // test
        if (GameAPI::Buttons::getState(RI_MGR, buttons->at(Buttons::Test)))
            *pad_bits |= 1 << 7;

        // coin mech
        if (GameAPI::Buttons::getState(RI_MGR, buttons->at(Buttons::CoinMech)))
            *pad_bits |= 1 << 22;

        // buttons
        static const size_t mapping[] = {
                Buttons::Button1,
                Buttons::Button2,
                Buttons::Button3,
                Buttons::Button4,
                Buttons::Button5,
                Buttons::Button6,
                Buttons::Button7,
                Buttons::Button8,
                Buttons::Button9,
        };
        for (unsigned int i = 0; i < 9; i++) {
            if (GameAPI::Buttons::getState(RI_MGR, buttons->at(mapping[i])))
                *pad_bits |= 1 << (8 + i);
        }

        // return no error
        return 0;
    }

    static int __cdecl usbPadReadLast(uint8_t *a1) {
        memset(a1, 0, 40);
        return 0;
    }

    static int __cdecl usbSecurityInit() {
        return 0;
    }

    static int __cdecl usbSecurityInitDone() {
        return 0;
    }

    static int __cdecl usbSecuritySearch() {
        return 0;
    }

    static int __cdecl usbSecuritySearchDone() {
        return 0;
    }

    static int __cdecl usbSecuritySelect() {
        return 0;
    }

    static int __cdecl usbSecuritySelectDone() {
        return 0;
    }

    static int __cdecl usbSetExtIo() {
        return 0;
    }

    static int __cdecl usbStart() {
        return 0;
    }

    static int __cdecl usbWdtReset() {
        return 0;
    }

    static int __cdecl usbWdtStart() {
        return 0;
    }

    static int __cdecl usbWdtStartDone() {
        return 0;
    }

    POPNGame::POPNGame() : Game("Pop'n Music") {
    }

    void POPNGame::pre_attach() {
        Game::pre_attach();

        // load without resolving references
        // makes game not trigger DLLMain which results in an error due to missing EZUSB device
        LoadLibraryEx((MODULE_PATH_STR + "ezusb.dll").c_str(), nullptr, DONT_RESOLVE_DLL_REFERENCES);
    }

    void POPNGame::attach() {
        Game::attach();

        /*
         * Fast Boot (TM) Patch
         * Game tries to create some directories and if it fails it will sleep for 1 second
         * We make it sleep 1ms each time instead
         */
        sleephook_init(999, 1);

        // EZUSB hooks
        HINSTANCE ezusb = libutils::try_library("ezusb.dll");
        if (ezusb) {
            detour::inline_hook((void *) &usbCheckAlive,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbCheckAlive@@YAHXZ"));
            detour::inline_hook((void *) &usbCheckSecurityNew,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbCheckSecurityNew@@YAHH@Z"));
            detour::inline_hook((void *) &usbCoinGet,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbCoinGet@@YAHH@Z"));
            detour::inline_hook((void *) &usbCoinMode,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbCoinMode@@YAHH@Z"));
            detour::inline_hook((void *) &usbEnd,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbEnd@@YAHXZ"));
            detour::inline_hook((void *) &usbFirmResult,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbFirmResult@@YAHXZ"));
            detour::inline_hook((void *) &usbGetKEYID,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbGetKEYID@@YAHPAEH@Z"));
            detour::inline_hook((void *) &usbGetSecurity,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbGetSecurity@@YAHHPAE@Z"));
            detour::inline_hook((void *) &usbLamp,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbLamp@@YAHH@Z"));
            detour::inline_hook((void *) &usbPadRead,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbPadRead@@YAHPAK@Z"));
            detour::inline_hook((void *) &usbPadReadLast,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbPadReadLast@@YAHPAE@Z"));
            detour::inline_hook((void *) &usbSecurityInit,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbSecurityInit@@YAHXZ"));
            detour::inline_hook((void *) &usbSecurityInitDone,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbSecurityInitDone@@YAHXZ"));
            detour::inline_hook((void *) &usbSecuritySearch,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbSecuritySearch@@YAHXZ"));
            detour::inline_hook((void *) &usbSecuritySearchDone,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbSecuritySearchDone@@YAHXZ"));
            detour::inline_hook((void *) &usbSecuritySelect,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbSecuritySelect@@YAHH@Z"));
            detour::inline_hook((void *) &usbSecuritySelectDone,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbSecuritySelectDone@@YAHXZ"));
            detour::inline_hook((void *) &usbSetExtIo,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbSetExtIo@@YAHH@Z"));
            detour::inline_hook((void *) &usbStart,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbStart@@YAHH@Z"));
            detour::inline_hook((void *) &usbWdtReset,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbWdtReset@@YAHXZ"));
            detour::inline_hook((void *) &usbWdtStart,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbWdtStart@@YAHH@Z"));
            detour::inline_hook((void *) &usbWdtStartDone,
                                (DWORD_PTR) libutils::try_proc(ezusb, "?usbWdtStartDone@@YAHXZ"));
        }
    }
}
