#ifndef SPICETOOLS_GAMES_POPN_H
#define SPICETOOLS_GAMES_POPN_H

#include "games/game.h"

namespace games::popn {

    class POPNGame : public games::Game {
    public:
        POPNGame();
        virtual void pre_attach() override;
        virtual void attach() override;
    };
}

#endif //SPICETOOLS_GAMES_POPN_H
