#include "io.h"

std::vector<Button*>* games::nost::get_buttons() {
    static std::vector<Button*>* buttons = nullptr;
    if (buttons == nullptr) {
        buttons = GameAPI::Buttons::getButtons("Nostalgia");
        GameAPI::Buttons::sortButtons(&buttons,
                             "Service",
                             "Test",
                             "Coin Mech",
                             "Key 1",
                             "Key 2",
                             "Key 3",
                             "Key 4",
                             "Key 5",
                             "Key 6",
                             "Key 7",
                             "Key 8",
                             "Key 9",
                             "Key 10",
                             "Key 11",
                             "Key 12",
                             "Key 13",
                             "Key 14",
                             "Key 15",
                             "Key 16",
                             "Key 17",
                             "Key 18",
                             "Key 19",
                             "Key 20",
                             "Key 21",
                             "Key 22",
                             "Key 23",
                             "Key 24",
                             "Key 25",
                             "Key 26",
                             "Key 27",
                             "Key 28"
        );
    }
    return buttons;
}

std::vector<Analog*>* games::nost::get_analogs() {
    static std::vector<Analog*>* analogs = nullptr;
    if (analogs == nullptr) {
        analogs = GameAPI::Analogs::getAnalogs("Nostalgia");
        GameAPI::Analogs::sortAnalogs(&analogs,
                             "Key 1",
                             "Key 2",
                             "Key 3",
                             "Key 4",
                             "Key 5",
                             "Key 6",
                             "Key 7",
                             "Key 8",
                             "Key 9",
                             "Key 10",
                             "Key 11",
                             "Key 12",
                             "Key 13",
                             "Key 14",
                             "Key 15",
                             "Key 16",
                             "Key 17",
                             "Key 18",
                             "Key 19",
                             "Key 20",
                             "Key 21",
                             "Key 22",
                             "Key 23",
                             "Key 24",
                             "Key 25",
                             "Key 26",
                             "Key 27",
                             "Key 28"
        );
    }
    return analogs;
}
