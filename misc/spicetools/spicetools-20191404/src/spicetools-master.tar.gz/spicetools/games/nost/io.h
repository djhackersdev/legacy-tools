#ifndef SPICETOOLS_GAMES_NOST_IO_H
#define SPICETOOLS_GAMES_NOST_IO_H

#include <vector>
#include "cfg/api.h"

namespace games::nost {

    // all buttons in correct order
    namespace Buttons {
        enum {
            Service,
            Test,
            CoinMech,
            Key1,
            Key2,
            Key3,
            Key4,
            Key5,
            Key6,
            Key7,
            Key8,
            Key9,
            Key10,
            Key11,
            Key12,
            Key13,
            Key14,
            Key15,
            Key16,
            Key17,
            Key18,
            Key19,
            Key20,
            Key21,
            Key22,
            Key23,
            Key24,
            Key25,
            Key26,
            Key27,
            Key28,
        };
    }

    // all analogs in correct order
    namespace Analogs {
        enum {
            Key1,
            Key2,
            Key3,
            Key4,
            Key5,
            Key6,
            Key7,
            Key8,
            Key9,
            Key10,
            Key11,
            Key12,
            Key13,
            Key14,
            Key15,
            Key16,
            Key17,
            Key18,
            Key19,
            Key20,
            Key21,
            Key22,
            Key23,
            Key24,
            Key25,
            Key26,
            Key27,
            Key28,
        };
    }

    // getters
    std::vector<Button*>* get_buttons();
    std::vector<Analog*>* get_analogs();
}

#endif //SPICETOOLS_GAMES_NOST_IO_H
