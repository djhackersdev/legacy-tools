// enable touch functions - set version to windows 7
// mingw otherwise doesn't load touch stuff
#define _WIN32_WINNT 0x0601

#include "nost.h"
#include "util/logging.h"
#include "hooks/setupapihook.h"
#include "util/detour.h"
#include "touch/touch.h"
#include "hooks/dxhook.h"
#include "avs/game.h"
#include "util/utils.h"

namespace games::nost {

    // touch stuff
    static BOOL (WINAPI *GetTouchInputInfo_orig)(HANDLE, UINT, PTOUCHINPUT, int);
    static bool NOSTALGIA_USE_MOUSE = false;
    static std::vector<TouchEvent> NOSTALGIA_TOUCH_EVENTS;
    static std::vector<TouchPoint> NOSTALGIA_TOUCH_POINTS;

    // stuff for faking touch screen
    typedef int (WINAPI * GetSystemMetrics_t)(int nIndex);
    static GetSystemMetrics_t GetSystemMetrics_orig = nullptr;
    int WINAPI GetSystemMetrics_hook(int nIndex) {

        /*
         * fake touch screen
         * the game requires 0x01 and 0x02 flags to be set
         * 0x40 and 0x80 are set for completeness
         */
        if (nIndex == 94)
            return 0x01 | 0x02 | 0x40 | 0x80;

        // call original
        if (GetSystemMetrics_orig != nullptr)
            return GetSystemMetrics_orig(nIndex);

        // return error
        return 0;
    }

    NostGame::NostGame() : Game("Nostalgia") {
    }

    void NostGame::attach() {
        Game::attach();

        // fake touchscreen
        ///////////////////

        SETUPAPI_SETTINGS touch_settings{};

        // GUID must be set to 0 to make SETUPAPI hook working
        touch_settings.class_guid[0] = 0x00000000;
        touch_settings.class_guid[1] = 0x00000000;
        touch_settings.class_guid[2] = 0x00000000;
        touch_settings.class_guid[3] = 0x00000000;

        /*
         * set hardware ID containing VID and PID
         * there is 3 known VID/PID combinations known to the game:
         * VID_04DD&PID_97CB
         * VID_0EEF&PID_C000
         * VID_29BD&PID_4101
         */
        std::string touch_hardwareid = "VID_29BD&PID_4101";
        memcpy(touch_settings.property_hardwareid, touch_hardwareid.c_str(), strlen(touch_hardwareid.c_str()) + 1);

        // apply settings
        setupapihook_init(avs::game::DLL_INSTANCE);
        setupapihook_add(touch_settings);

        // system metrics hook
        GetSystemMetrics_orig = (GetSystemMetrics_t) detour::iat_try(
                "GetSystemMetrics", (void *) &GetSystemMetrics_hook, avs::game::DLL_INSTANCE);
    }

    static BOOL WINAPI GetTouchInputInfoHook(HANDLE hTouchInput, UINT cInputs, PTOUCHINPUT pInputs, int cbSize) {

        // check if original should be called
        if (hTouchInput != &GetTouchInputInfoHook)
            return GetTouchInputInfo_orig(hTouchInput, cInputs, pInputs, cbSize);

        // set touch inputs
        bool mouse_used = false;
        static bool mouse_state_old = false;
        for (UINT input = 0; input < cInputs; input++) {
            PTOUCHINPUT touchInput = &pInputs[input];

            // clear touch input
            touchInput->x = 0;
            touchInput->y = 0;
            touchInput->hSource = nullptr;
            touchInput->dwID = 0;
            touchInput->dwFlags = 0;
            touchInput->dwMask = 0;
            touchInput->dwTime = 0;
            touchInput->dwExtraInfo = 0;
            touchInput->cxContact = 0;
            touchInput->cyContact = 0;

            // get touch event
            TouchEvent* touch_event = nullptr;
            if (NOSTALGIA_TOUCH_EVENTS.size() > input)
                touch_event = &NOSTALGIA_TOUCH_EVENTS.at(input);

            // check touch point
            if (touch_event) {

                // set touch point
                touchInput->x = touch_event->x * 100;
                touchInput->y = touch_event->y * 100;
                touchInput->hSource = hTouchInput;
                touchInput->dwID = touch_event->id;
                touchInput->dwFlags = 0;
                switch (touch_event->type) {
                    case TOUCH_DOWN:
                        touchInput->dwFlags |= TOUCHEVENTF_DOWN;
                        break;
                    case TOUCH_MOVE:
                        touchInput->dwFlags |= TOUCHEVENTF_MOVE;
                        break;
                    case TOUCH_UP:
                        touchInput->dwFlags |= TOUCHEVENTF_UP;
                        break;
                }
                touchInput->dwMask = 0;
                touchInput->dwTime = 0;
                touchInput->dwExtraInfo = 0;
                touchInput->cxContact = 0;
                touchInput->cyContact = 0;

            } else if (NOSTALGIA_USE_MOUSE && !mouse_used) {

                // disable further mouse inputs this call
                mouse_used = true;

                // get mouse state
                bool mouse_state = (GetKeyState(VK_LBUTTON) & 0x100) != 0;

                // check event needs to be generated
                if (mouse_state || mouse_state_old) {

                    // get current cursor position
                    POINT cursorPos{};
                    GetCursorPos(&cursorPos);

                    // set touch input to mouse
                    touchInput->x = cursorPos.x * 100;
                    touchInput->y = cursorPos.y * 100;
                    touchInput->hSource = hTouchInput;
                    touchInput->dwID = 0;
                    touchInput->dwFlags = 0;
                    if (mouse_state && !mouse_state_old)
                        touchInput->dwFlags |= TOUCHEVENTF_DOWN;
                    else if (mouse_state && mouse_state_old)
                        touchInput->dwFlags |= TOUCHEVENTF_MOVE;
                    else if (!mouse_state && mouse_state_old)
                        touchInput->dwFlags |= TOUCHEVENTF_UP;
                    touchInput->dwMask = 0;
                    touchInput->dwTime = 0;
                    touchInput->dwExtraInfo = 0;
                    touchInput->cxContact = 0;
                    touchInput->cyContact = 0;
                }

                // save old state
                mouse_state_old = mouse_state;
            } else {

                /*
                 * For some reason, the game won't show an active touch point unless a move event
                 * triggers in the same frame. To work around this, we just supply a fake move
                 * event if we didn't update the same pointer ID in the same call.
                 */

                // find touch point which has no associated input event
                TouchPoint* touch_point = nullptr;
                for (TouchPoint &tp : NOSTALGIA_TOUCH_POINTS) {
                    bool found = false;
                    for (UINT i = 0; i < cInputs; i++) {
                        if (input > 0 && pInputs[i].dwID == tp.id) {
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        touch_point = &tp;
                        break;
                    }
                }

                // check if unused touch point was found
                if (touch_point) {

                    // set touch point
                    touchInput->x = touch_point->x * 100;
                    touchInput->y = touch_point->y * 100;
                    touchInput->hSource = hTouchInput;
                    touchInput->dwID = touch_point->id;
                    touchInput->dwFlags = 0;
                    touchInput->dwFlags |= TOUCHEVENTF_MOVE;
                    touchInput->dwMask = 0;
                    touchInput->dwTime = 0;
                    touchInput->dwExtraInfo = 0;
                    touchInput->cxContact = 0;
                    touchInput->cyContact = 0;
                }
            }
        }

        // return success
        return TRUE;
    }

    void touch_update() {

        // no need for hooks if touch is available
        if (is_win_touch_available() && !DXHOOK_SHOW_CURSOR)
            return;

        // get nostalgia window handle
        static HWND hWnd = nullptr;
        if (hWnd == nullptr) {
            hWnd = GetForegroundWindow();
            if (!string_begins_with(GetActiveWindowTitle(), "nostalgia"))
                hWnd = FindWindowBeginsWith("nostalgia");

            // check window
            if (hWnd == nullptr)
                return;

            // check if windowed
            if (DXHOOK_WINDOWED) {

                // remove style borders
                LONG lStyle = GetWindowLong(hWnd, GWL_STYLE);
                lStyle &= ~(WS_CAPTION | WS_THICKFRAME | WS_MINIMIZE | WS_MAXIMIZE | WS_SYSMENU);
                SetWindowLongPtr(hWnd, GWL_STYLE, lStyle);

                // remove ex style borders
                LONG lExStyle = GetWindowLong(hWnd, GWL_EXSTYLE);
                lExStyle &= ~(WS_EX_DLGMODALFRAME | WS_EX_CLIENTEDGE | WS_EX_STATICEDGE);
                SetWindowLongPtr(hWnd, GWL_EXSTYLE, lExStyle);

                // update window
                SetWindowPos(hWnd, nullptr, 0, 0, 0, 0,
                             SWP_FRAMECHANGED | SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOOWNERZORDER);

                // create touch window
                touch_create_wnd(hWnd);
                NOSTALGIA_USE_MOUSE = false;

            } else {

                // mouse position based input only
                touch_attach_dx_hook();
                NOSTALGIA_USE_MOUSE = true;
            }

            // hooks
            GetTouchInputInfo_orig = (BOOL (WINAPI *)(HANDLE, UINT, PTOUCHINPUT, int)) detour::iat_try(
                    "GetTouchInputInfo", (void*) GetTouchInputInfoHook, avs::game::DLL_INSTANCE);
        }

        // update touch events
        if (hWnd != nullptr) {

            // get touch events
            NOSTALGIA_TOUCH_EVENTS.clear();
            touch_get_events(&NOSTALGIA_TOUCH_EVENTS);

            // get touch points
            NOSTALGIA_TOUCH_POINTS.clear();
            touch_get_points(&NOSTALGIA_TOUCH_POINTS);

            // get event count
            auto event_count = NOSTALGIA_TOUCH_EVENTS.size();
            if (NOSTALGIA_USE_MOUSE)
                event_count++;

            // for the fake move events
            event_count += MAX(0, (int) NOSTALGIA_TOUCH_POINTS.size() - (int) NOSTALGIA_TOUCH_EVENTS.size());

            // check if new events are available
            if (event_count > 0) {

                // send fake event to make the game update it's touch inputs
                auto wndProc = (LRESULT (WINAPI *)(HWND, UINT, WPARAM, LPARAM)) GetWindowLongPtr(
                        hWnd, GWLP_WNDPROC);
                wndProc(hWnd, WM_TOUCH, MAKEWORD(event_count, 0), (LPARAM) &GetTouchInputInfoHook);
            }
        }
    }
}
