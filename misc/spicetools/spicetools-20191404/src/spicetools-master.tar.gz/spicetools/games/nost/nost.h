#ifndef SPICETOOLS_GAMES_NOST_H
#define SPICETOOLS_GAMES_NOST_H

#include "games/game.h"

namespace games::nost {

    class NostGame : public games::Game {
    public:
        NostGame();
        virtual void attach() override;
    };

    void touch_update();
}

#endif //SPICETOOLS_GAMES_NOST_H
