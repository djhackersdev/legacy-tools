#ifndef SPICETOOLS_GAMES_DEA_IO_H
#define SPICETOOLS_GAMES_DEA_IO_H

#include <vector>
#include "cfg/api.h"

namespace games::dea {

    // all buttons in correct order
    namespace Buttons {
        enum {
            Service,
            Test,
            P1Start,
            P1Left,
            P1Right,
            P2Start,
            P2Left,
            P2Right
        };
    }

    // getters
    std::vector<Button*>* get_buttons();
}

#endif //SPICETOOLS_GAMES_DEA_IO_H
