#include "io.h"

std::vector<Button*>* games::dea::get_buttons() {
    static std::vector<Button*>* buttons = nullptr;
    if (buttons == nullptr) {
        buttons = GameAPI::Buttons::getButtons("Dance Evolution");
        GameAPI::Buttons::sortButtons(
                &buttons,
                "Service",
                "Test",
                "P1 Start",
                "P1 Left",
                "P1 Right",
                "P2 Start",
                "P2 Left",
                "P2 Right"
        );
    }
    return buttons;
}
