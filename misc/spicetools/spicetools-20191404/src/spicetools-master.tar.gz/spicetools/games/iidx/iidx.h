#ifndef SPICETOOLS_GAMES_IIDX_H
#define SPICETOOLS_GAMES_IIDX_H

#include "games/game.h"
#include <mutex>

namespace games::iidx {

    // settings
    extern bool FLIPCAMS;

    // state
    extern char IIDXIO_LED_TICKER[10];
    extern bool IIDXIO_LED_TICKER_READONLY;
    extern std::mutex IIDX_LED_TICKER_LOCK;

    class IIDXGame : public games::Game {
    public:
        IIDXGame();
        virtual void attach();
        virtual void detach();
    };

    // helper methods
    uint32_t get_pad();
    void write_lamp(uint16_t lamp);
    void write_led(uint8_t led);
    void write_top_lamp(uint8_t top_lamp);
    void write_top_neon(uint8_t top_neon);
    unsigned char get_tt(int player, bool slow);
    unsigned char get_slider(uint8_t slider);
}

#endif //SPICETOOLS_GAMES_IIDX_H
