#ifndef SPICETOOLS_GAMES_IIDX_IO_H
#define SPICETOOLS_GAMES_IIDX_IO_H

#include <vector>
#include "cfg/api.h"

namespace games::iidx {

    // all buttons in correct order
    namespace Buttons {
        enum {
            Service,
            Test,
            P1_1,
            P1_2,
            P1_3,
            P1_4,
            P1_5,
            P1_6,
            P1_7,
            P1_TTPlus,
            P1_TTMinus,
            P1_TTPlusMinus,
            P1_Start,
            P2_1,
            P2_2,
            P2_3,
            P2_4,
            P2_5,
            P2_6,
            P2_7,
            P2_TTPlus,
            P2_TTMinus,
            P2_TTPlusMinus,
            P2_Start,
            Effect,
            VEFX
        };
    }

    // all analogs in correct order
    namespace Analogs {
        enum {
            TT_P1,
            TT_P2,
            VEFX,
            LowEQ,
            HiEQ,
            Filter,
            PlayVolume
        };
    }

    // all lights in correct order
    namespace Lights {
        enum {
            P1_1,
            P1_2,
            P1_3,
            P1_4,
            P1_5,
            P1_6,
            P1_7,
            P2_1,
            P2_2,
            P2_3,
            P2_4,
            P2_5,
            P2_6,
            P2_7,
            P1_Start,
            P2_Start,
            VEFX,
            Effect,
            SpotLight1,
            SpotLight2,
            SpotLight3,
            SpotLight4,
            SpotLight5,
            SpotLight6,
            SpotLight7,
            SpotLight8,
            NeonLamp
        };
    }

    // getters
    std::vector<Button*>* get_buttons();
    std::vector<Analog*>* get_analogs();
    std::vector<Light*>* get_lights();
}

#endif //SPICETOOLS_GAMES_IIDX_IO_H
