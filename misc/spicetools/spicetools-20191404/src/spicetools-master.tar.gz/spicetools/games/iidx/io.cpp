#include "io.h"
#include "launcher/launcher.h"

std::vector<Button*>* games::iidx::get_buttons() {
    static std::vector<Button*>* buttons = nullptr;
    if (buttons == nullptr) {
        buttons = GameAPI::Buttons::getButtons("Beatmania IIDX");
        GameAPI::Buttons::sortButtons(
                &buttons,
                "Service",
                "Test",
                "P1 1",
                "P1 2",
                "P1 3",
                "P1 4",
                "P1 5",
                "P1 6",
                "P1 7",
                "P1 TT+",
                "P1 TT-",
                "P1 TT+/-",
                "P1 Start",
                "P2 1",
                "P2 2",
                "P2 3",
                "P2 4",
                "P2 5",
                "P2 6",
                "P2 7",
                "P2 TT+",
                "P2 TT-",
                "P2 TT+/-",
                "P2 Start",
                "EFFECT",
                "VEFX"
        );
    }
    return buttons;
}

std::vector<Analog*>* games::iidx::get_analogs() {
    static std::vector<Analog *> *analogs = nullptr;
    if (analogs == nullptr) {
        analogs = GameAPI::Analogs::getAnalogs("Beatmania IIDX");
        GameAPI::Analogs::sortAnalogs(
                &analogs,
                "Turntable P1",
                "Turntable P2",
                "VEFX",
                "Low-EQ",
                "Hi-EQ",
                "Filter",
                "Play Volume"
        );
    }
    return analogs;
}

std::vector<Light*>* games::iidx::get_lights() {
    static std::vector<Light*>* lights = nullptr;
    if (lights == nullptr) {
        lights = GameAPI::Lights::getLights("Beatmania IIDX");
        GameAPI::Lights::sortLights(
                &lights,
                "P1 1",
                "P1 2",
                "P1 3",
                "P1 4",
                "P1 5",
                "P1 6",
                "P1 7",
                "P2 1",
                "P2 2",
                "P2 3",
                "P2 4",
                "P2 5",
                "P2 6",
                "P2 7",
                "P1 Start",
                "P2 Start",
                "VEFX",
                "Effect",
                "Spot Light 1",
                "Spot Light 2",
                "Spot Light 3",
                "Spot Light 4",
                "Spot Light 5",
                "Spot Light 6",
                "Spot Light 7",
                "Spot Light 8",
                "Neon Lamp"
        );
    }
    return lights;
}
