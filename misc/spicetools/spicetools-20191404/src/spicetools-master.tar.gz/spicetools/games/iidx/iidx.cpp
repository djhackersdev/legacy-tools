#include "iidx.h"
#include <mfobjects.h>
#include <mfidl.h>
#include "hooks/rs232dummy.h"
#include "hooks/sleephook.h"
#include "hooks/devicehook.h"
#include "hooks/setupapihook.h"
#include "hooks/cfgmgr32hook.h"
#include "util/utils.h"
#include "util/detour.h"
#include "avs/game.h"
#include "ezusb.h"
#include "fmserial.h"
#include "io.h"

namespace games::iidx {

    // settings
    bool FLIPCAMS = false;

    // states
    static uint16_t IIDXIO_TT_STATE[2]{};
    static uint16_t IIDXIO_TT_DIRECTION[2]{};
    static bool IIDXIO_TT_PRESSED[2]{};
    char IIDXIO_LED_TICKER[10] = {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '\x00'};
    bool IIDXIO_LED_TICKER_READONLY = false;
    std::mutex IIDX_LED_TICKER_LOCK;

    /*
     * Dirty Workaround for IO Device
     * Game gets registry object via SetupDiOpenDevRegKey, then looks up "PortName" via RegQueryValueExA
     * We ignore the first and just cheat on the second.
     */
    typedef BOOL (WINAPI *RegQueryValueExA_t)(HKEY, LPCTSTR, LPDWORD, LPDWORD, LPBYTE, LPDWORD);

    static RegQueryValueExA_t RegQueryValueExA_real;

    static WINAPI BOOL RegQueryValueExA_hook(HKEY hKey, LPCTSTR lpValueName, LPDWORD lpReserved, LPDWORD lpType,
                                             LPBYTE lpData, LPDWORD lpcbData) {
        // check for port name lookup
        if (std::string(lpValueName) == "PortName") {
            std::string port = "COM1";
            memcpy(lpData, port.c_str(), port.length() + 1);
            return true;
        }

        // fallback
        return RegQueryValueExA_real(hKey, lpValueName, lpReserved, lpType, lpData, lpcbData);
    }

    /*
     * Camera related stuff
     */
    static std::wstring CAMERA0_ID;
    static std::wstring CAMERA1_ID;
    typedef HRESULT (WINAPI *GetAllocatedString_t)(IMFActivate*, REFGUID, LPWSTR*, UINT32*);
    static GetAllocatedString_t GetAllocatedString_orig = nullptr;
    typedef HRESULT (WINAPI *MFEnumDeviceSources_t)(IMFAttributes*, IMFActivate***, UINT32*);
    static MFEnumDeviceSources_t MFEnumDeviceSources_orig = nullptr;
    static GUID MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_VIDCAP_SYMBOLIC_LINK = {
            0x58f0aad8, 0x22bf, 0x4f8a, {0xbb, 0x3d, 0xd2, 0xc4, 0x97, 0x8c, 0x6e, 0x2f}
    };

    static HRESULT WINAPI GetAllocatedString_hook(IMFActivate* This, REFGUID guidKey, LPWSTR *ppwszValue,
                                                  UINT32 *pcchLength) {
        // call the original
        HRESULT result = GetAllocatedString_orig(This, guidKey, ppwszValue, pcchLength);

        // try first camera
        wchar_t *pwc = nullptr;
        if (CAMERA0_ID.length() == 23)
            pwc = wcsstr(*ppwszValue, CAMERA0_ID.c_str());

        // try second camera if first wasn't found
        if (!pwc && CAMERA1_ID.length() == 23)
            wcsstr(*ppwszValue, CAMERA1_ID.c_str());

        // check if camera could be identified
        if (pwc) {

            // fake the USB IDs
            pwc[4] = L'2';
            pwc[5] = L'8';
            pwc[6] = L'8';
            pwc[7] = L'c';
            pwc[13] = L'0';
            pwc[14] = L'0';
            pwc[15] = L'0';
            pwc[16] = L'2';
            pwc[21] = L'0';
            pwc[22] = L'0';
        }

        // return orignal result
        return result;
    }

    static void hook_camera(IMFActivate* camera, size_t no, std::wstring camera_id, std::string camera_instance) {

        // logic based on camera no
        if (no == 0) {

            // don't hook if camera 0 is already hooked
            if (CAMERA0_ID.length() > 0)
                return;

            // save the camera ID
            CAMERA0_ID = camera_id;

            // cfgmgr hook
            CFGMGR32_HOOK_SETTING camera_setting;
            camera_setting.device_instance = 0xDEADBEEF;
            camera_setting.parent_instance = ~camera_setting.device_instance;
            camera_setting.device_id = "USB\\VEN_1022&DEV_7908";
            camera_setting.device_node_id = "USB\\VID_288C&PID_0002&MI_00\\?&????????&?&????";
            if (camera_instance.length() == 17)
                for (int i = 0; i < 17; i++)
                    camera_setting.device_node_id[28 + i] = camera_instance[i];
            cfgmgr32hook_add(camera_setting);
        }
        else if (no == 1) {

            // don't hook if camera 1 is already hooked
            if (CAMERA1_ID.length() > 0)
                return;

            // save the camera ID
            CAMERA1_ID = camera_id;

            // cfgmgr hook
            CFGMGR32_HOOK_SETTING camera_setting;
            camera_setting.device_instance = 0xBEEFDEAD;
            camera_setting.parent_instance = ~camera_setting.device_instance;
            camera_setting.device_id = "USB\\VEN_1022&DEV_7914";
            camera_setting.device_node_id = "USB\\VID_288C&PID_0002&MI_00\\?&????????&?&????";
            if (camera_instance.length() == 17)
                for (int i = 0; i < 17; i++)
                    camera_setting.device_node_id[28 + i] = camera_instance[i];
            cfgmgr32hook_add(camera_setting);
        }

        // save original method for later use
        if (GetAllocatedString_orig == nullptr)
            GetAllocatedString_orig = camera->lpVtbl->GetAllocatedString;

        // hook allocated string method for camera identification
        unsigned int OldProtect = 0;
        unsigned int Temp = 0;
        VirtualProtect(
                (void *) &camera->lpVtbl->GetAllocatedString,
                4096,
                PAGE_EXECUTE_READWRITE,
                (PDWORD) &OldProtect
        );
        camera->lpVtbl->GetAllocatedString = &GetAllocatedString_hook;
        VirtualProtect(
                (void *) &camera->lpVtbl->GetAllocatedString,
                4096,
                OldProtect,
                (PDWORD) &Temp
        );
    }

    static HRESULT WINAPI MFEnumDeviceSources_hook(IMFAttributes *pAttributes, IMFActivate ***pppSourceActivate,
                                                   UINT32 *pcSourceActivate) {

        // call original function
        HRESULT result_orig = MFEnumDeviceSources_orig(pAttributes, pppSourceActivate, pcSourceActivate);
        if (FAILED(result_orig))
            return result_orig;

        // check for capture devices
        if (!*pcSourceActivate)
            return result_orig;

        // iterate cameras
        size_t cam_hook_num = 0;
        for (size_t cam_num = 0; cam_num < *pcSourceActivate && cam_hook_num < 2; cam_num++) {

            // flip
            size_t cam_num_flipped = cam_num;
            if (FLIPCAMS)
                cam_num_flipped = *pcSourceActivate - cam_num - 1;

            // get camera link
            IMFActivate *camera = (*pppSourceActivate)[cam_num_flipped];
            LPWSTR camera_link_lpwstr;
            UINT32 camera_link_length;
            if (SUCCEEDED(camera->lpVtbl->GetAllocatedString(
                    camera,
                    MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_VIDCAP_SYMBOLIC_LINK,
                    &camera_link_lpwstr,
                    &camera_link_length))) {

                // cut name to make ID
                std::wstring camera_link_ws = std::wstring(camera_link_lpwstr);
                std::wstring camera_id = camera_link_ws.substr(8, 23);

                // get camera instance
                std::string camera_link = ws2s(camera_link_ws);
                std::string camera_instance = camera_link.substr(32, 17);

                // hook the camera
                hook_camera(camera, cam_hook_num, camera_id, camera_instance);

                // increase camera hook number
                cam_hook_num++;
            }
        }

        // return result
        return result_orig;
    }

    IIDXGame::IIDXGame() : Game("Beatmania IIDX") {
    }

    void IIDXGame::attach() {
        Game::attach();

        // generic
        rs232dummy_init();
        sleephook_init(1000, 1);
        devicehook_init();

        // call init
        setupapihook_init(avs::game::DLL_INSTANCE);

        // add old IO board
        SETUPAPI_SETTINGS settings1{};
        settings1.class_guid[0] = 0xAE18AA60;
        settings1.class_guid[1] = 0x11D47F6A;
        settings1.class_guid[2] = 0x0100DD97;
        settings1.class_guid[3] = 0x59B92902;
        std::string property1 = "Cypress EZ-USB (2235 - EEPROM missing)";
        memcpy(settings1.property_devicedesc, property1.c_str(), strlen(property1.c_str()) + 1);
        std::string interface_detail1 = "\\\\.\\Ezusb-0";
        memcpy(settings1.interface_detail, interface_detail1.c_str(), strlen(interface_detail1.c_str()) + 1);
        setupapihook_add(settings1);

        // add new IO board
        SETUPAPI_SETTINGS settings2{};
        settings2.class_guid[0] = 0x4D36E978;
        settings2.class_guid[1] = 0x11CEE325;
        settings2.class_guid[2] = 0x0008C1BF;
        settings2.class_guid[3] = 0x1803E12B;
        std::string property2 = "BIO2(VIDEO)";
        memcpy(settings2.property_devicedesc, property2.c_str(), strlen(property2.c_str()) + 1);
        std::string interface_detail2 = "COM1";
        memcpy(settings2.interface_detail, interface_detail2.c_str(), strlen(interface_detail2.c_str()) + 1);
        setupapihook_add(settings2);

        // IIDX < 25 with EZUSB input device
        devicehook_add(new EZUSBHandle());

        // IIDX 25 input device
        devicehook_add(new IIDXFMSerialHandle());

        // IO device workaround
        RegQueryValueExA_real = (RegQueryValueExA_t) detour::iat_try(
                "RegQueryValueExA", (void *) &RegQueryValueExA_hook, avs::game::DLL_INSTANCE);

        // camera media framework hook
        MFEnumDeviceSources_orig = (MFEnumDeviceSources_t) detour::iat_try(
                "MFEnumDeviceSources", (void *) &MFEnumDeviceSources_hook, avs::game::DLL_INSTANCE);

        // camera settings
        SETUPAPI_SETTINGS settings3{};
        settings3.class_guid[0] = 0x00000000;
        settings3.class_guid[1] = 0x00000000;
        settings3.class_guid[2] = 0x00000000;
        settings3.class_guid[3] = 0x00000000;
        std::string property3 = "USB Composite Device";
        memcpy(settings3.property_devicedesc, property3.c_str(), strlen(property3.c_str()) + 1);
        settings3.property_address[0] = 1;
        settings3.property_address[1] = 7;
        setupapihook_add(settings3);

        // init cfgmgr32 hooks
        cfgmgr32hook_init(avs::game::DLL_INSTANCE);
    }

    void IIDXGame::detach() {
        Game::detach();
        devicehook_dispose();
    }

    uint32_t get_pad() {
        DWORD pad = 0;

        // get buttons
        auto buttons = get_buttons();

        // player 1 buttons
        if (GameAPI::Buttons::getState(RI_MGR, buttons->at(Buttons::P1_1)))
            pad |= 1 << 0x08;
        if (GameAPI::Buttons::getState(RI_MGR, buttons->at(Buttons::P1_2)))
            pad |= 1 << 0x09;
        if (GameAPI::Buttons::getState(RI_MGR, buttons->at(Buttons::P1_3)))
            pad |= 1 << 0x0A;
        if (GameAPI::Buttons::getState(RI_MGR, buttons->at(Buttons::P1_4)))
            pad |= 1 << 0x0B;
        if (GameAPI::Buttons::getState(RI_MGR, buttons->at(Buttons::P1_5)))
            pad |= 1 << 0x0C;
        if (GameAPI::Buttons::getState(RI_MGR, buttons->at(Buttons::P1_6)))
            pad |= 1 << 0x0D;
        if (GameAPI::Buttons::getState(RI_MGR, buttons->at(Buttons::P1_7)))
            pad |= 1 << 0x0E;

        // player 2 buttons
        if (GameAPI::Buttons::getState(RI_MGR, buttons->at(Buttons::P2_1)))
            pad |= 1 << 0x0F;
        if (GameAPI::Buttons::getState(RI_MGR, buttons->at(Buttons::P2_2)))
            pad |= 1 << 0x10;
        if (GameAPI::Buttons::getState(RI_MGR, buttons->at(Buttons::P2_3)))
            pad |= 1 << 0x11;
        if (GameAPI::Buttons::getState(RI_MGR, buttons->at(Buttons::P2_4)))
            pad |= 1 << 0x12;
        if (GameAPI::Buttons::getState(RI_MGR, buttons->at(Buttons::P2_5)))
            pad |= 1 << 0x13;
        if (GameAPI::Buttons::getState(RI_MGR, buttons->at(Buttons::P2_6)))
            pad |= 1 << 0x14;
        if (GameAPI::Buttons::getState(RI_MGR, buttons->at(Buttons::P2_7)))
            pad |= 1 << 0x15;

        // player 1 start
        if (GameAPI::Buttons::getState(RI_MGR, buttons->at(Buttons::P1_Start)))
            pad |= 1 << 0x18;

        // player 2 start
        if (GameAPI::Buttons::getState(RI_MGR, buttons->at(Buttons::P2_Start)))
            pad |= 1 << 0x19;

        // VEFX
        if (GameAPI::Buttons::getState(RI_MGR, buttons->at(Buttons::VEFX)))
            pad |= 1 << 0x1A;

        // EFFECT
        if (GameAPI::Buttons::getState(RI_MGR, buttons->at(Buttons::Effect)))
            pad |= 1 << 0x1B;

        // test
        if (GameAPI::Buttons::getState(RI_MGR, buttons->at(Buttons::Test)))
            pad |= 1 << 0x1C;

        // service
        if (GameAPI::Buttons::getState(RI_MGR, buttons->at(Buttons::Service)))
            pad |= 1 << 0x1D;

        return ~(pad & 0xFFFFFF00);
    }

    void write_lamp(uint16_t lamp) {

        // mapping
        static const size_t mapping[] = {
                Lights::P1_1,
                Lights::P1_2,
                Lights::P1_3,
                Lights::P1_4,
                Lights::P1_5,
                Lights::P1_6,
                Lights::P1_7,
                Lights::P2_1,
                Lights::P2_2,
                Lights::P2_3,
                Lights::P2_4,
                Lights::P2_5,
                Lights::P2_6,
                Lights::P2_7,
        };

        // get lights
        auto lights = get_lights();

        // bit scan
        for (int i = 0; i < 14; i++) {
            float value = (lamp & (1 << i)) ? 1.f : 0.f;
            GameAPI::Lights::writeLight(RI_MGR, lights->at(mapping[i]), value);
        }
    }

    void write_led(uint8_t led) {

        // mapping
        static const size_t mapping[] = {
                Lights::P1_Start,
                Lights::P2_Start,
                Lights::VEFX,
                Lights::Effect,
        };

        // get lights
        auto lights = get_lights();

        // bit scan
        for (int i = 0; i < 4; i++) {
            auto value = (led & (1 << i)) ? 1.f : 0.f;
            GameAPI::Lights::writeLight(RI_MGR, lights->at(mapping[i]), value);
        }
    }

    void write_top_lamp(uint8_t top_lamp) {

        // mapping
        static const size_t mapping[] = {
                Lights::SpotLight1,
                Lights::SpotLight2,
                Lights::SpotLight3,
                Lights::SpotLight4,
                Lights::SpotLight5,
                Lights::SpotLight6,
                Lights::SpotLight7,
                Lights::SpotLight8,
        };

        // get lights
        auto lights = get_lights();

        // bit scan
        for (int i = 0; i < 8; i++) {
            auto value = (top_lamp & (1 << i)) ? 1.f : 0.f;
            GameAPI::Lights::writeLight(RI_MGR, lights->at(mapping[i]), value);
        }
    }

    void write_top_neon(uint8_t top_neon) {

        // get lights
        auto lights = get_lights();

        // write value
        auto value = top_neon > 0 ? 1.f : 0.f;
        GameAPI::Lights::writeLight(RI_MGR, lights->at(Lights::NeonLamp), value);
    }

    unsigned char get_tt(int player, bool slow) {

        // check change value for high/low precision
        uint16_t change = slow ? (uint16_t) 1 : (uint16_t) 4;

        // check player number
        if (player > 1)
            return 0;

        // get buttons
        std::vector<Button *> *buttons = get_buttons();
        bool ttp = GameAPI::Buttons::getState(RI_MGR, buttons->at(
                player != 0 ? Buttons::P2_TTPlus : Buttons::P1_TTPlus));
        bool ttm = GameAPI::Buttons::getState(RI_MGR, buttons->at(
                player != 0 ? Buttons::P2_TTMinus : Buttons::P1_TTMinus));
        bool ttpm = GameAPI::Buttons::getState(RI_MGR, buttons->at(
                player != 0 ? Buttons::P2_TTPlusMinus : Buttons::P1_TTPlusMinus));

        // TT+
        if (ttp)
            IIDXIO_TT_STATE[player] += change;

        // TT-
        if (ttm)
            IIDXIO_TT_STATE[player] -= change;

        // TT+/-
        if (ttpm) {
            if (IIDXIO_TT_DIRECTION[player] != 0u) {
                if (!IIDXIO_TT_PRESSED[player])
                    IIDXIO_TT_DIRECTION[player] = 0;
                IIDXIO_TT_STATE[player] += change;
            } else {
                if (!IIDXIO_TT_PRESSED[player])
                    IIDXIO_TT_DIRECTION[player] = 1;
                IIDXIO_TT_STATE[player] -= change;
            }
            IIDXIO_TT_PRESSED[player] = true;
        } else
            IIDXIO_TT_PRESSED[player] = false;

        // raw input
        auto analogs = get_analogs();
        auto analog = (*analogs)[player != 0 ? Analogs::TT_P2 : Analogs::TT_P1];
        auto ret_value = IIDXIO_TT_STATE[player];
        if (analog->isSet()) {
            ret_value = IIDXIO_TT_STATE[player];
            ret_value += (uint16_t) (GameAPI::Analogs::getState(RI_MGR, analog) * 1023.999f);
        }

        // return higher 8 bit
        return (uint8_t) (ret_value >> 2);
    }

    unsigned char get_slider(uint8_t slider) {

        // check slide
        if (slider > 4)
            return 0;

        // get analog
        auto analogs = get_analogs();
        Analog* analog = nullptr;
        switch (slider) {
            case 0:
                analog = analogs->at(Analogs::VEFX);
                break;
            case 1:
                analog = analogs->at(Analogs::LowEQ);
                break;
            case 2:
                analog = analogs->at(Analogs::HiEQ);
                break;
            case 3:
                analog = analogs->at(Analogs::Filter);
                break;
            case 4:
                analog = analogs->at(Analogs::PlayVolume);
                break;
            default:
                break;
        }

        // if not set return max value
        if (!analogs || !analog->isSet())
            return 0xF;

        // return slide
        return (unsigned char) (GameAPI::Analogs::getState(RI_MGR, analog) * 15.999f);
    }
}
