#include "io.h"
#include <map>
#include "bbc/io.h"
#include "bs/io.h"
#include "ddr/io.h"
#include "dea/io.h"
#include "gitadora/io.h"
#include "iidx/io.h"
#include "jb/io.h"
#include "mga/io.h"
#include "museca/io.h"
#include "nost/io.h"
#include "popn/io.h"
#include "qma/io.h"
#include "rb/io.h"
#include "rf3d/io.h"
#include "sc/io.h"
#include "sdvx/io.h"


namespace games {

    // state
    static bool IO_INITIALIZED = false;
    static std::map<std::string, std::vector<Button*>*> buttons;
    static std::map<std::string, std::vector<Analog*>*> analogs;
    static std::map<std::string, std::vector<Light*>*> lights;

    static void initialize() {

        // check if already done
        if (IO_INITIALIZED)
            return;
        IO_INITIALIZED = true;

        // bbc
        std::string bbc("Bishi Bashi Channel");
        buttons[bbc] = bbc::get_buttons();
        analogs[bbc] = bbc::get_analogs();
        lights[bbc] = bbc::get_lights();

        // bs
        std::string bs("Beatstream");
        buttons[bs] = bs::get_buttons();

        // ddr
        std::string ddr("Dance Dance Revolution");
        buttons[ddr] = ddr::get_buttons();
        lights[ddr] = ddr::get_lights();

        // dea
        std::string dea("Dance Evolution");
        buttons[dea] = dea::get_buttons();

        // gitadora
        std::string gitadora("GitaDora");
        buttons[gitadora] = gitadora::get_buttons();
        analogs[gitadora] = gitadora::get_analogs();

        // iidx
        std::string iidx("Beatmania IIDX");
        buttons[iidx] = iidx::get_buttons();
        analogs[iidx] = iidx::get_analogs();
        lights[iidx] = iidx::get_lights();

        // jb
        std::string jb("Jubeat");
        buttons[jb] = jb::get_buttons();
        lights[jb] = jb::get_lights();

        // mga
        std::string mga("Metal Gear");
        buttons[mga] = mga::get_buttons();
        analogs[mga] = mga::get_analogs();

        // museca
        std::string museca("Museca");
        buttons[museca] = museca::get_buttons();
        analogs[museca] = museca::get_analogs();
        lights[museca] = museca::get_lights();

        // nost
        std::string nost("Nostalgia");
        buttons[nost] = nost::get_buttons();
        analogs[nost] = nost::get_analogs();

        // popn
        std::string popn("Pop'n Music");
        buttons[popn] = popn::get_buttons();
        lights[popn] = popn::get_lights();

        // qma
        std::string qma("Quiz Magic Academy");
        buttons[qma] = qma::get_buttons();
        lights[qma] = qma::get_lights();

        // rb
        std::string rb("Reflec Beat");
        buttons[rb] = rb::get_buttons();

        // rf3d
        std::string rf3d("Road Fighters 3D");
        buttons[rf3d] = rf3d::get_buttons();
        analogs[rf3d] = rf3d::get_analogs();

        // sc
        std::string sc("Steel Chronicles Victroopers");
        buttons[sc] = sc::get_buttons();

        // sdvx
        std::string sdvx("Sound Voltex");
        buttons[sdvx] = sdvx::get_buttons();
        analogs[sdvx] = sdvx::get_analogs();
        lights[sdvx] = sdvx::get_lights();
    }

    std::vector<Button*>* get_buttons(std::string game) {
        initialize();
        auto it = buttons.find(game);
        if (it == buttons.end())
            return nullptr;
        return it->second;
    }

    std::vector<Analog*>* get_analogs(std::string game) {
        initialize();
        auto it = analogs.find(game);
        if (it == analogs.end())
            return nullptr;
        return it->second;
    }

    std::vector<Light*>* get_lights(std::string game) {
        initialize();
        auto it = lights.find(game);
        if (it == lights.end())
            return nullptr;
        return it->second;
    }
}
