#include "jb.h"
#include <windows.h>
#include "util/logging.h"
#include "util/utils.h"
#include "util/detour.h"
#include "util/libutils.h"
#include "avs/game.h"
#include "touch/touch.h"
#include "hooks/dxhook.h"

namespace games::jb {

    // touch stuff
    static bool TOUCH_ENABLE = false;
    static bool TOUCH_ATTACHED = false;
    static bool IS_PORTRAIT = true;
    bool TOUCH_STATE[16];

    void touch_update() {

        // check if touch enabled
        if (!TOUCH_ENABLE)
            return;

        // attach touch module
        if (!TOUCH_ATTACHED) {

            /*
             * Find the game window.
             * We check the foreground window first, then fall back to searching for the window title
             * All game versions seem to have their model first in the window title
             */
            HWND wnd = GetForegroundWindow();
            if (!string_begins_with(GetActiveWindowTitle(), avs::game::MODEL))
                wnd = FindWindowBeginsWith(avs::game::MODEL);

            // attach touch hook
            if (wnd) {
                log_info("jubeat", "using window handle for touch: " + to_string(wnd));
                touch_create_wnd(wnd);
            } else {
                log_info("jubeat", "falling back to the DirectX window handle for touch");
                touch_attach_dx_hook();
            }

            // show cursor
            if (DXHOOK_SHOW_CURSOR)
                ShowCursor(1);

            // earlier games use a different screen orientation
            if (!avs::game::is_model("L44"))
                IS_PORTRAIT = false;

            // set attached
            TOUCH_ATTACHED = true;
        }

        // check touch points
        memset(TOUCH_STATE, 0, sizeof(TOUCH_STATE));
        std::vector<TouchPoint> touchPoints;
        touch_get_points(&touchPoints);
        int offset = IS_PORTRAIT ? 580 : 0;
        for (TouchPoint tp : touchPoints) {

            // get grid coordinates
            int x = tp.x * 4 / 768;
            int y = (tp.y - offset) * 4 / (1360 - 580);

            // set the corresponding state
            int index = y * 4 + x;
            if (index >= 0 && index < 16)
                TOUCH_STATE[index] = true;
        }
    }

    /*
     * to fix "IP ADDR CHANGE" errors on boot and in-game when using weird network setups such as a VPN
     */
    static __stdcall BOOL network_addr_is_changed() {
        return 0;
    }

    /*
     * to fix lag spikes when game tries to ping "eamuse.konami.fun" every few minutes
     */
    static __stdcall BOOL network_get_network_check_info() {
        return 0;
    }

    JBGame::JBGame() : Game("Jubeat") {
    }

    void JBGame::attach() {
        Game::attach();

        // enable touch
        TOUCH_ENABLE = true;

        // apply patches
        HMODULE network = libutils::try_module("network.dll");
        detour::inline_hook((void *) &network_addr_is_changed, (DWORD_PTR) libutils::try_proc(
                network, "network_addr_is_changed"));
        detour::inline_hook((void *) &network_get_network_check_info, (DWORD_PTR) libutils::try_proc(
                network, "network_get_network_check_info"));
    }

    void JBGame::detach() {
        Game::detach();

        // disable touch
        TOUCH_ENABLE = false;
    }
}
