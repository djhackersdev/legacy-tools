#ifndef SPICETOOLS_CFG_RAWINPUT_DEVICE_H
#define SPICETOOLS_CFG_RAWINPUT_DEVICE_H

#include <string>
#include <windows.h>
#include <thread>
#include <mutex>
#include <vector>
#include "sextet.h"

extern "C" {
#include <hidusage.h>
#include <hidpi.h>
#include <hidsdi.h>
}

namespace rawinput {

    enum DeviceType {
        UNKNOWN,
        MOUSE,
        KEYBOARD,
        HID,
        MIDI,
        SEXTET_OUTPUT,
        PIUIO_DEVICE
    };

    enum MouseKeys {
        MOUSEBTN_LEFT,
        MOUSEBTN_RIGHT,
        MOUSEBTN_MIDDLE,
        MOUSEBTN_1,
        MOUSEBTN_2,
        MOUSEBTN_3,
        MOUSEBTN_4,
        MOUSEBTN_5
    };

    struct DeviceInfo {
        std::string devclass;
        std::string subclass;
        std::string protocol;
        std::string guid_str;
        GUID guid;
    };

    struct DeviceMouseInfo {
        bool key_states[16];
        long pos_x, pos_y;
        long pos_wheel;
    };

    struct DeviceKeyboardInfo {
        bool key_states[1024];
    };

    enum class HIDDriver {
        Default,
        PacDrive
    };

    struct DeviceHIDInfo {
        HANDLE handle;
        _HIDP_CAPS caps;
        HIDD_ATTRIBUTES attributes;
        HIDDriver driver = HIDDriver::Default;
        std::vector<BYTE> preparsed_data;
        std::vector<HIDP_BUTTON_CAPS> button_caps_list;
        std::vector<std::string> button_caps_names;
        std::vector<HIDP_BUTTON_CAPS> button_output_caps_list;
        std::vector<std::string> button_output_caps_names;
        std::vector<HIDP_VALUE_CAPS> value_caps_list;
        std::vector<std::string> value_caps_names;
        std::vector<HIDP_VALUE_CAPS> value_output_caps_list;
        std::vector<std::string> value_output_caps_names;
        std::vector<std::vector<bool>> button_states;
        std::vector<std::vector<bool>> button_output_states;
        std::vector<float> value_states;
        std::vector<float> value_output_states;

        // for config binding function
        std::vector<float> bind_value_states;
    };

    struct DeviceMIDIInfo {
        std::vector<bool> states;
        std::vector<uint8_t> states_events;
        std::vector<bool> bind_states;
        std::vector<uint8_t> velocity;
        bool freeze;
    };

    class PIUIO;

    struct Device {
        std::string name;
        std::string desc;
        HANDLE handle = nullptr;
        DeviceType type = UNKNOWN;
        DeviceInfo info;
        std::mutex* mutex;
        bool updated = true;
        bool output_pending = true;
        bool output_enabled = false;
        DeviceMouseInfo* mouseInfo = nullptr;
        DeviceKeyboardInfo* keyboardInfo = nullptr;
        DeviceHIDInfo* hidInfo = nullptr;
        DeviceMIDIInfo* midiInfo = nullptr;
        SextetDevice* sextetInfo = nullptr;
        PIUIO* piuioDev = nullptr;
    };
}


#endif //SPICETOOLS_CFG_RAWINPUT_DEVICE_H
