#include "rawinput.h"
#include <cmath>
#include <setupapi.h>
#include <stdarg.h>
#include <hidpi.h>
#include "util/logging.h"
#include "util/utils.h"
#include "hooks/sleephook.h"
#include "piuio.h"

extern "C" {
#include "external/usbhidusage/usb-hid-usage.h"
}


rawinput::RawInputManager::RawInputManager() {
    this->input_hwnd_create();
    this->devices_reload();
}

rawinput::RawInputManager::~RawInputManager() {
    this->devices_destruct();
    this->input_hwnd_destroy();
    if (this->flush_thread) {
        this->flush_thread->join();
        delete this->flush_thread;
    }
}

void rawinput::RawInputManager::input_hwnd_create() {

    // register window class
    this->input_hwnd_class.hInstance = GetModuleHandle(nullptr);
    this->input_hwnd_class.lpszClassName = "input";
    this->input_hwnd_class.lpfnWndProc = this->input_wnd_proc;
    if (!RegisterClass(&this->input_hwnd_class)) {
        log_warning("rawinput", "Couldn't register input class.");
        return;
    }

    // create input thread
    this->input_thread = new std::thread([this]() {

        // create window
        this->input_hwnd = CreateWindow(
                this->input_hwnd_class.lpszClassName,
                nullptr,
                0, 0, 0, 0, 0,
                HWND_MESSAGE,
                nullptr,
                this->input_hwnd_class.hInstance,
                this
        );

        // window loop
        MSG msg{};
        while (GetMessage(&msg, this->input_hwnd, 0, 0) > 0) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }

        DestroyWindow(this->input_hwnd);
        this->input_hwnd = nullptr;
    });

    // wait for window creation being done
    while (!this->input_hwnd)
        Sleep(1);
}

void rawinput::RawInputManager::input_hwnd_destroy() {
    PostMessage(this->input_hwnd, WM_CLOSE, 0, 0);
    this->input_thread->join();

    delete this->input_thread;
    this->input_thread = nullptr;

    UnregisterClass(this->input_hwnd_class.lpszClassName, this->input_hwnd_class.hInstance);
}

void rawinput::RawInputManager::devices_reload() {
    this->devices_destruct();

    // get number of devices
    UINT device_no = 0;
    if (GetRawInputDeviceList(nullptr, &device_no, sizeof(RAWINPUTDEVICELIST)) == (UINT) -1)
        return;
    if (!device_no)
        return;

    // get device list
    std::shared_ptr<RAWINPUTDEVICELIST> device_list(new RAWINPUTDEVICELIST[device_no]);
    GetRawInputDeviceList(device_list.get(), &device_no, sizeof(RAWINPUTDEVICELIST));
    if (!device_no)
        return;

    // iterate devices
    for (UINT device_cur_index = 0; device_cur_index < device_no; device_cur_index++) {
        auto device = &device_list.get()[device_cur_index];

        // get device name (but it's actually the path)
        UINT device_name_len = 0;
        if (GetRawInputDeviceInfo(device->hDevice, RIDI_DEVICENAME, nullptr, &device_name_len) == (UINT) -1)
            continue;
        std::shared_ptr<char> device_name(new char[device_name_len + 1]());
        if (GetRawInputDeviceInfo(device->hDevice, RIDI_DEVICENAME, device_name.get(), &device_name_len) == (UINT) -1)
            continue;
        if (device_name_len < 4)
            continue;

        // the infamous XP fix
        // see http://stackoverflow.com/questions/10798798
        device_name.get()[1] = '\\'; //
        std::string device_name_str(device_name.get());

        // extract information out of name
        auto info_obj = this->get_device_info(device_name_str);

        // get device description
        // yes this whole motherfucker is just for the device name - gotta <3 microsoft
        std::string device_description;
        HDEVINFO devinfo = SetupDiGetClassDevs(&info_obj.guid, nullptr, nullptr, DIGCF_DEVICEINTERFACE | DIGCF_PRESENT);
        SP_DEVINFO_DATA devinfo_data{};
        devinfo_data.cbSize = sizeof(SP_DEVINFO_DATA);
        for (DWORD i1 = 0; SetupDiEnumDeviceInfo(devinfo, i1, &devinfo_data); i1++) {
            SP_DEVICE_INTERFACE_DATA i_data{};
            i_data.cbSize = sizeof(SP_DEVICE_INTERFACE_DATA);
            for (DWORD i2 = 0; SetupDiEnumDeviceInterfaces(devinfo, &devinfo_data, &info_obj.guid, i2, &i_data); i2++) {

                // get device path
                DWORD detail_data_size = 0;
                if (SetupDiGetDeviceInterfaceDetail(devinfo, &i_data, nullptr, 0, &detail_data_size, nullptr)
                    || GetLastError() != ERROR_INSUFFICIENT_BUFFER)
                    continue;
                std::shared_ptr<SP_DEVICE_INTERFACE_DETAIL_DATA> detail_data(
                        (SP_DEVICE_INTERFACE_DETAIL_DATA*) new uint8_t[detail_data_size]);
                detail_data.get()->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);
                if (!SetupDiGetDeviceInterfaceDetail(devinfo, &i_data, detail_data.get(), detail_data_size,
                                                     nullptr, nullptr))
                    continue;
                std::string device_path(detail_data.get()->DevicePath);

                // the XP fix again
                if (device_path.length() > 1)
                    device_path[1] = '\\';

                // check if this is our device (must be case insensitive)
                if (stricmp(device_path.c_str(), device_name_str.c_str()) == 0) {

                    // get property
                    DWORD desc_size = 0;
                    if (SetupDiGetDeviceRegistryProperty(
                            devinfo, &devinfo_data, SPDRP_DEVICEDESC, nullptr, nullptr, 0, &desc_size)
                            || GetLastError() != ERROR_INSUFFICIENT_BUFFER)
                        continue;
                    std::shared_ptr<BYTE> desc_data(new BYTE[desc_size]());
                    if (!SetupDiGetDeviceRegistryProperty(
                            devinfo, &devinfo_data, SPDRP_DEVICEDESC, nullptr, desc_data.get(), desc_size, nullptr))
                        continue;

                    // kthxbye
                    device_description = std::string((char*) desc_data.get());
                }
            }
        }

        // kill it with fire
        SetupDiDestroyDeviceInfoList(devinfo);

        // get device information
        RID_DEVICE_INFO device_info{};
        device_info.cbSize = sizeof(RID_DEVICE_INFO);
        UINT device_info_size = device_info.cbSize;
        if (GetRawInputDeviceInfo(device->hDevice, RIDI_DEVICEINFO, &device_info, &device_info_size) == (UINT) -1)
            continue;

        // build device
        Device new_device{};
        new_device.handle = device->hDevice;
        new_device.name = device_name_str;
        new_device.desc = device_description;
        new_device.info = info_obj;
        new_device.mutex = new std::mutex();
        switch (device->dwType) {
            case RIM_TYPEMOUSE:
                new_device.type = MOUSE;
                new_device.mouseInfo = new DeviceMouseInfo();
                break;
            case RIM_TYPEKEYBOARD:
                new_device.type = KEYBOARD;
                new_device.keyboardInfo = new DeviceKeyboardInfo();
                break;
            case RIM_TYPEHID: {
                new_device.type = HID;
                HIDDriver hid_driver = HIDDriver::Default;
                HIDD_ATTRIBUTES hid_attributes{};

                // get better device description
                HANDLE hid_handle = CreateFile(
                        device_name.get(), GENERIC_READ | GENERIC_WRITE,
                        FILE_SHARE_READ | FILE_SHARE_WRITE,
                        nullptr,
                        OPEN_EXISTING,
                        0, nullptr);
                if (hid_handle != INVALID_HANDLE_VALUE) {

                    // check manufacturer string
                    std::wstring man_ws;
                    wchar_t man_str_buffer[256]{};
                    if (HidD_GetManufacturerString(hid_handle, man_str_buffer, sizeof(man_str_buffer)))
                        man_ws = std::wstring(man_str_buffer);

                    // get product string
                    std::wstring prod_ws;
                    wchar_t prod_str_buffer[256]{};
                    if (HidD_GetProductString(hid_handle, prod_str_buffer, sizeof(prod_str_buffer)))
                        prod_ws = std::wstring(prod_str_buffer);

                    // build desc string
                    if (man_ws == prod_ws)
                        prod_ws = L"";
                    std::wstring desc_ws = man_ws;
                    if (!man_ws.empty() && !prod_ws.empty())
                        desc_ws += L" ";
                    desc_ws += prod_ws;

                    // convert to normal string
                    new_device.desc = ws2s(desc_ws);

                    // get attributes
                    HidD_GetAttributes(hid_handle, &hid_attributes);
                }

                // get preparsed information
                UINT preparsed_size = 0;
                if (GetRawInputDeviceInfo(
                        device->hDevice,
                        RIDI_PREPARSEDDATA,
                        nullptr,
                        &preparsed_size) == (UINT) -1)
                    continue;
                if (!preparsed_size)
                    continue;
                std::shared_ptr<BYTE> preparsed(new BYTE[preparsed_size]);
                if (GetRawInputDeviceInfo(
                        device->hDevice,
                        RIDI_PREPARSEDDATA,
                        preparsed.get(),
                        &preparsed_size) == (UINT) -1)
                    continue;
                std::vector<BYTE> preparsed_data;
                for (UINT i = 0; i < preparsed_size; i++)
                    preparsed_data.push_back(preparsed.get()[i]);

                // get caps
                _HIDP_CAPS caps{};
                if (HidP_GetCaps((PHIDP_PREPARSED_DATA) preparsed.get(), &caps) != HIDP_STATUS_SUCCESS)
                    continue;

                // get button caps
                USHORT button_cap_length = caps.NumberInputButtonCaps;
                std::shared_ptr<HIDP_BUTTON_CAPS> button_cap_data(new HIDP_BUTTON_CAPS[button_cap_length]);
                if (button_cap_length > 0)
                    if (HidP_GetButtonCaps(HidP_Input, button_cap_data.get(), &button_cap_length,
                                           (PHIDP_PREPARSED_DATA) preparsed.get()) != HIDP_STATUS_SUCCESS)
                        continue;
                std::vector<HIDP_BUTTON_CAPS> button_caps_list;
                std::vector<std::string> button_caps_names;
                std::vector<std::vector<bool>> button_states;
                for (int button_cap_num = 0; button_cap_num < button_cap_length; button_cap_num++) {
                    HIDP_BUTTON_CAPS button_caps = button_cap_data.get()[button_cap_num];

                    // fill out range fields so we don't have to care later on
                    if (!button_caps.IsRange) {
                        button_caps.Range.UsageMin = button_caps.NotRange.Usage;
                        button_caps.Range.UsageMax = button_caps.NotRange.Usage;
                        button_caps.Range.DataIndexMin = button_caps.NotRange.DataIndex;
                        button_caps.Range.DataIndexMax = button_caps.NotRange.DataIndex;
                        button_caps.Range.DesignatorMin = button_caps.NotRange.DesignatorIndex;
                        button_caps.Range.DesignatorMax = button_caps.NotRange.DesignatorIndex;
                        button_caps.Range.StringMin = button_caps.NotRange.StringIndex;
                        button_caps.Range.StringMax = button_caps.NotRange.StringIndex;
                    }

                    // fill vectors
                    button_caps_list.emplace_back(button_caps);
                    int button_count = button_caps.Range.UsageMax - button_caps.Range.UsageMin + 1;
                    button_states.emplace_back(std::vector<bool>((unsigned int) button_count, false));

                    // names
                    for (USAGE usg = button_caps.Range.UsageMin; usg <= button_caps.Range.UsageMax; usg++) {
                        const char* name = usb_hid_get_usage_text(button_caps.UsagePage, usg);
                        if (name)
                            button_caps_names.emplace_back(std::string(name));
                        else
                            button_caps_names.emplace_back("Button Control");
                        free((void*) name);
                    }
                }

                // get button output caps
                USHORT button_output_cap_length = caps.NumberOutputButtonCaps;
                std::shared_ptr<HIDP_BUTTON_CAPS> button_output_cap_data(
                        new HIDP_BUTTON_CAPS[button_output_cap_length]);
                if (button_output_cap_length > 0)
                    if (HidP_GetButtonCaps(HidP_Output, button_output_cap_data.get(), &button_output_cap_length,
                                           (PHIDP_PREPARSED_DATA) preparsed.get()) != HIDP_STATUS_SUCCESS)
                        continue;
                std::vector<HIDP_BUTTON_CAPS> button_output_caps_list;
                std::vector<std::string> button_output_caps_names;
                std::vector<std::vector<bool>> button_output_states;
                for (int button_cap_num = 0; button_cap_num < button_output_cap_length; button_cap_num++) {
                    HIDP_BUTTON_CAPS button_caps = button_output_cap_data.get()[button_cap_num];

                    // fill out range fields so we don't have to care later on
                    if (!button_caps.IsRange) {
                        button_caps.Range.UsageMin = button_caps.NotRange.Usage;
                        button_caps.Range.UsageMax = button_caps.NotRange.Usage;
                        button_caps.Range.DataIndexMin = button_caps.NotRange.DataIndex;
                        button_caps.Range.DataIndexMax = button_caps.NotRange.DataIndex;
                        button_caps.Range.DesignatorMin = button_caps.NotRange.DesignatorIndex;
                        button_caps.Range.DesignatorMax = button_caps.NotRange.DesignatorIndex;
                        button_caps.Range.StringMin = button_caps.NotRange.StringIndex;
                        button_caps.Range.StringMax = button_caps.NotRange.StringIndex;
                    }

                    // fill vectors
                    button_output_caps_list.emplace_back(button_caps);
                    int button_count = button_caps.Range.UsageMax - button_caps.Range.UsageMin + 1;
                    button_output_states.emplace_back(std::vector<bool>((unsigned int) button_count, false));

                    // names
                    for (USAGE usg = button_caps.Range.UsageMin; usg <= button_caps.Range.UsageMax; usg++) {
                        const char* name = usb_hid_get_usage_text(button_caps.UsagePage, usg);
                        if (name)
                            button_output_caps_names.emplace_back(std::string(name));
                        else
                            button_output_caps_names.emplace_back("Button Control");
                        free((void*) name);
                    }
                }

                /*
                 * PacDrive LED driver board ("Ultimarc LED Controller")
                 * It's HID descriptor is trash so we need to fix that
                 */
                if (hid_attributes.VendorID == 0xD209 && (hid_attributes.ProductID & 0xFFF8) == 0x1500) {
                    hid_driver = HIDDriver::PacDrive;

                    // clear
                    button_output_caps_list.clear();
                    button_output_caps_names.clear();
                    button_output_states.clear();

                    // fake the output LEDs
                    for (int i = 0; i < 16; i++) {

                        // create generic indicator caps
                        HIDP_BUTTON_CAPS fakeCaps{};
                        fakeCaps.Range.UsageMin = 0x4B;
                        fakeCaps.Range.UsageMax = 0x4B;

                        // add content to lists
                        button_output_caps_list.push_back(fakeCaps);
                        button_output_caps_names.push_back("LED " + to_string(i + 1));
                        button_output_states.emplace_back(std::vector<bool>(1, false));
                    }
                }

                // get value caps
                USHORT value_cap_length = caps.NumberInputValueCaps;
                std::shared_ptr<HIDP_VALUE_CAPS> value_cap_data(new HIDP_VALUE_CAPS[value_cap_length]());
                if (value_cap_length > 0)
                    if (HidP_GetValueCaps(HidP_Input, value_cap_data.get(), &value_cap_length,
                                          (PHIDP_PREPARSED_DATA) preparsed.get()) != HIDP_STATUS_SUCCESS)
                        continue;
                std::vector<HIDP_VALUE_CAPS> value_caps_list;
                std::vector<std::string> value_caps_names;
                std::vector<float> value_states(value_cap_length, 0.5f);
                std::vector<float> bind_value_states(value_cap_length, 0.5f);
                for (int value_cap_num = 0; value_cap_num < value_cap_length; value_cap_num++) {
                    HIDP_VALUE_CAPS value_caps = value_cap_data.get()[value_cap_num];

                    // fix logical values
                    value_caps.LogicalMin &= 0xFFFF;
                    value_caps.LogicalMax &= 0xFFFF;

                    // add to list
                    value_caps_list.emplace_back(value_caps);

                    // names
                    const char* name = usb_hid_get_usage_text(value_caps.UsagePage, value_caps.Range.UsageMin);
                    if (name)
                        value_caps_names.emplace_back(std::string(name));
                    else
                        value_caps_names.emplace_back("Analog Control");
                    free((void*) name);
                }

                // get value output caps
                USHORT value_output_cap_length = caps.NumberOutputValueCaps;
                std::shared_ptr<HIDP_VALUE_CAPS> value_output_cap_data(new HIDP_VALUE_CAPS[value_output_cap_length]());
                if (value_output_cap_length > 0)
                    if (HidP_GetValueCaps(HidP_Output, value_output_cap_data.get(), &value_output_cap_length,
                                          (PHIDP_PREPARSED_DATA) preparsed.get()) != HIDP_STATUS_SUCCESS)
                        continue;
                std::vector<HIDP_VALUE_CAPS> value_output_caps_list;
                std::vector<std::string> value_output_caps_names;
                std::vector<float> value_output_states;
                for (int value_cap_num = 0; value_cap_num < value_output_cap_length; value_cap_num++) {
                    HIDP_VALUE_CAPS value_caps = value_output_cap_data.get()[value_cap_num];

                    // fix logical values
                    value_caps.LogicalMin &= 0xFFFF;
                    value_caps.LogicalMax &= 0xFFFF;

                    // check if this is a range cap
                    if (value_caps.IsRange) {

                        // add a cap for each value for range caps
                        USAGE usage_min = value_caps.Range.UsageMin;
                        USAGE usage_max = value_caps.Range.UsageMax;
                        for (USAGE usage = usage_min; usage <= usage_max; usage++) {

                            // add to list
                            value_caps.NotRange.Usage = usage;
                            value_output_caps_list.push_back(value_caps);
                            value_output_states.push_back(0.f);

                            // names
                            const char* name = usb_hid_get_usage_text(value_caps.UsagePage, usage);
                            if (name)
                                value_output_caps_names.emplace_back(std::string(name));
                            else
                                value_output_caps_names.emplace_back("Value Output");
                            free((void*) name);
                        }

                    } else {

                        // add to list
                        value_output_caps_list.emplace_back(value_caps);
                        value_output_states.push_back(0.f);

                        // names
                        const char* name = usb_hid_get_usage_text(value_caps.UsagePage, value_caps.NotRange.Usage);
                        if (name)
                            value_output_caps_names.emplace_back(std::string(name));
                        else
                            value_output_caps_names.emplace_back("Value Output");
                        free((void*) name);
                    }
                }

                // generate HID info
                new_device.hidInfo = new DeviceHIDInfo();
                new_device.hidInfo->handle = hid_handle;
                new_device.hidInfo->caps = caps;
                new_device.hidInfo->attributes = hid_attributes;
                new_device.hidInfo->driver = hid_driver;
                new_device.hidInfo->preparsed_data = preparsed_data;
                new_device.hidInfo->button_caps_list = button_caps_list;
                new_device.hidInfo->button_caps_names = button_caps_names;
                new_device.hidInfo->button_output_caps_list = button_output_caps_list;
                new_device.hidInfo->button_output_caps_names = button_output_caps_names;
                new_device.hidInfo->value_caps_list = value_caps_list;
                new_device.hidInfo->value_caps_names = value_caps_names;
                new_device.hidInfo->value_output_caps_list = value_output_caps_list;
                new_device.hidInfo->value_output_caps_names = value_output_caps_names;
                new_device.hidInfo->button_states = button_states;
                new_device.hidInfo->button_output_states = button_output_states;
                new_device.hidInfo->value_states = value_states;
                new_device.hidInfo->value_output_states = value_output_states;
                new_device.hidInfo->bind_value_states = bind_value_states;

                break;
            }
            default:
                continue;
        }

        // add device to list
        this->devices.emplace_back(new_device);
    }

    // add midi devices
    auto midi_device_count = midiInGetNumDevs();
    for (size_t midi_device_id = 0; midi_device_id < midi_device_count; midi_device_id++) {

        // get dev caps
        MIDIINCAPS midi_device_caps{};
        if (midiInGetDevCaps(midi_device_id, &midi_device_caps, sizeof(MIDIINCAPS)) != MMSYSERR_NOERROR)
            continue;

        // open device
        HMIDIIN midi_device_handle;
        if (midiInOpen(&midi_device_handle,
                       (UINT) midi_device_id,
                       (DWORD_PTR) &input_midi_proc,
                       (DWORD_PTR) this,
                       CALLBACK_FUNCTION) != MMSYSERR_NOERROR)
            continue;

        // start input
        if (midiInStart(midi_device_handle) != MMSYSERR_NOERROR)
            continue;

        // device info
        DeviceInfo midi_device_info{};

        // device midi info
        auto midi_device_midi_info = new DeviceMIDIInfo();
        midi_device_midi_info->states = std::vector<bool>(16 * 128);
        midi_device_midi_info->states_events = std::vector<uint8_t>(16 * 128);
        midi_device_midi_info->bind_states = std::vector<bool>(16 * 128);
        midi_device_midi_info->velocity = std::vector<uint8_t>(16 * 128);
        midi_device_midi_info->freeze = false;

        // build identifier
        std::ostringstream midi_identifier;
        midi_identifier << ";" << "MIDI";
        midi_identifier << ";" << midi_device_id;
        midi_identifier << ";" << midi_device_caps.szPname;
        midi_identifier << ";" << midi_device_caps.wMid;
        midi_identifier << ";" << midi_device_caps.wPid;

        // build device
        Device midi_device{};
        midi_device.type = MIDI;
        midi_device.handle = midi_device_handle;
        midi_device.name = midi_identifier.str();
        midi_device.desc = to_string(midi_device_caps.szPname);
        midi_device.info = midi_device_info;
        midi_device.mutex = new std::mutex();
        midi_device.midiInfo = midi_device_midi_info;

        // add device to list
        this->devices.emplace_back(midi_device);
    }

    // check for any sextet-stream devices
    Device new_sextet_device{};
    new_sextet_device.type = SEXTET_OUTPUT;
    new_sextet_device.name = "lit_board";
    new_sextet_device.desc = "LIT Board (COM54)";
    new_sextet_device.sextetInfo = new rawinput::SextetDevice("\\\\.\\COM54");
    new_sextet_device.mutex = new std::mutex();

    // try to connect
    if (new_sextet_device.sextetInfo->connect()) {

        // successful connection
        this->devices.emplace_back(new_sextet_device);
    }

    // check for LIT Board by default
    sextet_register("COM54", "LIT Board");

    // add device to vector first so pointer is valid
    Device *new_piuio_device = new Device();
    new_piuio_device->type = PIUIO_DEVICE;
    new_piuio_device->name = "piuio";
    new_piuio_device->desc = "PIUIO";
    new_piuio_device->piuioDev = nullptr;
    new_piuio_device->mutex = new std::mutex();

    // try to initialize
    auto piuioDev = new PIUIO(&this->devices.emplace_back(*new_piuio_device));
    if (piuioDev->Init()) {

        // successful initialization
        this->devices.back().piuioDev = piuioDev;

    } else {

        // remove device since connection failed
        this->devices.pop_back();
    }

    // check input window
    if (!this->input_hwnd) {
        log_warning("rawinput", "Input window is broken :(");
        return;
    }

    // register devices
    this->devices_register();

    // start flush thread
    if (this->flush_thread == nullptr) {
        this->flush_thread = new std::thread([this] {
            while (this->input_hwnd) {

                /*
                 * Write output report all ~500ms so DAO IIDX boards (and probably more) don't go back
                 * to button based lighting. Retarded but reality.
                 */
                this->devices_flush_output(false);
                Sleep(495);
            }
        });
    }
}

void rawinput::RawInputManager::sextet_register(std::string port_name, std::string alias, bool warn) {

    // check for any sextet-stream devices
    Device device{};
    device.type = SEXTET_OUTPUT;
    device.name = "sextet_" + port_name;
    device.desc = alias + " (" + port_name + ")";
    device.sextetInfo = new rawinput::SextetDevice("\\\\.\\" + port_name);
    device.mutex = new std::mutex();

    // try to connect
    if (device.sextetInfo->connect()) {

        // successful connection
        this->devices.emplace_back(device);

    } else if (warn)
        log_warning("rawinput", "unable to connect to " + alias + " on " + port_name);
}

void rawinput::RawInputManager::devices_register() {

    // register keyboard
    RAWINPUTDEVICE keyboard_device{};
    keyboard_device.dwFlags = RIDEV_NOLEGACY | RIDEV_INPUTSINK;
    keyboard_device.usUsagePage = 1;
    keyboard_device.usUsage = 0x06;
    keyboard_device.hwndTarget = this->input_hwnd;
    if (!RegisterRawInputDevices(&keyboard_device, 1, sizeof(keyboard_device)))
        log_warning("rawinput", "Failed to register keyboard events: " + to_string(GetLastError()));

    // register keypad
    RAWINPUTDEVICE keypad_device{};
    keypad_device.dwFlags = RIDEV_INPUTSINK;
    keypad_device.usUsagePage = 1;
    keypad_device.usUsage = 0x07;
    keypad_device.hwndTarget = this->input_hwnd;
    if (!RegisterRawInputDevices(&keypad_device, 1, sizeof(keypad_device)))
        log_warning("rawinput", "Failed to register keypad events: " + to_string(GetLastError()));

    // register mouse
    RAWINPUTDEVICE mouse_device{};
    mouse_device.dwFlags = RIDEV_INPUTSINK;
    mouse_device.usUsagePage = 1;
    mouse_device.usUsage = 0x02;
    mouse_device.hwndTarget = this->input_hwnd;
    if (!RegisterRawInputDevices(&mouse_device, 1, sizeof(mouse_device)))
        log_warning("rawinput", "Failed to register mouse events: " + to_string(GetLastError()));

    // register joystick
    RAWINPUTDEVICE joystick_device{};
    joystick_device.dwFlags = RIDEV_INPUTSINK;
    joystick_device.usUsagePage = 1;
    joystick_device.usUsage = 0x04;
    joystick_device.hwndTarget = this->input_hwnd;
    if (!RegisterRawInputDevices(&joystick_device, 1, sizeof(joystick_device)))
        log_warning("rawinput", "Failed to register joystick events: " + to_string(GetLastError()));

    // register gamepad
    RAWINPUTDEVICE gamepad_device{};
    gamepad_device.dwFlags = RIDEV_INPUTSINK;
    gamepad_device.usUsagePage = 1;
    gamepad_device.usUsage = 0x05;
    gamepad_device.hwndTarget = this->input_hwnd;
    if (!RegisterRawInputDevices(&gamepad_device, 1, sizeof(gamepad_device)))
        log_warning("rawinput", "Failed to register gamepad events: " + to_string(GetLastError()));

}

void rawinput::RawInputManager::devices_destruct() {

    // unregister keyboard
    RAWINPUTDEVICE keyboard_device{};
    keyboard_device.dwFlags = RIDEV_NOLEGACY | RIDEV_INPUTSINK | RIDEV_REMOVE;
    keyboard_device.usUsagePage = 1;
    keyboard_device.usUsage = 0x06;
    keyboard_device.hwndTarget = this->input_hwnd;
    RegisterRawInputDevices(&keyboard_device, 1, sizeof(keyboard_device));

    // unregister keypad
    RAWINPUTDEVICE keypad_device{};
    keypad_device.dwFlags = RIDEV_NOLEGACY | RIDEV_INPUTSINK | RIDEV_REMOVE;
    keypad_device.usUsagePage = 1;
    keypad_device.usUsage = 0x07;
    keypad_device.hwndTarget = this->input_hwnd;
    RegisterRawInputDevices(&keypad_device, 1, sizeof(keypad_device));

    // unregister mouse
    RAWINPUTDEVICE mouse_device{};
    mouse_device.dwFlags = RIDEV_INPUTSINK | RIDEV_REMOVE;
    mouse_device.usUsagePage = 1;
    mouse_device.usUsage = 0x02;
    mouse_device.hwndTarget = this->input_hwnd;
    RegisterRawInputDevices(&mouse_device, 1, sizeof(mouse_device));

    // unregister joystick
    RAWINPUTDEVICE joystick_device{};
    joystick_device.dwFlags = RIDEV_INPUTSINK | RIDEV_REMOVE;
    joystick_device.usUsagePage = 1;
    joystick_device.usUsage = 0x04;
    joystick_device.hwndTarget = this->input_hwnd;
    RegisterRawInputDevices(&joystick_device, 1, sizeof(joystick_device));

    // unregister gamepad
    RAWINPUTDEVICE gamepad_device{};
    gamepad_device.dwFlags = RIDEV_INPUTSINK | RIDEV_REMOVE;
    gamepad_device.usUsagePage = 1;
    gamepad_device.usUsage = 0x06;
    gamepad_device.hwndTarget = this->input_hwnd;
    RegisterRawInputDevices(&gamepad_device, 1, sizeof(gamepad_device));

    // check if there's something to destruct
    if (this->devices.empty())
        return;

    // dispose devices
    for (const Device &device : devices) {

        // close device handles
        switch (device.type) {
            case HID:
                CloseHandle(device.hidInfo->handle);
                CloseHandle(device.handle);
                break;
            case MIDI:
                midiInReset((HMIDIIN) device.handle);
                midiInClose((HMIDIIN) device.handle);
                break;
            case SEXTET_OUTPUT:
                device.sextetInfo->disconnect();
                break;
            default:
                CloseHandle(device.handle);
                break;
        }

        delete device.mutex;
        delete device.mouseInfo;
        delete device.keyboardInfo;
        delete device.hidInfo;
        delete device.midiInfo;
        delete device.sextetInfo;
    }

    // empty array
    this->devices.clear();
}

LRESULT CALLBACK rawinput::RawInputManager::input_wnd_proc(
        HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) {

    // message switch
    switch (msg) {
        case WM_CREATE: {

            // save reference
            SetWindowLongPtrW(hwnd, GWLP_USERDATA, PtrToUlong(((LPCREATESTRUCT) lparam)->lpCreateParams));

            break;
        }
        case WM_INPUT: {

            // get reference
            auto ref = (RawInputManager*) GetWindowLongPtrW(hwnd, GWLP_USERDATA);

            // get raw input data
            UINT data_size = 0;
            if (GetRawInputData(
                    (HRAWINPUT) lparam,
                    RID_INPUT,
                    nullptr,
                    &data_size,
                    sizeof(RAWINPUTHEADER)) == (UINT) -1)
                break;
            if (!data_size)
                break;
            std::shared_ptr<RAWINPUT> data((RAWINPUT*) new char[data_size]{});
            if (GetRawInputData(
                    (HRAWINPUT) lparam,
                    RID_INPUT,
                    data.get(),
                    &data_size,
                    sizeof(RAWINPUTHEADER)) != data_size)
                break;

            // find device
            HANDLE device_handle = data.get()->header.hDevice;
            for (Device &device : *ref->devices_get()) {

                // skip if this is the wrong device
                if (device.handle != device_handle)
                    continue;

                // lock device
                device.mutex->lock();

                // check type
                switch (device.type) {
                    case MOUSE: {

                        // get mouse data
                        auto data_mouse = data.get()->data.mouse;

                        // save position
                        if (data_mouse.usFlags & MOUSE_MOVE_ABSOLUTE) {
                            if (device.mouseInfo->pos_x != data_mouse.lLastX)
                                device.updated = true;
                            device.mouseInfo->pos_x = data_mouse.lLastX;
                            if (device.mouseInfo->pos_y != data_mouse.lLastY)
                                device.updated = true;
                            device.mouseInfo->pos_y = data_mouse.lLastY;
                        } else {
                            if (data_mouse.lLastX != 0 || data_mouse.lLastY != 0)
                                device.updated = true;
                            device.mouseInfo->pos_x += data_mouse.lLastX;
                            device.mouseInfo->pos_y += data_mouse.lLastY;
                        }

                        // check buttons
                        if (data_mouse.usButtonFlags) {
                            if (data_mouse.usButtonFlags & RI_MOUSE_LEFT_BUTTON_DOWN) {
                                device.updated = true;
                                device.mouseInfo->key_states[MOUSEBTN_LEFT] = true;
                            }
                            if (data_mouse.usButtonFlags & RI_MOUSE_LEFT_BUTTON_UP) {
                                device.updated = true;
                                device.mouseInfo->key_states[MOUSEBTN_LEFT] = false;
                            }
                            if (data_mouse.usButtonFlags & RI_MOUSE_RIGHT_BUTTON_DOWN) {
                                device.updated = true;
                                device.mouseInfo->key_states[MOUSEBTN_RIGHT] = true;
                            }
                            if (data_mouse.usButtonFlags & RI_MOUSE_RIGHT_BUTTON_UP) {
                                device.updated = true;
                                device.mouseInfo->key_states[MOUSEBTN_RIGHT] = false;
                            }
                            if (data_mouse.usButtonFlags & RI_MOUSE_MIDDLE_BUTTON_DOWN) {
                                device.updated = true;
                                device.mouseInfo->key_states[MOUSEBTN_MIDDLE] = true;
                            }
                            if (data_mouse.usButtonFlags & RI_MOUSE_MIDDLE_BUTTON_UP) {
                                device.updated = true;
                                device.mouseInfo->key_states[MOUSEBTN_MIDDLE] = false;
                            }
                            if (data_mouse.usButtonFlags & RI_MOUSE_BUTTON_1_DOWN) {
                                device.updated = true;
                                device.mouseInfo->key_states[MOUSEBTN_1] = true;
                            }
                            if (data_mouse.usButtonFlags & RI_MOUSE_BUTTON_1_UP) {
                                device.updated = true;
                                device.mouseInfo->key_states[MOUSEBTN_1] = false;
                            }
                            if (data_mouse.usButtonFlags & RI_MOUSE_BUTTON_2_DOWN) {
                                device.updated = true;
                                device.mouseInfo->key_states[MOUSEBTN_2] = true;
                            }
                            if (data_mouse.usButtonFlags & RI_MOUSE_BUTTON_2_UP) {
                                device.updated = true;
                                device.mouseInfo->key_states[MOUSEBTN_2] = false;
                            }
                            if (data_mouse.usButtonFlags & RI_MOUSE_BUTTON_3_DOWN) {
                                device.updated = true;
                                device.mouseInfo->key_states[MOUSEBTN_3] = true;
                            }
                            if (data_mouse.usButtonFlags & RI_MOUSE_BUTTON_3_UP) {
                                device.updated = true;
                                device.mouseInfo->key_states[MOUSEBTN_3] = false;
                            }
                            if (data_mouse.usButtonFlags & RI_MOUSE_BUTTON_4_DOWN) {
                                device.updated = true;
                                device.mouseInfo->key_states[MOUSEBTN_4] = true;
                            }
                            if (data_mouse.usButtonFlags & RI_MOUSE_BUTTON_4_UP) {
                                device.updated = true;
                                device.mouseInfo->key_states[MOUSEBTN_4] = false;
                            }
                            if (data_mouse.usButtonFlags & RI_MOUSE_BUTTON_5_DOWN) {
                                device.updated = true;
                                device.mouseInfo->key_states[MOUSEBTN_5] = true;
                            }
                            if (data_mouse.usButtonFlags & RI_MOUSE_BUTTON_5_UP) {
                                device.updated = true;
                                device.mouseInfo->key_states[MOUSEBTN_5] = false;
                            }
                        }

                        // check wheel
                        if (data_mouse.usButtonFlags & RI_MOUSE_WHEEL) {
                            if ((short) data_mouse.usButtonData != 0)
                                device.updated = true;
                            device.mouseInfo->pos_wheel += (short) data_mouse.usButtonData;
                        }

                        break;
                    }
                    case KEYBOARD: {

                        // get keyboard data
                        auto data_keyboard = &data.get()->data.keyboard;

                        // set index based on flags
                        int index = 0;
                        if (data_keyboard->Flags & RI_KEY_E0)
                            index += 256;
                        if (data_keyboard->Flags & RI_KEY_E1)
                            index += 512;

                        // update key state
                        USHORT vkey = data_keyboard->VKey;
                        if (vkey < 255) {
                            bool state = (data_keyboard->Flags & RI_KEY_BREAK) == 0;
                            auto cur_state = &device.keyboardInfo->key_states[index + vkey];
                            if (*cur_state != state) {
                                device.updated = true;
                                *cur_state = state;
                            }
                        }

                        break;
                    }
                    case HID: {

                        // get HID data
                        auto data_hid = &data.get()->data.hid;

                        // buttons
                        for (size_t cap_num = 0; cap_num < device.hidInfo->button_caps_list.size(); cap_num++) {
                            auto button_caps = &device.hidInfo->button_caps_list[cap_num];
                            auto button_states = &device.hidInfo->button_states[cap_num];

                            // get button count
                            int button_count = button_caps->Range.UsageMax - button_caps->Range.UsageMin + 1;
                            if (button_count <= 0)
                                continue;

                            // get usages
                            auto usages_length = (ULONG) button_count;
                            std::shared_ptr<USAGE> usages(new USAGE[usages_length]{});
                            if (HidP_GetUsages(
                                    HidP_Input,
                                    button_caps->UsagePage,
                                    button_caps->LinkCollection,
                                    usages.get(),
                                    &usages_length,
                                    (PHIDP_PREPARSED_DATA) device.hidInfo->preparsed_data.data(),
                                    (PCHAR) data_hid->bRawData,
                                    data_hid->dwSizeHid) != HIDP_STATUS_SUCCESS)
                                continue;

                            // update buttons
                            std::vector<bool> new_states((unsigned int) button_count, false);
                            for (ULONG usage_num = 0; usage_num < usages_length; usage_num++) {
                                USAGE usage = usages.get()[usage_num] - button_caps->Range.UsageMin;
                                new_states[usage] = true;
                            }
                            for (int button_num = 0; button_num < button_count; button_num++) {
                                if (new_states[button_num] != (*button_states)[button_num]) {
                                    device.updated = true;
                                    (*button_states)[button_num] = new_states[button_num];
                                }
                            }
                        }

                        // analogs
                        for (int cap_num = 0; cap_num < device.hidInfo->caps.NumberInputValueCaps; cap_num++) {
                            HIDP_VALUE_CAPS* value_caps = &device.hidInfo->value_caps_list[cap_num];

                            // get value
                            LONG value_raw;
                            if (HidP_GetUsageValue(
                                    HidP_Input,
                                    value_caps->UsagePage,
                                    value_caps->LinkCollection,
                                    value_caps->Range.UsageMin,
                                    (PULONG) &value_raw,
                                    (PHIDP_PREPARSED_DATA) device.hidInfo->preparsed_data.data(),
                                    (PCHAR) data_hid->bRawData,
                                    data_hid->dwSizeHid) != HIDP_STATUS_SUCCESS)
                                continue;

                            // get min and max
                            LONG value_min = value_caps->LogicalMin;
                            LONG value_max = value_caps->LogicalMax;

                            // automatic calibration
                            if (value_raw < value_min) {
                                value_caps->LogicalMin = value_raw;
                                value_min = value_raw;
                            }
                            if (value_raw > value_max) {
                                value_caps->LogicalMax = value_raw;
                                value_max = value_raw;
                            }

                            // scale to float
                            float value = (float) (value_raw - value_min) / (float) (value_max - value_min);

                            // store value
                            auto cur_state = &device.hidInfo->value_states[cap_num];
                            if (*cur_state != value) {
                                device.updated = true;
                                *cur_state = value;
                            }
                        }

                        break;
                    }
                    default:
                        break;
                }

                // free device
                device.mutex->unlock();
            }
        }
        default:
            break;
    }

    // default
    return DefWindowProc(hwnd, msg, wparam, lparam);
}

void CALLBACK rawinput::RawInputManager::input_midi_proc(HMIDIIN hMidiIn, UINT wMsg, DWORD_PTR dwInstance,
                                                         DWORD_PTR dwParam1, DWORD_PTR dwParam2) {
    // get instance
    auto ri_mgr = (RawInputManager*) dwInstance;

    // find device
    for (Device &device : *ri_mgr->devices_get()) {

        // filter non MIDI devices
        if (device.type != MIDI)
            continue;

        // filter wrong handles
        if (device.handle != hMidiIn)
            continue;

        // lock device
        std::lock_guard<std::mutex> lock(*device.mutex);

        // handle message
        switch (wMsg) {
            case MIM_OPEN:
                break;
            case MIM_CLOSE:
                break;
            case MIM_MOREDATA:
            case MIM_DATA: {

                // param mapping
                auto dwMidiMessage = dwParam1;
                //auto dwTimestamp = dwParam2;

                // message unpacking
                auto midi_status = LOBYTE(LOWORD(dwMidiMessage));
                auto midi_status_command = (midi_status & 0xF0) >> 4;
                auto midi_status_channel = (midi_status & 0x0F);
                auto midi_byte1 = HIBYTE(LOWORD(dwMidiMessage));
                auto midi_byte2 = LOBYTE(HIWORD(dwMidiMessage));

                switch (midi_status_command) {
                    case 0x8: { // NOTE OFF

                        // param mapping
                        auto midi_note = midi_byte1 & 127;

                        // get index
                        auto midi_index = midi_status_channel * 128 + midi_note;
                        if (midi_index < 16 * 128) {

                            // update velocity
                            device.midiInfo->velocity[midi_index] = 0;

                            // disable note
                            if (device.midiInfo->states_events[midi_index])
                                device.midiInfo->states[midi_index] = false;

                            // mark device as updated
                            device.updated = true;
                        }

                        break;
                    }
                    case 0x9: { // NOTE ON

                        // param mapping
                        auto midi_note = midi_byte1 & 127;
                        auto midi_velocity = midi_byte2 & 127;

                        // get index
                        auto midi_index = midi_status_channel * 128 + midi_note;
                        if (midi_index < 16 * 128) {

                            // update velocity
                            device.midiInfo->velocity[midi_index] = (uint8_t) midi_velocity;

                            // update events
                            if (midi_velocity) {

                                // so currently it's meant to be turned on
                                device.midiInfo->states[midi_index] = true;

                                // if its already on just increase it by one to turn it off
                                if (device.midiInfo->states_events[midi_index] % 2)
                                    device.midiInfo->states_events[midi_index]++;
                                else
                                    device.midiInfo->states_events[midi_index] += 2;

                            } else if (!device.midiInfo->freeze) {

                                // velocity 0 means turn it off
                                device.midiInfo->states[midi_index] = false;
                            }

                            // mark device as updated
                            device.updated = true;
                        }

                        break;
                    }
                    case 0xA: // POLYPHONIC PRESSURE
                        break;
                    case 0xB: // CONTROL CHANGE
                        break;
                    case 0xC: // PROGRAM CHANGE
                        break;
                    case 0xD: // CHANNEL PRESSURE
                        break;
                    case 0xE: // PITCH BENDING
                        break;
                    case 0xF: // SYSTEM EXCLUSIVE
                        break;
                    default:
                        break;
                }

                break;
            }
            case MIM_LONGDATA:
                break;
            case MIM_ERROR:
                break;
            case MIM_LONGERROR:
                break;
            default:
                break;
        }

        // don't iterate through the other devices
        break;
    }
}

void rawinput::RawInputManager::device_write_output(Device* device, bool only_updated) {

    // check if output is enabled
    if (!device->output_enabled)
        return;

    // check if output is pending
    if (only_updated && !device->output_pending)
        return;

    // lock device
    device->mutex->lock();

    // check device type
    switch (device->type) {
        case HID: {

            // get HID info
            auto hid = device->hidInfo;

            // check handle
            if (hid->handle == INVALID_HANDLE_VALUE)
                break;

            // check driver
            switch (hid->driver) {
                case HIDDriver::Default: {

                    // allocate report
                    CHAR* report_data = new CHAR[hid->caps.OutputReportByteLength]{};

                    // set buttons
                    for (size_t cap_no = 0; cap_no < hid->button_output_caps_list.size(); cap_no++) {
                        auto &button_cap = hid->button_output_caps_list[cap_no];
                        auto &button_state_list = hid->button_output_states[cap_no];

                        // determine which buttons to turn on
                        std::vector<USAGE> usage_list;
                        std::vector<USAGE> usage_off_list;
                        usage_list.reserve(button_state_list.size());
                        usage_off_list.reserve(button_state_list.size());
                        for (size_t state_no = 0; state_no < button_state_list.size(); state_no++) {
                            if (button_state_list[state_no])
                                usage_list.push_back(button_cap.Range.UsageMin + (USAGE) state_no);
                            else
                                usage_off_list.push_back(button_cap.Range.UsageMin + (USAGE) state_no);
                        }

                        // set the buttons
                        auto usage_list_length = (ULONG) usage_list.size();
                        while (HidP_SetButtons(
                                       HidP_Output,
                                       button_cap.UsagePage,
                                       button_cap.LinkCollection,
                                       &usage_list[0],
                                       &usage_list_length,
                                       (PHIDP_PREPARSED_DATA) &hid->preparsed_data[0],
                                       report_data,
                                       hid->caps.OutputReportByteLength) == HIDP_STATUS_INCOMPATIBLE_REPORT_ID) {

                            // flush report
                            HidD_SetOutputReport(hid->handle, report_data, hid->caps.OutputReportByteLength);
                            memset(report_data, 0, hid->caps.OutputReportByteLength);
                        }

                        // clear the buttons
                        auto usage_off_list_length = (ULONG) usage_off_list.size();
                        while (HidP_UnsetButtons(
                                       HidP_Output,
                                       button_cap.UsagePage,
                                       button_cap.LinkCollection,
                                       &usage_off_list[0],
                                       &usage_off_list_length,
                                       (PHIDP_PREPARSED_DATA) &hid->preparsed_data[0],
                                       report_data,
                                       hid->caps.OutputReportByteLength) == HIDP_STATUS_INCOMPATIBLE_REPORT_ID) {

                            // flush report
                            DWORD written_bytes = 0;
                            WriteFile(
                                    hid->handle,
                                    (void*) report_data,
                                    hid->caps.OutputReportByteLength,
                                    &written_bytes,
                                    nullptr
                            );
                            memset(report_data, 0, hid->caps.OutputReportByteLength);
                        }
                    }

                    // set values
                    for (size_t cap_no = 0; cap_no < hid->value_output_caps_list.size(); cap_no++) {
                        auto &value_cap = hid->value_output_caps_list[cap_no];
                        auto &value_state = hid->value_output_states[cap_no];

                        // build value
                        LONG usage_value = value_cap.LogicalMin +
                                           lroundf((value_cap.LogicalMax - value_cap.LogicalMin) * value_state);
                        if (usage_value > value_cap.LogicalMax)
                            usage_value = value_cap.LogicalMax;
                        else if (usage_value < value_cap.LogicalMin)
                            usage_value = value_cap.LogicalMin;

                        // set the state
                        while (HidP_SetUsageValue(
                                HidP_Output,
                                value_cap.UsagePage,
                                value_cap.LinkCollection,
                                value_cap.NotRange.Usage,
                                (ULONG) usage_value,
                                (PHIDP_PREPARSED_DATA) &hid->preparsed_data[0],
                                report_data,
                                hid->caps.OutputReportByteLength) == HIDP_STATUS_INCOMPATIBLE_REPORT_ID) {

                            // flush report
                            DWORD written_bytes = 0;
                            WriteFile(
                                    hid->handle,
                                    (void*) report_data,
                                    hid->caps.OutputReportByteLength,
                                    &written_bytes,
                                    nullptr
                            );
                            memset(report_data, 0, hid->caps.OutputReportByteLength);
                        }
                    }

                    // write final report
                    DWORD written_bytes = 0;
                    WriteFile(
                            hid->handle,
                            (void*) report_data,
                            hid->caps.OutputReportByteLength,
                            &written_bytes,
                            nullptr
                    );

                    // delete report
                    delete[] report_data;

                    break;
                }
                case HIDDriver::PacDrive: {

                    // allocate report
                    uint8_t report_data[5]{};

                    // set leds
                    size_t mapping[] = {
                            8, 9, 10, 11, 12, 13, 14, 15,
                            0, 1, 2, 3, 4, 5, 6, 7
                    };
                    auto led_data = (uint16_t*) &report_data[3];
                    int count = 0;
                    for (auto &button_output_states : hid->button_output_states) {
                        for (size_t i = 0; i < button_output_states.size(); i++) {
                            if (button_output_states[i])
                                *led_data |= 1 << mapping[count];
                            count++;
                        }
                    }

                    // write report
                    DWORD written_bytes = 0;
                    WriteFile(
                            hid->handle,
                            (void*) &report_data,
                            sizeof(report_data),
                            &written_bytes,
                            nullptr
                    );

                    break;
                }
                default:
                    break;
            }
            break;
        }
        case SEXTET_OUTPUT:
        {
            device->sextetInfo->push_light_state();
            break;
        }
        default:
            break;
    }

    // mark device as updated
    device->output_pending = false;

    // unlock device
    device->mutex->unlock();
}

void rawinput::RawInputManager::devices_flush_output(bool only_updated) {

    // iterate all devices
    for (auto &device : this->devices) {

        // write output
        device_write_output(&device, only_updated);
    }
}

void rawinput::RawInputManager::devices_print() {

    // iterate devices
    log_info("rawinput", "Detected device count: " + to_string(devices.size()));
    for (Device &device : devices) {

        // lock it
        device.mutex->lock();

        // general information
        log_info("rawinput", "Device name: " + device.name);
        log_info("rawinput", "Device desc: " + device.desc);
        log_info("rawinput", "Device handle: " + to_string(device.handle));

        // type specific
        switch (device.type) {
            case MOUSE:
                log_info("rawinput", "Device type: MOUSE");
                break;
            case KEYBOARD:
                log_info("rawinput", "Device type: KEYBOARD");
                break;
            case HID: {
                log_info("rawinput", "Device type: HID");
                log_info("rawinput", "Device preparsed size: " + to_string(
                        device.hidInfo->preparsed_data.size()));
                log_info("rawinput", "Device button caps count: " + to_string(
                        device.hidInfo->button_caps_list.size()));
                int button_name_index = 0;
                for (size_t i = 0; i < device.hidInfo->button_caps_list.size(); i++) {
                    HIDP_BUTTON_CAPS *button_caps = &device.hidInfo->button_caps_list[i];
                    USAGE usage_min = button_caps->Range.UsageMin;
                    USAGE usage_max = button_caps->Range.UsageMax;
                    int cap_len = usage_max - usage_min;
                    std::string *name1 = &device.hidInfo->button_caps_names[button_name_index];
                    std::string *name2 = &device.hidInfo->button_caps_names[button_name_index + cap_len];
                    button_name_index += cap_len + 1;
                    log_info("rawinput",
                            "Device button caps detected: " + *name1 + " to " + *name2 +
                            " (" + to_string(usage_min) + "-" + to_string(usage_max) + ")");
                }
                log_info("rawinput", "Device button output caps count: " + to_string(
                        device.hidInfo->button_output_caps_list.size()));
                int button_output_name_index = 0;
                for (size_t i = 0; i < device.hidInfo->button_output_caps_list.size(); i++) {
                    HIDP_BUTTON_CAPS *button_caps = &device.hidInfo->button_output_caps_list[i];
                    USAGE usage_min = button_caps->Range.UsageMin;
                    USAGE usage_max = button_caps->Range.UsageMax;
                    int cap_len = usage_max - usage_min;
                    std::string *name1 = &device.hidInfo->button_output_caps_names[button_output_name_index];
                    std::string *name2 = &device.hidInfo->button_output_caps_names[button_output_name_index + cap_len];
                    button_output_name_index += cap_len + 1;
                    log_info("rawinput",
                            "Device button output caps detected: " + *name1 + " to " + *name2 +
                            " (" + to_string(usage_min) + "-" + to_string(usage_max) + ")");
                }
                if (!device.hidInfo->value_caps_list.empty()) {
                    log_info("rawinput", "Device value caps count: " + to_string(
                            device.hidInfo->value_caps_list.size()));
                    for (size_t i = 0; i < device.hidInfo->value_caps_list.size(); i++) {
                        HIDP_VALUE_CAPS *value_caps = &device.hidInfo->value_caps_list[i];
                        if (device.hidInfo->value_caps_names.size() < i)
                            log_fatal("rawinput", "Value cap has no name!");
                        std::string &name = device.hidInfo->value_caps_names[i];
                        LONG min = value_caps->LogicalMin;
                        LONG max = value_caps->LogicalMax;
                        log_info("rawinput",
                                "Device value caps detected: " + name +
                                " (" + to_string(min) + " to " + to_string(max) + ")");
                    }
                }
                if (!device.hidInfo->value_output_caps_list.empty()) {
                    log_info("rawinput", "Device value output caps count: " + to_string(
                            device.hidInfo->value_output_caps_list.size()));
                    for (size_t i = 0; i < device.hidInfo->value_output_caps_list.size(); i++) {
                        HIDP_VALUE_CAPS *value_caps = &device.hidInfo->value_output_caps_list[i];
                        if (device.hidInfo->value_output_caps_names.size() < i)
                            log_fatal("rawinput", "Value output cap has no name!");
                        std::string &name = device.hidInfo->value_output_caps_names[i];
                        LONG min = value_caps->LogicalMin;
                        LONG max = value_caps->LogicalMax;
                        log_info("rawinput",
                                "Device value output caps detected: " + name +
                                " (" + to_string(min) + " to " + to_string(max) + ")");
                    }
                }
                break;
            }
            case MIDI: {
                log_info("rawinput", "Device type: MIDI");
                break;
            }
            case SEXTET_OUTPUT: {
                log_info("rawinput", "Device type: SEXTET_OUTPUT");
                break;
            }
            case PIUIO_DEVICE: {
                log_info("rawinput", "Device type: PIUIO");
                break;
            }
            case UNKNOWN:
            default:
                log_info("rawinput", "Device type: UNKNOWN");
                break;
        }

        // unlock device
        device.mutex->unlock();
    }
}

rawinput::DeviceInfo rawinput::RawInputManager::get_device_info(std::string device_name) {
    DeviceInfo info{};

    // check device name
    if (device_name.size() < 16)
        return info;

    // remove header
    device_name = device_name.substr(4);

    // split
    std::vector<std::string> elements;
    strsplit(device_name, elements, '#');

    // check split
    if (elements.size() < 4)
        return info;

    // fill out fields
    info.devclass = elements[0];
    info.subclass = elements[1];
    info.protocol = elements[2];
    info.guid_str = elements[3];

    // generate GUID
    std::wstring guid_wstr = s2ws(info.guid_str);
    if (IIDFromString(guid_wstr.c_str(), &info.guid) != S_OK)
        return info;

    return info;
}

rawinput::Device* rawinput::RawInputManager::devices_get(std::string &name, bool updated) {

    // if the device name is empty we don't even have to look for it
    if (name.empty())
        return nullptr;

    // check if caller wants only updated devices
    if (updated) {

        // iterate the devices
        for (size_t i = 0; i < this->devices.size(); i++) {

            // check if the device names match
            if (this->devices[i].name == name) {

                // lock the device since we are messing with updated
                this->devices[i].mutex->lock();

                // was the device updated?
                if (this->devices[i].updated) {

                    // next call shouldn't trigger
                    this->devices[i].updated = false;

                    // unlock the device
                    this->devices[i].mutex->unlock();

                    // return the device
                    return &this->devices[i];

                } else {

                    // unlock the device again
                    this->devices[i].mutex->unlock();

                    // return null since the device wasn't updated
                    return nullptr;
                }
            }
        }

    } else {

        // just the usual "lookup by name"
        for (size_t i = 0; i < this->devices.size(); i++) {
            if (this->devices[i].name == name)
                return &this->devices[i];
        }
    }

    // device not found
    return nullptr;
}
