#ifndef SPICETOOLS_RAWINPUT_H
#define SPICETOOLS_RAWINPUT_H

#include <vector>
#include <thread>
#include <windows.h>
#include "device.h"

namespace rawinput {

    class RawInputManager {
    private:

        std::vector<Device> devices;
        HWND input_hwnd = nullptr;
        WNDCLASS input_hwnd_class{};
        std::thread* input_thread = nullptr;
        std::thread* flush_thread = nullptr;

        void input_hwnd_create();
        void input_hwnd_destroy();
        void devices_reload();
        void devices_destruct();

        static LRESULT CALLBACK input_wnd_proc(HWND, UINT, WPARAM, LPARAM);
        static void CALLBACK input_midi_proc(HMIDIIN, UINT, DWORD_PTR, DWORD_PTR, DWORD_PTR);
        static DeviceInfo get_device_info(std::string device_name);

    public:

        RawInputManager();
        ~RawInputManager();

        void sextet_register(std::string port_name, std::string alias="Sextet", bool warn=true);

        void devices_register();

        void device_write_output(Device* device, bool only_updated = true);
        void devices_flush_output(bool only_updated = true);

        __stdcall void devices_print();
        Device* devices_get(std::string &name, bool updated=false);

        inline std::vector<Device>* devices_get() {
            return &devices;
        }

        inline std::vector<Device*> devices_get_updated() {
            std::vector<Device*> updated;
            for (auto &device : *devices_get()) {
                device.mutex->lock();
                if (device.updated) {
                    device.updated = false;
                    device.mutex->unlock();
                    updated.emplace_back(&device);
                } else
                    device.mutex->unlock();
            }
            return updated;
        }

        inline void devices_midi_freeze(bool freeze) {
            for (auto &device : *devices_get()) {
                device.mutex->lock();
                if (device.type == MIDI) {
                    device.midiInfo->freeze = freeze;
                    if (!freeze)
                        for (unsigned short index = 0; index < 16 * 128; index++)
                            device.midiInfo->states[index] = false;
                }
                device.mutex->unlock();
            }
        }
    };
}

#endif //SPICETOOLS_RAWINPUT_H
