#include "dxhook.h"
#include <vector>
#include <d3d9.h>
#include "util/detour.h"
#include "util/libutils.h"
#include "util/logging.h"
#include "avs/game.h"

// state
static DWORD_PTR D3D9_DIRECT3D_CREATE9_ADR = 0;
static char D3D9_DIRECT3D_CREATE9_CONTENTS[16];
static WNDPROC WNDPROC_ORIG = nullptr;
static std::vector<WNDPROC> WNDPROC_CUSTOM;

// settings
bool DXHOOK_WINDOWED = false;
bool DXHOOK_CAPTURE = false;
bool DXHOOK_SHOW_CURSOR = false;
DWORD DXHOOK_BEHAVIOR_DISABLE = 0;
std::string DXHOOK_DEVICEID = "PCI\\VEN_1002&DEV_7146";

// types
typedef LONG (WINAPI *ChangeDisplaySettingsExA_t)(LPCSTR lpszDeviceName, DEVMODEA *lpDevMode, HWND hwnd,
                                                  DWORD dwflags, LPVOID lParam);

typedef HRESULT (STDMETHODCALLTYPE *IDirect3D9_CreateDevice_t)(
    IDirect3D9 FAR *This,
    UINT Adapter,
    D3DDEVTYPE DeviceType,
    HWND hFocusWindow,
    DWORD BehaviorFlags,
    D3DPRESENT_PARAMETERS *pPresentationParameters,
    IDirect3DDevice9 **ppReturnedDeviceInterface
);
typedef HRESULT (STDMETHODCALLTYPE *IDirect3D9Ex_CreateDeviceEx_t)(
    IDirect3D9Ex FAR *This,
    UINT Adapter,
    D3DDEVTYPE DeviceType,
    HWND hFocusWindow,
    DWORD BehaviorFlags,
    D3DPRESENT_PARAMETERS *pPresentationParameters,
    D3DDISPLAYMODEEX *pFullscreenDisplayMode,
    IDirect3DDevice9Ex **ppReturnedDeviceInterface
);

typedef HWND (WINAPI *CreateWindowExA_t)(DWORD dwExStyle, LPCTSTR lpClassName, LPCTSTR lpWindowName,
                                         DWORD dwStyle, int x, int y, int nWidth, int nHeight, HWND hWndParent,
                                         HMENU hMenu, HINSTANCE hInstance, LPVOID lpParam);

typedef BOOL (WINAPI *EnumDisplayDevicesA_t)(LPCTSTR lpDevice, DWORD iDevNum, PDISPLAY_DEVICE lpDisplayDevice,
                                             DWORD dwFlags);

typedef IDirect3D9 *(STDMETHODCALLTYPE *Direct3DCreate9_t)(UINT SDKVersion);
typedef HRESULT (WINAPI *Direct3DCreate9Ex_t)(UINT SDKVersion, IDirect3D9Ex **d3d9ex);

static ChangeDisplaySettingsExA_t ChangeDisplaySettingsExA_orig = nullptr;
static IDirect3D9_CreateDevice_t D3D9_CREATE_DEVICE_ORIG = nullptr;
static IDirect3D9Ex_CreateDeviceEx_t D3D9_CREATE_DEVICE_EX_ORIG = nullptr;
static CreateWindowExA_t CreateWindowExA_orig = nullptr;
static Direct3DCreate9_t Direct3DCreate9_orig = nullptr;
static Direct3DCreate9Ex_t Direct3DCreate9Ex_orig = nullptr;
static EnumDisplayDevicesA_t EnumDisplayDevicesA_orig = nullptr;

// window procedure
static RECT WINDOW_RECT;

static LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {

    // call custom procedures
    for (WNDPROC wndProc : WNDPROC_CUSTOM)
        wndProc(hwnd, uMsg, wParam, lParam);

    // capture mouse
    if (DXHOOK_CAPTURE) {
        switch (uMsg) {
            case WM_SETFOCUS: {

                // capture mouse
                GetWindowRect(hwnd, &WINDOW_RECT);
                ClipCursor(&WINDOW_RECT);
                return 1;
            }
            case WM_KILLFOCUS: {

                // free mouse
                ClipCursor(0);
                return 1;
            }
            default:
                break;
        }
    }

    // call default
    return CallWindowProcA(WNDPROC_ORIG, hwnd, uMsg, wParam, lParam);
}

// create device hook function
static HRESULT STDMETHODCALLTYPE D3D9CreateDeviceHook(
    IDirect3D9 FAR *This,
    UINT Adapter,
    D3DDEVTYPE DeviceType,
    HWND hFocusWindow,
    DWORD BehaviorFlags,
    D3DPRESENT_PARAMETERS *pPresentationParameters,
    IDirect3DDevice9 **ppReturnedDeviceInterface
) {
    log_info("dxhook", "IDirect3D9::CreateDevice hook hit");

    // behavior flags
    if (DXHOOK_BEHAVIOR_DISABLE)
        BehaviorFlags &= ~DXHOOK_BEHAVIOR_DISABLE;

    // when rendering via software, disable pure device
    if (BehaviorFlags & D3DCREATE_SOFTWARE_VERTEXPROCESSING)
        BehaviorFlags &= ~D3DCREATE_PUREDEVICE;

    // set windowed
    if (DXHOOK_WINDOWED) {
        pPresentationParameters->Windowed = true;
        pPresentationParameters->FullScreen_RefreshRateInHz = 0;
    }

    // call original
    HRESULT value = D3D9_CREATE_DEVICE_ORIG(This, Adapter, DeviceType, hFocusWindow, BehaviorFlags,
                                            pPresentationParameters, ppReturnedDeviceInterface);

    // check for error
    if (value != D3D_OK) {

        // log error
        log_info("dxhook", "CreateDevice failed: " + to_string(value));

    } else {

        // show cursor
        if (DXHOOK_SHOW_CURSOR)
            ShowCursor(1);

        // hook window procedure
        WNDPROC_ORIG = (WNDPROC) GetWindowLongPtrA(hFocusWindow, GWLP_WNDPROC);
        SetWindowLongPtrA(hFocusWindow, GWLP_WNDPROC, (LONG_PTR) &WindowProc);
    }

    // return result
    return value;
}

// create context hook function
static IDirect3D9 *CALLBACK Direct3DCreate9Hook(UINT SDKVersion) {
    log_info("dxhook", "Direct3DCreate9 hook hit");

    // remove hook
    if (D3D9_DIRECT3D_CREATE9_ADR)
        detour::inline_restore(D3D9_DIRECT3D_CREATE9_ADR, D3D9_DIRECT3D_CREATE9_CONTENTS);

    // create interface
    IDirect3D9 *value = Direct3DCreate9_orig(SDKVersion);
    if (value == NULL) {
        log_warning("dxhook", "Failed to create Direct3D interface for " + to_string(SDKVersion));
        return value;
    }

    // save original function
    if (D3D9_CREATE_DEVICE_ORIG == nullptr)
        D3D9_CREATE_DEVICE_ORIG = value->lpVtbl->CreateDevice;

    // modify interface
    unsigned int OldProtect = 0;
    unsigned int Temp = 0;
    VirtualProtect((void *) &value->lpVtbl->CreateDevice, 4096, PAGE_EXECUTE_READWRITE, (PDWORD) &OldProtect);
    value->lpVtbl->CreateDevice = &D3D9CreateDeviceHook;
    VirtualProtect((void *) &value->lpVtbl->CreateDevice, 4096, OldProtect, (PDWORD) &Temp);

    // add hook
    if (D3D9_DIRECT3D_CREATE9_ADR)
        detour::inline_noprotect((void *) &Direct3DCreate9Hook, D3D9_DIRECT3D_CREATE9_ADR);

    // return modified interface
    return value;
}

// create device hook function
static HRESULT STDMETHODCALLTYPE D3D9CreateDeviceExHook(
    IDirect3D9Ex FAR *This,
    UINT Adapter,
    D3DDEVTYPE DeviceType,
    HWND hFocusWindow,
    DWORD BehaviorFlags,
    D3DPRESENT_PARAMETERS *pPresentationParameters,
    D3DDISPLAYMODEEX *pFullscreenDisplayMode,
    IDirect3DDevice9Ex **ppReturnedDeviceInterface
) {
    log_info("dxhook", "IDirect3D9Ex::CreateDeviceEx hook hit");

    // behavior flags
    if (DXHOOK_BEHAVIOR_DISABLE)
        BehaviorFlags &= ~DXHOOK_BEHAVIOR_DISABLE;

    // when rendering via software, disable pure device
    if (BehaviorFlags & D3DCREATE_SOFTWARE_VERTEXPROCESSING)
        BehaviorFlags &= ~D3DCREATE_PUREDEVICE;

    // set windowed
    //
    // note from MSDN: `pFullscreenDisplayMode` must be NULL for windowed mode.
    if (DXHOOK_WINDOWED) {
        pFullscreenDisplayMode = NULL;
        pPresentationParameters->Windowed = true;
        pPresentationParameters->FullScreen_RefreshRateInHz = 0;
    }

    // call original
    HRESULT result = D3D9_CREATE_DEVICE_EX_ORIG(This, Adapter, DeviceType, hFocusWindow, BehaviorFlags,
                                            pPresentationParameters, pFullscreenDisplayMode,
                                            ppReturnedDeviceInterface);

    // check for error
    if (result != D3D_OK) {

        // log error
        log_info("dxhook", "CreateDeviceEx failed: " + to_string(result));

    } else {

        // show cursor
        if (DXHOOK_SHOW_CURSOR)
            ShowCursor(1);

        // hook window procedure
        WNDPROC_ORIG = (WNDPROC) GetWindowLongPtrA(hFocusWindow, GWLP_WNDPROC);
        SetWindowLongPtrA(hFocusWindow, GWLP_WNDPROC, (LONG_PTR) &WindowProc);
    }

    return result;
}

// create context hook function
static HRESULT WINAPI Direct3DCreate9ExHook(UINT SDKVersion, IDirect3D9Ex **d3d9ex) {
    log_info("dxhook", "Direct3DCreate9Ex hook hit");

    HRESULT result = Direct3DCreate9Ex_orig(SDKVersion, d3d9ex);
    if (result != S_OK || *d3d9ex == NULL) {
        log_warning("dxhook", "Failed to create Direct3D interface for " + to_string(SDKVersion));
        return result;
    }

    // dereference the interface
    IDirect3D9Ex *value = *d3d9ex;

    // save original function
    if (D3D9_CREATE_DEVICE_EX_ORIG == nullptr)
        D3D9_CREATE_DEVICE_EX_ORIG = value->lpVtbl->CreateDeviceEx;

    // modify interface
    unsigned int OldProtect = 0;
    unsigned int Temp = 0;
    VirtualProtect((void *) &value->lpVtbl->CreateDeviceEx, 4096, PAGE_EXECUTE_READWRITE, (PDWORD) &OldProtect);
    value->lpVtbl->CreateDeviceEx = &D3D9CreateDeviceExHook;
    VirtualProtect((void *) &value->lpVtbl->CreateDeviceEx, 4096, OldProtect, (PDWORD) &Temp);

    // return original result
    return result;
}

static WINAPI LONG ChangeDisplaySettingsExA_hook(LPCSTR lpszDeviceName, DEVMODEA *lpDevMode, HWND hwnd,
    DWORD dwflags, LPVOID lParam)
{
    if (DXHOOK_WINDOWED) {
        // Ignore display settings changes when running windowed
        return DISP_CHANGE_SUCCESSFUL;
    }

    return ChangeDisplaySettingsExA_orig(lpszDeviceName, lpDevMode, hwnd, dwflags, lParam);
}

static WINAPI BOOL EnumDisplayDevicesA_hook(LPCTSTR lpDevice, DWORD iDevNum, PDISPLAY_DEVICE lpDisplayDevice,
                                           DWORD dwFlags) {
    BOOL value = EnumDisplayDevicesA_orig(lpDevice, iDevNum, lpDisplayDevice, dwFlags);
    if (value) {
        memcpy(&lpDisplayDevice->DeviceID, DXHOOK_DEVICEID.c_str(), DXHOOK_DEVICEID.size() + 1);
    }
    return value;
}

static WINAPI HWND CreateWindowExA_hook(DWORD dwExStyle, LPCTSTR lpClassName, LPCTSTR lpWindowName,
                                        DWORD dwStyle, int x, int y, int nWidth, int nHeight, HWND hWndParent,
                                        HMENU hMenu, HINSTANCE hInstance, LPVOID lpParam)
{
    return CreateWindowExA_orig(dwExStyle, lpClassName, lpWindowName, dwStyle, x, y, nWidth, nHeight,
                                hWndParent, hMenu, hInstance, lpParam);
}

void dxhook_init() {
    log_info("dxhook", "initializing");

    // patch create context
    if (DXHOOK_WINDOWED || DXHOOK_CAPTURE || DXHOOK_SHOW_CURSOR || DXHOOK_BEHAVIOR_DISABLE) {

        // ignore beatstream since that breaks it for some reason
        if (!avs::game::is_model("NBT")) {

            // inline hook
            D3D9_DIRECT3D_CREATE9_ADR = (DWORD_PTR) GetProcAddress(
                    libutils::get_module("d3d9.dll"),
                    "Direct3DCreate9");
            detour::inline_preserve(
                    (void *) &Direct3DCreate9Hook,
                    D3D9_DIRECT3D_CREATE9_ADR,
                    D3D9_DIRECT3D_CREATE9_CONTENTS);

            // IAT hook
            Direct3DCreate9_orig = (Direct3DCreate9_t) detour::iat_try(
                    "Direct3DCreate9", (void *) &Direct3DCreate9Hook);
            Direct3DCreate9Ex_orig = (Direct3DCreate9Ex_t) detour::iat_try(
                    "Direct3DCreate9Ex", (void *) &Direct3DCreate9ExHook);
        }
    }

    // general hooks
    ChangeDisplaySettingsExA_orig = (ChangeDisplaySettingsExA_t) detour::iat_try(
            "ChangeDisplaySettingsExA", (void *) &ChangeDisplaySettingsExA_hook);
    CreateWindowExA_orig = (CreateWindowExA_t) detour::iat_try(
            "CreateWindowExA", (void *) &CreateWindowExA_hook);
    EnumDisplayDevicesA_orig = (EnumDisplayDevicesA_t) detour::iat_try(
            "EnumDisplayDevicesA", (void *) &EnumDisplayDevicesA_hook);
}

void dxhook_add_wnd_proc(WNDPROC wndProc) {
    WNDPROC_CUSTOM.push_back(wndProc);
}

void dxhook_remove_wnd_proc(WNDPROC wndProc) {
    for (size_t x = 0; x < WNDPROC_CUSTOM.size(); x++)
        if (WNDPROC_CUSTOM[x] == wndProc)
            WNDPROC_CUSTOM.erase(WNDPROC_CUSTOM.begin() + x);
}
