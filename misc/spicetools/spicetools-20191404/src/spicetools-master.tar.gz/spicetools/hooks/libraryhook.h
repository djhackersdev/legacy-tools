#ifndef SPICETOOLS_HOOKS_LIBRARYHOOK_H
#define SPICETOOLS_HOOKS_LIBRARYHOOK_H

#include <string>
#include <windows.h>

void libraryhook_enable(HMODULE module = nullptr);

void libraryhook_hook_library(std::string libraryName, HMODULE libraryAddress);

void libraryhook_hook_proc(std::string procName, FARPROC procAddress);

#endif //SPICETOOLS_HOOKS_LIBRARYHOOK_H
