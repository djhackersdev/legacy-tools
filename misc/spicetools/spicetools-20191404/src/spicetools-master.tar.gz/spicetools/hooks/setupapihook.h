#ifndef SPICETOOLS_HOOKS_SETUPAPIHOOK_H
#define SPICETOOLS_HOOKS_SETUPAPIHOOK_H

#include <minwindef.h>

struct SETUPAPI_SETTINGS {
    int class_guid[4];
    char property_devicedesc[256];
    char property_hardwareid[256];
    DWORD property_address[2];
    char interface_detail[256];
};

void setupapihook_init(HINSTANCE module);

void setupapihook_add(SETUPAPI_SETTINGS settings);

#endif //SPICETOOLS_HOOKS_SETUPAPIHOOK_H
