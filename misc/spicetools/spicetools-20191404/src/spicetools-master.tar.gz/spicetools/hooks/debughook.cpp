#include "debughook.h"
#include "util/utils.h"
#include "util/detour.h"
#include "util/libutils.h"
#include "avs/core.h"
#include "avs/ea3.h"
#include "avs/game.h"

namespace debughook {

    // settings
    bool DEBUGHOOK_LOGGING = true;

    static void WINAPI OutputDebugStringA_hook(LPCTSTR str) {

        // check if logging is enabled
        if (!DEBUGHOOK_LOGGING)
            return;

        // create buffer
        auto buf = new TCHAR[strlen(str)];
        memset(buf, 0, strlen(str));

        // copy to buffer - excluding new lines
        int buf_i = 0;
        for (int i = 0; str[i] != 0; i++) {
            if (str[i] != '\r' && str[i] != '\n') {
                buf[i] = str[i];
                buf_i++;
            }
        }

        // log buffer
        log_info("dbg-hook", buf);

        // delete buffer
        delete[] buf;
    }

    static void WINAPI OutputDebugStringW_hook(const wchar_t *str) {
        OutputDebugStringA_hook(ws2s(str).c_str());
    }

    void attach() {
        log_info("dbg-hook", "attaching...");
        HMODULE kernel32 = libutils::try_module("kernel32.dll");
        detour::inline_hook((void *) &OutputDebugStringA_hook,
                            (DWORD_PTR) libutils::try_proc(kernel32, "OutputDebugStringA"));
        detour::inline_hook((void *) &OutputDebugStringW_hook,
                            (DWORD_PTR) libutils::try_proc(kernel32, "OutputDebugStringW"));
        detour::iat_try("OutputDebugStringA", (void *) &OutputDebugStringA_hook, nullptr);
        detour::iat_try("OutputDebugStringW", (void *) &OutputDebugStringW_hook, nullptr);
        log_info("dbg-hook", "attached");
    }

    void detach() {
        // TODO
    }

}
