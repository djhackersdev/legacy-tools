#include "rs232dummy.h"
#include <vector>
#include <windows.h>
#include "util/detour.h"
#include "util/libutils.h"
#include "launcher/launcher.h"
#include "avs/game.h"

static int WINAPI rs232dummy_dummy1(int a1, int a2) {
    return 1;
}

static int WINAPI rs232dummy_dummy2(int a1, int a2, int a3) {
    return 1;
}

static int WINAPI rs232dummy_ClearCommError(HANDLE hFile, LPDWORD lpErrors, LPCOMSTAT lpStat) {
    if (lpStat) {
        lpStat->fXoffSent = 1;

        /*
         * Some games may check the input queue size.
         * QMA doesn't even attempt to read if this is set to 0.
         * We just set this to 255 and hope games don't rely on this for buffer sizes.
         */
        lpStat->cbInQue = 255;
    }
    return 1;
}

static BOOL WINAPI rs232dummy_SetCommBreak(HANDLE hFile) {
    return true;
}

static BOOL WINAPI rs232dummy_ClearCommBreak(HANDLE hFile) {
    return true;
}

void rs232dummy_init() {

    // insert hooks
    detour::iat_try("SetCommMask", (void *) &rs232dummy_dummy1);
    detour::iat_try("SetupComm", (void *) &rs232dummy_dummy2);
    detour::iat_try("PurgeComm", (void *) &rs232dummy_dummy1);
    detour::iat_try("SetCommTimeouts", (void *) &rs232dummy_dummy1);
    detour::iat_try("GetCommState", (void *) &rs232dummy_dummy1);
    detour::iat_try("SetCommState", (void *) &rs232dummy_dummy1);
    detour::iat_try("EscapeCommFunction", (void *) &rs232dummy_dummy1);
    detour::iat_try("ClearCommError", (void *) &rs232dummy_ClearCommError);
    detour::iat_try("SetCommBreak", (void *) &rs232dummy_SetCommBreak);
    detour::iat_try("ClearCommBreak", (void *) &rs232dummy_ClearCommBreak);
}
