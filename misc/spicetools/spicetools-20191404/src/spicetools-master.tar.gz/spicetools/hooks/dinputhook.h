#ifndef SPICETOOLS_HOOKS_DINPUTHOOK_H
#define SPICETOOLS_HOOKS_DINPUTHOOK_H

#include <windows.h>

void dinputhook_init(HMODULE module = nullptr);

#endif //SPICETOOLS_HOOKS_DINPUTHOOK_H
