#include "devicehook.h"
#include <vector>
#include "util/detour.h"
#include "util/utils.h"
#include "avs/game.h"

bool DEVICE_CREATEFILE_DEBUG = false;
static std::string PATH_HARD_CODE_COMPARE = "d:/###-###/contents";

typedef HANDLE (WINAPI *CreateFileA_t)(LPCSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode,
                                       LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition,
                                       DWORD dwFlagsAndAttributes, HANDLE hTemplateFile);

static CreateFileA_t CreateFileA_real = nullptr;

typedef HANDLE (WINAPI *CreateFileW_t)(LPCWSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode,
                                       LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition,
                                       DWORD dwFlagsAndAttributes, HANDLE hTemplateFile);

static CreateFileW_t CreateFileW_real = nullptr;

typedef BOOL (WINAPI *ReadFile_t)(HANDLE hFile, LPVOID lpBuffer, DWORD nNumberOfBytesToRead,
                                  LPDWORD lpNumberOfBytesRead, LPOVERLAPPED lpOverlapped);

static ReadFile_t ReadFile_real = nullptr;

typedef BOOL (WINAPI *WriteFile_t)(HANDLE hFile, LPCVOID lpBuffer, DWORD nNumberOfBytesToWrite,
                                   LPDWORD lpNumberOfBytesWritten, LPOVERLAPPED lpOverlapped);

static WriteFile_t WriteFile_real = nullptr;

typedef BOOL (WINAPI *DeviceIoControl_t)(HANDLE hDevice, DWORD dwIoControlCode, LPVOID lpInBuffer, DWORD nInBufferSize,
                                         LPVOID lpOutBuffer, DWORD nOutBufferSize, LPDWORD lpBytesReturned,
                                         LPOVERLAPPED lpOverlapped);

static DeviceIoControl_t DeviceIoControl_real = nullptr;

typedef BOOL (WINAPI *CloseHandle_t)(HANDLE hObject);

static CloseHandle_t CloseHandle_real = nullptr;

static std::vector<CustomHandle *> CUSTOM_HANDLES;

static inline CustomHandle *get_custom_handle(HANDLE handle) {
    for (auto customHandle : CUSTOM_HANDLES)
        if ((HANDLE) customHandle == handle)
            return customHandle;
    return nullptr;
}

static HANDLE WINAPI CreateFileA_Hook(LPCSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode,
                                      LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition,
                                      DWORD dwFlagsAndAttributes, HANDLE hTemplateFile) {
    HANDLE result = nullptr;

    // convert to wide char
    WCHAR lpFileNameW[512];
    if (!MultiByteToWideChar(CP_ACP, 0, lpFileName, -1, lpFileNameW, 512))
        return (HANDLE *) -1;

    // debug
    if (DEVICE_CREATEFILE_DEBUG)
        log_info("devicehook", to_string(lpFileName));

    // check custom handles
    if (!CUSTOM_HANDLES.empty()) {
        for (auto handle : CUSTOM_HANDLES) {
            if (handle->open(lpFileNameW)) {
                SetLastError(0);
                result = (HANDLE) handle;
                break;
            }
        }
    }

    // hard coded paths fix
    bool fix = true;
    int lpFileNameLen = wcslen(lpFileNameW);
    for (int i = 0, c = 0; i < lpFileNameLen && (c = PATH_HARD_CODE_COMPARE[i]) != 0; i++) {
        if (c != '#' && lpFileName[i] != (wchar_t) PATH_HARD_CODE_COMPARE[i]) {
            fix = false;
            break;
        }
    }

    // do the fix
    if (fix) {
        int hcLen = PATH_HARD_CODE_COMPARE.length();
        auto buffer = new wchar_t[wcslen(lpFileNameW) + 1]{};
        buffer[0] = '.';
        for (int i = 0; i < lpFileNameLen - hcLen; i++)
            buffer[i + 1] = lpFileName[hcLen + i];
        if (DEVICE_CREATEFILE_DEBUG)
            std::cout << '-' << '>' << ws2s(buffer) << std::endl;

        // check fallback function
        if (CreateFileA_real == nullptr)
            log_fatal("device", "CreateFileA not available.");

        result = CreateFileA_real(lpFileName, dwDesiredAccess, dwShareMode, lpSecurityAttributes,
                                  dwCreationDisposition, dwFlagsAndAttributes, hTemplateFile);
        delete[] buffer;
        return result;
    }

    // fallback
    if (!result) {

        // check fallback function
        if (CreateFileA_real == nullptr)
            log_fatal("device", "CreateFileA not available.");

        // call original
        result = CreateFileA_real(lpFileName, dwDesiredAccess, dwShareMode, lpSecurityAttributes,
                                  dwCreationDisposition, dwFlagsAndAttributes, hTemplateFile);
    }

    // return result
    return result;
}

static HANDLE WINAPI CreateFileW_Hook(LPCWSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode,
                                      LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition,
                                      DWORD dwFlagsAndAttributes, HANDLE hTemplateFile) {
    HANDLE result = nullptr;

    // debug
    if (DEVICE_CREATEFILE_DEBUG)
        log_info("devicehook", ws2s(std::wstring(lpFileName)));

    // check custom handles
    if (!CUSTOM_HANDLES.empty()) {
        for (auto handle : CUSTOM_HANDLES) {
            if (handle->open(lpFileName)) {
                SetLastError(0);
                result = (HANDLE) handle;
                break;
            }
        }
    }

    // hard coded paths fix
    bool fix = true;
    int lpFileNameLen = wcslen(lpFileName);
    for (int i = 0, c = 0; i < lpFileNameLen && (c = PATH_HARD_CODE_COMPARE[i]) != 0; i++) {
        if (c != '#' && lpFileName[i] != (wchar_t) PATH_HARD_CODE_COMPARE[i]) {
            fix = false;
            break;
        }
    }

    // do the fix
    if (fix) {
        int hcLen = PATH_HARD_CODE_COMPARE.length();
        auto buffer = new wchar_t[wcslen(lpFileName) + 1]{};
        buffer[0] = '.';
        for (int i = 0; i < lpFileNameLen - hcLen; i++)
            buffer[i + 1] = lpFileName[hcLen + i];
        if (DEVICE_CREATEFILE_DEBUG)
            std::cout << '-' << '>' << ws2s(buffer) << std::endl;

        // check fallback function
        if (CreateFileW_real == nullptr)
            log_fatal("device", "CreateFileW not available.");

        result = CreateFileW_real(buffer, dwDesiredAccess, dwShareMode, lpSecurityAttributes,
                                  dwCreationDisposition, dwFlagsAndAttributes, hTemplateFile);
        delete[] buffer;
        return result;
    }

    // fallback
    if (!result) {

        // check fallback function
        if (CreateFileW_real == nullptr)
            log_fatal("device", "CreateFileW not available.");

        // call original
        result = CreateFileW_real(lpFileName, dwDesiredAccess, dwShareMode, lpSecurityAttributes,
                                  dwCreationDisposition, dwFlagsAndAttributes, hTemplateFile);
    }

    // return result
    return result;
}

static BOOL WINAPI ReadFileHook(HANDLE hFile, LPVOID lpBuffer, DWORD nNumberOfBytesToRead, LPDWORD lpNumberOfBytesRead,
                                LPOVERLAPPED lpOverlapped) {

    // custom handle
    CustomHandle *customHandle = get_custom_handle(hFile);
    if (customHandle) {
        int value = customHandle->read(lpBuffer, nNumberOfBytesToRead);
        if (value >= 0) {
            SetLastError(0);
            *lpNumberOfBytesRead = (DWORD) value;
            return true;
        } else {
            SetLastError(0xD);
            return false;
        }
    }

    // check fallback function
    if (ReadFile_real == nullptr)
        log_fatal("device", "ReadFile not available.");

    // fallback
    return ReadFile_real(hFile, lpBuffer, nNumberOfBytesToRead, lpNumberOfBytesRead, lpOverlapped);
}

static BOOL WINAPI WriteFileHook(HANDLE hFile, LPCVOID lpBuffer, DWORD nNumberOfBytesToWrite,
                                 LPDWORD lpNumberOfBytesWritten, LPOVERLAPPED lpOverlapped) {

    // custom handle
    CustomHandle *customHandle = get_custom_handle(hFile);
    if (customHandle) {
        int value = customHandle->write(lpBuffer, nNumberOfBytesToWrite);
        if (value >= 0) {
            SetLastError(0);
            *lpNumberOfBytesWritten = (DWORD) value;
            return true;
        } else {
            SetLastError(0xD);
            return false;
        }
    }

    // check fallback function
    if (WriteFile_real == nullptr)
        log_fatal("device", "WriteFile not available.");

    // fallback
    return WriteFile_real(hFile, lpBuffer, nNumberOfBytesToWrite, lpNumberOfBytesWritten, lpOverlapped);
}

static BOOL WINAPI DeviceIoControlHook(HANDLE hDevice, DWORD dwIoControlCode, LPVOID lpInBuffer, DWORD nInBufferSize,
                                       LPVOID lpOutBuffer, DWORD nOutBufferSize, LPDWORD lpBytesReturned,
                                       LPOVERLAPPED lpOverlapped) {
    // custom handle
    CustomHandle *customHandle = get_custom_handle(hDevice);
    if (customHandle) {
        int count = customHandle->device_io(dwIoControlCode, lpInBuffer, nInBufferSize, lpOutBuffer, nOutBufferSize);
        if (count >= 0) {
            SetLastError(0);
            *lpBytesReturned = (DWORD) count;
            if (lpOverlapped)
                SetEvent(lpOverlapped->hEvent);
            return true;
        } else {
            log_info("device", "device_io failed.");
            SetLastError(0xD);
            return false;
        }
    }

    // check fallback function
    if (DeviceIoControl_real == nullptr)
        log_fatal("device", "DeviceIoControl not available.");

    // fallback
    return DeviceIoControl_real(hDevice, dwIoControlCode, lpInBuffer, nInBufferSize, lpOutBuffer, nOutBufferSize,
                                lpBytesReturned, lpOverlapped);
}

static BOOL WINAPI CloseHandleHook(HANDLE hObject) {

    // custom handle
    CustomHandle *customHandle = get_custom_handle(hObject);
    if (customHandle) {
        SetLastError(0);
        return customHandle->close();
    }

    // check fallback function
    if (CloseHandle_real == nullptr)
        log_fatal("device", "CloseHandle not available.");

    // call original
    return CloseHandle_real(hObject);
}

void devicehook_init(HINSTANCE module) {

    // auto module
    if (module == nullptr) {
        module = avs::game::DLL_INSTANCE;
    }

    // hook functions
    void *tmp;
    tmp = detour::iat_try("CreateFileA", (void *) &CreateFileA_Hook, module);
    CreateFileA_real = CreateFileA_real == nullptr ? (CreateFileA_t) tmp : CreateFileA_real;
    tmp = detour::iat_try("CreateFileW", (void *) &CreateFileW_Hook, module);
    CreateFileW_real = CreateFileW_real == nullptr ? (CreateFileW_t) tmp : CreateFileW_real;
    tmp = detour::iat_try("ReadFile", (void *) &ReadFileHook, module);
    ReadFile_real = ReadFile_real == nullptr ? (ReadFile_t) tmp : ReadFile_real;
    tmp = detour::iat_try("WriteFile", (void *) &WriteFileHook, module);
    WriteFile_real = WriteFile_real == nullptr ? (WriteFile_t) tmp : WriteFile_real;
    tmp = detour::iat_try("CloseHandle", (void *) &CloseHandleHook, module);
    CloseHandle_real = CloseHandle_real == nullptr ? (CloseHandle_t) tmp : CloseHandle_real;
    tmp = detour::iat_try("DeviceIoControl", (void *) &DeviceIoControlHook, module);
    DeviceIoControl_real = DeviceIoControl_real == nullptr ? (DeviceIoControl_t) tmp : DeviceIoControl_real;
}

void devicehook_add(CustomHandle *device_handle) {
    CUSTOM_HANDLES.push_back(device_handle);
}

void devicehook_dispose() {
    for (auto handle : CUSTOM_HANDLES)
        delete handle;
    CUSTOM_HANDLES.clear();
}
