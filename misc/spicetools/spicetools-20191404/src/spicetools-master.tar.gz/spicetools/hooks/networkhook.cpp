#include <windows.h>
#include <iphlpapi.h>
#include <stdlib.h>
#include <getopt.h>
#include <string>
#include "util/logging.h"
#include "util/detour.h"
#include "util/fileutils.h"
#include "util/libutils.h"
#include "avs/core.h"
#include "avs/ea3.h"
#include "avs/game.h"

// hooking related stuff
typedef DWORD (WINAPI *GetAdaptersInfo_t)(PIP_ADAPTER_INFO, PULONG);
static GetAdaptersInfo_t GetAdaptersInfo_orig = nullptr;
typedef int (*bind_t)(SOCKET, const struct sockaddr *, int);
static bind_t bind_orig = nullptr;

// settings
std::string NETWORK_ADDRESS = "10.9.0.0";
std::string NETWORK_SUBNET = "255.255.0.0";
static bool GetAdaptersInfo_log = true;

// network structs
static struct in_addr network;
static struct in_addr prefix;
static struct in_addr subnet;

static DWORD WINAPI GetAdaptersInfo_hook(PIP_ADAPTER_INFO pAdapterInfo, PULONG pOutBufLen) {

    // call orig
    DWORD ret = GetAdaptersInfo_orig(pAdapterInfo, pOutBufLen);
    if (ret != 0) {
        return ret;
    }

    // set the best network adapter
    PIP_ADAPTER_INFO info = pAdapterInfo;
    while (info != NULL) {

        // set subnet
        struct in_addr info_subnet;
        info_subnet.s_addr = inet_addr(info->IpAddressList.IpMask.String);

        // set prefix
        struct in_addr info_prefix;
        info_prefix.s_addr = inet_addr(info->IpAddressList.IpAddress.String) & info_subnet.s_addr;

        // check base IP and subnet
        bool isCorrectBaseIp = prefix.s_addr == info_prefix.s_addr;
        bool isCorrectSubnetMask = subnet.s_addr == info_subnet.s_addr;

        // check if requirements are met
        if (isCorrectBaseIp && isCorrectSubnetMask) {

            // log adapter
            if (GetAdaptersInfo_log)
                log_info("network", "Using preferred network adapter: " + to_string(info->AdapterName) +
                         ", " + to_string(info->IpAddressList.IpAddress.String) +
                         ", " + to_string(info->IpAddressList.IpMask.String));

            // set adapter information
            memcpy(pAdapterInfo, info, sizeof(*info));
            pAdapterInfo->Next = NULL;

            // we're done
            GetAdaptersInfo_log = false;
            return ret;
        }

        // iterate
        info = info->Next;
    }

    // get IP forward table
    PMIB_IPFORWARDTABLE pIpForwardTable = (MIB_IPFORWARDTABLE *) malloc(sizeof(MIB_IPFORWARDTABLE));
    DWORD dwSize = 0;
    if (GetIpForwardTable(pIpForwardTable, &dwSize, 1) == ERROR_INSUFFICIENT_BUFFER) {
        free(pIpForwardTable);
        pIpForwardTable = (MIB_IPFORWARDTABLE *) malloc(dwSize);
    }
    if (GetIpForwardTable(pIpForwardTable, &dwSize, 1) != NO_ERROR || pIpForwardTable->dwNumEntries == 0)
        return ret;

    // determine best interface
    DWORD best = pIpForwardTable->table[0].dwForwardIfIndex;
    free(pIpForwardTable);

    // find fallback adapter
    info = pAdapterInfo;
    while (info != NULL) {

        // check if this the adapter we search for
        if (info->Index == best) {

            // log information
            if (GetAdaptersInfo_log)
                log_info("network", "Using fallback adapter: " + to_string(info->AdapterName) +
                         ", " + to_string(info->IpAddressList.IpAddress.String) +
                         ", " + to_string(info->IpAddressList.IpMask.String));

            // set adapter information
            memcpy(pAdapterInfo, info, sizeof(*info));
            pAdapterInfo->Next = NULL;

            // exit the loop
            break;
        }

        // iterate
        info = info->Next;
    }

    // return original value
    GetAdaptersInfo_log = false;
    return ret;
}

static int WINAPI bind_hook(SOCKET s, const struct sockaddr *name, int namelen) {

#pragma clang diagnostic push
#pragma ide diagnostic ignored "OCDFAInspection"

    // cast to sockaddr_in
    sockaddr_in *in_name = (sockaddr_in *) name;

#pragma clang diagnostic pop

    // override bind to allow all hosts
    in_name->sin_addr.s_addr = inet_addr("0.0.0.0");

    // call original
    int ret = bind_orig(s, name, namelen);
    if (ret != 0)
        log_warning("network", "Bind failed: " + to_string(ret));

    // return result
    return ret;
}

void networkhook_init() {

    // announce init
    log_info("network", "SpiceTools Network");

    // set some same defaults
    network.s_addr = inet_addr(NETWORK_ADDRESS.c_str());
    subnet.s_addr = inet_addr(NETWORK_SUBNET.c_str());
    prefix.s_addr = network.s_addr & subnet.s_addr;

    // inet_ntoa(...) reuses the same char array so the results must be copied
    char s_network[17]{}, s_subnet[17]{}, s_prefix[17]{};
    strncpy(s_network, inet_ntoa(network), 16);
    strncpy(s_subnet, inet_ntoa(subnet), 16);
    strncpy(s_prefix, inet_ntoa(prefix), 16);

    // log preferences
    log_info("network", "Network preferences: " + to_string(s_network) +
             ", " + to_string(s_subnet) +
             ", " + to_string(s_prefix));


    // GetAdaptersInfo hook
    auto orig_addr = (GetAdaptersInfo_t) detour::iat_try(
        "GetAdaptersInfo", (void*) GetAdaptersInfo_hook, nullptr);
    if (!orig_addr)
        log_warning("network", "Couldn't hook GetAdaptersInfo.");
    else if (GetAdaptersInfo_orig == nullptr)
        GetAdaptersInfo_orig = orig_addr;

    /*
     * Bind Hook
     */
    bool bind_hook_enabled = true;

    // disable hook for DDR A since the bind hook crashes there for some reason
    if (fileutils::file_exists((MODULE_PATH_STR + "gamemdx.dll").c_str()))
        bind_hook_enabled = false;

    // hook bind
    if (bind_hook_enabled) {

        // hook by name
        auto new_bind_orig = (bind_t) detour::iat_try("bind", (void *) bind_hook, nullptr);
        if (bind_orig == nullptr)
            bind_orig = new_bind_orig;

        // hook ESS by ordinal
        HMODULE ESS_DLL = libutils::try_module("ess.dll");
        if (ESS_DLL) {
            auto bind_orig2 = (bind_t) detour::iat_try_ordinal("WS2_32.dll", 2, (void *) bind_hook, ESS_DLL);

            // try to get some valid pointer
            if (!bind_orig && bind_orig2)
                bind_orig = bind_orig2;
        }
    }
}
