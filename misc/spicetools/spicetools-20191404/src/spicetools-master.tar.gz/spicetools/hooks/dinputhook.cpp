#include "dinputhook.h"
#include <windows.h>
#include <dinput.h>
#include "util/logging.h"
#include "util/detour.h"


typedef HRESULT (WINAPI *DirectInput8Create_t) (HINSTANCE, DWORD, REFIID, LPVOID*, LPUNKNOWN);
static DirectInput8Create_t DirectInput8Create_real = nullptr;

static HRESULT WINAPI CreateDeviceHook(IDirectInput8W FAR *This,
        REFGUID rguid,
        LPDIRECTINPUTDEVICE8W* lplpDirectInputDevice,
        LPUNKNOWN pUnkOuter) {
    return DIERR_NOINTERFACE;
}

static HRESULT WINAPI EnumDevicesHook(IDirectInput8W FAR *This,
        DWORD dwDevType,
        LPDIENUMDEVICESCALLBACKW lpCallback,
        LPVOID pvRef,
        DWORD dwFlags) {
    return DI_OK;
}

static HRESULT WINAPI DirectInput8CreateHook(
        HINSTANCE hinst,
        DWORD dwVersion,
        REFIID riidltf,
        LPVOID* ppvOut,
        LPUNKNOWN punkOuter) {

    // call original function
    IDirectInput8W* interface_ptr = nullptr;
    HRESULT result = DirectInput8Create_real(
            hinst,
            dwVersion,
            riidltf,
            (LPVOID*) &interface_ptr,
            punkOuter);

    // check for errors
    if (result != DI_OK)
        return result;

    // patch functions
    unsigned int old = 0, tmp = 0;
    VirtualProtect((void*) interface_ptr->lpVtbl->CreateDevice, 4096, PAGE_EXECUTE_READWRITE, (PDWORD) &old);
    interface_ptr->lpVtbl->CreateDevice = CreateDeviceHook;
    VirtualProtect((void*) interface_ptr->lpVtbl->CreateDevice, 4096, old, (PDWORD) &tmp);
    VirtualProtect((void*) interface_ptr->lpVtbl->EnumDevices, 4096, PAGE_EXECUTE_READWRITE, (PDWORD) &old);
    interface_ptr->lpVtbl->EnumDevices = EnumDevicesHook;
    VirtualProtect((void*) interface_ptr->lpVtbl->EnumDevices, 4096, old, (PDWORD) &tmp);

    // return result
    *ppvOut = interface_ptr;
    return result;
}

void dinputhook_init(HMODULE module) {

    /*
     * This is for the games using DirectInput for keyboard/gamepad controls themselves,
     * for things such as debug controls. We don't want that, neither do we want the game to
     * interfere with our RawInput stuff.
     */

    // patch IAT
    auto tmp = (DirectInput8Create_t) detour::iat_try(
            "DirectInput8Create", (void *) DirectInput8CreateHook, module, "dinput8.dll");
    if (!DirectInput8Create_real) {
        log_info("dinputhook", "DirectInput8Create hooked");
        DirectInput8Create_real = tmp;
    }
}
