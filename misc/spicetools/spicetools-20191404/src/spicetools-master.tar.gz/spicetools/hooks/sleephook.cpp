#include "sleephook.h"
#include "util/detour.h"
#include "launcher/launcher.h"
#include "avs/game.h"

// settings
static DWORD SLEEPHOOK_MS_MAX;
static DWORD SLEEPHOOK_MS_REPLACE;

typedef VOID (WINAPI *Sleep_t)(DWORD dwMilliseconds);
static Sleep_t Sleep_orig;

typedef DWORD (WINAPI *SleepEx_t)(DWORD dwMilliseconds, BOOL bAltertable);
static SleepEx_t SleepEx_orig;

static VOID WINAPI SleepHook(DWORD dwMilliseconds) {
    if (dwMilliseconds > SLEEPHOOK_MS_MAX)
        dwMilliseconds = SLEEPHOOK_MS_REPLACE;
    Sleep_orig(dwMilliseconds);
}

static VOID WINAPI SleepExHook(DWORD dwMilliseconds, BOOL bAltertable) {
    if (dwMilliseconds > SLEEPHOOK_MS_MAX)
        dwMilliseconds = SLEEPHOOK_MS_REPLACE;
    SleepEx_orig(dwMilliseconds, bAltertable);
}

void sleephook_init(DWORD ms_max, DWORD ms_replace, HMODULE module) {

    // auto module
    if (!module) {
        module = avs::game::DLL_INSTANCE;
    }

    // settings
    SLEEPHOOK_MS_MAX = ms_max;
    SLEEPHOOK_MS_REPLACE = ms_replace;

    // hook functions
    Sleep_orig = (Sleep_t) detour::iat_try(
            "Sleep", (void *) &SleepHook, module);
    SleepEx_orig = (SleepEx_t) detour::iat_try(
            "SleepEx", (void *) &SleepExHook, module);
}
