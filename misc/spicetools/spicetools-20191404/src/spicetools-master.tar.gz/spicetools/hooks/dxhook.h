#ifndef SPICETOOLS_HOOKS_DXHOOK_H
#define SPICETOOLS_HOOKS_DXHOOK_H

#include <windows.h>
#include <string>

extern bool DXHOOK_WINDOWED;
extern bool DXHOOK_CAPTURE;
extern bool DXHOOK_SHOW_CURSOR;
extern DWORD DXHOOK_BEHAVIOR_DISABLE;
extern std::string DXHOOK_DEVICEID;

void dxhook_init();

void dxhook_add_wnd_proc(WNDPROC wndProc);

void dxhook_remove_wnd_proc(WNDPROC wndProc);

#endif //SPICETOOLS_HOOKS_DXHOOK_H
