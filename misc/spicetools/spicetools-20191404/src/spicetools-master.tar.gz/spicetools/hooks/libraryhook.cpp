#include "libraryhook.h"
#include <vector>
#include <util/utils.h>
#include "util/detour.h"
#include "util/logging.h"

struct LHOOK_LIB {
    std::string libName;
    HMODULE libAddress;
};

struct LHOOK_PROC {
    std::string procName;
    FARPROC procAddress;
};

static bool LHOOK_ENABLED = false;
static std::vector<LHOOK_LIB> LHOOK_LIBS;
static std::vector<LHOOK_PROC> LHOOK_PROCS;

static HMODULE WINAPI LoadLibraryA_Hook(LPCTSTR lpFileName) {

    // check hooks
    if (LHOOK_ENABLED && lpFileName)
        for (LHOOK_LIB hook : LHOOK_LIBS)
            if (!stricmp(lpFileName, hook.libName.c_str()))
                return hook.libAddress;

    // fallback
    return LoadLibraryA(lpFileName);
}

static HMODULE WINAPI LoadLibraryW_Hook(LPCWSTR lpFileName) {

    // check hooks
    if (LHOOK_ENABLED && lpFileName)
        for (LHOOK_LIB hook : LHOOK_LIBS)
            if (ws2s(std::wstring(lpFileName)) == hook.libName)
                return hook.libAddress;

    // fallback
    return LoadLibraryW(lpFileName);
}

static HMODULE WINAPI GetModuleHandleA_Hook(LPCSTR lpModuleName) {

    // check hooks
    if (LHOOK_ENABLED && lpModuleName)
        for (LHOOK_LIB hook : LHOOK_LIBS)
            if (!stricmp(lpModuleName, hook.libName.c_str()))
                return hook.libAddress;

    // fallback
    return GetModuleHandleA(lpModuleName);
}

static HMODULE WINAPI GetModuleHandleW_Hook(LPCWSTR lpModuleName) {

    // check hooks
    if (LHOOK_ENABLED && lpModuleName)
        for (LHOOK_LIB hook : LHOOK_LIBS)
            if (ws2s(std::wstring(lpModuleName)) == hook.libName)
                return hook.libAddress;

    // fallback
    return GetModuleHandleW(lpModuleName);
}

static FARPROC WINAPI GetProcAddress_Hook(HMODULE hModule, LPCSTR lpProcName) {

    // check for ordinal
    if ((size_t) lpProcName <= UINT16_MAX) {

        // fallback
        return GetProcAddress(hModule, lpProcName);
    }

    // check hooks
    if (LHOOK_ENABLED && lpProcName)
        for (LHOOK_PROC hook : LHOOK_PROCS)
            if (!strcmp(lpProcName, hook.procName.c_str()))
                return hook.procAddress;

    // fallback
    return GetProcAddress(hModule, lpProcName);
}

void libraryhook_enable(HMODULE module) {
    log_info("libraryhook", "LibraryHook Attach");

    // detour
    detour::iat_try("LoadLibraryA", (void *) LoadLibraryA_Hook, module, "kernel32.dll");
    detour::iat_try("LoadLibraryW", (void *) LoadLibraryW_Hook, module, "kernel32.dll");
    detour::iat_try("GetModuleHandleA", (void *) GetModuleHandleA_Hook, module, "kernel32.dll");
    detour::iat_try("GetModuleHandleW", (void *) GetModuleHandleW_Hook, module, "kernel32.dll");
    detour::iat_try("GetProcAddress", (void *) GetProcAddress_Hook, module, "kernel32.dll");

    // set enabled
    LHOOK_ENABLED = true;
}

void libraryhook_hook_library(std::string libraryName, HMODULE libraryAddress) {

    // add library to list
    LHOOK_LIB hook;
    hook.libName = libraryName;
    hook.libAddress = libraryAddress;
    LHOOK_LIBS.push_back(hook);
}

void libraryhook_hook_proc(std::string procName, FARPROC procAddress) {

    // add proc to list
    LHOOK_PROC hook;
    hook.procName = procName;
    hook.procAddress = procAddress;
    LHOOK_PROCS.push_back(hook);
}
