#ifndef SPICETOOLS_HOOKS_DEVICEHOOK_H
#define SPICETOOLS_HOOKS_DEVICEHOOK_H

#include <windows.h>

extern bool DEVICE_CREATEFILE_DEBUG;

class CustomHandle {
public:
    virtual ~CustomHandle() = default;

    virtual bool open(LPCWSTR lpFileName) = 0;

    virtual int read(LPVOID lpBuffer, DWORD nNumberOfBytesToRead) = 0;

    virtual int write(LPCVOID lpBuffer, DWORD nNumberOfBytesToWrite) = 0;

    virtual int device_io(DWORD dwIoControlCode, LPVOID lpInBuffer, DWORD nInBufferSize, LPVOID lpOutBuffer,
                          DWORD nOutBufferSize) = 0;

    virtual bool close() = 0;
};

void devicehook_init(HINSTANCE module = nullptr);

void devicehook_add(CustomHandle *device_handle);

void devicehook_dispose();

#endif //SPICETOOLS_HOOKS_DEVICEHOOK_H
