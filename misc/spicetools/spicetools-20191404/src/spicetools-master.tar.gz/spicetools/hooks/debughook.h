#ifndef SPICETOOLS_HOOKS_DEBUGHOOK_H
#define SPICETOOLS_HOOKS_DEBUGHOOK_H

#include <windows.h>
#include "util/logging.h"
#include "util/detour.h"

namespace debughook {

    // settings
    extern bool DEBUGHOOK_LOGGING;

    // functions
    void attach();
    void detach();
}

#endif //SPICETOOLS_HOOKS_DEBUGHOOK_H
