#ifndef SPICETOOLS_HOOKS_NETWORK_H
#define SPICETOOLS_HOOKS_NETWORK_H

#include <string>

extern std::string NETWORK_ADDRESS;
extern std::string NETWORK_SUBNET;

void networkhook_init();

#endif //SPICETOOLS_HOOKS_NETWORK_H
