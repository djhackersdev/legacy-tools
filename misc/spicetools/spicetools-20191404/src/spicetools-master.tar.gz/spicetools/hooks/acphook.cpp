#include <ntstatus.h>
#include <avs/game.h>
#include <util/utils.h>
#include "acphook.h"
#include "util/detour.h"
#include "util/logging.h"

// ANSI/OEM Japanese; Japanese (Shift-JIS)
static const UINT ACPHOOK_CODEPAGE = 932;

static NTSTATUS NTAPI RtlMultiByteToUnicodeNHook(
        PWCH UnicodeString,
        ULONG MaxBytesInUnicodeString,
        PULONG BytesInUnicodeString,
        const CHAR *MultiByteString,
        ULONG BytesInMultiByteString) {

    // try to convert
    auto wc_num = MultiByteToWideChar(
            ACPHOOK_CODEPAGE,
            0,
            MultiByteString,
            (int) BytesInMultiByteString,
            UnicodeString,
            (int) MaxBytesInUnicodeString
    );

    // error handling
    if (!wc_num) {
        auto error = GetLastError();
        if (error == ERROR_INSUFFICIENT_BUFFER)
            return STATUS_BUFFER_TOO_SMALL;
        if (error == ERROR_INVALID_PARAMETER || error == ERROR_INVALID_FLAGS)
            return STATUS_INVALID_PARAMETER;
        if (error == ERROR_NO_UNICODE_TRANSLATION)
            return STATUS_UNMAPPABLE_CHARACTER;
        return STATUS_UNSUCCESSFUL;
    }

    // set byte count
    if (BytesInUnicodeString)
        *BytesInUnicodeString = 2 * (UINT) wc_num;

    // return success
    return STATUS_SUCCESS;
}

void acphook_init() {
    log_info("acphook", "initializing");
    detour::iat_try("RtlMultiByteToUnicodeN", (void*) &RtlMultiByteToUnicodeNHook, nullptr, "ntdll.dll");
}
