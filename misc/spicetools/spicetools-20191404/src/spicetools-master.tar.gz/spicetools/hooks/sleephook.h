#ifndef SPICETOOLS_HOOKS_SLEEPHOOK_H
#define SPICETOOLS_HOOKS_SLEEPHOOK_H

#include <windows.h>

void sleephook_init(DWORD ms_max, DWORD ms_replace, HMODULE module = NULL);

#endif //SPICETOOLS_HOOKS_SLEEPHOOK_H
