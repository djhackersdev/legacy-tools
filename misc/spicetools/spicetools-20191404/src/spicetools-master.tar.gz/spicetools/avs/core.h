#ifndef SPICETOOLS_AVS_CORE_H
#define SPICETOOLS_AVS_CORE_H

#include <cstddef>
#include <string>
#include <windows.h>

namespace avs {

    /*
     * helpers
     */
    namespace core {

        // import mapping
        struct avs_core_import {
            const char *version;
            const char *property_search;
            const char *boot;
            const char *shutdown;
            const char *property_desc_to_buffer;
            const char *property_destroy;
            const char *property_read_query_memsize;
            const char *property_create;
            const char *property_insert_read;
            const char *property_node_create;
            const char *property_node_refer;
            const char *std_setenv;
            const char *property_node_remove;
        };

        // settings
        enum Version {
            AVSLEGACY,
            AVS21360,
            AVS21580,
            AVS21610,
            AVS21651,
            AVS21671,
            AVS21700,
            AVS_VERSION_COUNT
        };
        extern Version VERSION;
        extern size_t HEAP_SIZE;
        extern std::string LOG_PATH;
        extern std::string CFG_PATH;

        // handle
        extern HINSTANCE DLL_INSTANCE;
        extern std::string DLL_NAME;

        // helpers
        void* config_read(const std::string &filename);
        void* property_search_safe(void* node, void* node2, char* name);
        void config_destroy(void* config);

        // functions
        void create_log();
        void load_dll();
        void boot();
        void shutdown();
    }

    /*
     * library functions
     */

    typedef void *(*AVS_PROPERTY_SEARCH_T)(void*, void*, char*);
    extern AVS_PROPERTY_SEARCH_T avs_property_search;

    typedef int (*AVS215_BOOT_T)(void*, void*, size_t, void*, size_t, void*, HANDLE);
    typedef int (*AVS216_BOOT_T)(void*, void*, size_t, void*, void*, HANDLE);
    extern AVS215_BOOT_T avs215_boot;
    extern AVS216_BOOT_T avs216_boot;

    typedef void (*AVS_SHUTDOWN_T)(void);
    extern AVS_SHUTDOWN_T avs_shutdown;

    typedef void *(*AVS_PROPERTY_DESC_TO_BUFFER_T)(void*);
    extern AVS_PROPERTY_DESC_TO_BUFFER_T avs_property_desc_to_buffer;

    typedef int (*AVS_PROPERTY_DESTROY_T)(void*);
    extern AVS_PROPERTY_DESTROY_T avs_property_destroy;

    typedef size_t (*AVS_PROPERTY_READ_QUERY_MEMSIZE_T)(void*, DWORD, DWORD*, DWORD*);
    extern AVS_PROPERTY_READ_QUERY_MEMSIZE_T avs_property_read_query_memsize;

    typedef void *(*AVS_PROPERTY_CREATE_T)(int, void*, int);
    extern AVS_PROPERTY_CREATE_T avs_property_create;

    typedef int (*AVS_PROPERTY_INSERT_READ_T)(void*, int, void*, int);
    extern AVS_PROPERTY_INSERT_READ_T avs_property_insert_read;

    typedef int (*AVS_PROPERTY_NODE_CREATE_T)(void*, void*, int, char*, void*);
    extern AVS_PROPERTY_NODE_CREATE_T avs_property_node_create;

    typedef int (*AVS_PROPERTY_NODE_REFER_T)(void*, void*, char*, int, void*, int);
    extern AVS_PROPERTY_NODE_REFER_T avs_property_node_refer;

    typedef int (*AVS_STD_SETENV_T)(char*, char*);
    extern AVS_STD_SETENV_T avs_std_setenv;

    typedef int (*AVS_PROPERTY_NODE_REMOVE_T)(void*);
    extern AVS_PROPERTY_NODE_REMOVE_T avs_property_node_remove;

}

#endif //SPICETOOLS_AVS_CORE_H
