#ifndef SPICETOOLS_AVS_GAME_H
#define SPICETOOLS_AVS_GAME_H

#include <string>
#include <windows.h>

namespace avs {

    /*
     * helpers
     */
    namespace game {

        // properties
        extern char MODEL[4];
        extern char DEST[2];
        extern char SPEC[2];
        extern char REV[2];
        extern char EXT[11];

        // handle
        extern HINSTANCE DLL_INSTANCE;
        extern std::string DLL_NAME;

        // helpers
        bool is_model(const char* model);

        // functions
        void load_dll();

        /*
         * library functions
         */

        typedef bool (*ENTRY_INIT_T)(void *, void *);
        extern ENTRY_INIT_T entry_init;

        typedef void (*ENTRY_MAIN_T)();
        extern ENTRY_MAIN_T entry_main;
    }
}

#endif //SPICETOOLS_AVS_GAME_H
