#include "game.h"
#include "util/libutils.h"
#include "util/fileutils.h"
#include "util/logging.h"
#include "launcher/launcher.h"

namespace avs {

    namespace game {

        // functions
        ENTRY_INIT_T entry_init;
        ENTRY_MAIN_T entry_main;

        // properties
        char MODEL[4] = {'0', '0', '0', '\x00'};
        char DEST[2] = {'0', '\x00'};
        char SPEC[2] = {'0', '\x00'};
        char REV[2] = {'0', '\x00'};
        char EXT[11] = {'0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '\x00'};

        // handle
        HINSTANCE DLL_INSTANCE;
        std::string DLL_NAME;

        bool is_model(const char* model) {
            return stricmp(MODEL, model) == 0;
        }

        void load_dll() {
            log_info("avs-game", "loading DLL");

            // load game instance
            if (fileutils::verify_header_pe(MODULE_PATH_STR + DLL_NAME))
                DLL_INSTANCE = libutils::load_library(MODULE_PATH_STR + DLL_NAME);

            // load entry points
            entry_init = (ENTRY_INIT_T) libutils::get_proc(DLL_INSTANCE, "dll_entry_init");
            entry_main = (ENTRY_MAIN_T) libutils::get_proc(DLL_INSTANCE, "dll_entry_main");
            log_info("avs-game", "loaded successfully");
        }
    }
}
