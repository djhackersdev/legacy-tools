#ifndef SPICETOOLS_AVS_EA3_H
#define SPICETOOLS_AVS_EA3_H

#include <windows.h>
#include <string>

namespace avs {

    /*
     * helpers
     */
    namespace ea3 {

        // import mapping
        struct avs_ea3_import {
            const char *version;
            const char *boot;
            const char *shutdown;
        };

        // settings
        extern std::string CFG_PATH;
        extern std::string APP_PATH;
        extern char* PCBID_CUSTOM;
        extern char* SOFTID_CUSTOM;
        extern char* URL_CUSTOM;
        extern int URL_SLASH;

        // handle
        extern HINSTANCE DLL_INSTANCE;
        extern std::string DLL_NAME;

        // functions
        void load_dll();
        void boot(unsigned short easrv_port);
        void shutdown();
    }

    /*
     * library functions
     */

    typedef int (*AVS_EA3_BOOT_STARTUP_T)(void *);
    extern AVS_EA3_BOOT_STARTUP_T avs_ea3_boot_startup;

    typedef void (*AVS_EA3_SHUTDOWN_T)(void);
    extern AVS_EA3_SHUTDOWN_T avs_ea3_shutdown;
}

#endif //SPICETOOLS_AVS_EA3_H
