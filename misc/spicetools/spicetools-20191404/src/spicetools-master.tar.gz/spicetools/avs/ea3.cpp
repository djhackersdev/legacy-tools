#include "ea3.h"
#include "core.h"
#include "game.h"
#include "util/detour.h"
#include "util/logging.h"
#include "util/fileutils.h"
#include "util/libutils.h"

namespace avs {

    // functions
    AVS_EA3_BOOT_STARTUP_T avs_ea3_boot_startup;
    AVS_EA3_SHUTDOWN_T avs_ea3_shutdown;

    namespace ea3 {

        // settings
        std::string CFG_PATH;
        std::string APP_PATH;
        char* PCBID_CUSTOM = nullptr;
        char* SOFTID_CUSTOM = nullptr;
        char* URL_CUSTOM = nullptr;
        int URL_SLASH = -1;

        // handle
        HINSTANCE DLL_INSTANCE = nullptr;
        std::string DLL_NAME = "";

        // static fields
        static avs_ea3_import IMPORTS[core::AVS_VERSION_COUNT];

        void load_dll() {
            log_info("avs-ea3", "loading DLL");

            // detect DLL name
            if (fileutils::file_exists((MODULE_PATH_STR + "avs2-core.dll").c_str())) {
                DLL_NAME = "avs2-ea3.dll";
            } else {
#ifdef SPICE64
                DLL_NAME = "libavs-win64-ea3.dll";
#else
                DLL_NAME = "libavs-win32-ea3.dll";
#endif
            }

            /*
             * Imports
             */

            IMPORTS[core::AVSLEGACY] = {
                .version  = "legacy",
                .boot     = "ea3_boot",
                .shutdown = "ea3_shutdown",
            };
            IMPORTS[core::AVS21360] = {
                .version  = "2.13.6.0",
                .boot     = "XEb552d500005d",
                .shutdown = "XEb552d5000060",
            };
            IMPORTS[core::AVS21580] = {
                .version  = "2.15.8.0",
                .boot     = "XE592acd00008c",
                .shutdown = "XE592acd00005a",
            };
            IMPORTS[core::AVS21610] = {
                .version  = "2.16.1.0",
                .boot     = "XEyy2igh000006",
                .shutdown = "XEyy2igh000007",
            };
            IMPORTS[core::AVS21651] = {
                .version  = "2.16.5.1",
                .boot     = "XEyy2igh000007",
                .shutdown = "XEyy2igh000008",
            };
            IMPORTS[core::AVS21671] = {
                .version  = "2.16.7.1",
                .boot     = "XEyy2igh000007",
                .shutdown = "XEyy2igh000008",
            };
            IMPORTS[core::AVS21700] = {
                .version  = "2.17.0.0",
                .boot     = "XEmdwapa000024",
                .shutdown = "XEmdwapa000025",
            };

            // load library
            DLL_INSTANCE = libutils::load_library(MODULE_PATH_STR + DLL_NAME);

            // get version string
            char version[32];
            fileutils::version_pe(MODULE_PATH_STR + DLL_NAME, version);

            // check by version string
            int ver = -1;
            for (int i = 0; i < core::AVS_VERSION_COUNT; i++) {
                if (strcmp(IMPORTS[i].version, version) == 0) {
                    ver = i;
                    break;
                }
            }

            // check version by brute force
            if (ver < 0) {
                for (int i = 0; i < core::AVS_VERSION_COUNT; i++) {
                    if (GetProcAddress(DLL_INSTANCE, IMPORTS[i].boot) != nullptr) {
                        ver = i;
                        break;
                    }
                }
            }

            // check if version was found
            if (ver < 0)
                log_fatal("avs-ea3", "Unknown " + DLL_NAME);

            // print version
            log_info("avs-ea3", "Found AVS2 EA3 " + to_string(IMPORTS[ver].version));

            // load functions
            avs_ea3_boot_startup = (AVS_EA3_BOOT_STARTUP_T) libutils::get_proc(
                    DLL_INSTANCE, IMPORTS[ver].boot);
            avs_ea3_shutdown = (AVS_EA3_SHUTDOWN_T) libutils::get_proc(
                    DLL_INSTANCE, IMPORTS[ver].shutdown);
        }

        void boot(unsigned short easrv_port) {
            log_info("avs-ea3", "booting");

            // detect file name
            std::string ea3_config_name;
            if (CFG_PATH.size())
                ea3_config_name = CFG_PATH;
            else
                ea3_config_name = fileutils::file_exists("prop/ea3-config.xml")
                                  ? "prop/ea3-config.xml"
                                  : "prop/eamuse-config.xml";

            // read configuration
            void *ea3_config = avs::core::config_read(ea3_config_name);
            void *app_config = avs::core::config_read(APP_PATH.size()
                                           ? APP_PATH
                                           : "prop/app-config.xml");

            // get nodes
            void *ea3 = avs::core::property_search_safe(ea3_config, nullptr, (char *) "/ea3");
            void *ea3_id = avs::core::property_search_safe(ea3_config, nullptr, (char *) "/ea3/id");
            void *ea3_id_hard = avs_property_search(ea3_config, nullptr, (char *) "/ea3/id/hardid");
            void *ea3_soft = avs::core::property_search_safe(ea3_config, nullptr, (char *) "/ea3/soft");
            void *app_param = avs::core::property_search_safe(app_config, nullptr, (char *) "/param");

            // set hard ID
            if (ea3_id_hard == nullptr)
                avs_property_node_create(ea3_config, ea3_id, 11, (char *) "hardid", (char *) "DEADBEEFDEAD");

            // node values
            char EA3_PCBID[21]{};
            char EA3_HARDID[21]{};
            char EA3_SOFTID[21]{};
            char EA3_MODEL[4]{};
            char EA3_DEST[2]{};
            char EA3_SPEC[2]{};
            char EA3_REV[2]{};
            char EA3_EXT[11]{};

            // read nodes
            avs_property_node_refer(ea3_config, ea3_id, (char *) "pcbid", 11, (char *) &EA3_PCBID, 21);
            avs_property_node_refer(ea3_config, ea3_id, (char *) "hardid", 11, (char *) &EA3_HARDID, 21);
            avs_property_node_refer(ea3_config, ea3_id, (char *) "softid", 11, (char *) &EA3_SOFTID, 21);
            avs_property_node_refer(ea3_config, ea3_soft, (char *) "model", 11, (char *) &EA3_MODEL, 4);
            avs_property_node_refer(ea3_config, ea3_soft, (char *) "dest", 11, (char *) &EA3_DEST, 2);
            avs_property_node_refer(ea3_config, ea3_soft, (char *) "spec", 11, (char *) &EA3_SPEC, 2);
            avs_property_node_refer(ea3_config, ea3_soft, (char *) "rev", 11, (char *) &EA3_REV, 2);
            avs_property_node_refer(ea3_config, ea3_soft, (char *) "ext", 11, (char *) &EA3_EXT, 11);

            // custom PCBID
            if (PCBID_CUSTOM != nullptr) {

                // copy ID
                for (int i = 0; i < 20; i++) {
                    char c = PCBID_CUSTOM[i];
                    if (c != 0)
                        EA3_PCBID[i] = c;
                    else
                        log_fatal("avs-ea3", "Custom PCBID too short.");
                }
                EA3_PCBID[20] = 0;

                // set nodes
                avs_property_node_remove(avs_property_search(ea3_config, ea3_id, (char *) "pcbid"));
                avs_property_node_create(ea3_config, ea3_id, 11, (char *) "pcbid", EA3_PCBID);
            }

            // custom SOFTID
            if (SOFTID_CUSTOM != nullptr) {

                // copy ID
                for (int i = 0; i < 20; i++) {
                    char c = SOFTID_CUSTOM[i];
                    if (c != 0)
                        EA3_SOFTID[i] = c;
                    else
                        log_fatal("avs-ea3", "Custom SOFTID too short.");
                }
                EA3_SOFTID[20] = 0;

                // set nodes
                avs_property_node_remove(avs_property_search(ea3_config, ea3_id, (char *) "softid"));
                avs_property_node_create(ea3_config, ea3_id, 11, (char *) "softid", EA3_SOFTID);
            }

            // build security code
            std::ostringstream security_code;
            security_code << "G*";
            security_code << (char *) &EA3_MODEL;
            security_code << (char *) &EA3_DEST;
            security_code << (char *) &EA3_SPEC;
            security_code << (char *) &EA3_REV;
            std::string security_code_str = security_code.str();

            // set env variables
            avs_std_setenv((char *) "/env/boot/version", (char *) "SPICETOOLS");
            avs_std_setenv((char *) "/env/profile/security_code", (char *) security_code_str.c_str());
            avs_std_setenv((char *) "/env/profile/secplug_b_security_code", (char *) security_code_str.c_str());
            avs_std_setenv((char *) "/env/profile/system_id", (char *) &EA3_PCBID);
            avs_std_setenv((char *) "/env/profile/account_id", (char *) &EA3_PCBID);
            avs_std_setenv((char *) "/env/profile/license_id", (char *) &EA3_SOFTID);
            avs_std_setenv((char *) "/env/profile/software_id", (char *) &EA3_SOFTID);
            avs_std_setenv((char *) "/env/profile/hardware_id", (char *) &EA3_HARDID);

            // build game init code
            std::ostringstream init_code;
            init_code << (char *) &EA3_MODEL;
            init_code << (char *) &EA3_DEST;
            init_code << (char *) &EA3_SPEC;
            init_code << (char *) &EA3_REV;
            init_code << (char *) &EA3_EXT;
            std::string init_code_str = init_code.str();

            // call the game init
            log_info("avs-ea3", "calling entry init");
            if (!avs::game::entry_init((char *) init_code_str.c_str(), app_param))
                log_fatal("avs-ea3", "entry init failed :(");

            // remove nodes
            avs_property_node_remove(avs_property_search(ea3_config, nullptr, (char *) "/ea3/soft/model"));
            avs_property_node_remove(avs_property_search(ea3_config, nullptr, (char *) "/ea3/soft/dest"));
            avs_property_node_remove(avs_property_search(ea3_config, nullptr, (char *) "/ea3/soft/spec"));
            avs_property_node_remove(avs_property_search(ea3_config, nullptr, (char *) "/ea3/soft/rev"));
            avs_property_node_remove(avs_property_search(ea3_config, nullptr, (char *) "/ea3/soft/ext"));

            // create nodes
            avs_property_node_create(ea3_config, ea3_soft, 11, (char *) "model", (char *) &EA3_MODEL);
            avs_property_node_create(ea3_config, ea3_soft, 11, (char *) "dest", (char *) &EA3_DEST);
            avs_property_node_create(ea3_config, ea3_soft, 11, (char *) "spec", (char *) &EA3_SPEC);
            avs_property_node_create(ea3_config, ea3_soft, 11, (char *) "rev", (char *) &EA3_REV);
            avs_property_node_create(ea3_config, ea3_soft, 11, (char *) "ext", (char *) &EA3_EXT);

            // create soft ID code
            std::ostringstream soft_id_code;
            soft_id_code << (char *) &EA3_MODEL << ":";
            soft_id_code << (char *) &EA3_DEST << ":";
            soft_id_code << (char *) &EA3_SPEC << ":";
            soft_id_code << (char *) &EA3_REV << ":";
            soft_id_code << (char *) &EA3_EXT;
            std::string soft_id_code_str = soft_id_code.str();

            // set soft ID code
            avs_std_setenv((char *) "/env/profile/soft_id_code", (char *) soft_id_code_str.c_str());

            // save game info
            memcpy(avs::game::MODEL, EA3_MODEL, 4);
            memcpy(avs::game::DEST, EA3_DEST, 2);
            memcpy(avs::game::SPEC, EA3_SPEC, 2);
            memcpy(avs::game::REV, EA3_REV, 2);
            memcpy(avs::game::EXT, EA3_EXT, 11);

            // url slash
            void *ea3_network = avs_property_search(ea3_config, nullptr, (char *) "/ea3/network");
            if (URL_SLASH >= 0) {
                void *url_slash = avs_property_search(ea3_config, nullptr, (char *) "/ea3/network/url_slash");
                if (url_slash != nullptr)
                    avs_property_node_remove(url_slash);
                avs_property_node_create(ea3_config, ea3_network, 52, (char *) "url_slash", (void *) &URL_SLASH);
            }

            // custom service url
            if (URL_CUSTOM != nullptr) {
                avs_property_node_remove(avs_property_search(ea3_config, nullptr, (char *) "/ea3/network/services"));
                avs_property_node_create(ea3_config, ea3_network, 11, (char *) "services", URL_CUSTOM);
            }

            // server - replace URL on the fly
            if (easrv_port != 0u) {
                std::ostringstream url;
                url << "http://localhost:" << easrv_port << "/";
                std::string url_str = url.str();
                avs_property_node_remove(avs_property_search(ea3_config, nullptr, (char *) "/ea3/network/services"));
                avs_property_node_create(ea3_config, ea3_network, 11, (char *) "services", (char *) url_str.c_str());
            }

            // boot EA3
            log_info("avs-ea3", "calling ea3 boot");
            avs_ea3_boot_startup(ea3);

            // clean up
            avs::core::config_destroy(app_config);
            avs::core::config_destroy(ea3_config);

            // success
            log_info("avs-ea3", "boot done");
        }

        void shutdown() {
            log_info("avs-ea3", "shutdown");

            // call shutdown
            avs_ea3_shutdown();
        }
    }
}
