#include "core.h"
#include <mutex>
#include "util/logging.h"
#include "util/fileutils.h"
#include "util/libutils.h"


namespace avs {

    // functions
    AVS_PROPERTY_SEARCH_T avs_property_search;
    AVS215_BOOT_T avs215_boot;
    AVS216_BOOT_T avs216_boot;
    AVS_SHUTDOWN_T avs_shutdown;
    AVS_PROPERTY_DESC_TO_BUFFER_T avs_property_desc_to_buffer;
    AVS_PROPERTY_DESTROY_T avs_property_destroy;
    AVS_PROPERTY_READ_QUERY_MEMSIZE_T avs_property_read_query_memsize;
    AVS_PROPERTY_CREATE_T avs_property_create;
    AVS_PROPERTY_INSERT_READ_T avs_property_insert_read;
    AVS_PROPERTY_NODE_CREATE_T avs_property_node_create;
    AVS_PROPERTY_NODE_REFER_T avs_property_node_refer;
    AVS_STD_SETENV_T avs_std_setenv;
    AVS_PROPERTY_NODE_REMOVE_T avs_property_node_remove;

    namespace core {

        // settings
        Version VERSION = AVS21580;
        size_t HEAP_SIZE = 0x1000000;
        std::string LOG_PATH;
        std::string CFG_PATH;

        // handle
        HINSTANCE DLL_INSTANCE = nullptr;
        std::string DLL_NAME = "";

        // static fields
        static void *AVS_HEAP1 = nullptr;
        static void *AVS_HEAP2 = nullptr;
        static avs_core_import IMPORTS[AVS_VERSION_COUNT];
        static std::mutex OUTPUT_MUTEX;

        /*
         * Helpers
         */

        static BOOL output_callback(LPCVOID buf, DWORD size, HANDLE file) {

            // check size
            if (size == 0)
                return TRUE;

            // lock
            OUTPUT_MUTEX.lock();

            // write to file
            DWORD written_bytes;
            if (file != nullptr) {
                WriteFile(file, buf, size - 1, &written_bytes, nullptr);
                WriteFile(file, "\r\n", 2, &written_bytes, nullptr);
            }

            // write to std out
            HANDLE output_handle = GetStdHandle(STD_OUTPUT_HANDLE);
            WriteFile(output_handle, buf, size - 1, &written_bytes, nullptr);
            WriteFile(output_handle, "\r\n", 2, &written_bytes, nullptr);

            // unlock
            OUTPUT_MUTEX.unlock();

            // success
            return TRUE;
        }

        static BOOL output_callback_old(HANDLE file, LPCVOID buf, DWORD size) {

            // check size
            if (size == 0)
                return TRUE;

            // prefix
            std::string prefix;
            if (((char*) buf)[0] != '[') {
                prefix = log_get_datetime() + " ";
            }

            // lock
            OUTPUT_MUTEX.lock();

            // write to file
            DWORD written_bytes;
            if (file != nullptr) {
                if (prefix.size())
                    WriteFile(file, prefix.c_str(), (DWORD) prefix.size(), &written_bytes, nullptr);
                WriteFile(file, buf, size - 1, &written_bytes, nullptr);
            }

            // write to std out
            HANDLE output_handle = GetStdHandle(STD_OUTPUT_HANDLE);
            if (prefix.size())
                WriteFile(output_handle, prefix.c_str(), (DWORD) prefix.size(), &written_bytes, nullptr);
            WriteFile(output_handle, buf, size - 1, &written_bytes, nullptr);

            // unlock
            OUTPUT_MUTEX.unlock();

            // success
            return TRUE;
        }

        static size_t avs_property_read_callback(DWORD tlsIndex, void *dst_buf, size_t count) {
            auto file = (FILE *) TlsGetValue(tlsIndex);
            return fread(dst_buf, 1, count, file);
        }

        void* config_read(const std::string &filename) {

            // open file in tls
            FILE *file = fopen(filename.c_str(), "r");
            DWORD tls = TlsAlloc();
            TlsSetValue(tls, file);

            // check file
            if (file == nullptr)
                log_fatal("avs-core", "Error reading config (file=NULL): " + filename);

            // get file size
            size_t property_read_size = avs_property_read_query_memsize(
                    (void *) &avs_property_read_callback, tls, 0, 0);

            // check file size
            if (property_read_size <= 0)
                log_fatal("avs-core", "Error reading config (size<=0): " + filename);

            // allocate memory
            void *property_read_memory = malloc(property_read_size);

            // read file contents
            void *property_read2_value = avs_property_create(23, property_read_memory, (int) property_read_size);
            if (property_read2_value == nullptr)
                log_fatal("avs-core", "Cannot create property: " + filename);

            // rewind file
            rewind(file);

            // read 3
            if (avs_property_insert_read(property_read2_value, 0, (void *) &avs_property_read_callback, (int) tls) == 0)
                log_fatal("avs-core", "Cannot read property: " + filename);

            // clean up
            TlsFree(tls);
            fclose(file);

            // return value
            return property_read2_value;
        }

        void* property_search_safe(void* node, void* node2, char* name) {
            void* property = avs_property_search(node, node2, name);
            if (property == nullptr)
                log_fatal("avs-core", "Node not found: " + std::string(name));
            return property;
        }

        void config_destroy(void* config) {
            void* mem = avs_property_desc_to_buffer(config);
            avs_property_destroy(config);
            free(mem);
        }

        /*
         * Functions
         */

        void create_log() {

            // create log file
            LOG_FILE = CreateFileA(
                    LOG_PATH.size() > 0 ? LOG_PATH.c_str() : "log.txt",
                    GENERIC_WRITE,
                    FILE_SHARE_READ,
                    nullptr,
                    CREATE_ALWAYS,
                    0,
                    nullptr
            );
        }

        void load_dll() {
            log_info("avs-core", "loading DLL");

            // detect DLL name
            if (fileutils::file_exists((MODULE_PATH_STR + "avs2-core.dll").c_str())) {
                DLL_NAME = "avs2-core.dll";
            } else {
#ifdef SPICE64
                DLL_NAME = "libavs-win64.dll";
#else
                DLL_NAME = "libavs-win32.dll";
#endif
            }

            /*
             * Imports
             */

            IMPORTS[AVSLEGACY] = {
                .version                     = "legacy",
                .property_search             = "property_search",
                .boot                        = "avs_boot",
                .shutdown                    = "avs_shutdown",
                .property_desc_to_buffer     = "property_desc_to_buffer",
                .property_destroy            = "property_destroy",
                .property_read_query_memsize = "property_read_query_memsize",
                .property_create             = "property_create",
                .property_insert_read        = "property_insert_read",
                .property_node_create        = "property_node_create",
                .property_node_refer         = "property_node_refer",
                .std_setenv                  = "std_setenv",
                .property_node_remove        = "property_node_remove",
            };
            IMPORTS[AVS21360] = {
                .version                     = "2.13.6.0",
                .property_search             = "XC058ba50000fb",
                .boot                        = "XC058ba50000f4",
                .shutdown                    = "XC058ba5000154",
                .property_desc_to_buffer     = "XC058ba50000cd",
                .property_destroy            = "XC058ba500010f",
                .property_read_query_memsize = "XC058ba5000066",
                .property_create             = "XC058ba5000107",
                .property_insert_read        = "XC058ba5000016",
                .property_node_create        = "XC058ba5000143",
                .property_node_refer         = "XC058ba5000113",
                .std_setenv                  = "XC058ba5000075",
                .property_node_remove        = "XC058ba5000085",
            };
            IMPORTS[AVS21580] = {
                .version                     = "2.15.8.0",
                .property_search             = "XCd229cc00012e",
                .boot                        = "XCd229cc0000aa",
                .shutdown                    = "XCd229cc00001d",
                .property_desc_to_buffer     = "XCd229cc0000fd",
                .property_destroy            = "XCd229cc00013c",
                .property_read_query_memsize = "XCd229cc0000ff",
                .property_create             = "XCd229cc000126",
                .property_insert_read        = "XCd229cc00009a",
                .property_node_create        = "XCd229cc00002c",
                .property_node_refer         = "XCd229cc000009",
                .std_setenv                  = "XCd229cc000094",
                .property_node_remove        = "XCd229cc000028",
            };
            IMPORTS[AVS21610] = {
                .version                     = "2.16.1.0",
                .property_search             = "XCnbrep700008c",
                .boot                        = "XCnbrep700011a",
                .shutdown                    = "XCnbrep700011b",
                .property_desc_to_buffer     = "XCnbrep700007d",
                .property_destroy            = "XCnbrep700007c",
                .property_read_query_memsize = "XCnbrep700009b",
                .property_create             = "XCnbrep700007b",
                .property_insert_read        = "XCnbrep700007f",
                .property_node_create        = "XCnbrep700008d",
                .property_node_refer         = "XCnbrep700009a",
                .std_setenv                  = "XCnbrep70000cc",
                .property_node_remove        = "XCnbrep700008e",
            };
            IMPORTS[AVS21651] = {
                .version                     = "2.16.5.1",
                .property_search             = "XCnbrep70000a1",
                .boot                        = "XCnbrep7000129",
                .shutdown                    = "XCnbrep700012a",
                .property_desc_to_buffer     = "XCnbrep7000092",
                .property_destroy            = "XCnbrep7000091",
                .property_read_query_memsize = "XCnbrep70000b0",
                .property_create             = "XCnbrep7000090",
                .property_insert_read        = "XCnbrep7000094",
                .property_node_create        = "XCnbrep70000a2",
                .property_node_refer         = "XCnbrep70000af",
                .std_setenv                  = "XCnbrep70000d4",
                .property_node_remove        = "XCnbrep70000a3",
            };
            IMPORTS[AVS21671] = {
                .version                     = "2.16.7.1",
                .property_search             = "XCnbrep70000a1",
                .boot                        = "XCnbrep7000129",
                .shutdown                    = "XCnbrep700012a",
                .property_desc_to_buffer     = "XCnbrep7000092",
                .property_destroy            = "XCnbrep7000091",
                .property_read_query_memsize = "XCnbrep70000b0",
                .property_create             = "XCnbrep7000090",
                .property_insert_read        = "XCnbrep7000094",
                .property_node_create        = "XCnbrep70000a2",
                .property_node_refer         = "XCnbrep70000af",
                .std_setenv                  = "XCnbrep70000d4",
                .property_node_remove        = "XCnbrep70000a3",
            };
            IMPORTS[AVS21700] = {
                .version                     = "2.17.0.0",
                .property_search             = "XCgsqzn00000a1",
                .boot                        = "XCgsqzn0000129",
                .shutdown                    = "XCgsqzn000012a",
                .property_desc_to_buffer     = "XCgsqzn0000092",
                .property_destroy            = "XCgsqzn0000091",
                .property_read_query_memsize = "XCgsqzn00000b0",
                .property_create             = "XCgsqzn0000090",
                .property_insert_read        = "XCgsqzn0000094",
                .property_node_create        = "XCgsqzn00000a2",
                .property_node_refer         = "XCgsqzn00000af",
                .std_setenv                  = "XCgsqzn00000d4",
                .property_node_remove        = "XCgsqzn00000a3",
            };

            // load library
            DLL_INSTANCE = libutils::load_library(MODULE_PATH_STR + DLL_NAME);

            // get version string
            char version[32];
            fileutils::version_pe(MODULE_PATH_STR + DLL_NAME, version);

            // check by version string
            int ver = -1;
            for (int i = 0; i < AVS_VERSION_COUNT; i++) {
                if (strcmp(IMPORTS[i].version, version) == 0) {
                    ver = i;
                    break;
                }
            }

            // check version by brute force
            if (ver < 0) {
                for (int i = 0; i < AVS_VERSION_COUNT; i++) {
                    if (GetProcAddress(DLL_INSTANCE, IMPORTS[i].property_search) != nullptr) {
                        ver = i;
                        break;
                    }
                }
            }

            // check if version was found
            if (ver < 0)
                log_fatal("avs-core", "Unknown " + DLL_NAME);

            // print version
            VERSION = (avs::core::Version) ver;
            log_info("avs-core", "Found AVS2 core " + to_string(IMPORTS[ver].version));

            // load functions
            avs_property_search = (AVS_PROPERTY_SEARCH_T) libutils::get_proc(
                    DLL_INSTANCE, IMPORTS[ver].property_search);
            avs215_boot = (AVS215_BOOT_T) libutils::get_proc(
                    DLL_INSTANCE, IMPORTS[ver].boot);
            avs216_boot = (AVS216_BOOT_T) libutils::get_proc(
                    DLL_INSTANCE, IMPORTS[ver].boot);
            avs_shutdown = (AVS_SHUTDOWN_T) libutils::get_proc(
                    DLL_INSTANCE, IMPORTS[ver].shutdown);
            avs_property_desc_to_buffer = (AVS_PROPERTY_DESC_TO_BUFFER_T) libutils::get_proc(
                    DLL_INSTANCE, IMPORTS[ver].property_desc_to_buffer);
            avs_property_destroy = (AVS_PROPERTY_DESTROY_T) libutils::get_proc(
                    DLL_INSTANCE, IMPORTS[ver].property_destroy);
            avs_property_read_query_memsize = (AVS_PROPERTY_READ_QUERY_MEMSIZE_T) libutils::get_proc(
                    DLL_INSTANCE, IMPORTS[ver].property_read_query_memsize);
            avs_property_create = (AVS_PROPERTY_CREATE_T) libutils::get_proc(
                    DLL_INSTANCE, IMPORTS[ver].property_create);
            avs_property_insert_read = (AVS_PROPERTY_INSERT_READ_T) libutils::get_proc(
                    DLL_INSTANCE, IMPORTS[ver].property_insert_read);
            avs_property_node_create = (AVS_PROPERTY_NODE_CREATE_T) libutils::get_proc(
                    DLL_INSTANCE, IMPORTS[ver].property_node_create);
            avs_property_node_refer = (AVS_PROPERTY_NODE_REFER_T) libutils::get_proc(
                    DLL_INSTANCE, IMPORTS[ver].property_node_refer);
            avs_std_setenv = (AVS_STD_SETENV_T) libutils::get_proc(
                    DLL_INSTANCE, IMPORTS[ver].std_setenv);
            avs_property_node_remove = (AVS_PROPERTY_NODE_REMOVE_T) libutils::get_proc(
                    DLL_INSTANCE, IMPORTS[ver].property_node_remove);
        }

        void boot() {
            log_info("avs-core", "booting");

            // read configuration
            void *config = config_read(CFG_PATH.size() ? CFG_PATH : "prop/avs-config.xml");
            void *config_node = property_search_safe(config, nullptr, (char *) "/config");

            // check heap size
            if (HEAP_SIZE <= 0)
                log_fatal("avs-core", "Invalid heap size.");
            log_info("avs-core", "using heap size: " + to_string(HEAP_SIZE));

            // initialize avs
            switch (VERSION) {
                case AVS21580: {
                    AVS_HEAP1 = malloc(HEAP_SIZE);
                    if (!AVS_HEAP1)
                        log_warning("avs-core", "Couldn't allocate heap 1");
                    AVS_HEAP2 = malloc(HEAP_SIZE);
                    if (!AVS_HEAP2)
                        log_warning("avs-core", "Couldn't allocate heap 2");
                    avs215_boot(config_node, AVS_HEAP1, HEAP_SIZE, AVS_HEAP2, HEAP_SIZE,
                            (void *) &output_callback, LOG_FILE);
                    break;
                }
                case AVS21610:
                case AVS21651:
                case AVS21671:
                case AVS21700: {
                    AVS_HEAP1 = malloc(HEAP_SIZE);
                    if (!AVS_HEAP1)
                        log_warning("avs-core", "Couldn't allocate heap 1");
                    avs216_boot(config_node, AVS_HEAP1, HEAP_SIZE, nullptr,
                            (void *) &output_callback, LOG_FILE);
                    break;
                }
                case AVS21360:
                case AVSLEGACY: {
                    AVS_HEAP1 = malloc(HEAP_SIZE);
                    if (!AVS_HEAP1)
                        log_warning("avs-core", "Couldn't allocate heap 1");
                    AVS_HEAP2 = malloc(HEAP_SIZE);
                    if (!AVS_HEAP2)
                        log_warning("avs-core", "Couldn't allocate heap 2");
                    avs215_boot(config_node, AVS_HEAP1, HEAP_SIZE, AVS_HEAP2, HEAP_SIZE,
                            (void *) &output_callback_old, LOG_FILE);
                    break;
                }
                default:
                    log_fatal("avs-core", "Unknown AVS boot procedure.");
            }

            // wait a bit for output
            Sleep(100);

            // destroy config
            config_destroy(config);
        }

        void shutdown() {
            log_info("avs-core", "shutdown");

            // call shutdown
            avs_shutdown();

            // clean heaps
            if (AVS_HEAP1) {
                free(AVS_HEAP1);
                AVS_HEAP1 = nullptr;
            }
            if (AVS_HEAP2) {
                free(AVS_HEAP2);
                AVS_HEAP2 = nullptr;
            }
        }
    }
}
