#ifndef USB_HID_USAGE_H
#define USB_HID_USAGE_H

char* usb_hid_get_usage_text(uint32_t usagePage, uint32_t usage);

#endif //USB_HID_USAGE_H
