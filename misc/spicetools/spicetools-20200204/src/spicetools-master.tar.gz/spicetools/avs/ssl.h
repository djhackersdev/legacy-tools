#pragma once

namespace avs::ssl {

    constexpr int32_t SSL_PROTOCOL_ID = 0x102;

    void init();
}
