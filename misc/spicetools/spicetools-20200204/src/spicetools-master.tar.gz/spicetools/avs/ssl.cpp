#define SECURITY_WIN32

#include <cstring>
#include <iostream>
#include <vector>

#include <windows.h>
#include <schnlsp.h>
#include <sspi.h>

#include "util/logging.h"

#include "ssl.h"
#include "core.h"

namespace avs {

    struct avs::core::avs_net_socket_work {
        int64_t s;
        const char *hostname;
        uint8_t *recv_buf;
        size_t recv_buf_pos;
        size_t recv_buf_remaining;
        size_t recv_buf_capacity;
        void *extra_bytes_buf;
        uint32_t extra_bytes_num;
        CtxtHandle security_context;
        CredHandle credentials_handle;
    };

    namespace ssl {
        const int recv_buf_initial_size = 8192;

        int ssl_protocol_initialize() {
            return 0;
        }

        int ssl_protocol_finalize() {
            return 0;
        }

        int ssl_socket_allocate(avs::core::avs_net_socket_work *work) {
            memset(work, 0, sizeof(avs::core::avs_net_socket_work));

            work->recv_buf = (uint8_t *) malloc(recv_buf_initial_size);
            work->recv_buf_capacity = recv_buf_initial_size;

            return 0;
        }

        int ssl_socket_free(avs::core::avs_net_socket_work *work) {
            free(work->recv_buf);
            return 0;
        }

        int ssl_socket_initialize(avs::core::avs_net_socket_work *work) {
            int result = 0;

            auto s = avs::core::avs_net_socket(0);
            if (s > 0) {
                work->s = s;
            } else {
                result = s;
            }

            return result;
        }

        int ssl_socket_finalize(avs::core::avs_net_socket_work *work) {
            return 0;
        }

        int ssl_socket_setsockopt(avs::core::avs_net_socket_work *work,
                int optname, const char *optval, int optlen) {

            auto sock = work->s;
            if (sock <= 0) {
                return sock;
            }

            return avs::core::avs_net_setsockopt(sock, optname, optval, optlen);
        }

        int ssl_socket_getsockopt(avs::core::avs_net_socket_work *work,
                int optname, char *optval, int *optlen) {

            auto sock = work->s;
            if (sock <= 0) {
                return sock;
            }

            return avs::core::avs_net_getsockopt(sock, optname, optval, optlen);
        }

        int ssl_socket_bind(avs::core::avs_net_socket_work *work,
                uint32_t address, uint16_t port) {

            auto sock = work->s;
            if (sock <= 0) {
                return sock;
            }

            return avs::core::avs_net_bind(sock, address, port);
        }

        int ssl_socket_connect(avs::core::avs_net_socket_work *work,
                uint32_t address, uint16_t port) {

            auto sock = work->s;
            if (sock <= 0) {
                return sock;
            }

            char hostname[256];
            if (!core::avs_net_addrinfobyaddr(address, hostname, sizeof(hostname), 1)) {
                log_warning("ssl", "failed to resolve hostname");
                return -1;
            }
            work->hostname = hostname;
            if (avs::core::avs_net_connect(sock, address, port)) {
                return -1;
            }

            TimeStamp lifetime;
            CredHandle credentials_handle;
            SCHANNEL_CRED credentials;

            memset(&credentials, 0, sizeof(SCHANNEL_CRED));
            credentials.dwVersion = SCHANNEL_CRED_VERSION;
            credentials.grbitEnabledProtocols = SP_PROT_TLS1_CLIENT | 0x200 | 0x800;

            auto status = AcquireCredentialsHandleA(
                NULL,
                (SEC_CHAR *) UNISP_NAME,
                SECPKG_CRED_OUTBOUND,
                NULL,
                &credentials,
                NULL,
                NULL,
                &credentials_handle,
                &lifetime
            );
            if (status != SEC_E_OK) {
                log_warning("ssl", "AcquireCredentialsHandleA failed: {}", status);
                return -1;
            }

            uint8_t send_buf[8192];
            SecBuffer send_sec_buf;
            SecBufferDesc send_buf_desc;

            send_sec_buf.cbBuffer = sizeof(send_buf);
            send_sec_buf.BufferType = SECBUFFER_TOKEN;
            send_sec_buf.pvBuffer = send_buf;

            send_buf_desc.ulVersion = 0;
            send_buf_desc.cBuffers = 1;
            send_buf_desc.pBuffers = &send_sec_buf;

            SecBufferDesc recv_buf_desc;
            SecBuffer recv_sec_buf;

            recv_sec_buf.cbBuffer = work->recv_buf_capacity;
            recv_sec_buf.BufferType = SECBUFFER_TOKEN;
            recv_sec_buf.pvBuffer = work->recv_buf;

            recv_buf_desc.ulVersion = 0;
            recv_buf_desc.cBuffers = 1;
            recv_buf_desc.pBuffers = &recv_sec_buf;

            CtxtHandle security_context;
            ULONG attributes = 0;

            status = InitializeSecurityContextA(
                &credentials_handle,
                nullptr,
                reinterpret_cast<SEC_CHAR *>(hostname),
                ISC_REQ_CONFIDENTIALITY,
                0,
                0,
                nullptr ,
                0,
                &security_context,
                &send_buf_desc,
                &attributes,
                &lifetime
            );

            while (status != SEC_E_OK) {
                int sent = 0;
                int received = 0;

                switch (status) {
                    case SEC_I_CONTINUE_NEEDED: {
                        sent = avs::core::avs_net_send(
                                sock,
                                (uint8_t *) send_sec_buf.pvBuffer,
                                send_sec_buf.cbBuffer
                        );
                        if (sent < 0) {
                            log_warning("ssl", "failed to send data for handshake");
                            return -1;
                        }

                        received = avs::core::avs_net_recv(
                                sock,
                                work->recv_buf,
                                work->recv_buf_capacity -
                                work->recv_buf_remaining
                        );
                        if (received > 0) {
                            work->recv_buf_remaining += received;
                        } else {
                            log_warning("ssl", "failed to receive data for handshake");
                            return -1;
                        }

                        break;
                    }
                    case SEC_E_INCOMPLETE_MESSAGE: {
                        work->recv_buf = (uint8_t *) realloc(
                                work->recv_buf,
                                work->recv_buf_capacity += recv_buf_initial_size
                        );
                        work->recv_buf_capacity += recv_buf_initial_size;

                        break;
                    }
                    default: {
                        log_warning("ssl", "InitializeSecurityContextA failed: {}", status);
                        return -1;
                    }
                }

                status = InitializeSecurityContextA(
                    &credentials_handle,
                    &security_context,
                    reinterpret_cast<SEC_CHAR *>(hostname),
                    ISC_REQ_CONFIDENTIALITY,
                    0,
                    0,
                    &recv_buf_desc,
                    0,
                    nullptr,
                    &send_buf_desc,
                    &attributes,
                    nullptr
                );
            }

            log_info("ssl", "SSL/TLS handshake complete");

            work->security_context = security_context;
            work->credentials_handle = credentials_handle;

            work->recv_buf_remaining = 0;
            work->recv_buf_pos = 0;

            work->recv_buf = (uint8_t *) realloc(work->recv_buf, recv_buf_initial_size);

            return 0;
        }

        int ssl_socket_listen(avs::core::avs_net_socket_work *work, uint16_t backlog) {
            return -1;
        }

        int ssl_socket_accept(avs::core::avs_net_socket_work *work, void *, void *) {
            return -1;
        }

        int ssl_socket_close(avs::core::avs_net_socket_work *work) {
            auto sock = work->s;
            if (sock <= 0) {
                return sock;
            }

            SecBufferDesc shutdown_buf_desc;
            SecBuffer shutdown_sec_buf;

            auto schannel_shutdown = SCHANNEL_SHUTDOWN;

            shutdown_sec_buf.cbBuffer = sizeof(DWORD);
            shutdown_sec_buf.BufferType = SECBUFFER_TOKEN;
            shutdown_sec_buf.pvBuffer = &schannel_shutdown;

            shutdown_buf_desc.ulVersion = 0;
            shutdown_buf_desc.cBuffers = 1;
            shutdown_buf_desc.pBuffers = &shutdown_sec_buf;

            auto status = ApplyControlToken(&work->security_context, &shutdown_buf_desc);
            if (status != SEC_E_OK) {
                log_warning("ssl", "ApplyControlToken failed: {}", status);
                goto close;
            }

            shutdown_sec_buf.cbBuffer = 0;
            shutdown_sec_buf.BufferType = SECBUFFER_TOKEN;
            shutdown_sec_buf.pvBuffer = NULL;

            TimeStamp lifetime;
            ULONG attributes;
            status = InitializeSecurityContext(
                &work->security_context,
                &work->credentials_handle,
                (SEC_CHAR *) work->hostname,
                0,
                0,
                0,
                NULL,
                0,
                NULL,
                &shutdown_buf_desc,
                &attributes,
                &lifetime
            );
            if (status != SEC_I_CONTEXT_EXPIRED &&
                status != SEC_E_OK) {
                log_warning("ssl", "InitializeSecurityContext failed: {}", status);
                goto close;
            }

            if (shutdown_sec_buf.pvBuffer &&
                shutdown_sec_buf.cbBuffer) {
                avs::core::avs_net_send(
                        sock,
                        (uint8_t *) shutdown_sec_buf.pvBuffer,
                        sizeof(shutdown_sec_buf.cbBuffer));
            }
            DeleteSecurityContext(&work->security_context);
            FreeCredentialsHandle(&work->credentials_handle);

close:
            return avs::core::avs_net_close(sock);
        }

        int ssl_socket_shutdown(avs::core::avs_net_socket_work *work) {
            return 0;
        }

        int ssl_socket_sendtov(avs::core::avs_net_socket_work *work,
                avs::core::avs_net_iovec *iovec,
                int32_t iovec_count, uint32_t address, uint16_t port) {

            auto sock = work->s;
            if (sock <= 0) {
                return sock;
            }

            SecPkgContext_StreamSizes sizes;
            auto status = QueryContextAttributesA(
                    &work->security_context,
                    SECPKG_ATTR_STREAM_SIZES,
                    &sizes);
            if (status != SEC_E_OK) {
                log_warning("ssl", "QueryContextAttributesA failed: {}", status);
                return -1;
            }

            auto send_buf_size = sizes.cbHeader +
                                 sizes.cbMaximumMessage +
                                 sizes.cbTrailer;
            auto send_buf = (uint8_t *) malloc(send_buf_size);
            if (!send_buf) {
                log_warning("ssl", "failed to allocate memory for send buffer");
                return -1;
            }

            int number_of_bytes_sent = 0;
            for (int i = 0; i < iovec_count; i++) {
                auto current_vec = iovec[i];
                auto message = send_buf + sizes.cbHeader;
                memcpy(message, current_vec.buf, current_vec.buf_len);

                SecBufferDesc send_buf_desc;
                SecBuffer send_sec_bufs[4];

                send_sec_bufs[0].pvBuffer = send_buf;
                send_sec_bufs[0].BufferType = SECBUFFER_STREAM_HEADER;
                send_sec_bufs[0].cbBuffer = sizes.cbHeader;

                send_sec_bufs[1].cbBuffer = current_vec.buf_len;
                send_sec_bufs[1].BufferType = SECBUFFER_DATA;
                send_sec_bufs[1].pvBuffer = message;

                send_sec_bufs[2].cbBuffer = sizes.cbTrailer;
                send_sec_bufs[2].BufferType = SECBUFFER_STREAM_TRAILER;
                send_sec_bufs[2].pvBuffer = message + current_vec.buf_len;

                send_sec_bufs[3].BufferType = SECBUFFER_EMPTY;

                send_buf_desc.ulVersion = 0;
                send_buf_desc.cBuffers = 4;
                send_buf_desc.pBuffers = send_sec_bufs;

                auto status = EncryptMessage(&work->security_context, 0, &send_buf_desc, 0);
                if (status != SEC_E_OK) {
                    log_warning("ssl", "EncryptMessage failed: {}", status);
                    break;
                }

                int sent = avs::core::avs_net_send(
                    sock,
                    send_buf,
                    send_sec_bufs[0].cbBuffer + send_sec_bufs[1].cbBuffer + send_sec_bufs[2].cbBuffer
                );
                if (sent < 0) {
                    return -1;
                }

                number_of_bytes_sent += current_vec.buf_len;
            }

            free(send_buf);
            return number_of_bytes_sent;
        }

        int ssl_socket_recvfromv(avs::core::avs_net_socket_work *work,
                avs::core::avs_net_iovec *iovec,
                int32_t iovec_count, uint32_t address, uint16_t port) {

            auto sock = work->s;
            if (sock <= 0) {
                return sock;
            }

            int number_of_bytes_recv = 0;
            for (int i = 0; i < iovec_count; i++) {
copy:
                auto current_vec = iovec[i];
                if (work->recv_buf_remaining > 0) {
                    auto copy_length = work->recv_buf_remaining < current_vec.buf_len
                                       ? work->recv_buf_remaining
                                       : current_vec.buf_len;

                    memcpy(current_vec.buf, work->recv_buf + work->recv_buf_pos, copy_length);

                    number_of_bytes_recv += copy_length;
                    work->recv_buf_pos += copy_length;
                    work->recv_buf_remaining -= copy_length;

                    continue;
                }

                if (work->extra_bytes_num > 0) {
                    work->recv_buf_remaining = work->extra_bytes_num;
                    memcpy(work->recv_buf, work->extra_bytes_buf, work->extra_bytes_num);

                    work->extra_bytes_num = 0;

                    goto decrypt;
                }

                work->recv_buf_pos = 0;
                work->recv_buf_remaining = 0;

                work->recv_buf = (uint8_t *) realloc(work->recv_buf, recv_buf_initial_size);

receive:
                work->recv_buf_remaining += avs::core::avs_net_recv(
                    sock,
                    work->recv_buf + work->recv_buf_remaining,
                    work->recv_buf_capacity - work->recv_buf_remaining
                );

decrypt:
                SecBuffer recv_sec_bufs[4];
                recv_sec_bufs[0].pvBuffer = work->recv_buf;
                recv_sec_bufs[0].cbBuffer = work->recv_buf_remaining;
                recv_sec_bufs[0].BufferType = SECBUFFER_DATA;

                recv_sec_bufs[1].BufferType = SECBUFFER_EMPTY;
                recv_sec_bufs[2].BufferType = SECBUFFER_EMPTY;
                recv_sec_bufs[3].BufferType = SECBUFFER_EMPTY;

                SecBufferDesc recv_buf_desc;
                recv_buf_desc.ulVersion = 0;
                recv_buf_desc.cBuffers = 4;
                recv_buf_desc.pBuffers = recv_sec_bufs;

                auto status = DecryptMessage(&work->security_context, &recv_buf_desc, 0, 0);
                if (status == SEC_E_INCOMPLETE_MESSAGE) {
                    if (work->recv_buf_remaining >=
                        work->recv_buf_capacity) {

                        work->recv_buf = (uint8_t *) realloc(
                            work->recv_buf,
                            work->recv_buf_capacity += recv_buf_initial_size
                        );
                    }

                    goto receive;
                } else if (status != SEC_E_OK) {
                    log_warning("ssl", "DecryptMessage failed: {}", status);
                    return -1;
                }

                for (int j = 0; j < 4; j++) {
                    if (recv_sec_bufs[j].BufferType == SECBUFFER_DATA) {
                        work->recv_buf_pos = (uint8_t *) recv_sec_bufs[j].pvBuffer - work->recv_buf;
                        work->recv_buf_remaining = recv_sec_bufs[j].cbBuffer;
                    }
                    else if (recv_sec_bufs[j].BufferType == SECBUFFER_EXTRA ) {
                        work->extra_bytes_num = recv_sec_bufs[j].cbBuffer;
                        work->extra_bytes_buf = recv_sec_bufs[j].pvBuffer;
                    }
                }

                goto copy;
            }

            return number_of_bytes_recv;
        }

        void ssl_socket_pollfds_add(avs::core::avs_net_socket_work *work,
                void *fds, int fds_size, void *events) {

            if (work->s > 0) {
                avs::core::avs_net_pollfds_add(work->s, fds, fds_size, events);
            }
        }

        void ssl_socket_pollfds_get(avs::core::avs_net_socket_work *work,
                void *fds, void *events) {

            if (work->s > 0) {
                avs::core::avs_net_pollfds_get(work->s, fds, events);
            }
        }

        int ssl_socket_sockpeer(avs::core::avs_net_socket_work *work,
                uint8_t type, uint32_t *address, uint16_t *port) {
            return -1;
        }

        avs::core::avs_net_protocol_function_table ssl_protocol_function_table {
            .initialize        = ssl_protocol_initialize,
            .finalize          = ssl_protocol_finalize,
            .allocate_socket   = ssl_socket_allocate,
            .free_socket       = ssl_socket_free,
            .initialize_socket = ssl_socket_initialize,
            .finalize_socket   = ssl_socket_finalize,
            .setsockopt        = ssl_socket_setsockopt,
            .getsockopt        = ssl_socket_getsockopt,
            .bind              = ssl_socket_bind,
            .connect           = ssl_socket_connect,
            .listen            = ssl_socket_listen,
            .accept            = ssl_socket_accept,
            .close             = ssl_socket_close,
            .shutdown          = ssl_socket_shutdown,
            .sendtov           = ssl_socket_sendtov,
            .recvfromv         = ssl_socket_recvfromv,
            .pollfds_add       = ssl_socket_pollfds_add,
            .pollfds_get       = ssl_socket_pollfds_get,
            .sockpeer          = ssl_socket_sockpeer
        };

        avs::core::avs_net_protocol ssl_protocol {
            .function_table = &ssl_protocol_function_table,
            .magic          = avs::core::AVS_NET_PROTOCOL_MAGIC,
            .protocol_id    = SSL_PROTOCOL_ID,
            .mystery        = 0,
            .sz_work        = sizeof(avs::core::avs_net_socket_work)
        };

        avs::core::avs_net_protocol_legacy ssl_protocol_legacy {
            .function_table = &ssl_protocol_function_table,
            .protocol_id    = SSL_PROTOCOL_ID,
            .mystery        = 0,
            .sz_work        = sizeof(avs::core::avs_net_socket_work)
        };

        void init() {
            log_info("ssl", "initializing");

            if (!avs::core::avs_net_add_protocol) {
                log_warning("ssl", "missing optional avs imports which are required for this module to work");
                return;
            }

            avs::core::avs_net_del_protocol(SSL_PROTOCOL_ID);

            int regist_res = 0;
            if (avs::core::VERSION == avs::core::AVSLEGACY) {
                avs::core::avs_net_add_protocol_legacy(&ssl_protocol_legacy);
            } else {
                avs::core::avs_net_add_protocol(&ssl_protocol);
            }

            if (regist_res) {
                log_fatal("ssl", "failed to register protocol");
            }
        }
    }
}
