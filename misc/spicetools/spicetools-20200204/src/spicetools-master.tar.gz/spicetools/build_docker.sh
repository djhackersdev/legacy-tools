#!/bin/bash

docker build external/docker -t spicetools/deps
docker build . -t spicetools/spice
docker run --rm -it -v `pwd`/dist:/src/dist -v `pwd`/bin:/src/bin spicetools/spice
