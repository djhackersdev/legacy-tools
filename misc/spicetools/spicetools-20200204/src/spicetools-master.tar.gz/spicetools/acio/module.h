#pragma once

#include <string>
#include <windows.h>

// macro for lazy typing of hooks
#define ACIO_MODULE_HOOK(f) this->hook((void *) f, #f)

namespace acio {

    /*
     * Hook Modes
     * Since some versions can't handle inline hooking
     */
    enum class HookMode {
        INLINE,
        IAT
    };

    // this makes logging easier
    const char *hookmode_tostr(HookMode hookMode);

    /*
     * The ACIO module itself
     * Inherit this for extending our libacio implementation
     */
    class ACIOModule {
    protected:

        // the magic
        void hook(void* func, std::string func_name);

    public:

        // settings
        std::string name;
        HMODULE module;
        HookMode hookMode;
        bool attached = false;

        // buffer state (optional)
        uint8_t *status_buffer = nullptr;
        size_t status_buffer_size = 0;
        bool *status_buffer_freeze = nullptr;

        ACIOModule(std::string name, HMODULE module, HookMode hookMode);
        virtual ~ACIOModule() = default;

        virtual void attach();
    };
}
