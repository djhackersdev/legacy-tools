# SpiceAPI C++ Library
This library is still a bit experimental and might contain bugs.

To include it into your project, it's recommended to just copy the
files into your source directory.

To use the wrappers, RapidJSON is required and you might need to
adjust the include paths for your project's build.
