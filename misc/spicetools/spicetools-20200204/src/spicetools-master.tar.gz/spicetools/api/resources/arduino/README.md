# SpiceAPI Arduino Library
This library is still a bit experimental and might contain bugs.

To use this library, it's recommended to just copy the Arduino project and start from that.
