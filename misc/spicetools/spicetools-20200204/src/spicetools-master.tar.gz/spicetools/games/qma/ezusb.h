#pragma once

namespace games::qma {

    void ezusb_init();
}
