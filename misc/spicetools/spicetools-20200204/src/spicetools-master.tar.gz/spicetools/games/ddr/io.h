#pragma once

#include <vector>

#include "cfg/api.h"

namespace games::ddr {

    // all buttons in correct order
    namespace Buttons {
        enum {
            Service,
            Test,
            CoinMech,
            P1Start,
            P1PanelUp,
            P1PanelDown,
            P1PanelLeft,
            P1PanelRight,
            P1MenuUp,
            P1MenuDown,
            P1MenuLeft,
            P1MenuRight,
            P2Start,
            P2PanelUp,
            P2PanelDown,
            P2PanelLeft,
            P2PanelRight,
            P2MenuUp,
            P2MenuDown,
            P2MenuLeft,
            P2MenuRight,
        };
    }

    // all lights in correct order
    namespace Lights {
        enum {
            P1FootLeft,
            P1FootUp,
            P1FootRight,
            P1FootDown,
            P2FootLeft,
            P2FootUp,
            P2FootRight,
            P2FootDown,
            SpotRed,
            SpotBlue,
            TopSpotRed,
            TopSpotBlue,
            P1HalogenUpper,
            P1HalogenLower,
            P2HalogenUpper,
            P2HalogenLower,
            P1Button,
            P2Button,
            Neon,
            HDP1Start,
            HDP1LeftRight,
            HDP1UpDown,
            HDP2Start,
            HDP2LeftRight,
            HDP2UpDown
        };
    }

    // getters
    std::vector<Button> &get_buttons();
    std::vector<Light> &get_lights();
}
