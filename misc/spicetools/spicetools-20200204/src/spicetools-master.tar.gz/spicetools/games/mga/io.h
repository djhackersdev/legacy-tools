#pragma once

#include <vector>
#include "cfg/api.h"

namespace games::mga {

    // all buttons in correct order
    namespace Buttons {
        enum {
            Service,
            Test,
            CoinMech,
            TriggerAlternative,
            Start,
            Top,
            FrontTop,
            FrontBottom,
            SideLeft,
            SideRight,
            SideLever,
            TriggerButton,
            JoyForwards,
            JoyBackwards,
            JoyLeft,
            JoyRight
        };
    }

    // all analogs in correct order
    namespace Analogs {
        enum {
            JoyX,
            JoyY
        };
    }

    // getters
    std::vector<Button> &get_buttons();
    std::vector<Analog> &get_analogs();
}
