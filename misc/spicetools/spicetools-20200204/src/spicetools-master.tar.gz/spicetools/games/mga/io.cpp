#include "io.h"

std::vector<Button> &games::mga::get_buttons() {
    static std::vector<Button> buttons;

    if (buttons.empty()) {
        buttons = GameAPI::Buttons::getButtons("Metal Gear");

        GameAPI::Buttons::sortButtons(
                &buttons,
                "Service",
                "Test",
                "Coin Mech",
                "Trigger Alternative",
                "Start",
                "Top",
                "Front Top",
                "Front Bottom",
                "Side Left",
                "Side Right",
                "Side Lever",
                "Trigger Button",
                "Joy Forwards",
                "Joy Backwards",
                "Joy Left",
                "Joy Right"
        );
    }

    return buttons;
}

std::vector<Analog> &games::mga::get_analogs() {
    static std::vector<Analog> analogs;

    if (analogs.empty()) {
        analogs = GameAPI::Analogs::getAnalogs("Metal Gear");

        GameAPI::Analogs::sortAnalogs(
                &analogs,
                "Joy X",
                "Joy Y"
        );
    }

    return analogs;
}
