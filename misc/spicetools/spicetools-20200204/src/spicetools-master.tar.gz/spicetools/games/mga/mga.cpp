#include "mga.h"

#include "hooks/devicehook.h"
#include "util/libutils.h"

#include "gunio.h"

namespace games::mga {

    MGAGame::MGAGame() : Game("Metal Gear Arcade") {
    }

    void MGAGame::attach() {
        Game::attach();

        // load system.dll (along with the serial functions)
        libutils::load_library("system.dll");

        // add the gun
        devicehook_init();
        devicehook_add(new SpiceGearGunHandle());
    }

    void MGAGame::detach() {
        Game::detach();

        devicehook_dispose();
    }
}
