#pragma once

namespace games::sdvx {

    void camera_init();
}
