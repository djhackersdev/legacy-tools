#pragma once

namespace games::iidx {

    void bi2x_hook_init();
}
