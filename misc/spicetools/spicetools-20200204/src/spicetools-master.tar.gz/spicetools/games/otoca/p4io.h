#pragma once

namespace games::otoca {

    void p4io_hook();
}
