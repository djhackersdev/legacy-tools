#pragma once

#include "games/game.h"

namespace games::drs {

    enum DRS_TOUCH_TYPE {
        DRS_DOWN = 0,
        DRS_UP   = 1,
        DRS_MOVE = 2,
    };

    typedef struct {
        int type;
        int id;
        double x;
        double y;
        double width;
        double height;
    } drs_touch_t;

    extern char DRS_TAPELED[38 * 49][3];

    void fire_touches(drs_touch_t *events, size_t event_count);

    class DRSGame : public games::Game {
    public:
        DRSGame();
        virtual void attach() override;
        virtual void detach() override;
    };
}
