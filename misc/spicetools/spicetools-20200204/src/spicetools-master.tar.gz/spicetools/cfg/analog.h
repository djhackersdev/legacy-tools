#pragma once

#include <string>

namespace rawinput {
    class RawInputManager;
}

class Analog {
private:
    std::string name;
    std::string device_identifier = "";
    unsigned short index = 0xFF;
    float sensitivity = 1.f;
    bool invert = false;
    float last_state = 0.5f;

public:

    // overrides
    bool override_enabled = false;
    float override_state = 0.5f;

    explicit Analog(std::string name) : name(std::move(name)) {};

    std::string getDisplayString(rawinput::RawInputManager* manager);

    inline bool isSet() {
        if (this->override_enabled) {
            return true;
        }
        return this->index != 0xFF;
    }

    inline void clearBindings() {
        device_identifier = "";
        index = 0xFF;
        sensitivity = 1.f;
        invert = false;
    }

    inline const std::string &getName() const {
        return this->name;
    }

    inline const std::string &getDeviceIdentifier() const {
        return this->device_identifier;
    }

    inline void setDeviceIdentifier(std::string device_identifier) {
        this->device_identifier = std::move(device_identifier);
    }

    inline unsigned short getIndex() const {
        return this->index;
    }

    inline void setIndex(unsigned short index) {
        this->index = index;
    }

    inline float getSensitivity() const {
        return this->sensitivity;
    }

    inline void setSensitivity(float sensitivity) {
        this->sensitivity = sensitivity;
    }

    inline bool getInvert() const {
        return this->invert;
    }

    inline void setInvert(bool invert) {
        this->invert = invert;
    }

    inline float getLastState() const {
        return this->last_state;
    }

    inline void setLastState(float last_state) {
        this->last_state = last_state;
    }
};
