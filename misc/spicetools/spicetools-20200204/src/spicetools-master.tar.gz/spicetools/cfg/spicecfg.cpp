#include "spicecfg.h"

#include <memory>

#include <windows.h>

// Workaround MSVC issue with C++ with COBJMACROS defined
#ifdef COBJMACROS
#undef COBJMACROS
#define COBJMACROS_RESTORE
#endif

#include <shlwapi.h>

#ifdef COBJMACROS_RESTORE
#undef COBJMACROS_RESTORE
#define COBJMACROS
#endif

#include "launcher/launcher.h"
#include "launcher/logger.h"
#include "launcher/signal.h"
#include "launcher/options.h"
#include "util/crypt.h"
#include "util/libutils.h"
#include "rawinput/rawinput.h"

#include "config.h"
#include "configurator.h"

static bool USE_CONSOLE = false;

int spicecfg_run(const std::vector<std::string> &sextet_devices) {

    // initialize console
    if (USE_CONSOLE) {
        AllocConsole();
        freopen("conin$", "r", stdin);
        freopen("conout$", "w", stdout);
        freopen("conout$", "w", stderr);
    }

    // initialize config
    auto &config = Config::getInstance();
    if (!config.getStatus()) {
        return EXIT_FAILURE;
    }

    // initialize input
    RI_MGR = std::make_unique<rawinput::RawInputManager>();
    RI_MGR->devices_print();
    for (const auto &device : sextet_devices) {
        RI_MGR->sextet_register(device);
    }

    // run configurator
    cfg::CONFIGURATOR_STANDALONE = true;
    cfg::Configurator configurator;
    configurator.run();

    // success
    return 0;
}

#ifdef SPICETOOLS_SPICECFG_STANDALONE
#ifdef _MSC_VER
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR lpCmdLine, int nCmdShow) {
#else
int main(int argc, char *argv[]) {
#endif

    // register exception handler and control handler
    launcher::signal::init();

    // start logger
    logger::start();

    // get module path
    MODULE_PATH = libutils::module_file_name(nullptr).parent_path();

    // initialize crypt
    crypt::init();

    // parse arguments
#ifdef _MSC_VER
    LAUNCHER_OPTIONS = std::move(launcher::parse_options(__argc, __argv));
#else
    LAUNCHER_OPTIONS = std::move(launcher::parse_options(argc, argv));
#endif

    // run configurator
    return spicecfg_run(std::vector<std::string>());
}
#endif
