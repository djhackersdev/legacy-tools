#pragma once

#define MAINICON 20
