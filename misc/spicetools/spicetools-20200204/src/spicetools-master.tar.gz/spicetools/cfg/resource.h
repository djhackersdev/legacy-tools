#pragma once

#define IDR_CHANGELOG                   130
#define IDR_LICENSES                    131
#define IDR_PATCHES                     132
#define IDR_README                      133
