#pragma once

#include <vector>
#include <string>

int spicecfg_run(const std::vector<std::string> &sextet_devices);
