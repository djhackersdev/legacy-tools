#include "analog.h"

#include "rawinput/rawinput.h"
#include "util/logging.h"
#include "util/utils.h"

std::string Analog::getDisplayString(rawinput::RawInputManager *manager) {

    // device must be existing
    if (this->device_identifier.empty()) {
        return "";
    }

    // get index string
    auto index = this->getIndex();
    std::string indexString = fmt::format("{:#x}", index);

    // get device
    auto device = manager->devices_get(this->device_identifier);
    if (!device) {
        return "Device missing (" + indexString + ")";
    }

    // return string based on device type
    switch (device->type) {
        case rawinput::MOUSE:
            return std::string(index > 0 ? "Y" : "X") + " (" + device->desc + ")";
        case rawinput::HID: {
            auto hid = device->hidInfo;
            if (index < hid->value_caps_names.size()) {
                return hid->value_caps_names[index] + " (" + device->desc + ")";
            }
            return "Invalid Axis (" + indexString + ")";
        }
        case rawinput::MIDI: {
            auto midi = device->midiInfo;
            if (index < midi->controls_precision.size()) {
                return "MIDI PREC " + indexString + " (" + device->desc + ")";
            } else if (index < midi->controls_precision.size() + midi->controls_single.size()) {
                return "MIDI CTRL " + indexString + " (" + device->desc + ")";
            } else if (index < midi->controls_precision.size() + midi->controls_single.size()
                                                               + midi->controls_onoff.size())
            {
                return "MIDI ONOFF " + indexString + " (" + device->desc + ")";
            } else if (index == midi->controls_precision.size() + midi->controls_single.size()
                                                                + midi->controls_onoff.size())
            {
                return "MIDI Pitch Bend (" + device->desc + ")";
            } else {
                return "MIDI Unknown " + indexString + " (" + device->desc + ")";
            }
        }
        case rawinput::DESTROYED:
            return "Device unplugged (" + indexString + ")";
        default:
            return "Unknown Axis (" + indexString + ")";
    }
}
