#pragma once

#include <string>

namespace smartea {

    bool check_url(std::string url);
}
