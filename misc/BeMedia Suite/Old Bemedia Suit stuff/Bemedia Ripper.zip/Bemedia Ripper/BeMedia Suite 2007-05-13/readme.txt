***************************************************************
** BeMedia Suite 1                                           **
** SaxxonPike 2oo7                              May 13, 2007 **
***************************************************************

  This ripper is gaining functionality very quickly with both
early Bemani games as well as the newest CS releases. It's also
going through some cosmetic evolution (mainly to be more user-
friendly.) With so many options and such complexity, I don't
believe a simple command line tool is the end-all, be-all
solution. So everything in the BeMedia suite will remain as a
GUI application. (Sorry Linux guys, this isn't C, so you
won't get a port unless someone out there feels like porting
~5000 lines of VB6 code.) With all these updates being so
segregated and all, I figured it would be much easier on
everyone just to do this.

  If you're questionable about the legality of these programs,
there's no need to worry. The programs themselves are legal--
though the material that gets ripped is copyrighted. But if you
couldn't care less, well... have fun constructing/releasing
simfile sets. It only gets more automated with time. But don't
complain to me if anyone you don't know comes knocking on your
door because of what you did with these utilities. (I doubt
they'd care anyway, but that's just to save my ass.)

  Just so you know, you are using these programs at your own
risk. In the (highly unlikely) event that one of these programs
should malfunction and screw up your machine, break your combo,
ruin your life because of all the IIDX awesomeness, date your
girlfriend, or otherwise disrupt the normal operation of your
life, computer and/or household pets, just remember the above
statement. I'm not responsible for it.

What utilities do we have here? *******************************
  * Bemani2BMS            v3.3.2
  * BeMedia Ripper        v2.1.12
  * OJN2BMS               v1.0
  * Prefixer              v1.0
  * WaveCombiner          v1.0

As for the other files (you will need them):
  * BeMedia2.dll          v1.0
  * output.txt
  * songDB.txt

The "songDB.txt" and "output.txt" files are editable databases
for song names, artists, and genres. They are tab-separated and
will hurt your eyes. But if you've got any fixes, don't hesi-
tate to notify me so they can be added for the next version.

What are these utilities used for? ****************************

  - Bemani2BMS converts simfiles from their official formats
into BME (BMS-compatible) files.

  - BeMedia Ripper is the ultimate Bemani media ripper. It
can rip raw/vag format-audio and vob-format video (DVD). In
addition, if you feed it the game's executable file, the media
can be automatically named. This is very useful when creating
simfile sets.

  - OJN2BMS converts a OJM/OJN set to a BME file. If you use
a simulator that is compatible with freeze notes, those can
be converted as well, provided the simulator you use knows the
proper BML scripts.

  - Prefixer allows you to take a whole bunch of files and
add a filename prefix to them. This is useful when you want
to keep multiple keysound sets in a single folder. Though if
you prefix a whole bunch of keysounds, don't forget to make
the appropriate changes in the BME file.

  - WaveCombiner allows you to take two WAV files and combine
them into one. Its use is quite limited, since BeMedia Ripper
already does this for you. But it's included anyway. You may
find it handy sometime.

How do I use them? ********************************************

- BeMedia Ripper ----------------------------------------------

  There are many ways to fill in the (many) blanks in this
program. In fact, you don't even have to fill them all. Here
are the steps you'll take when ripping any game:

  1) select the game type you want to rip from
  2) select the file from which to rip from (source file)
  3) select the target folder to put the ripped stuff into
  4) *OPTIONAL* select the game's executable file for auto-
     naming - this is shown in red on the left side of the box,
     and you will also need to hit the checkbox to specify that
     you want to use it.
  5) Click Begin.

  Unlike previous versions of BeMedia, the target folder
doesn't even need to exist, as long as it is a valid path and
the program has privileges to create a folder there.
      
  You can also specify which types of media you want to rip
on the left side. There are KEYSOUNDS, BGM, VIDEO, and CS.
When keysounds are ripped, they are grouped up in folders that
are created (and named, if possible.) Background music tracks,
videos, and CS chart files are stored in the base folder.

  When ripping CS chart files, there is a specific way that the
files are named. They will be in this format:

  SONGNAME [MODE] (DIFFICULTY) b### k###

  SONGNAME is the name of the song. MODE specifies what mode
the song is: 7key, Light7, etc. DIFFICULTY specifies the
difficulty of the song. b### is the BGM track that this CS
file uses (for example if it says b244, you will use BGM track
number 1244 - note the added 1 on the left.) k### is the key-
sound folder that this CS file uses. It follows the same format
as the BGM track. Take note that not all files will use this
format. Ripped material from Pop'n Music will simply be called
"all.cs9" - this is because all the charts are grouped and
cannot be named by automated means. Twinkle and DJMain hardware
will rip as "@0.CS2" and so on.

  Videos are ripped in their native VOB format. This is the
only supported video format at this time. Future versions may
include IPU (and conversion of that to VOB, because they are
so similar.)

- Bemani2BMS --------------------------------------------------

  At first, this program may seem quite indimidating. But it's
quite unlikely you will use anything other than the TITLE,
ARTIST, GENRE, Input File(s), and Type&Alignment boxes. Here's
what you need to do in order to convert any kind of chart file:

  1) Down on the right by "Type & Alignment", select which
     format you will be converting. The ".CS (multi)" format
     has been phased out and only remains for backwards
     compatibility with memory rips I did in the past, and
     should not be used.

  Now, if you are converting charts ripped using BeMedia
Ripper, you're in luck! The song database information contained
in the "SongDB.txt" file can actually automatically fill in the
TITLE, ARTIST, and GENRE boxes for you. To set this up, right-
click the "** Fill **" button at the top by the Input File(s)
box. It should now read "(Auto-fill)". If you are converting
files from the ARCADE version of beatmaniaIIDX, the data will
instead be pulled from the Sound List file, which is specified
by the "Begin" button down below. Now, continue following
these steps:

  2) Drag all the files you want to convert into the Input
     File(s) box. Note that if you are converting Pop'n Music
     CS9 files or beatmaniaIIDX .1 arcade files, you can only
     convert one at a time.
  3) If you are not using the Auto-Fill feature, you'll need
     to put in the difficulties in the colored boxes. Leave
     them blank if you plan to do this yourself (as not all
     files are the same.)
  4) Select which Keysound Numbering you will be using. More
     often than not, you will want to select "BME (1-ZZ)".
     But for backwards compatibility, I've offered other
     numbering solutions if you are using audio files that
     are numbered differently than how BeMedia Ripper does it.
  5) Click Begin to start conversion.

  If you are using BeMedia Ripper to rip your chart files, the
mode and difficulty will automatically be pulled from the file
name, so you don't have to worry about entering them.

- OJN2BMS -----------------------------------------------------

  This is a simple utility. You feed it a OJN file, and it will
convert it to a BMS file. It will also rip out all the OGG
files from the OJM file (but conversion of these to WAV is up
to you.) If you want to convert freeze notes, the program will
also add the required BML scripting to accomidate that.

- Prefixer ----------------------------------------------------

  All this program does is add prefixes to filenames. First,
you feed it a bunch of files you want to add a prefix to. Next,
type in the prefix in the text box below and click Prefix.
Easy.

- WaveCombiner ------------------------------------------------

  This program simply takes two wave files and combines them.
As stated before, though, it has limited use as BeMedia Ripper
automatically does this for most split files. However, it could
potentially be useful to someone. It's included just for kicks.

Now to wrap things up *****************************************

  BeMedia has been a work-in-progress since early 2003. I'm
very proud of what I've done. It was inspired by the lack of
decent older-game simfiles. The ones that were available dis-
gusted me. So I started working with the only IIDX game I had
(thank you dial-up): beatmaniaIIDX 4th style. A very lackluster
game in terms of songlist quality. But 4th style was still
decent itself. 2 complete rewrites and 4 years later, the
project has come a long way. I still work on it because I love
to contribute to introducing beatmaniaIIDX to the US. I really
want to see an official US release of IIDX. Until then, the
only alternative that I have is to offer simfiles. But if the
simfiles aren't quality, they suck and they give the impression
that the game sucks. Which simply isn't true. There just needed
to be better quality simfiles. So this is written in dedication
to the communities that cherish IIDX (Sows especially, because
they actually care... sort of.)

  If you like what you see here, do us all a favor and go play
the game in the arcades, if there's one nearby. If you want a
decent US release just like I do, you'll have to make that
small sacrifice to show that you want it, and encourage others
to do the same. (Hell, it's not much of a sacrifice, 'cause
arcade controllers kick ass.)

  If you have any questions, you know where to find me. Until
then, enjoy.

  Dongs.

-Saxx