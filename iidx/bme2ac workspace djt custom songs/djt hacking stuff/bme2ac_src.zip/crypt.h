
//encrypt.h
//code for encrypting .2dx files with DistorteD's algorithm/key

//apparently konami's internal implementation of this doesn't do proper boundchecking and also doesn't zero its buffers, so there is some garbage left behind in the original files

//format of encrypted .2dx file:
//header:
//4 bytes: identifier ("%e12" in case of distorted)
//4 bytes: length of the decrypted .2dx file
//after this follows the encrypted data

byte cryptkey[8] = { 0xED, 0xF0, 0x9C, 0x90, 0x44, 0x1A, 0x5A, 0x03 }; //DistorteD'S encryption key

//XORs two 8 byte blocks
void block_xor(byte *data, byte *parm)
{
	int i;
	for (i = 0 ; i < 8 ; i++) 
		data[i] ^= parm[i];
	return;
}

//Swaps the lower 4 bytes with the upper 4 bytes
void block_swap(byte *data)
{
	int i;
	for (i = 0 ; i < 4 ; i++)
	{
		data[i]   ^= data[i+4]; //let's do this without temp variables ;D
		data[i+4] ^= data[i];
		data[i]   ^= data[i+4];
	}
	return;
}

//I bow to whoever figured this one out
void block_obfus(byte *data)
{
	byte a,b,c,d,e,f,g,h,i;

	a = data[0] * 63;
	b = a + data[3];
	c = data[1] * 17;
	d = c + data[2];
	e = d + b;
	f = e * data[3];
	g = f + b + 51;
	h = b ^ d;
	i = g ^ e;

	data[4] ^= h;
	data[5] ^= d;
	data[6] ^= i;
	data[7] ^= g;

	return;
}

//encrypts the .2dx file; this simply takes the reverse way from crack2dx.c by an unknown author (QQQ again, but HOLY SHIT that code is a mess (and buggy))
void encrypt_2dx()
{
	byte *cur; //current block of 8 bytes
	int enclen;

	int i;

	//actsize = twodxsize;
	enclen = twodxsize + 8; //length of the encoded 2dx = length of unencoded 2dx + headersize (8 bytes)
	tdx_enc = malloc(8 + twodxsize);

	memset(tdx_enc, 0, enclen); 
	memcpy(tdx_enc+8, tdx, twodxsize); //fill up the encoded array with unencoded stuff

	printf("encrypting .2dx file...\n");
	for(i = 8; i <= enclen - 8; i+=8) //encode in blocks of 8 bytes, start at byte 8 of data
	{
		cur = tdx_enc+i;

		//Step 1: XOR the current block with the encrypted previous block
		block_xor(cur, cur-8);

		//Step 2: Swap the lower and upper 4 bytes of the block
		block_swap(cur);

		//Step 3: Further obfuscation with XOR; the lower 4 bytes are untouched, so encrypting works the same as decrypting
		block_obfus(cur);

		//Step 4: XOR the block (yet again) with DistorteD's key
		block_xor(cur, cryptkey);
        }


	if(style == 0)
		memcpy(tdx_enc, "%hid", 4); //encryption identifier (Troopers)
	else
		memcpy(tdx_enc, "%e12", 4); //encryption identifier (GOLD and below)

	memcpy(tdx_enc+4, &twodxsize, 4); //write the length of the decoded 2dx file
	PNEWLINE;
	//printf("done\n");
}
