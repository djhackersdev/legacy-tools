//bme2ac.c by ryuuou
//takes a bunch of bms/bme files and produces .2dx and .1 files (hopefully) usable with beatmania iidx ac
//!!!WARNING!!! THIS WILL PROBABLY FAIL HORRIBLY ON 64BIT PLATFORMS!!! Then again it might just work

//still unsupported:
	//songs with missing wav files?
	//5keys charts; can AC even handle those?

//Changelog:
// v0.4
//	- speedups
//	- implemented #STOP events (_NOT_ #STP events!)
//	- fixed a potential problem with fractional bpm
//	- fixed a bug with file names that have '#' in them
//	- the measure line of the last measure wasn't written out correctly
//	- nixed decrypted.2dx; encrypted.2dx -> output.2dx
//	- songs now end 4 seconds after the end of the last measure
//	- added several tools:
//	  create2dx_new, crack2dx_new, timebase_single, encrypt2dx, merge1, parse1; with sources
// v0.3
//	- killed debug output
//	- standard events are now written after bpm corrections to avoid screwing with the end-song event
//	- keysound preload events are now dynamic and always placed between keys; this should fix wrong keysounds on fast repeats once and for all
// v0.2
//	- implemented bpm changes
//	- implemented changing measure sizes, this should fix a lot of offsync songs
// v0.1
//	- initial release


#include "common.h"

#include "bms.h"
#include "wav.h"
#include "2dx.h"
#include "crypt.h"
#include "1.h"

//initialize stuff, set things to zero etc.
void init()
{
	memset(bms, 0, sizeof(bmsfile)*CHARTCOUNT);
	memset(waves, 0, sizeof(WAVE)*MAXWAVS*CHARTCOUNT);
	
	memset(onecharts, 0, sizeof(event*)*CHARTCOUNT);

	wavcount = 0;
	wavlen = 0;
	onesize = 0;
	onefile = NULL;

	twodxsize = 0;

	style = 0; //standard = troopers
	factor = 1; //.1 events in ms
	return;
}

int main()
{
	init();

	printf("bme2ac v0.4 by ryuuou\n \
	Converts BME/BMS style files and WAVs into .1 and .2dx files\n\
	Suitable for use with beatmania IIDX TROOPERS AC _only_\n\n\n");

	if(!readbmsfiles())
	{
		printf("found no charts, aborting\n");
		getchar();
		return 1;
	}

	parsebms_wav();
	if(wavcount > 1000)
	{
		printf("You're trying to pack an excessive amount (>1000) of wav files into one .2dx file; Troopers might crash when attempting to load it.\n\
Please try and split your charts into different files.\npress enter to continue\n");
		getchar();
	}
	parsebms_bpm();
	parsebms_measures();
	parsebms_stops();
	create_wavtable();
	if(load_waves())
	{
		printf("!!!Several wave files failed to load, Troopers might crash!!!\npress enter to continue\n");
		getchar();
		//return 1;
	}

	convert_to_1_events();
	adjust_bpm();
	add_keysounds();
	cleanup_1();
	add_standard_events();
	add_stop_events();
	create_1();

	create_2dx();
	encrypt_2dx();

	writeout_1();
	writeout_2dx();

	printf("\nDone. Press enter to exit.\n");
	getchar();
	return 0;
}

