Dance Dance Revolution 5th Mix CS
    Data Bank DWI Collection
---------------------------------

Main program code written by Taren
MCS Extraction assisted by aaroninjapan.com message board crew.
Late July - Early September 2004

To add these songs to your collection, extract to your main simulator folder. The DWI files will reference a communal MP3 folder using the #FILE: tag if you have the FULL version. If you have the DIET version, you will not have an MP3 folder.

***WARNING: There are 3771 simfiles in this collection. At the time of writing this, DWI only supports up to 2048 songs. You do the math.

The artist names on the DWI tags have been replaced with the song's edit index, and backgrounds and banners have not been included, in order to save space.

The edit index is a three-digit number assigned to each file from Data Bank. The first digit is the block number (1 to 8), and the next two are the count- which position the file is in in that block. For example, B4U has about 15 edits per block, so the first edit listed under Block 1 will be "101"; the second, "102"; the tenth, "110"; etc. You can use these indexes to look up data in the HTML compilation page.

The HTML page containing info on all data is organized by song name, then by edit index. You will see artist name, comment, and difficulty information. The artist name appears in red if the edit is their ichioshi (top pick). 

Difficulty data is NOT standard to Data Bank; it was designed specially for this project. It is defined as follows:

V (Voltage)  : Peak density of steps (dependent on BPM)
A (Amplitude): Overall density of steps (dependent on BPM)
C (Chaos)    : Percentage of syncopated steps
J (Jump)     : Number of 2/3/4-arrow steps 
(yes, 3- and 4-arrow steps are possible on Solo edits using corner panels)

These are converted into "stars" and added up to give you an idea of how difficult the edit is. For reference:
6 stars = 8 feet or easy cata
7 stars = 9 feet or easy 10'
8 stars = 10 feet to bordering on impossible (by foot)
9 stars = hard-10 to impossible on feet, challenging on keyboard

Interesting facts- distribution of ratings is as follows:
9.0-9.9: 4
8.0-8.9: 45
7.0-7.9: 166
6.0-6.9: 614
5.0-5.9: 1291
4.0-4.9: 1095
3.0-3.9: 392
2.0-2.9: 96
1.0-1.9: 50
0.0-0.9: 18

If you want to put some of these edits on a memory card for use in a PS/PS2, look up the song and edit number in the HTML page, and look for the .MCS name in the right column. Search for that filename in the appropriate folder, and send to a Dexdrive/PSXMemTool. If you have one, you should know what to do from here.

Five-letter prefixes to songs are not consistent from block to block because the main program looked for a song's two-byte ID in the edit file instead.

Block 9, "ICHIOSHI" is not included because it is merely a collection of all the flashing-name edits from the other eight blocks.

About:
DDR 5th CS has an entry on the main menu called DATA BANK. It contains 3771 edits by fans for various songs from previous home versions. The home versions covered are:

1st     - 2nd       - 3rd
4th     - 5th*      - Club v1
Club v2 - Best Hits - Extra Mix

*Note: The only songs from 5th Mix in Data Bank are ones that have appeared in previous mixes, such as Dancing All Alone from 4th (as a trial song), and Dive, Broken my Heart, Remember You, and Afronova Primeval from Extra Mix. Dive deeper and more deep (Block 8) is the only exception to this rule being exclusive on 5th, however, the three edits for it are done by Naoki, Riyu, and Noria instead of fans. Songs like Matsuri Japan and Can't Stop Fallin' In Love Speed Mix debut on 5th, and will not appear in Data Bank. Songs that have not appeared on home versions, such as the Korean songs from 3rd Mix and Petit Love will not appear, either.

CS-premiere songs in Data Bank that debuted on DDR MAX (AC) are: Groove, Orion.78 (civilization Mix), Share My Love, and Midnite Blaze (all from 4th CS), and Groove 2001 (from Extra Mix).

Important Notes:
There are two serious typos in Data Bank: "20.Novermber(another version)" in Block 2, and "CLUB TOROPICANA" in Block 4.

Special thanks / Data Extraction: (in no particular order)
Deathrazor
Wolfman2000
billyjr82
SSGotenksUFO

Contact info:
Taren (Taren on AIJ forums)
AIM: x12x300x
email: furusato@insightbb.com
angelfire.com/ex/ddr1