=================================================================
   DDReditMAX2  The DDR(*) Step Editor

                             Version 3.60 beta1 (Release 351-90)
                                          (C) 2000 2010 TornadoX
 This is a FREE SOFTWARE with NO WARRANTY.
=================================================================

SUMMARY
-------
 DDReditMAX2 is a utility which can edit/display/print the steps
of "Dance Dance Revolution" and "Dancing Stage" series. It mainly
uses PSX memcard image to import/export the steps. Importing from
.BMS and exporting to StepMania(.sm) are also available.

*** The DDReditMAX2 Official Website ***
http://www.unzcopse.homeip.net/ddredit/index.php?DDReditMAX2
(Sorry, some contents are written in Japanese only.)


CHANGES FROM VERSION 3.51
-------------------------

* Main window is now extendable up to 5 measures
* A large bugfix about undo buffer
* Generate timings from BPM support

CHANGES FROM VERSION 3.50
-------------------------

* Bugfixes around auto-update
* StepMania(*.sm) converter for Timing editor
* Timings for 100+ songs


REQUIREMENTS
------------
* Windows 98/Me/2000/XP/Vista/7
* At least 640x480x16 display
* Visual Basic 6.0 runtime(SP6 or higher)
* Windows Media Player 6 or higher


LIST OF SUPPORTED BGM SOUND SOURCES
-----------------------------------
* Dance Dance Revolution(*)(CS JP)
* Dance Dance Revolution 2ndReMIX(*)(CS JP)
* Dance Dance Revolution 2ndReMIX APPEND CLUB VERSION vol.1(*)(CS JP)
* Dance Dance Revolution 2ndReMIX APPEND CLUB VERSION vol.2(*)(CS JP)
* Dance Dance Revolution 3rdMIX(*) ORIGINAL SOUNDTRACK
* Dance Dance Revolution 4thMIX(*) ORIGINAL SOUNDTRACK
* Dance Dance Revolution Solo 2000(*) ORIGINAL SOUNDTRACK
* Dance Dance Revolution 5thMIX(*) ORIGINAL SOUNDTRACK
* DDRMAX(*) ORIGINAL SOUNDTRACK
* DDRMAX2(*) ORIGINAL SOUNDTRACK
* Dance Dance Revolution EXTREME(*) ORIGINAL SOUNDTRACK
* Dance Dance Revolution Party Collection(*) ORIGINAL SOUNDTRACK
* DDR FESTIVAL(*) & Dance Dance Revolution STRIKE(*) ORIGINAL SOUNDTRACK
* Dance Dance Revolution SuperNOVA(*) Original Soundtrack
* Dance Dance Revolution SuperNOVA2(*) Original Soundtrack
* Dance Dance Revolution HOTTEST PARTY(*) Original Soundtrack
* DanceDanceRevolution X(*) & FullFull Party(*) Original Soundtrack

And MP3s from these CDs

(*)Each of the game titles are trademarks of Konami Digital Entertainment.


INSTALL
-------
* With a simple installer (an .exe, self-extract archive)
 Double-click on the installer and follow the instructions.
You can create Start menu icons automatically when you set the system
locale to Japanese. 

* Without installer (an .zip)
 Unzip all files, and then Double-click on OCXReg.bat. Registrations
of the external components are done by this.


ON THE FIRST RUN
----------------
 You probably like English better than Japanese, so choose English
in the first dialog and press OK. Then DDReM2 loads English locale.


CHANGELOG
---------
Please refer the official website for more changelogs.

09/28/2010 V3.60 beta1  Main window is now extendable up to 5 measures.
                        A large bugfix about undo buffer.
                        Supported generating timings from BPM.

07/04/2009 V3.51        Fixed some bugs around auto-update.
                        Added timings for 100+ songs.

05/03/2009 V3.50        Supported DS EuroMIX/EuroMIX2/Megamix/Fever/Fusion/
                        MAX(AC/CS), DDR MAX2/EXTREME/EXTREME2/SuperNOVA/
                        SuperNOVA2(AC/CS US/EU), and additional songs of
                        DDR X(AC JP).
                        Added "My Favorite" filter and "DnD copying of MP3"
                        features.
                        Many many many bugfixes.
                        Revised some of the interfaces.

03/02/2009 V3.30        Supported DDR X(CS/AC JP).
                        Added importing from mcrwwin/uLaunchElf feature.

03/10/2008 V3.20        Supported DDR SuperNOVA2(CS JP).

02/01/2007 V3.00        Official release
�@�@�@�@�@�@�@�@�@�@�@�@Supported DDR SuperNOVA(CS JP).
