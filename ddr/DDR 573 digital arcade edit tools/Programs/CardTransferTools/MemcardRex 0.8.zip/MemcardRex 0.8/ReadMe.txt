=================
 MemcardRex:
=================

Author: Shendo
Version 0.8
Compiled: 08/11/2008

================
 Requirements:
================

Windows XP or Vista. with .NET Framework 2.0 installed.

=========================
 About the MemcardRex:
=========================

MemcardRex is a PSX memory card explorer/editor.
The following memcard formats are supported:

    * ePSXe/PSEmu Pro Memory Card(*.mcr)
    * DexDrive Memory Card(*.gme)
    * pSX Memory Card(*.bin)
    * Bleem! Memory Card(*.mcd)
    * VGS Memory Card(*.mem, *.vgs)
    * PSXGame Edit Memory Card(*.mc)
    * DataDeck Memory Card(*.ddf)
    * WinPSM Memory Card(*.ps)
    * Smart Link Memory Card(*.psm)
    * MCExplorer(*.mci)
    * PSX PSP memory card(*.vmp) (opening only)

The following single save formats are supported:
    * PSXGame Edit single save(*.mcs)
    * XP, AR, GS, Caetla single save(*.psx)
    * Memory Juggler(*.ps1)
    * Smart Link(*.mcb)
    * Datel(*.mcx;*.pda)
    * RAW single saves
    * PS3 virtual saves (*.psv) (importing only)

=======================
 Agreement:
=======================

This program may not be modified or distributed in any other way than originally packaged.
The Author (Shendo) won't be held responsible if any harm is caused by using this program.
If you disagree with this DO NOT use MemcardRex.

=================================
 Changelog for the version 0.8:
=================================

* VMP format is supported once again (opening only) since some people were asking for it.
* PS3 virtual save format (*.psv) is now supported (importing only).
* RAW single save format is now supported (both importing and exporting).
* On startup first slot of both memorycards is now selected.
		- This will prevent errors with the save import function if user has not selected the slot to import to.

=================================
 Changelog for the version 0.7:
=================================

* Fixed error with the "format slot(s)" function (some data was not deleted after formatting).
* Fixed error with the "Paste from temp buffer" function (sometimes occupied slots were detected as free so pasted saves could overwrite existing ones).
* Added flipping and rotation options to icon editor.
* Added support for additional image formats when exporting the icon.
* Added support for XPlorer, Action Replay, GameShark, Caetla, Smart Link and Datel single saves.

=================================
 Changelog for the version 0.6:
=================================

* Memory Card open function rewritten, files should load a lot faster now.
* Fixed a small error when editing icon of the save on Memory Card 2.
* Old DexDrive cards (with missing slots) and the ones with corrupted header are now supported.
* Requirements have been dropped down to .NET Framework 2.0.
* Right click menu added per Hard core Rikki's suggestion.
* Added save cards prompt upon closing if memorycards have been edited.
* Added occupied slots indicator in save information dialog.

======================================
 Changelog for the version 0.5 rev 2:
======================================

* Fixed a major bug in the card formatting function.
* Fixed error with import save function for Memory Card 2.
* Fixed error with the grid line settings for Memory Card 2.
* Added command line support per RedawgTS's suggestion.
	- That means you can now associate memcards with MemcardRex to open them.

=================================
 Changelog for the version 0.5:
=================================

* Fixed error with the Shift JIS to ASCII conversion where 'b' character would come out as "bb".
* Added icon editor per TheCloudOfSmoke's suggestion.
* Added preferences dialog where user can change settings.
* Added support for Memory Juggler single saves.

=================================
 Changelog for the version 0.4:
=================================

Note: This version of MemcardRex was written from the scratch.

* Added comments support for dexdrive memory cards.
* Added toolstrip informations.
* Added support for simultaneous editing of 2 memory cards.
* Added support for dragging-and-dropping of memory card files.
* Saves can now be copied to the temp buffer and pasted to the selected card and slot.
* Double click on the selected item now shows a save information.
* Product code, Identifier and Region now shown in the list instead on the toolbar.
* Editing operations are now save based instead of the slot based like in older versions.
* Dropped support for .vmp cards until proper header reconstruction is possible.

=================================
 Changelog for the version 0.3b:
=================================

* New GUI.
* Added export/import single save function.

=================================
 Changelog for the version 0.2b:
=================================

* Fixed a small issue with the list refresh function.

=================================
 Changelog for the version 0.1b:
=================================

* Initial release.

============
 Thanks to:
============

* @ruantec.
* Cobalt.
* Gamesoul Master.
* TheCloudOfSmoke.
* RedawgTS.
* Hard core Rikki.
* RainMotorsports.
* Zieg.
* Bobbi.

==========
 Contact:
==========

To report a bug or make a suggestion please mail to:
Shendo@net.hr

(c) 2008 Shendo, All rights reserved.